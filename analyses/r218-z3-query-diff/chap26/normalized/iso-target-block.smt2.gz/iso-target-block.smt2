(push)
 (get-info :all-statistics)
 (declare-const sums! tuple%2.)
 (declare-const a! lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.)
 (declare-const tmp%1 Poly)
 (declare-const verus_tmp_input@ vstd!seq.Seq<usize.>.)
 (declare-const verus_tmp_spec_f@ %%Function%%)
 (declare-const tmp%2 Poly)
 (declare-const tmp%3 Poly)
 (declare-const tmp%4 Bool)
 (declare-const tmp%5 Bool)
 (declare-const tmp%6 Bool)
 (declare-const tmp%7 Bool)
 (declare-const tmp%8 Bool)
 (declare-const tmp%9 Poly)
 (declare-const total@ Int)
 (declare-const tmp%10 Poly)
 (declare-const tmp%11 Poly)
 (declare-const tmp%12 Poly)
 (declare-const tmp%13 Poly)
 (declare-const tmp%14 Int)
 (declare-const decrease%init0%0 Int)
 (declare-const tmp%15 Poly)
 (declare-const tmp%16 Poly)
 (declare-const tmp%17 Poly)
 (declare-const tmp%18 Poly)
 (declare-const tmp%19 Poly)
 (declare-const tmp%20 Poly)
 (declare-const tmp%21 Int)
 (declare-const decrease%init1%0 Int)
 (declare-const verus_tmp_left_input@ vstd!seq.Seq<usize.>.)
 (declare-const verus_tmp_right_input@ vstd!seq.Seq<usize.>.)
 (declare-const tmp%22 Bool)
 (declare-const tmp%23 Bool)
 (declare-const tmp%24 Bool)
 (declare-const r~1222 tuple%2.)
 (declare-const tmp%25 tuple%2.)
 (declare-const tmp%%7 anonymous_closure%C1.)
 (declare-const r~1325 tuple%2.)
 (declare-const tmp%26 tuple%2.)
 (declare-const tmp%%8 anonymous_closure%C2.)
 (declare-const verus_tmp_l_pref_view@ vstd!seq.Seq<usize.>.)
 (declare-const verus_tmp_r_pref_view@ vstd!seq.Seq<usize.>.)
 (declare-const tmp%27 Poly)
 (declare-const tmp%28 Poly)
 (declare-const verus_tmp_l_pv@ vstd!seq.Seq<usize.>.)
 (declare-const verus_tmp_r_pv@ vstd!seq.Seq<usize.>.)
 (declare-const r~1633 alloc!vec.Vec<usize./alloc!alloc.Global.>.)
 (declare-const tmp%29 Poly)
 (declare-const tmp%30 Poly)
 (declare-const tmp%31 Poly)
 (declare-const tmp%32 Poly)
 (declare-const tmp%33 Poly)
 (declare-const tmp%34 Int)
 (declare-const decrease%init2%0 Int)
 (declare-const ll@ Int)
 (declare-const v@0 alloc!vec.Vec<usize./alloc!alloc.Global.>.)
 (declare-const i$10@0 Int)
 (declare-const tmp%%19 anonymous_closure%C3.)
 (declare-const r~2121 alloc!vec.Vec<usize./alloc!alloc.Global.>.)
 (declare-const tmp%35 Poly)
 (declare-const tmp%36 Poly)
 (declare-const tmp%37 Poly)
 (declare-const tmp%38 Int)
 (declare-const tmp%39 Poly)
 (declare-const tmp%40 Poly)
 (declare-const tmp%41 Int)
 (declare-const val@ Int)
 (declare-const decrease%init3%0 Int)
 (declare-const rl@ Int)
 (declare-const v$1@0 alloc!vec.Vec<usize./alloc!alloc.Global.>.)
 (declare-const i$11@0 Int)
 (declare-const tmp%%29 anonymous_closure%C4.)
 (declare-const tmp%42 Poly)
 (declare-const tmp%43 Poly)
 (declare-const tmp%44 Poly)
 (declare-const tmp%45 Int)
 (declare-const decrease%init4%0 Int)
 (declare-const verus_tmp_result_view@ vstd!seq.Seq<usize.>.)
 (declare-const tmp%46 Bool)
 (declare-const tmp%47 Bool)
 (declare-const tmp%48 Bool)
 (declare-const tmp%49 Bool)
 (declare-const i$14@ Poly)
 (declare-const tmp%50 Bool)
 (declare-const tmp%51 Bool)
 (declare-const tmp%52 Bool)
 (declare-const tmp%53 Bool)
 (declare-const tmp%54 vstd!seq.Seq<usize.>.)
 (declare-const tmp%55 Bool)
 (declare-const tmp%56 Bool)
 (declare-const tmp%57 vstd!seq.Seq<usize.>.)
 (declare-const j@ Int)
 (declare-const rp@ vstd!seq.Seq<usize.>.)
 (declare-const n@ Int)
 (declare-const verus_tmp@0 vstd!seq.Seq<usize.>.)
 (declare-const input@0 vstd!seq.Seq<usize.>.)
 (declare-const verus_tmp$1@0 %%Function%%)
 (declare-const spec_f@0 %%Function%%)
 (declare-const mid@ Int)
 (declare-const left_vec@0 alloc!vec.Vec<usize./alloc!alloc.Global.>.)
 (declare-const i@0 Int)
 (declare-const left@ lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.)
 (declare-const right_len@ Int)
 (declare-const right_vec@0 alloc!vec.Vec<usize./alloc!alloc.Global.>.)
 (declare-const i$1@0 Int)
 (declare-const right@ lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.)
 (declare-const verus_tmp$2@0 vstd!seq.Seq<usize.>.)
 (declare-const left_input@0 vstd!seq.Seq<usize.>.)
 (declare-const verus_tmp$3@0 vstd!seq.Seq<usize.>.)
 (declare-const right_input@0 vstd!seq.Seq<usize.>.)
 (declare-const f1@ anonymous_closure%C1.)
 (declare-const f2@ anonymous_closure%C2.)
 (declare-const tmp%%$6@ tuple%2.)
 (declare-const left_result@ tuple%2.)
 (declare-const right_result@ tuple%2.)
 (declare-const l_prefixes@ lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.)
 (declare-const l_total@ Int)
 (declare-const r_prefixes@ lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.)
 (declare-const r_total@ Int)
 (declare-const verus_tmp$4@0 vstd!seq.Seq<usize.>.)
 (declare-const l_pref_view@0 vstd!seq.Seq<usize.>.)
 (declare-const verus_tmp$5@0 vstd!seq.Seq<usize.>.)
 (declare-const r_pref_view@0 vstd!seq.Seq<usize.>.)
 (declare-const l_len@ Int)
 (declare-const r_len@ Int)
 (declare-const verus_tmp$6@0 vstd!seq.Seq<usize.>.)
 (declare-const l_pv@0 vstd!seq.Seq<usize.>.)
 (declare-const verus_tmp$7@0 vstd!seq.Seq<usize.>.)
 (declare-const r_pv@0 vstd!seq.Seq<usize.>.)
 (declare-const lt@ Int)
 (declare-const copy_left@ anonymous_closure%C3.)
 (declare-const adjust_right@ anonymous_closure%C4.)
 (declare-const tmp%%$31@ tuple%2.)
 (declare-const left_part@ alloc!vec.Vec<usize./alloc!alloc.Global.>.)
 (declare-const right_part@ alloc!vec.Vec<usize./alloc!alloc.Global.>.)
 (declare-const result_vec@0 alloc!vec.Vec<usize./alloc!alloc.Global.>.)
 (declare-const i$12@0 Int)
 (declare-const total$1@ Int)
 (declare-const verus_tmp$8@0 vstd!seq.Seq<usize.>.)
 (declare-const result_view@0 vstd!seq.Seq<usize.>.)
 (declare-const result_prefixes@ lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.)
 (declare-const decrease%init0 Int)
 (assert
  fuel_defaults
 )
 (assert
  (has_type (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. a!) (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
    $ USIZE
 )))
 (assert
  (<= (%I (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_len.? $
     (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE) $ USIZE (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
      a!
    ))
   ) (- (uHi SZ) 1)
 ))
 (declare-const verus_tmp@1 vstd!seq.Seq<usize.>.)
 (declare-const input@1 vstd!seq.Seq<usize.>.)
 (declare-const verus_tmp$1@1 %%Function%%)
 (declare-const spec_f@1 %%Function%%)
 (declare-const left_vec@1 alloc!vec.Vec<usize./alloc!alloc.Global.>.)
 (declare-const i@1 Int)
 (declare-const right_vec@1 alloc!vec.Vec<usize./alloc!alloc.Global.>.)
 (declare-const i$1@1 Int)
 (declare-const verus_tmp$2@1 vstd!seq.Seq<usize.>.)
 (declare-const left_input@1 vstd!seq.Seq<usize.>.)
 (declare-const verus_tmp$3@1 vstd!seq.Seq<usize.>.)
 (declare-const right_input@1 vstd!seq.Seq<usize.>.)
 (declare-const verus_tmp$4@1 vstd!seq.Seq<usize.>.)
 (declare-const l_pref_view@1 vstd!seq.Seq<usize.>.)
 (declare-const verus_tmp$5@1 vstd!seq.Seq<usize.>.)
 (declare-const r_pref_view@1 vstd!seq.Seq<usize.>.)
 (declare-const verus_tmp$6@1 vstd!seq.Seq<usize.>.)
 (declare-const l_pv@1 vstd!seq.Seq<usize.>.)
 (declare-const verus_tmp$7@1 vstd!seq.Seq<usize.>.)
 (declare-const r_pv@1 vstd!seq.Seq<usize.>.)
 (declare-const v@1 alloc!vec.Vec<usize./alloc!alloc.Global.>.)
 (declare-const i$10@1 Int)
 (declare-const v$1@1 alloc!vec.Vec<usize./alloc!alloc.Global.>.)
 (declare-const i$11@1 Int)
 (declare-const result_vec@1 alloc!vec.Vec<usize./alloc!alloc.Global.>.)
 (declare-const i$12@1 Int)
 (declare-const verus_tmp$8@1 vstd!seq.Seq<usize.>.)
 (declare-const result_view@1 vstd!seq.Seq<usize.>.)
 (declare-const %%switch_label%%0 Bool)
 (declare-const %%switch_label%%1 Bool)
 (declare-const %%switch_label%%2 Bool)
 ;; postcondition not satisfied
 (declare-const %%location_label%%0 Bool)
 ;; precondition not satisfied
 (declare-const %%location_label%%1 Bool)
 ;; assertion failed
 (declare-const %%location_label%%2 Bool)
 ;; assertion failed
 (declare-const %%location_label%%3 Bool)
 ;; assertion failed
 (declare-const %%location_label%%4 Bool)
 ;; assertion failed
 (declare-const %%location_label%%5 Bool)
 ;; assertion failed
 (declare-const %%location_label%%6 Bool)
 ;; postcondition not satisfied
 (declare-const %%location_label%%7 Bool)
 ;; possible division by zero
 (declare-const %%location_label%%8 Bool)
 ;; invariant not satisfied before loop
 (declare-const %%location_label%%9 Bool)
 ;; invariant not satisfied before loop
 (declare-const %%location_label%%10 Bool)
 ;; invariant not satisfied before loop
 (declare-const %%location_label%%11 Bool)
 ;; invariant not satisfied before loop
 (declare-const %%location_label%%12 Bool)
 ;; invariant not satisfied before loop
 (declare-const %%location_label%%13 Bool)
 ;; possible arithmetic underflow/overflow
 (declare-const %%location_label%%14 Bool)
 ;; invariant not satisfied before loop
 (declare-const %%location_label%%15 Bool)
 ;; invariant not satisfied before loop
 (declare-const %%location_label%%16 Bool)
 ;; invariant not satisfied before loop
 (declare-const %%location_label%%17 Bool)
 ;; invariant not satisfied before loop
 (declare-const %%location_label%%18 Bool)
 ;; invariant not satisfied before loop
 (declare-const %%location_label%%19 Bool)
 ;; invariant not satisfied before loop
 (declare-const %%location_label%%20 Bool)
 ;; assertion failed
 (declare-const %%location_label%%21 Bool)
 ;; assertion failed
 (declare-const %%location_label%%22 Bool)
 ;; assertion failed
 (declare-const %%location_label%%23 Bool)
 ;; could not prove termination
 (declare-const %%location_label%%24 Bool)
 ;; precondition not satisfied
 (declare-const %%location_label%%25 Bool)
 ;; unable to prove post-condition of closure
 (declare-const %%location_label%%26 Bool)
 ;; could not prove termination
 (declare-const %%location_label%%27 Bool)
 ;; precondition not satisfied
 (declare-const %%location_label%%28 Bool)
 ;; unable to prove post-condition of closure
 (declare-const %%location_label%%29 Bool)
 ;; precondition not satisfied
 (declare-const %%location_label%%30 Bool)
 ;; invariant not satisfied before loop
 (declare-const %%location_label%%31 Bool)
 ;; invariant not satisfied before loop
 (declare-const %%location_label%%32 Bool)
 ;; invariant not satisfied before loop
 (declare-const %%location_label%%33 Bool)
 ;; invariant not satisfied before loop
 (declare-const %%location_label%%34 Bool)
 ;; invariant not satisfied before loop
 (declare-const %%location_label%%35 Bool)
 ;; invariant not satisfied before loop
 (declare-const %%location_label%%36 Bool)
 ;; unable to prove post-condition of closure
 (declare-const %%location_label%%37 Bool)
 ;; unable to prove post-condition of closure
 (declare-const %%location_label%%38 Bool)
 ;; invariant not satisfied before loop
 (declare-const %%location_label%%39 Bool)
 ;; invariant not satisfied before loop
 (declare-const %%location_label%%40 Bool)
 ;; invariant not satisfied before loop
 (declare-const %%location_label%%41 Bool)
 ;; invariant not satisfied before loop
 (declare-const %%location_label%%42 Bool)
 ;; invariant not satisfied before loop
 (declare-const %%location_label%%43 Bool)
 ;; invariant not satisfied before loop
 (declare-const %%location_label%%44 Bool)
 ;; unable to prove post-condition of closure
 (declare-const %%location_label%%45 Bool)
 ;; unable to prove post-condition of closure
 (declare-const %%location_label%%46 Bool)
 ;; precondition not satisfied
 (declare-const %%location_label%%47 Bool)
 ;; invariant not satisfied before loop
 (declare-const %%location_label%%48 Bool)
 ;; invariant not satisfied before loop
 (declare-const %%location_label%%49 Bool)
 ;; invariant not satisfied before loop
 (declare-const %%location_label%%50 Bool)
 ;; invariant not satisfied before loop
 (declare-const %%location_label%%51 Bool)
 ;; invariant not satisfied before loop
 (declare-const %%location_label%%52 Bool)
 ;; invariant not satisfied before loop
 (declare-const %%location_label%%53 Bool)
 ;; invariant not satisfied before loop
 (declare-const %%location_label%%54 Bool)
 ;; invariant not satisfied before loop
 (declare-const %%location_label%%55 Bool)
 ;; invariant not satisfied before loop
 (declare-const %%location_label%%56 Bool)
 ;; assertion failed
 (declare-const %%location_label%%57 Bool)
 ;; assertion failed
 (declare-const %%location_label%%58 Bool)
 ;; assertion failed
 (declare-const %%location_label%%59 Bool)
 ;; assertion failed
 (declare-const %%location_label%%60 Bool)
 ;; precondition not satisfied
 (declare-const %%location_label%%61 Bool)
 ;; precondition not satisfied
 (declare-const %%location_label%%62 Bool)
 ;; assertion failed
 (declare-const %%location_label%%63 Bool)
 ;; assertion failed
 (declare-const %%location_label%%64 Bool)
 ;; assertion failed
 (declare-const %%location_label%%65 Bool)
 ;; assertion failed
 (declare-const %%location_label%%66 Bool)
 ;; precondition not satisfied
 (declare-const %%location_label%%67 Bool)
 ;; assertion failed
 (declare-const %%location_label%%68 Bool)
 ;; assertion failed
 (declare-const %%location_label%%69 Bool)
 ;; precondition not satisfied
 (declare-const %%location_label%%70 Bool)
 ;; assertion failed
 (declare-const %%location_label%%71 Bool)
 ;; postcondition not satisfied
 (declare-const %%location_label%%72 Bool)
 (assert
  (not (=>
    (= decrease%init0 (%I (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_len.?
       $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE) $ USIZE (
        Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. a!
    ))))
    (=>
     (ens%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.length. $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
       $ USIZE
      ) $ USIZE (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. a!) tmp%1
     )
     (=>
      (= n@ (%I tmp%1))
      (=>
       (= verus_tmp@1 (%Poly%vstd!seq.Seq<usize.>. (vstd!seq.Seq.new.? $ USIZE (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_len.?
           $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE) $ USIZE (
            Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. a!
           )
          ) (Poly%fun%1. (mk_fun (%%lambda%%L $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
              $ USIZE
             ) $ USIZE (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. a!)
       ))))))
       (=>
        (= verus_tmp_input@ verus_tmp@1)
        (=>
         (= input@1 verus_tmp_input@)
         (=>
          (= verus_tmp$1@1 (lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_sum_fn.? (I 0)))
          (=>
           (= verus_tmp_spec_f@ verus_tmp$1@1)
           (=>
            (= spec_f@1 verus_tmp_spec_f@)
            (or
             (and
              (=>
               (= n@ 0)
               (=>
                (ens%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerRedefinableTrait.empty. $
                 (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE) $ USIZE tmp%2
                )
                (=>
                 (= sums! (tuple%2./tuple%2 tmp%2 (I 0)))
                 (=>
                  %%location_label%%0
                  (lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_scan_post.? (vstd!seq.Seq.new.? $ USIZE (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_len.?
                     $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE) $ USIZE (
                      Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. a!
                     )
                    ) (Poly%fun%1. (mk_fun (%%lambda%%L $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
                        $ USIZE
                       ) $ USIZE (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. a!)
                    )))
                   ) (Poly%fun%2. (lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_sum_fn.? (I 0))) (I 0) (vstd!seq.Seq.new.?
                    $ USIZE (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_len.?
                     $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE) $ USIZE (
                      tuple%2./tuple%2/0 (%Poly%tuple%2. (Poly%tuple%2. sums!))
                     )
                    ) (Poly%fun%1. (mk_fun (%%lambda%%L $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
                        $ USIZE
                       ) $ USIZE (tuple%2./tuple%2/0 (%Poly%tuple%2. (Poly%tuple%2. sums!)))
                    )))
                   ) (tuple%2./tuple%2/1 (%Poly%tuple%2. (Poly%tuple%2. sums!)))
              )))))
              (=>
               (not (= n@ 0))
               %%switch_label%%2
             ))
             (and
              (not %%switch_label%%2)
              (or
               (and
                (=>
                 (= n@ 1)
                 (and
                  (=>
                   %%location_label%%1
                   (req%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.nth. $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
                     $ USIZE
                    ) $ USIZE (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. a!) (I 0)
                  ))
                  (=>
                   (ens%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.nth. $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
                     $ USIZE
                    ) $ USIZE (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. a!) (I 0)
                    tmp%3
                   )
                   (=>
                    (ens%core!num.impl&%11.wrapping_add. (%I tmp%3) 0 total@)
                    (=>
                     (fuel_bool fuel%vstd!seq_lib.impl&%0.fold_left.)
                     (=>
                      (= tmp%4 (= (vstd!seq.Seq.len.? $ USIZE (Poly%vstd!seq.Seq<usize.>. input@1)) 1))
                      (and
                       (=>
                        %%location_label%%2
                        tmp%4
                       )
                       (=>
                        tmp%4
                        (=>
                         (= tmp%5 (ext_eq false (TYPE%vstd!seq.Seq. $ USIZE) (vstd!seq_lib.impl&%0.drop_last.?
                            $ USIZE (Poly%vstd!seq.Seq<usize.>. input@1)
                           ) (vstd!seq.Seq.empty.? $ USIZE)
                         ))
                         (and
                          (=>
                           %%location_label%%3
                           tmp%5
                          )
                          (=>
                           tmp%5
                           (=>
                            (= tmp%6 (= (%I (vstd!seq_lib.impl&%0.fold_left.? $ USIZE $ USIZE (vstd!seq.Seq.empty.?
                                 $ USIZE
                                ) (I (uClip SZ 0)) (Poly%fun%2. spec_f@1)
                               )
                              ) (uClip SZ 0)
                            ))
                            (and
                             (=>
                              %%location_label%%4
                              tmp%6
                             )
                             (=>
                              tmp%6
                              (=>
                               (= tmp%7 (= (vstd!seq_lib.impl&%0.fold_left.? $ USIZE $ USIZE (Poly%vstd!seq.Seq<usize.>.
                                   input@1
                                  ) (I (uClip SZ 0)) (Poly%fun%2. spec_f@1)
                                 ) (%%apply%%1 spec_f@1 (I (uClip SZ 0)) (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_index.?
                                   $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE) $ USIZE (
                                    Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. a!
                                   ) (I 0)
                               ))))
                               (and
                                (=>
                                 %%location_label%%5
                                 tmp%7
                                )
                                (=>
                                 tmp%7
                                 (=>
                                  (= tmp%8 (ext_eq false (TYPE%vstd!seq.Seq. $ USIZE) (vstd!seq.Seq.subrange.? $ USIZE
                                     (Poly%vstd!seq.Seq<usize.>. input@1) (I 0) (I 0)
                                    ) (vstd!seq.Seq.empty.? $ USIZE)
                                  ))
                                  (and
                                   (=>
                                    %%location_label%%6
                                    tmp%8
                                   )
                                   (=>
                                    tmp%8
                                    (=>
                                     (ens%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerRedefinableTrait.singleton.
                                      $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE) $ USIZE (
                                       I 0
                                      ) tmp%9
                                     )
                                     (=>
                                      (= sums! (tuple%2./tuple%2 tmp%9 (I total@)))
                                      (=>
                                       %%location_label%%7
                                       (lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_scan_post.? (vstd!seq.Seq.new.? $ USIZE (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_len.?
                                          $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE) $ USIZE (
                                           Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. a!
                                          )
                                         ) (Poly%fun%1. (mk_fun (%%lambda%%L $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
                                             $ USIZE
                                            ) $ USIZE (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. a!)
                                         )))
                                        ) (Poly%fun%2. (lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_sum_fn.? (I 0))) (I 0) (vstd!seq.Seq.new.?
                                         $ USIZE (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_len.?
                                          $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE) $ USIZE (
                                           tuple%2./tuple%2/0 (%Poly%tuple%2. (Poly%tuple%2. sums!))
                                          )
                                         ) (Poly%fun%1. (mk_fun (%%lambda%%L $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
                                             $ USIZE
                                            ) $ USIZE (tuple%2./tuple%2/0 (%Poly%tuple%2. (Poly%tuple%2. sums!)))
                                         )))
                                        ) (tuple%2./tuple%2/1 (%Poly%tuple%2. (Poly%tuple%2. sums!)))
                ))))))))))))))))))))))))
                (=>
                 (not (= n@ 1))
                 %%switch_label%%1
               ))
               (and
                (not %%switch_label%%1)
                (and
                 (=>
                  %%location_label%%8
                  (not (= 2 0))
                 )
                 (=>
                  (not (= 2 0))
                  (=>
                   (= mid@ (uClip SZ (EucDiv n@ 2)))
                   (=>
                    (ens%alloc!vec.impl&%0.with_capacity. $ USIZE mid@ tmp%10)
                    (=>
                     (= left_vec@0 (%Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. tmp%10))
                     (=>
                      (= i@0 0)
                      (and
                       (=>
                        %%location_label%%9
                        (<= i@0 mid@)
                       )
                       (and
                        (=>
                         %%location_label%%10
                         (<= mid@ n@)
                        )
                        (and
                         (=>
                          %%location_label%%11
                          (= n@ (%I (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_len.?
                             $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE) $ USIZE (
                              Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. a!
                         )))))
                         (and
                          (=>
                           %%location_label%%12
                           (= (vstd!seq.Seq.len.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ USIZE
                               $ TYPE%alloc!alloc.Global.
                              ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. left_vec@0)
                             )
                            ) i@0
                          ))
                          (and
                           (=>
                            %%location_label%%13
                            (forall ((j$ Poly)) (!
                              (=>
                               (has_type j$ INT)
                               (=>
                                (let
                                 ((tmp%%$ 0))
                                 (let
                                  ((tmp%%$1 (%I j$)))
                                  (let
                                   ((tmp%%$2 i@0))
                                   (and
                                    (<= tmp%%$ tmp%%$1)
                                    (< tmp%%$1 tmp%%$2)
                                ))))
                                (= (vstd!seq.Seq.index.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ USIZE
                                    $ TYPE%alloc!alloc.Global.
                                   ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. left_vec@0)
                                  ) j$
                                 ) (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_index.? $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
                                   $ USIZE
                                  ) $ USIZE (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. a!) j$
                              ))))
                              :pattern ((vstd!seq.Seq.index.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec.
                                  $ USIZE $ TYPE%alloc!alloc.Global.
                                 ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. left_vec@0)
                                ) j$
                              ))
                              :qid user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_0
                              :skolemid skolem_user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_0
                           )))
                           (=>
                            (uInv SZ i@1)
                            (=>
                             (<= i@1 mid@)
                             (=>
                              (<= mid@ n@)
                              (=>
                               (= n@ (%I (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_len.?
                                  $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE) $ USIZE (
                                   Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. a!
                               ))))
                               (=>
                                (= (vstd!seq.Seq.len.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ USIZE
                                    $ TYPE%alloc!alloc.Global.
                                   ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. left_vec@1)
                                  )
                                 ) i@1
                                )
                                (=>
                                 (forall ((j$ Poly)) (!
                                   (=>
                                    (has_type j$ INT)
                                    (=>
                                     (let
                                      ((tmp%%$ 0))
                                      (let
                                       ((tmp%%$1 (%I j$)))
                                       (let
                                        ((tmp%%$2 i@1))
                                        (and
                                         (<= tmp%%$ tmp%%$1)
                                         (< tmp%%$1 tmp%%$2)
                                     ))))
                                     (= (vstd!seq.Seq.index.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ USIZE
                                         $ TYPE%alloc!alloc.Global.
                                        ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. left_vec@1)
                                       ) j$
                                      ) (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_index.? $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
                                        $ USIZE
                                       ) $ USIZE (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. a!) j$
                                   ))))
                                   :pattern ((vstd!seq.Seq.index.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec.
                                       $ USIZE $ TYPE%alloc!alloc.Global.
                                      ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. left_vec@1)
                                     ) j$
                                   ))
                                   :qid user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_0
                                   :skolemid skolem_user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_0
                                 ))
                                 (=>
                                  (not (< i@1 mid@))
                                  (=>
                                   (= left@ (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS./ArraySeqMtPerS (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>.
                                      left_vec@1
                                   )))
                                   (=>
                                    (has_resolved $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE)
                                     (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. left@)
                                    )
                                    (and
                                     (=>
                                      %%location_label%%14
                                      (uInv SZ (Sub n@ mid@))
                                     )
                                     (=>
                                      (uInv SZ (Sub n@ mid@))
                                      (=>
                                       (= right_len@ (uClip SZ (Sub n@ mid@)))
                                       (=>
                                        (ens%alloc!vec.impl&%0.with_capacity. $ USIZE right_len@ tmp%15)
                                        (=>
                                         (= right_vec@0 (%Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. tmp%15))
                                         (=>
                                          (= i$1@0 0)
                                          (and
                                           (=>
                                            %%location_label%%15
                                            (<= i$1@0 right_len@)
                                           )
                                           (and
                                            (=>
                                             %%location_label%%16
                                             (= right_len@ (Sub n@ mid@))
                                            )
                                            (and
                                             (=>
                                              %%location_label%%17
                                              (<= mid@ n@)
                                             )
                                             (and
                                              (=>
                                               %%location_label%%18
                                               (= n@ (%I (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_len.?
                                                  $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE) $ USIZE (
                                                   Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. a!
                                              )))))
                                              (and
                                               (=>
                                                %%location_label%%19
                                                (= (vstd!seq.Seq.len.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ USIZE
                                                    $ TYPE%alloc!alloc.Global.
                                                   ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. right_vec@0)
                                                  )
                                                 ) i$1@0
                                               ))
                                               (and
                                                (=>
                                                 %%location_label%%20
                                                 (forall ((j$ Poly)) (!
                                                   (=>
                                                    (has_type j$ INT)
                                                    (=>
                                                     (let
                                                      ((tmp%%$ 0))
                                                      (let
                                                       ((tmp%%$4 (%I j$)))
                                                       (let
                                                        ((tmp%%$5 i$1@0))
                                                        (and
                                                         (<= tmp%%$ tmp%%$4)
                                                         (< tmp%%$4 tmp%%$5)
                                                     ))))
                                                     (= (vstd!seq.Seq.index.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ USIZE
                                                         $ TYPE%alloc!alloc.Global.
                                                        ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. right_vec@0)
                                                       ) j$
                                                      ) (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_index.? $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
                                                        $ USIZE
                                                       ) $ USIZE (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. a!) (I (Add
                                                         mid@ (%I j$)
                                                   ))))))
                                                   :pattern ((vstd!seq.Seq.index.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec.
                                                       $ USIZE $ TYPE%alloc!alloc.Global.
                                                      ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. right_vec@0)
                                                     ) j$
                                                   ))
                                                   :qid user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_1
                                                   :skolemid skolem_user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_1
                                                )))
                                                (=>
                                                 (uInv SZ i$1@1)
                                                 (=>
                                                  (<= i$1@1 right_len@)
                                                  (=>
                                                   (= right_len@ (Sub n@ mid@))
                                                   (=>
                                                    (<= mid@ n@)
                                                    (=>
                                                     (= n@ (%I (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_len.?
                                                        $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE) $ USIZE (
                                                         Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. a!
                                                     ))))
                                                     (=>
                                                      (= (vstd!seq.Seq.len.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ USIZE
                                                          $ TYPE%alloc!alloc.Global.
                                                         ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. right_vec@1)
                                                        )
                                                       ) i$1@1
                                                      )
                                                      (=>
                                                       (forall ((j$ Poly)) (!
                                                         (=>
                                                          (has_type j$ INT)
                                                          (=>
                                                           (let
                                                            ((tmp%%$ 0))
                                                            (let
                                                             ((tmp%%$4 (%I j$)))
                                                             (let
                                                              ((tmp%%$5 i$1@1))
                                                              (and
                                                               (<= tmp%%$ tmp%%$4)
                                                               (< tmp%%$4 tmp%%$5)
                                                           ))))
                                                           (= (vstd!seq.Seq.index.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ USIZE
                                                               $ TYPE%alloc!alloc.Global.
                                                              ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. right_vec@1)
                                                             ) j$
                                                            ) (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_index.? $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
                                                              $ USIZE
                                                             ) $ USIZE (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. a!) (I (Add
                                                               mid@ (%I j$)
                                                         ))))))
                                                         :pattern ((vstd!seq.Seq.index.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec.
                                                             $ USIZE $ TYPE%alloc!alloc.Global.
                                                            ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. right_vec@1)
                                                           ) j$
                                                         ))
                                                         :qid user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_1
                                                         :skolemid skolem_user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_1
                                                       ))
                                                       (=>
                                                        (has_resolved $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE)
                                                         (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. left@)
                                                        )
                                                        (=>
                                                         (not (< i$1@1 right_len@))
                                                         (=>
                                                          (has_resolved $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE)
                                                           (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. left@)
                                                          )
                                                          (=>
                                                           (= right@ (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS./ArraySeqMtPerS (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>.
                                                              right_vec@1
                                                           )))
                                                           (=>
                                                            (has_resolved $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE)
                                                             (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. right@)
                                                            )
                                                            (=>
                                                             (= verus_tmp$2@1 (%Poly%vstd!seq.Seq<usize.>. (vstd!seq.Seq.new.? $ USIZE (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_len.?
                                                                 $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE) $ USIZE (
                                                                  Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. left@
                                                                 )
                                                                ) (Poly%fun%1. (mk_fun (%%lambda%%L $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
                                                                    $ USIZE
                                                                   ) $ USIZE (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. left@)
                                                             ))))))
                                                             (=>
                                                              (= verus_tmp_left_input@ verus_tmp$2@1)
                                                              (=>
                                                               (= left_input@1 verus_tmp_left_input@)
                                                               (=>
                                                                (= verus_tmp$3@1 (%Poly%vstd!seq.Seq<usize.>. (vstd!seq.Seq.new.? $ USIZE (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_len.?
                                                                    $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE) $ USIZE (
                                                                     Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. right@
                                                                    )
                                                                   ) (Poly%fun%1. (mk_fun (%%lambda%%L $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
                                                                       $ USIZE
                                                                      ) $ USIZE (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. right@)
                                                                ))))))
                                                                (=>
                                                                 (= verus_tmp_right_input@ verus_tmp$3@1)
                                                                 (=>
                                                                  (= right_input@1 verus_tmp_right_input@)
                                                                  (=>
                                                                   (= tmp%22 (ext_eq false (TYPE%vstd!seq.Seq. $ USIZE) (Poly%vstd!seq.Seq<usize.>. left_input@1)
                                                                     (vstd!seq.Seq.subrange.? $ USIZE (Poly%vstd!seq.Seq<usize.>. input@1) (I 0) (I mid@))
                                                                   ))
                                                                   (and
                                                                    (=>
                                                                     %%location_label%%21
                                                                     tmp%22
                                                                    )
                                                                    (=>
                                                                     tmp%22
                                                                     (=>
                                                                      (= tmp%23 (ext_eq false (TYPE%vstd!seq.Seq. $ USIZE) (Poly%vstd!seq.Seq<usize.>. right_input@1)
                                                                        (vstd!seq.Seq.subrange.? $ USIZE (Poly%vstd!seq.Seq<usize.>. input@1) (I mid@) (I n@))
                                                                      ))
                                                                      (and
                                                                       (=>
                                                                        %%location_label%%22
                                                                        tmp%23
                                                                       )
                                                                       (=>
                                                                        tmp%23
                                                                        (=>
                                                                         (= tmp%24 (ext_eq false (TYPE%vstd!seq.Seq. $ USIZE) (vstd!seq.Seq.add.? $ USIZE (Poly%vstd!seq.Seq<usize.>.
                                                                             left_input@1
                                                                            ) (Poly%vstd!seq.Seq<usize.>. right_input@1)
                                                                           ) (Poly%vstd!seq.Seq<usize.>. input@1)
                                                                         ))
                                                                         (and
                                                                          (=>
                                                                           %%location_label%%23
                                                                           tmp%24
                                                                          )
                                                                          (=>
                                                                           tmp%24
                                                                           (and
                                                                            (and
                                                                             (=>
                                                                              %%location_label%%24
                                                                              (check_decrease_height (let
                                                                                ((a!$0 left@))
                                                                                (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_len.? $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
                                                                                  $ USIZE
                                                                                 ) $ USIZE (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. a!$0)
                                                                                )
                                                                               ) (I decrease%init0) false
                                                                             ))
                                                                             (and
                                                                              (=>
                                                                               %%location_label%%25
                                                                               (req%lib!Chap26.ScanDCMtPer.ScanDCMtPer.prefix_sums_dc_inner. left@)
                                                                              )
                                                                              (=>
                                                                               (ens%lib!Chap26.ScanDCMtPer.ScanDCMtPer.prefix_sums_dc_inner. left@ tmp%25)
                                                                               (=>
                                                                                (= r~1222 tmp%25)
                                                                                (=>
                                                                                 %%location_label%%26
                                                                                 (lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_scan_post.? (Poly%vstd!seq.Seq<usize.>. left_input@1)
                                                                                  (Poly%fun%2. (lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_sum_fn.? (I 0))) (I 0) (vstd!seq.Seq.new.?
                                                                                   $ USIZE (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_len.?
                                                                                    $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE) $ USIZE (
                                                                                     tuple%2./tuple%2/0 (%Poly%tuple%2. (Poly%tuple%2. r~1222))
                                                                                    )
                                                                                   ) (Poly%fun%1. (mk_fun (%%lambda%%L $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
                                                                                       $ USIZE
                                                                                      ) $ USIZE (tuple%2./tuple%2/0 (%Poly%tuple%2. (Poly%tuple%2. r~1222)))
                                                                                   )))
                                                                                  ) (tuple%2./tuple%2/1 (%Poly%tuple%2. (Poly%tuple%2. r~1222)))
                                                                            ))))))
                                                                            (=>
                                                                             (and
                                                                              (forall ((closure%$ Poly)) (!
                                                                                (=>
                                                                                 (has_type closure%$ TYPE%tuple%0.)
                                                                                 (closure_req TYPE%anonymous_closure%C1. $ TYPE%tuple%0. (Poly%anonymous_closure%C1.
                                                                                   tmp%%7
                                                                                  ) closure%$
                                                                                ))
                                                                                :pattern ((closure_req TYPE%anonymous_closure%C1. $ TYPE%tuple%0. (Poly%anonymous_closure%C1.
                                                                                   tmp%%7
                                                                                  ) closure%$
                                                                                ))
                                                                                :qid user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_2
                                                                                :skolemid skolem_user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_2
                                                                              ))
                                                                              (forall ((closure%$ Poly) (r$ Poly)) (!
                                                                                (=>
                                                                                 (and
                                                                                  (has_type closure%$ TYPE%tuple%0.)
                                                                                  (has_type r$ (TYPE%tuple%2. $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
                                                                                     $ USIZE
                                                                                    ) $ USIZE
                                                                                 )))
                                                                                 (=>
                                                                                  (closure_ens TYPE%anonymous_closure%C1. $ TYPE%tuple%0. (Poly%anonymous_closure%C1.
                                                                                    tmp%%7
                                                                                   ) closure%$ r$
                                                                                  )
                                                                                  (lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_scan_post.? (Poly%vstd!seq.Seq<usize.>. left_input@1)
                                                                                   (Poly%fun%2. (lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_sum_fn.? (I 0))) (I 0) (vstd!seq.Seq.new.?
                                                                                    $ USIZE (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_len.?
                                                                                     $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE) $ USIZE (
                                                                                      tuple%2./tuple%2/0 (%Poly%tuple%2. r$)
                                                                                     )
                                                                                    ) (Poly%fun%1. (mk_fun (%%lambda%%L $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
                                                                                        $ USIZE
                                                                                       ) $ USIZE (tuple%2./tuple%2/0 (%Poly%tuple%2. r$))
                                                                                    )))
                                                                                   ) (tuple%2./tuple%2/1 (%Poly%tuple%2. r$))
                                                                                )))
                                                                                :pattern ((closure_ens TYPE%anonymous_closure%C1. $ TYPE%tuple%0. (Poly%anonymous_closure%C1.
                                                                                   tmp%%7
                                                                                  ) closure%$ r$
                                                                                ))
                                                                                :qid user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_3
                                                                                :skolemid skolem_user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_3
                                                                             )))
                                                                             (=>
                                                                              (= f1@ tmp%%7)
                                                                              (and
                                                                               (and
                                                                                (=>
                                                                                 %%location_label%%27
                                                                                 (check_decrease_height (let
                                                                                   ((a!$0 right@))
                                                                                   (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_len.? $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
                                                                                     $ USIZE
                                                                                    ) $ USIZE (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. a!$0)
                                                                                   )
                                                                                  ) (I decrease%init0) false
                                                                                ))
                                                                                (and
                                                                                 (=>
                                                                                  %%location_label%%28
                                                                                  (req%lib!Chap26.ScanDCMtPer.ScanDCMtPer.prefix_sums_dc_inner. right@)
                                                                                 )
                                                                                 (=>
                                                                                  (ens%lib!Chap26.ScanDCMtPer.ScanDCMtPer.prefix_sums_dc_inner. right@ tmp%26)
                                                                                  (=>
                                                                                   (= r~1325 tmp%26)
                                                                                   (=>
                                                                                    %%location_label%%29
                                                                                    (lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_scan_post.? (Poly%vstd!seq.Seq<usize.>. right_input@1)
                                                                                     (Poly%fun%2. (lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_sum_fn.? (I 0))) (I 0) (vstd!seq.Seq.new.?
                                                                                      $ USIZE (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_len.?
                                                                                       $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE) $ USIZE (
                                                                                        tuple%2./tuple%2/0 (%Poly%tuple%2. (Poly%tuple%2. r~1325))
                                                                                       )
                                                                                      ) (Poly%fun%1. (mk_fun (%%lambda%%L $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
                                                                                          $ USIZE
                                                                                         ) $ USIZE (tuple%2./tuple%2/0 (%Poly%tuple%2. (Poly%tuple%2. r~1325)))
                                                                                      )))
                                                                                     ) (tuple%2./tuple%2/1 (%Poly%tuple%2. (Poly%tuple%2. r~1325)))
                                                                               ))))))
                                                                               (=>
                                                                                (and
                                                                                 (forall ((closure%$ Poly)) (!
                                                                                   (=>
                                                                                    (has_type closure%$ TYPE%tuple%0.)
                                                                                    (closure_req TYPE%anonymous_closure%C2. $ TYPE%tuple%0. (Poly%anonymous_closure%C2.
                                                                                      tmp%%8
                                                                                     ) closure%$
                                                                                   ))
                                                                                   :pattern ((closure_req TYPE%anonymous_closure%C2. $ TYPE%tuple%0. (Poly%anonymous_closure%C2.
                                                                                      tmp%%8
                                                                                     ) closure%$
                                                                                   ))
                                                                                   :qid user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_4
                                                                                   :skolemid skolem_user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_4
                                                                                 ))
                                                                                 (forall ((closure%$ Poly) (r$ Poly)) (!
                                                                                   (=>
                                                                                    (and
                                                                                     (has_type closure%$ TYPE%tuple%0.)
                                                                                     (has_type r$ (TYPE%tuple%2. $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
                                                                                        $ USIZE
                                                                                       ) $ USIZE
                                                                                    )))
                                                                                    (=>
                                                                                     (closure_ens TYPE%anonymous_closure%C2. $ TYPE%tuple%0. (Poly%anonymous_closure%C2.
                                                                                       tmp%%8
                                                                                      ) closure%$ r$
                                                                                     )
                                                                                     (lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_scan_post.? (Poly%vstd!seq.Seq<usize.>. right_input@1)
                                                                                      (Poly%fun%2. (lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_sum_fn.? (I 0))) (I 0) (vstd!seq.Seq.new.?
                                                                                       $ USIZE (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_len.?
                                                                                        $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE) $ USIZE (
                                                                                         tuple%2./tuple%2/0 (%Poly%tuple%2. r$)
                                                                                        )
                                                                                       ) (Poly%fun%1. (mk_fun (%%lambda%%L $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
                                                                                           $ USIZE
                                                                                          ) $ USIZE (tuple%2./tuple%2/0 (%Poly%tuple%2. r$))
                                                                                       )))
                                                                                      ) (tuple%2./tuple%2/1 (%Poly%tuple%2. r$))
                                                                                   )))
                                                                                   :pattern ((closure_ens TYPE%anonymous_closure%C2. $ TYPE%tuple%0. (Poly%anonymous_closure%C2.
                                                                                      tmp%%8
                                                                                     ) closure%$ r$
                                                                                   ))
                                                                                   :qid user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_5
                                                                                   :skolemid skolem_user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_5
                                                                                )))
                                                                                (=>
                                                                                 (= f2@ tmp%%8)
                                                                                 (and
                                                                                  (=>
                                                                                   %%location_label%%30
                                                                                   (req%lib!Chap02.HFSchedulerMtEph.HFSchedulerMtEph.join. (DST $) (TYPE%tuple%2. $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
                                                                                      $ USIZE
                                                                                     ) $ USIZE
                                                                                    ) (DST $) (TYPE%tuple%2. $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
                                                                                      $ USIZE
                                                                                     ) $ USIZE
                                                                                    ) $ TYPE%anonymous_closure%C1. $ TYPE%anonymous_closure%C2. (Poly%anonymous_closure%C1.
                                                                                     f1@
                                                                                    ) (Poly%anonymous_closure%C2. f2@)
                                                                                  ))
                                                                                  (=>
                                                                                   (ens%lib!Chap02.HFSchedulerMtEph.HFSchedulerMtEph.join. (DST $) (TYPE%tuple%2. $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
                                                                                      $ USIZE
                                                                                     ) $ USIZE
                                                                                    ) (DST $) (TYPE%tuple%2. $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
                                                                                      $ USIZE
                                                                                     ) $ USIZE
                                                                                    ) $ TYPE%anonymous_closure%C1. $ TYPE%anonymous_closure%C2. (Poly%anonymous_closure%C1.
                                                                                     f1@
                                                                                    ) (Poly%anonymous_closure%C2. f2@) tmp%%$6@
                                                                                   )
                                                                                   (=>
                                                                                    (= left_result@ (%Poly%tuple%2. (tuple%2./tuple%2/0 (%Poly%tuple%2. (Poly%tuple%2. tmp%%$6@)))))
                                                                                    (=>
                                                                                     (= right_result@ (%Poly%tuple%2. (tuple%2./tuple%2/1 (%Poly%tuple%2. (Poly%tuple%2. tmp%%$6@)))))
                                                                                     (=>
                                                                                      (= l_prefixes@ (%Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. (tuple%2./tuple%2/0
                                                                                         (%Poly%tuple%2. (Poly%tuple%2. left_result@))
                                                                                      )))
                                                                                      (=>
                                                                                       (= l_total@ (%I (tuple%2./tuple%2/1 (%Poly%tuple%2. (Poly%tuple%2. left_result@)))))
                                                                                       (=>
                                                                                        (has_resolved $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE)
                                                                                         (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. l_prefixes@)
                                                                                        )
                                                                                        (=>
                                                                                         (= r_prefixes@ (%Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. (tuple%2./tuple%2/0
                                                                                            (%Poly%tuple%2. (Poly%tuple%2. right_result@))
                                                                                         )))
                                                                                         (=>
                                                                                          (= r_total@ (%I (tuple%2./tuple%2/1 (%Poly%tuple%2. (Poly%tuple%2. right_result@)))))
                                                                                          (=>
                                                                                           (has_resolved $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE)
                                                                                            (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. r_prefixes@)
                                                                                           )
                                                                                           (=>
                                                                                            (= verus_tmp$4@1 (%Poly%vstd!seq.Seq<usize.>. (vstd!seq.Seq.new.? $ USIZE (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_len.?
                                                                                                $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE) $ USIZE (
                                                                                                 Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. l_prefixes@
                                                                                                )
                                                                                               ) (Poly%fun%1. (mk_fun (%%lambda%%L $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
                                                                                                   $ USIZE
                                                                                                  ) $ USIZE (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. l_prefixes@)
                                                                                            ))))))
                                                                                            (=>
                                                                                             (= verus_tmp_l_pref_view@ verus_tmp$4@1)
                                                                                             (=>
                                                                                              (= l_pref_view@1 verus_tmp_l_pref_view@)
                                                                                              (=>
                                                                                               (= verus_tmp$5@1 (%Poly%vstd!seq.Seq<usize.>. (vstd!seq.Seq.new.? $ USIZE (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_len.?
                                                                                                   $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE) $ USIZE (
                                                                                                    Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. r_prefixes@
                                                                                                   )
                                                                                                  ) (Poly%fun%1. (mk_fun (%%lambda%%L $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
                                                                                                      $ USIZE
                                                                                                     ) $ USIZE (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. r_prefixes@)
                                                                                               ))))))
                                                                                               (=>
                                                                                                (= verus_tmp_r_pref_view@ verus_tmp$5@1)
                                                                                                (=>
                                                                                                 (= r_pref_view@1 verus_tmp_r_pref_view@)
                                                                                                 (=>
                                                                                                  (ens%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.length. $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
                                                                                                    $ USIZE
                                                                                                   ) $ USIZE (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. l_prefixes@)
                                                                                                   tmp%27
                                                                                                  )
                                                                                                  (=>
                                                                                                   (= l_len@ (%I tmp%27))
                                                                                                   (=>
                                                                                                    (ens%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.length. $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
                                                                                                      $ USIZE
                                                                                                     ) $ USIZE (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. r_prefixes@)
                                                                                                     tmp%28
                                                                                                    )
                                                                                                    (=>
                                                                                                     (= r_len@ (%I tmp%28))
                                                                                                     (=>
                                                                                                      (= verus_tmp$6@1 l_pref_view@1)
                                                                                                      (=>
                                                                                                       (= verus_tmp_l_pv@ verus_tmp$6@1)
                                                                                                       (=>
                                                                                                        (= l_pv@1 verus_tmp_l_pv@)
                                                                                                        (=>
                                                                                                         (= verus_tmp$7@1 r_pref_view@1)
                                                                                                         (=>
                                                                                                          (= verus_tmp_r_pv@ verus_tmp$7@1)
                                                                                                          (=>
                                                                                                           (= r_pv@1 verus_tmp_r_pv@)
                                                                                                           (=>
                                                                                                            (= lt@ l_total@)
                                                                                                            (and
                                                                                                             (=>
                                                                                                              (ens%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.length. $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
                                                                                                                $ USIZE
                                                                                                               ) $ USIZE (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. l_prefixes@)
                                                                                                               tmp%29
                                                                                                              )
                                                                                                              (=>
                                                                                                               (= ll@ (%I tmp%29))
                                                                                                               (=>
                                                                                                                (ens%alloc!vec.impl&%0.with_capacity. $ USIZE ll@ tmp%30)
                                                                                                                (=>
                                                                                                                 (= v@0 (%Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. tmp%30))
                                                                                                                 (=>
                                                                                                                  (= i$10@0 0)
                                                                                                                  (and
                                                                                                                   (=>
                                                                                                                    %%location_label%%31
                                                                                                                    (<= i$10@0 ll@)
                                                                                                                   )
                                                                                                                   (and
                                                                                                                    (=>
                                                                                                                     %%location_label%%32
                                                                                                                     (= ll@ (%I (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_len.?
                                                                                                                        $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE) $ USIZE (
                                                                                                                         Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. l_prefixes@
                                                                                                                    )))))
                                                                                                                    (and
                                                                                                                     (=>
                                                                                                                      %%location_label%%33
                                                                                                                      (= (vstd!seq.Seq.len.? $ USIZE (Poly%vstd!seq.Seq<usize.>. l_pv@1)) ll@)
                                                                                                                     )
                                                                                                                     (and
                                                                                                                      (=>
                                                                                                                       %%location_label%%34
                                                                                                                       (= (vstd!seq.Seq.len.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ USIZE
                                                                                                                           $ TYPE%alloc!alloc.Global.
                                                                                                                          ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. v@0)
                                                                                                                         )
                                                                                                                        ) i$10@0
                                                                                                                      ))
                                                                                                                      (and
                                                                                                                       (=>
                                                                                                                        %%location_label%%35
                                                                                                                        (forall ((j$ Poly)) (!
                                                                                                                          (=>
                                                                                                                           (has_type j$ INT)
                                                                                                                           (=>
                                                                                                                            (let
                                                                                                                             ((tmp%%$10 0))
                                                                                                                             (let
                                                                                                                              ((tmp%%$11 (%I j$)))
                                                                                                                              (let
                                                                                                                               ((tmp%%$12 ll@))
                                                                                                                               (and
                                                                                                                                (<= tmp%%$10 tmp%%$11)
                                                                                                                                (< tmp%%$11 tmp%%$12)
                                                                                                                            ))))
                                                                                                                            (= (vstd!seq.Seq.index.? $ USIZE (Poly%vstd!seq.Seq<usize.>. l_pv@1) j$) (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_index.?
                                                                                                                              $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE) $ USIZE (
                                                                                                                               Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. l_prefixes@
                                                                                                                              ) j$
                                                                                                                          ))))
                                                                                                                          :pattern ((vstd!seq.Seq.index.? $ USIZE (Poly%vstd!seq.Seq<usize.>. l_pv@1) j$))
                                                                                                                          :qid user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_6
                                                                                                                          :skolemid skolem_user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_6
                                                                                                                       )))
                                                                                                                       (and
                                                                                                                        (=>
                                                                                                                         %%location_label%%36
                                                                                                                         (forall ((j$ Poly)) (!
                                                                                                                           (=>
                                                                                                                            (has_type j$ INT)
                                                                                                                            (=>
                                                                                                                             (let
                                                                                                                              ((tmp%%$13 0))
                                                                                                                              (let
                                                                                                                               ((tmp%%$14 (%I j$)))
                                                                                                                               (let
                                                                                                                                ((tmp%%$15 i$10@0))
                                                                                                                                (and
                                                                                                                                 (<= tmp%%$13 tmp%%$14)
                                                                                                                                 (< tmp%%$14 tmp%%$15)
                                                                                                                             ))))
                                                                                                                             (= (vstd!seq.Seq.index.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ USIZE
                                                                                                                                 $ TYPE%alloc!alloc.Global.
                                                                                                                                ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. v@0)
                                                                                                                               ) j$
                                                                                                                              ) (vstd!seq.Seq.index.? $ USIZE (Poly%vstd!seq.Seq<usize.>. l_pv@1) j$)
                                                                                                                           )))
                                                                                                                           :pattern ((vstd!seq.Seq.index.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec.
                                                                                                                               $ USIZE $ TYPE%alloc!alloc.Global.
                                                                                                                              ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. v@0)
                                                                                                                             ) j$
                                                                                                                           ))
                                                                                                                           :qid user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_7
                                                                                                                           :skolemid skolem_user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_7
                                                                                                                        )))
                                                                                                                        (=>
                                                                                                                         (uInv SZ i$10@1)
                                                                                                                         (=>
                                                                                                                          (<= i$10@1 ll@)
                                                                                                                          (=>
                                                                                                                           (= ll@ (%I (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_len.?
                                                                                                                              $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE) $ USIZE (
                                                                                                                               Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. l_prefixes@
                                                                                                                           ))))
                                                                                                                           (=>
                                                                                                                            (= (vstd!seq.Seq.len.? $ USIZE (Poly%vstd!seq.Seq<usize.>. l_pv@1)) ll@)
                                                                                                                            (=>
                                                                                                                             (= (vstd!seq.Seq.len.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ USIZE
                                                                                                                                 $ TYPE%alloc!alloc.Global.
                                                                                                                                ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. v@1)
                                                                                                                               )
                                                                                                                              ) i$10@1
                                                                                                                             )
                                                                                                                             (=>
                                                                                                                              (forall ((j$ Poly)) (!
                                                                                                                                (=>
                                                                                                                                 (has_type j$ INT)
                                                                                                                                 (=>
                                                                                                                                  (let
                                                                                                                                   ((tmp%%$10 0))
                                                                                                                                   (let
                                                                                                                                    ((tmp%%$11 (%I j$)))
                                                                                                                                    (let
                                                                                                                                     ((tmp%%$12 ll@))
                                                                                                                                     (and
                                                                                                                                      (<= tmp%%$10 tmp%%$11)
                                                                                                                                      (< tmp%%$11 tmp%%$12)
                                                                                                                                  ))))
                                                                                                                                  (= (vstd!seq.Seq.index.? $ USIZE (Poly%vstd!seq.Seq<usize.>. l_pv@1) j$) (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_index.?
                                                                                                                                    $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE) $ USIZE (
                                                                                                                                     Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. l_prefixes@
                                                                                                                                    ) j$
                                                                                                                                ))))
                                                                                                                                :pattern ((vstd!seq.Seq.index.? $ USIZE (Poly%vstd!seq.Seq<usize.>. l_pv@1) j$))
                                                                                                                                :qid user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_6
                                                                                                                                :skolemid skolem_user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_6
                                                                                                                              ))
                                                                                                                              (=>
                                                                                                                               (forall ((j$ Poly)) (!
                                                                                                                                 (=>
                                                                                                                                  (has_type j$ INT)
                                                                                                                                  (=>
                                                                                                                                   (let
                                                                                                                                    ((tmp%%$13 0))
                                                                                                                                    (let
                                                                                                                                     ((tmp%%$14 (%I j$)))
                                                                                                                                     (let
                                                                                                                                      ((tmp%%$15 i$10@1))
                                                                                                                                      (and
                                                                                                                                       (<= tmp%%$13 tmp%%$14)
                                                                                                                                       (< tmp%%$14 tmp%%$15)
                                                                                                                                   ))))
                                                                                                                                   (= (vstd!seq.Seq.index.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ USIZE
                                                                                                                                       $ TYPE%alloc!alloc.Global.
                                                                                                                                      ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. v@1)
                                                                                                                                     ) j$
                                                                                                                                    ) (vstd!seq.Seq.index.? $ USIZE (Poly%vstd!seq.Seq<usize.>. l_pv@1) j$)
                                                                                                                                 )))
                                                                                                                                 :pattern ((vstd!seq.Seq.index.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec.
                                                                                                                                     $ USIZE $ TYPE%alloc!alloc.Global.
                                                                                                                                    ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. v@1)
                                                                                                                                   ) j$
                                                                                                                                 ))
                                                                                                                                 :qid user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_7
                                                                                                                                 :skolemid skolem_user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_7
                                                                                                                               ))
                                                                                                                               (=>
                                                                                                                                (not (< i$10@1 ll@))
                                                                                                                                (=>
                                                                                                                                 (= r~1633 v@1)
                                                                                                                                 (and
                                                                                                                                  (=>
                                                                                                                                   %%location_label%%37
                                                                                                                                   (= (vstd!seq.Seq.len.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ USIZE
                                                                                                                                       $ TYPE%alloc!alloc.Global.
                                                                                                                                      ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. r~1633)
                                                                                                                                     )
                                                                                                                                    ) (vstd!seq.Seq.len.? $ USIZE (Poly%vstd!seq.Seq<usize.>. l_pv@1))
                                                                                                                                  ))
                                                                                                                                  (=>
                                                                                                                                   %%location_label%%38
                                                                                                                                   (forall ((j$ Poly)) (!
                                                                                                                                     (=>
                                                                                                                                      (has_type j$ INT)
                                                                                                                                      (=>
                                                                                                                                       (let
                                                                                                                                        ((tmp%%$7 0))
                                                                                                                                        (let
                                                                                                                                         ((tmp%%$8 (%I j$)))
                                                                                                                                         (let
                                                                                                                                          ((tmp%%$9 (vstd!seq.Seq.len.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $
                                                                                                                                               USIZE $ TYPE%alloc!alloc.Global.
                                                                                                                                              ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. r~1633)
                                                                                                                                          ))))
                                                                                                                                          (and
                                                                                                                                           (<= tmp%%$7 tmp%%$8)
                                                                                                                                           (< tmp%%$8 tmp%%$9)
                                                                                                                                       ))))
                                                                                                                                       (= (vstd!seq.Seq.index.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ USIZE
                                                                                                                                           $ TYPE%alloc!alloc.Global.
                                                                                                                                          ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. r~1633)
                                                                                                                                         ) j$
                                                                                                                                        ) (vstd!seq.Seq.index.? $ USIZE (Poly%vstd!seq.Seq<usize.>. l_pv@1) j$)
                                                                                                                                     )))
                                                                                                                                     :pattern ((vstd!seq.Seq.index.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec.
                                                                                                                                         $ USIZE $ TYPE%alloc!alloc.Global.
                                                                                                                                        ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. r~1633)
                                                                                                                                       ) j$
                                                                                                                                     ))
                                                                                                                                     :qid user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_8
                                                                                                                                     :skolemid skolem_user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_8
                                                                                                             ))))))))))))))))))))))))
                                                                                                             (=>
                                                                                                              (and
                                                                                                               (forall ((closure%$ Poly)) (!
                                                                                                                 (=>
                                                                                                                  (has_type closure%$ TYPE%tuple%0.)
                                                                                                                  (closure_req TYPE%anonymous_closure%C3. $ TYPE%tuple%0. (Poly%anonymous_closure%C3.
                                                                                                                    tmp%%19
                                                                                                                   ) closure%$
                                                                                                                 ))
                                                                                                                 :pattern ((closure_req TYPE%anonymous_closure%C3. $ TYPE%tuple%0. (Poly%anonymous_closure%C3.
                                                                                                                    tmp%%19
                                                                                                                   ) closure%$
                                                                                                                 ))
                                                                                                                 :qid user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_9
                                                                                                                 :skolemid skolem_user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_9
                                                                                                               ))
                                                                                                               (forall ((closure%$ Poly) (r$ Poly)) (!
                                                                                                                 (=>
                                                                                                                  (and
                                                                                                                   (has_type closure%$ TYPE%tuple%0.)
                                                                                                                   (has_type r$ (TYPE%alloc!vec.Vec. $ USIZE $ TYPE%alloc!alloc.Global.))
                                                                                                                  )
                                                                                                                  (=>
                                                                                                                   (closure_ens TYPE%anonymous_closure%C3. $ TYPE%tuple%0. (Poly%anonymous_closure%C3.
                                                                                                                     tmp%%19
                                                                                                                    ) closure%$ r$
                                                                                                                   )
                                                                                                                   (and
                                                                                                                    (= (vstd!seq.Seq.len.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ USIZE
                                                                                                                        $ TYPE%alloc!alloc.Global.
                                                                                                                       ) r$
                                                                                                                      )
                                                                                                                     ) (vstd!seq.Seq.len.? $ USIZE (Poly%vstd!seq.Seq<usize.>. l_pv@1))
                                                                                                                    )
                                                                                                                    (forall ((j$ Poly)) (!
                                                                                                                      (=>
                                                                                                                       (has_type j$ INT)
                                                                                                                       (=>
                                                                                                                        (let
                                                                                                                         ((tmp%%$16 0))
                                                                                                                         (let
                                                                                                                          ((tmp%%$17 (%I j$)))
                                                                                                                          (let
                                                                                                                           ((tmp%%$18 (vstd!seq.Seq.len.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $
                                                                                                                                USIZE $ TYPE%alloc!alloc.Global.
                                                                                                                               ) r$
                                                                                                                           ))))
                                                                                                                           (and
                                                                                                                            (<= tmp%%$16 tmp%%$17)
                                                                                                                            (< tmp%%$17 tmp%%$18)
                                                                                                                        ))))
                                                                                                                        (= (vstd!seq.Seq.index.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ USIZE
                                                                                                                            $ TYPE%alloc!alloc.Global.
                                                                                                                           ) r$
                                                                                                                          ) j$
                                                                                                                         ) (vstd!seq.Seq.index.? $ USIZE (Poly%vstd!seq.Seq<usize.>. l_pv@1) j$)
                                                                                                                      )))
                                                                                                                      :pattern ((vstd!seq.Seq.index.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec.
                                                                                                                          $ USIZE $ TYPE%alloc!alloc.Global.
                                                                                                                         ) r$
                                                                                                                        ) j$
                                                                                                                      ))
                                                                                                                      :qid user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_10
                                                                                                                      :skolemid skolem_user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_10
                                                                                                                 )))))
                                                                                                                 :pattern ((closure_ens TYPE%anonymous_closure%C3. $ TYPE%tuple%0. (Poly%anonymous_closure%C3.
                                                                                                                    tmp%%19
                                                                                                                   ) closure%$ r$
                                                                                                                 ))
                                                                                                                 :qid user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_11
                                                                                                                 :skolemid skolem_user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_11
                                                                                                              )))
                                                                                                              (=>
                                                                                                               (= copy_left@ tmp%%19)
                                                                                                               (and
                                                                                                                (=>
                                                                                                                 (ens%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.length. $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
                                                                                                                   $ USIZE
                                                                                                                  ) $ USIZE (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. r_prefixes@)
                                                                                                                  tmp%35
                                                                                                                 )
                                                                                                                 (=>
                                                                                                                  (= rl@ (%I tmp%35))
                                                                                                                  (=>
                                                                                                                   (ens%alloc!vec.impl&%0.with_capacity. $ USIZE rl@ tmp%36)
                                                                                                                   (=>
                                                                                                                    (= v$1@0 (%Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. tmp%36))
                                                                                                                    (=>
                                                                                                                     (= i$11@0 0)
                                                                                                                     (and
                                                                                                                      (=>
                                                                                                                       %%location_label%%39
                                                                                                                       (<= i$11@0 rl@)
                                                                                                                      )
                                                                                                                      (and
                                                                                                                       (=>
                                                                                                                        %%location_label%%40
                                                                                                                        (= rl@ (%I (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_len.?
                                                                                                                           $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE) $ USIZE (
                                                                                                                            Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. r_prefixes@
                                                                                                                       )))))
                                                                                                                       (and
                                                                                                                        (=>
                                                                                                                         %%location_label%%41
                                                                                                                         (= (vstd!seq.Seq.len.? $ USIZE (Poly%vstd!seq.Seq<usize.>. r_pv@1)) rl@)
                                                                                                                        )
                                                                                                                        (and
                                                                                                                         (=>
                                                                                                                          %%location_label%%42
                                                                                                                          (= (vstd!seq.Seq.len.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ USIZE
                                                                                                                              $ TYPE%alloc!alloc.Global.
                                                                                                                             ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. v$1@0)
                                                                                                                            )
                                                                                                                           ) i$11@0
                                                                                                                         ))
                                                                                                                         (and
                                                                                                                          (=>
                                                                                                                           %%location_label%%43
                                                                                                                           (forall ((j$ Poly)) (!
                                                                                                                             (=>
                                                                                                                              (has_type j$ INT)
                                                                                                                              (=>
                                                                                                                               (let
                                                                                                                                ((tmp%%$22 0))
                                                                                                                                (let
                                                                                                                                 ((tmp%%$23 (%I j$)))
                                                                                                                                 (let
                                                                                                                                  ((tmp%%$24 rl@))
                                                                                                                                  (and
                                                                                                                                   (<= tmp%%$22 tmp%%$23)
                                                                                                                                   (< tmp%%$23 tmp%%$24)
                                                                                                                               ))))
                                                                                                                               (= (vstd!seq.Seq.index.? $ USIZE (Poly%vstd!seq.Seq<usize.>. r_pv@1) j$) (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_index.?
                                                                                                                                 $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE) $ USIZE (
                                                                                                                                  Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. r_prefixes@
                                                                                                                                 ) j$
                                                                                                                             ))))
                                                                                                                             :pattern ((vstd!seq.Seq.index.? $ USIZE (Poly%vstd!seq.Seq<usize.>. r_pv@1) j$))
                                                                                                                             :qid user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_12
                                                                                                                             :skolemid skolem_user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_12
                                                                                                                          )))
                                                                                                                          (and
                                                                                                                           (=>
                                                                                                                            %%location_label%%44
                                                                                                                            (forall ((j$ Poly)) (!
                                                                                                                              (=>
                                                                                                                               (has_type j$ INT)
                                                                                                                               (=>
                                                                                                                                (let
                                                                                                                                 ((tmp%%$25 0))
                                                                                                                                 (let
                                                                                                                                  ((tmp%%$26 (%I j$)))
                                                                                                                                  (let
                                                                                                                                   ((tmp%%$27 i$11@0))
                                                                                                                                   (and
                                                                                                                                    (<= tmp%%$25 tmp%%$26)
                                                                                                                                    (< tmp%%$26 tmp%%$27)
                                                                                                                                ))))
                                                                                                                                (= (%I (vstd!seq.Seq.index.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ USIZE
                                                                                                                                     $ TYPE%alloc!alloc.Global.
                                                                                                                                    ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. v$1@0)
                                                                                                                                   ) j$
                                                                                                                                  )
                                                                                                                                 ) (lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_wrapping_add.? (I lt@) (vstd!seq.Seq.index.?
                                                                                                                                   $ USIZE (Poly%vstd!seq.Seq<usize.>. r_pv@1) j$
                                                                                                                              )))))
                                                                                                                              :pattern ((vstd!seq.Seq.index.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec.
                                                                                                                                  $ USIZE $ TYPE%alloc!alloc.Global.
                                                                                                                                 ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. v$1@0)
                                                                                                                                ) j$
                                                                                                                              ))
                                                                                                                              :qid user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_13
                                                                                                                              :skolemid skolem_user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_13
                                                                                                                           )))
                                                                                                                           (=>
                                                                                                                            (uInv SZ i$11@1)
                                                                                                                            (=>
                                                                                                                             (<= i$11@1 rl@)
                                                                                                                             (=>
                                                                                                                              (= rl@ (%I (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_len.?
                                                                                                                                 $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE) $ USIZE (
                                                                                                                                  Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. r_prefixes@
                                                                                                                              ))))
                                                                                                                              (=>
                                                                                                                               (= (vstd!seq.Seq.len.? $ USIZE (Poly%vstd!seq.Seq<usize.>. r_pv@1)) rl@)
                                                                                                                               (=>
                                                                                                                                (= (vstd!seq.Seq.len.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ USIZE
                                                                                                                                    $ TYPE%alloc!alloc.Global.
                                                                                                                                   ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. v$1@1)
                                                                                                                                  )
                                                                                                                                 ) i$11@1
                                                                                                                                )
                                                                                                                                (=>
                                                                                                                                 (forall ((j$ Poly)) (!
                                                                                                                                   (=>
                                                                                                                                    (has_type j$ INT)
                                                                                                                                    (=>
                                                                                                                                     (let
                                                                                                                                      ((tmp%%$22 0))
                                                                                                                                      (let
                                                                                                                                       ((tmp%%$23 (%I j$)))
                                                                                                                                       (let
                                                                                                                                        ((tmp%%$24 rl@))
                                                                                                                                        (and
                                                                                                                                         (<= tmp%%$22 tmp%%$23)
                                                                                                                                         (< tmp%%$23 tmp%%$24)
                                                                                                                                     ))))
                                                                                                                                     (= (vstd!seq.Seq.index.? $ USIZE (Poly%vstd!seq.Seq<usize.>. r_pv@1) j$) (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_index.?
                                                                                                                                       $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE) $ USIZE (
                                                                                                                                        Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. r_prefixes@
                                                                                                                                       ) j$
                                                                                                                                   ))))
                                                                                                                                   :pattern ((vstd!seq.Seq.index.? $ USIZE (Poly%vstd!seq.Seq<usize.>. r_pv@1) j$))
                                                                                                                                   :qid user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_12
                                                                                                                                   :skolemid skolem_user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_12
                                                                                                                                 ))
                                                                                                                                 (=>
                                                                                                                                  (forall ((j$ Poly)) (!
                                                                                                                                    (=>
                                                                                                                                     (has_type j$ INT)
                                                                                                                                     (=>
                                                                                                                                      (let
                                                                                                                                       ((tmp%%$25 0))
                                                                                                                                       (let
                                                                                                                                        ((tmp%%$26 (%I j$)))
                                                                                                                                        (let
                                                                                                                                         ((tmp%%$27 i$11@1))
                                                                                                                                         (and
                                                                                                                                          (<= tmp%%$25 tmp%%$26)
                                                                                                                                          (< tmp%%$26 tmp%%$27)
                                                                                                                                      ))))
                                                                                                                                      (= (%I (vstd!seq.Seq.index.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ USIZE
                                                                                                                                           $ TYPE%alloc!alloc.Global.
                                                                                                                                          ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. v$1@1)
                                                                                                                                         ) j$
                                                                                                                                        )
                                                                                                                                       ) (lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_wrapping_add.? (I lt@) (vstd!seq.Seq.index.?
                                                                                                                                         $ USIZE (Poly%vstd!seq.Seq<usize.>. r_pv@1) j$
                                                                                                                                    )))))
                                                                                                                                    :pattern ((vstd!seq.Seq.index.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec.
                                                                                                                                        $ USIZE $ TYPE%alloc!alloc.Global.
                                                                                                                                       ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. v$1@1)
                                                                                                                                      ) j$
                                                                                                                                    ))
                                                                                                                                    :qid user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_13
                                                                                                                                    :skolemid skolem_user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_13
                                                                                                                                  ))
                                                                                                                                  (=>
                                                                                                                                   (not (< i$11@1 rl@))
                                                                                                                                   (=>
                                                                                                                                    (= r~2121 v$1@1)
                                                                                                                                    (and
                                                                                                                                     (=>
                                                                                                                                      %%location_label%%45
                                                                                                                                      (= (vstd!seq.Seq.len.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ USIZE
                                                                                                                                          $ TYPE%alloc!alloc.Global.
                                                                                                                                         ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. r~2121)
                                                                                                                                        )
                                                                                                                                       ) (vstd!seq.Seq.len.? $ USIZE (Poly%vstd!seq.Seq<usize.>. r_pv@1))
                                                                                                                                     ))
                                                                                                                                     (=>
                                                                                                                                      %%location_label%%46
                                                                                                                                      (forall ((j$ Poly)) (!
                                                                                                                                        (=>
                                                                                                                                         (has_type j$ INT)
                                                                                                                                         (=>
                                                                                                                                          (let
                                                                                                                                           ((tmp%%$19 0))
                                                                                                                                           (let
                                                                                                                                            ((tmp%%$20 (%I j$)))
                                                                                                                                            (let
                                                                                                                                             ((tmp%%$21 (vstd!seq.Seq.len.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $
                                                                                                                                                  USIZE $ TYPE%alloc!alloc.Global.
                                                                                                                                                 ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. r~2121)
                                                                                                                                             ))))
                                                                                                                                             (and
                                                                                                                                              (<= tmp%%$19 tmp%%$20)
                                                                                                                                              (< tmp%%$20 tmp%%$21)
                                                                                                                                          ))))
                                                                                                                                          (= (%I (vstd!seq.Seq.index.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ USIZE
                                                                                                                                               $ TYPE%alloc!alloc.Global.
                                                                                                                                              ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. r~2121)
                                                                                                                                             ) j$
                                                                                                                                            )
                                                                                                                                           ) (lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_wrapping_add.? (I l_total@) (vstd!seq.Seq.index.?
                                                                                                                                             $ USIZE (Poly%vstd!seq.Seq<usize.>. r_pv@1) j$
                                                                                                                                        )))))
                                                                                                                                        :pattern ((vstd!seq.Seq.index.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec.
                                                                                                                                            $ USIZE $ TYPE%alloc!alloc.Global.
                                                                                                                                           ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. r~2121)
                                                                                                                                          ) j$
                                                                                                                                        ))
                                                                                                                                        :qid user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_14
                                                                                                                                        :skolemid skolem_user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_14
                                                                                                                ))))))))))))))))))))))))
                                                                                                                (=>
                                                                                                                 (and
                                                                                                                  (forall ((closure%$ Poly)) (!
                                                                                                                    (=>
                                                                                                                     (has_type closure%$ TYPE%tuple%0.)
                                                                                                                     (closure_req TYPE%anonymous_closure%C4. $ TYPE%tuple%0. (Poly%anonymous_closure%C4.
                                                                                                                       tmp%%29
                                                                                                                      ) closure%$
                                                                                                                    ))
                                                                                                                    :pattern ((closure_req TYPE%anonymous_closure%C4. $ TYPE%tuple%0. (Poly%anonymous_closure%C4.
                                                                                                                       tmp%%29
                                                                                                                      ) closure%$
                                                                                                                    ))
                                                                                                                    :qid user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_15
                                                                                                                    :skolemid skolem_user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_15
                                                                                                                  ))
                                                                                                                  (forall ((closure%$ Poly) (r$ Poly)) (!
                                                                                                                    (=>
                                                                                                                     (and
                                                                                                                      (has_type closure%$ TYPE%tuple%0.)
                                                                                                                      (has_type r$ (TYPE%alloc!vec.Vec. $ USIZE $ TYPE%alloc!alloc.Global.))
                                                                                                                     )
                                                                                                                     (=>
                                                                                                                      (closure_ens TYPE%anonymous_closure%C4. $ TYPE%tuple%0. (Poly%anonymous_closure%C4.
                                                                                                                        tmp%%29
                                                                                                                       ) closure%$ r$
                                                                                                                      )
                                                                                                                      (and
                                                                                                                       (= (vstd!seq.Seq.len.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ USIZE
                                                                                                                           $ TYPE%alloc!alloc.Global.
                                                                                                                          ) r$
                                                                                                                         )
                                                                                                                        ) (vstd!seq.Seq.len.? $ USIZE (Poly%vstd!seq.Seq<usize.>. r_pv@1))
                                                                                                                       )
                                                                                                                       (forall ((j$ Poly)) (!
                                                                                                                         (=>
                                                                                                                          (has_type j$ INT)
                                                                                                                          (=>
                                                                                                                           (let
                                                                                                                            ((tmp%%$28 0))
                                                                                                                            (let
                                                                                                                             ((tmp%%$29 (%I j$)))
                                                                                                                             (let
                                                                                                                              ((tmp%%$30 (vstd!seq.Seq.len.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $
                                                                                                                                   USIZE $ TYPE%alloc!alloc.Global.
                                                                                                                                  ) r$
                                                                                                                              ))))
                                                                                                                              (and
                                                                                                                               (<= tmp%%$28 tmp%%$29)
                                                                                                                               (< tmp%%$29 tmp%%$30)
                                                                                                                           ))))
                                                                                                                           (= (%I (vstd!seq.Seq.index.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ USIZE
                                                                                                                                $ TYPE%alloc!alloc.Global.
                                                                                                                               ) r$
                                                                                                                              ) j$
                                                                                                                             )
                                                                                                                            ) (lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_wrapping_add.? (I l_total@) (vstd!seq.Seq.index.?
                                                                                                                              $ USIZE (Poly%vstd!seq.Seq<usize.>. r_pv@1) j$
                                                                                                                         )))))
                                                                                                                         :pattern ((vstd!seq.Seq.index.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec.
                                                                                                                             $ USIZE $ TYPE%alloc!alloc.Global.
                                                                                                                            ) r$
                                                                                                                           ) j$
                                                                                                                         ))
                                                                                                                         :qid user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_16
                                                                                                                         :skolemid skolem_user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_16
                                                                                                                    )))))
                                                                                                                    :pattern ((closure_ens TYPE%anonymous_closure%C4. $ TYPE%tuple%0. (Poly%anonymous_closure%C4.
                                                                                                                       tmp%%29
                                                                                                                      ) closure%$ r$
                                                                                                                    ))
                                                                                                                    :qid user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_17
                                                                                                                    :skolemid skolem_user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_17
                                                                                                                 )))
                                                                                                                 (=>
                                                                                                                  (= adjust_right@ tmp%%29)
                                                                                                                  (and
                                                                                                                   (=>
                                                                                                                    %%location_label%%47
                                                                                                                    (req%lib!Chap02.HFSchedulerMtEph.HFSchedulerMtEph.join. $ (TYPE%alloc!vec.Vec. $ USIZE
                                                                                                                      $ TYPE%alloc!alloc.Global.
                                                                                                                     ) $ (TYPE%alloc!vec.Vec. $ USIZE $ TYPE%alloc!alloc.Global.) $ TYPE%anonymous_closure%C3.
                                                                                                                     $ TYPE%anonymous_closure%C4. (Poly%anonymous_closure%C3. copy_left@) (Poly%anonymous_closure%C4.
                                                                                                                      adjust_right@
                                                                                                                   )))
                                                                                                                   (=>
                                                                                                                    (ens%lib!Chap02.HFSchedulerMtEph.HFSchedulerMtEph.join. $ (TYPE%alloc!vec.Vec. $ USIZE
                                                                                                                      $ TYPE%alloc!alloc.Global.
                                                                                                                     ) $ (TYPE%alloc!vec.Vec. $ USIZE $ TYPE%alloc!alloc.Global.) $ TYPE%anonymous_closure%C3.
                                                                                                                     $ TYPE%anonymous_closure%C4. (Poly%anonymous_closure%C3. copy_left@) (Poly%anonymous_closure%C4.
                                                                                                                      adjust_right@
                                                                                                                     ) tmp%%$31@
                                                                                                                    )
                                                                                                                    (=>
                                                                                                                     (= left_part@ (%Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. (tuple%2./tuple%2/0
                                                                                                                        (%Poly%tuple%2. (Poly%tuple%2. tmp%%$31@))
                                                                                                                     )))
                                                                                                                     (=>
                                                                                                                      (= right_part@ (%Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. (tuple%2./tuple%2/1
                                                                                                                         (%Poly%tuple%2. (Poly%tuple%2. tmp%%$31@))
                                                                                                                      )))
                                                                                                                      (=>
                                                                                                                       (has_resolved $ (TYPE%alloc!vec.Vec. $ USIZE $ TYPE%alloc!alloc.Global.) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>.
                                                                                                                         right_part@
                                                                                                                       ))
                                                                                                                       (=>
                                                                                                                        (= result_vec@0 left_part@)
                                                                                                                        (=>
                                                                                                                         (= i$12@0 0)
                                                                                                                         (and
                                                                                                                          (=>
                                                                                                                           %%location_label%%48
                                                                                                                           (<= i$12@0 r_len@)
                                                                                                                          )
                                                                                                                          (and
                                                                                                                           (=>
                                                                                                                            %%location_label%%49
                                                                                                                            (= r_len@ (vstd!seq.Seq.len.? $ USIZE (Poly%vstd!seq.Seq<usize.>. r_pref_view@1)))
                                                                                                                           )
                                                                                                                           (and
                                                                                                                            (=>
                                                                                                                             %%location_label%%50
                                                                                                                             (= l_len@ (vstd!seq.Seq.len.? $ USIZE (Poly%vstd!seq.Seq<usize.>. l_pref_view@1)))
                                                                                                                            )
                                                                                                                            (and
                                                                                                                             (=>
                                                                                                                              %%location_label%%51
                                                                                                                              (= l_len@ mid@)
                                                                                                                             )
                                                                                                                             (and
                                                                                                                              (=>
                                                                                                                               %%location_label%%52
                                                                                                                               (= (vstd!seq.Seq.len.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ USIZE
                                                                                                                                   $ TYPE%alloc!alloc.Global.
                                                                                                                                  ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. right_part@)
                                                                                                                                 )
                                                                                                                                ) r_len@
                                                                                                                              ))
                                                                                                                              (and
                                                                                                                               (=>
                                                                                                                                %%location_label%%53
                                                                                                                                (= (vstd!seq.Seq.len.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ USIZE
                                                                                                                                    $ TYPE%alloc!alloc.Global.
                                                                                                                                   ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. result_vec@0)
                                                                                                                                  )
                                                                                                                                 ) (Add l_len@ i$12@0)
                                                                                                                               ))
                                                                                                                               (and
                                                                                                                                (=>
                                                                                                                                 %%location_label%%54
                                                                                                                                 (forall ((j$ Poly)) (!
                                                                                                                                   (=>
                                                                                                                                    (has_type j$ INT)
                                                                                                                                    (=>
                                                                                                                                     (let
                                                                                                                                      ((tmp%%$32 0))
                                                                                                                                      (let
                                                                                                                                       ((tmp%%$33 (%I j$)))
                                                                                                                                       (let
                                                                                                                                        ((tmp%%$34 r_len@))
                                                                                                                                        (and
                                                                                                                                         (<= tmp%%$32 tmp%%$33)
                                                                                                                                         (< tmp%%$33 tmp%%$34)
                                                                                                                                     ))))
                                                                                                                                     (= (%I (vstd!seq.Seq.index.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ USIZE
                                                                                                                                          $ TYPE%alloc!alloc.Global.
                                                                                                                                         ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. right_part@)
                                                                                                                                        ) j$
                                                                                                                                       )
                                                                                                                                      ) (lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_wrapping_add.? (I l_total@) (vstd!seq.Seq.index.?
                                                                                                                                        $ USIZE (Poly%vstd!seq.Seq<usize.>. r_pref_view@1) j$
                                                                                                                                   )))))
                                                                                                                                   :pattern ((vstd!seq.Seq.index.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec.
                                                                                                                                       $ USIZE $ TYPE%alloc!alloc.Global.
                                                                                                                                      ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. right_part@)
                                                                                                                                     ) j$
                                                                                                                                   ))
                                                                                                                                   :qid user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_18
                                                                                                                                   :skolemid skolem_user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_18
                                                                                                                                )))
                                                                                                                                (and
                                                                                                                                 (=>
                                                                                                                                  %%location_label%%55
                                                                                                                                  (forall ((j$ Poly)) (!
                                                                                                                                    (=>
                                                                                                                                     (has_type j$ INT)
                                                                                                                                     (=>
                                                                                                                                      (let
                                                                                                                                       ((tmp%%$35 0))
                                                                                                                                       (let
                                                                                                                                        ((tmp%%$36 (%I j$)))
                                                                                                                                        (let
                                                                                                                                         ((tmp%%$37 l_len@))
                                                                                                                                         (and
                                                                                                                                          (<= tmp%%$35 tmp%%$36)
                                                                                                                                          (< tmp%%$36 tmp%%$37)
                                                                                                                                      ))))
                                                                                                                                      (= (vstd!seq.Seq.index.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ USIZE
                                                                                                                                          $ TYPE%alloc!alloc.Global.
                                                                                                                                         ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. result_vec@0)
                                                                                                                                        ) j$
                                                                                                                                       ) (vstd!seq.Seq.index.? $ USIZE (Poly%vstd!seq.Seq<usize.>. l_pref_view@1) j$)
                                                                                                                                    )))
                                                                                                                                    :pattern ((vstd!seq.Seq.index.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec.
                                                                                                                                        $ USIZE $ TYPE%alloc!alloc.Global.
                                                                                                                                       ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. result_vec@0)
                                                                                                                                      ) j$
                                                                                                                                    ))
                                                                                                                                    :qid user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_19
                                                                                                                                    :skolemid skolem_user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_19
                                                                                                                                 )))
                                                                                                                                 (and
                                                                                                                                  (=>
                                                                                                                                   %%location_label%%56
                                                                                                                                   (forall ((j$ Int)) (!
                                                                                                                                     (=>
                                                                                                                                      (let
                                                                                                                                       ((tmp%%$38 0))
                                                                                                                                       (let
                                                                                                                                        ((tmp%%$39 j$))
                                                                                                                                        (let
                                                                                                                                         ((tmp%%$40 i$12@0))
                                                                                                                                         (and
                                                                                                                                          (<= tmp%%$38 tmp%%$39)
                                                                                                                                          (< tmp%%$39 tmp%%$40)
                                                                                                                                      ))))
                                                                                                                                      (= (%I (vstd!seq.Seq.index.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ USIZE
                                                                                                                                           $ TYPE%alloc!alloc.Global.
                                                                                                                                          ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. result_vec@0)
                                                                                                                                         ) (I (Add l_len@ j$))
                                                                                                                                        )
                                                                                                                                       ) (lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_wrapping_add.? (I l_total@) (vstd!seq.Seq.index.?
                                                                                                                                         $ USIZE (Poly%vstd!seq.Seq<usize.>. r_pref_view@1) (I j$)
                                                                                                                                     ))))
                                                                                                                                     :pattern ((vstd!seq.Seq.index.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec.
                                                                                                                                         $ USIZE $ TYPE%alloc!alloc.Global.
                                                                                                                                        ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. result_vec@0)
                                                                                                                                       ) (I (Add l_len@ j$))
                                                                                                                                     ))
                                                                                                                                     :qid user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_20
                                                                                                                                     :skolemid skolem_user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_20
                                                                                                                                  )))
                                                                                                                                  (=>
                                                                                                                                   (uInv SZ i$12@1)
                                                                                                                                   (=>
                                                                                                                                    (<= i$12@1 r_len@)
                                                                                                                                    (=>
                                                                                                                                     (= r_len@ (vstd!seq.Seq.len.? $ USIZE (Poly%vstd!seq.Seq<usize.>. r_pref_view@1)))
                                                                                                                                     (=>
                                                                                                                                      (= l_len@ (vstd!seq.Seq.len.? $ USIZE (Poly%vstd!seq.Seq<usize.>. l_pref_view@1)))
                                                                                                                                      (=>
                                                                                                                                       (= l_len@ mid@)
                                                                                                                                       (=>
                                                                                                                                        (= (vstd!seq.Seq.len.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ USIZE
                                                                                                                                            $ TYPE%alloc!alloc.Global.
                                                                                                                                           ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. right_part@)
                                                                                                                                          )
                                                                                                                                         ) r_len@
                                                                                                                                        )
                                                                                                                                        (=>
                                                                                                                                         (= (vstd!seq.Seq.len.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ USIZE
                                                                                                                                             $ TYPE%alloc!alloc.Global.
                                                                                                                                            ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. result_vec@1)
                                                                                                                                           )
                                                                                                                                          ) (Add l_len@ i$12@1)
                                                                                                                                         )
                                                                                                                                         (=>
                                                                                                                                          (forall ((j$ Poly)) (!
                                                                                                                                            (=>
                                                                                                                                             (has_type j$ INT)
                                                                                                                                             (=>
                                                                                                                                              (let
                                                                                                                                               ((tmp%%$32 0))
                                                                                                                                               (let
                                                                                                                                                ((tmp%%$33 (%I j$)))
                                                                                                                                                (let
                                                                                                                                                 ((tmp%%$34 r_len@))
                                                                                                                                                 (and
                                                                                                                                                  (<= tmp%%$32 tmp%%$33)
                                                                                                                                                  (< tmp%%$33 tmp%%$34)
                                                                                                                                              ))))
                                                                                                                                              (= (%I (vstd!seq.Seq.index.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ USIZE
                                                                                                                                                   $ TYPE%alloc!alloc.Global.
                                                                                                                                                  ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. right_part@)
                                                                                                                                                 ) j$
                                                                                                                                                )
                                                                                                                                               ) (lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_wrapping_add.? (I l_total@) (vstd!seq.Seq.index.?
                                                                                                                                                 $ USIZE (Poly%vstd!seq.Seq<usize.>. r_pref_view@1) j$
                                                                                                                                            )))))
                                                                                                                                            :pattern ((vstd!seq.Seq.index.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec.
                                                                                                                                                $ USIZE $ TYPE%alloc!alloc.Global.
                                                                                                                                               ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. right_part@)
                                                                                                                                              ) j$
                                                                                                                                            ))
                                                                                                                                            :qid user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_18
                                                                                                                                            :skolemid skolem_user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_18
                                                                                                                                          ))
                                                                                                                                          (=>
                                                                                                                                           (forall ((j$ Poly)) (!
                                                                                                                                             (=>
                                                                                                                                              (has_type j$ INT)
                                                                                                                                              (=>
                                                                                                                                               (let
                                                                                                                                                ((tmp%%$35 0))
                                                                                                                                                (let
                                                                                                                                                 ((tmp%%$36 (%I j$)))
                                                                                                                                                 (let
                                                                                                                                                  ((tmp%%$37 l_len@))
                                                                                                                                                  (and
                                                                                                                                                   (<= tmp%%$35 tmp%%$36)
                                                                                                                                                   (< tmp%%$36 tmp%%$37)
                                                                                                                                               ))))
                                                                                                                                               (= (vstd!seq.Seq.index.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ USIZE
                                                                                                                                                   $ TYPE%alloc!alloc.Global.
                                                                                                                                                  ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. result_vec@1)
                                                                                                                                                 ) j$
                                                                                                                                                ) (vstd!seq.Seq.index.? $ USIZE (Poly%vstd!seq.Seq<usize.>. l_pref_view@1) j$)
                                                                                                                                             )))
                                                                                                                                             :pattern ((vstd!seq.Seq.index.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec.
                                                                                                                                                 $ USIZE $ TYPE%alloc!alloc.Global.
                                                                                                                                                ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. result_vec@1)
                                                                                                                                               ) j$
                                                                                                                                             ))
                                                                                                                                             :qid user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_19
                                                                                                                                             :skolemid skolem_user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_19
                                                                                                                                           ))
                                                                                                                                           (=>
                                                                                                                                            (forall ((j$ Int)) (!
                                                                                                                                              (=>
                                                                                                                                               (let
                                                                                                                                                ((tmp%%$38 0))
                                                                                                                                                (let
                                                                                                                                                 ((tmp%%$39 j$))
                                                                                                                                                 (let
                                                                                                                                                  ((tmp%%$40 i$12@1))
                                                                                                                                                  (and
                                                                                                                                                   (<= tmp%%$38 tmp%%$39)
                                                                                                                                                   (< tmp%%$39 tmp%%$40)
                                                                                                                                               ))))
                                                                                                                                               (= (%I (vstd!seq.Seq.index.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ USIZE
                                                                                                                                                    $ TYPE%alloc!alloc.Global.
                                                                                                                                                   ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. result_vec@1)
                                                                                                                                                  ) (I (Add l_len@ j$))
                                                                                                                                                 )
                                                                                                                                                ) (lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_wrapping_add.? (I l_total@) (vstd!seq.Seq.index.?
                                                                                                                                                  $ USIZE (Poly%vstd!seq.Seq<usize.>. r_pref_view@1) (I j$)
                                                                                                                                              ))))
                                                                                                                                              :pattern ((vstd!seq.Seq.index.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec.
                                                                                                                                                  $ USIZE $ TYPE%alloc!alloc.Global.
                                                                                                                                                 ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. result_vec@1)
                                                                                                                                                ) (I (Add l_len@ j$))
                                                                                                                                              ))
                                                                                                                                              :qid user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_20
                                                                                                                                              :skolemid skolem_user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_20
                                                                                                                                            ))
                                                                                                                                            (=>
                                                                                                                                             (has_resolved $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE)
                                                                                                                                              (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. left@)
                                                                                                                                             )
                                                                                                                                             (=>
                                                                                                                                              (has_resolved $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE)
                                                                                                                                               (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. right@)
                                                                                                                                              )
                                                                                                                                              (=>
                                                                                                                                               (has_resolved $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE)
                                                                                                                                                (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. l_prefixes@)
                                                                                                                                               )
                                                                                                                                               (=>
                                                                                                                                                (has_resolved $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE)
                                                                                                                                                 (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. r_prefixes@)
                                                                                                                                                )
                                                                                                                                                (=>
                                                                                                                                                 (has_resolved $ (TYPE%alloc!vec.Vec. $ USIZE $ TYPE%alloc!alloc.Global.) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>.
                                                                                                                                                   right_part@
                                                                                                                                                 ))
                                                                                                                                                 (=>
                                                                                                                                                  (not (< i$12@1 r_len@))
                                                                                                                                                  (=>
                                                                                                                                                   (has_resolved $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE)
                                                                                                                                                    (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. left@)
                                                                                                                                                   )
                                                                                                                                                   (=>
                                                                                                                                                    (has_resolved $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE)
                                                                                                                                                     (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. right@)
                                                                                                                                                    )
                                                                                                                                                    (=>
                                                                                                                                                     (has_resolved $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE)
                                                                                                                                                      (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. l_prefixes@)
                                                                                                                                                     )
                                                                                                                                                     (=>
                                                                                                                                                      (has_resolved $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE)
                                                                                                                                                       (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. r_prefixes@)
                                                                                                                                                      )
                                                                                                                                                      (=>
                                                                                                                                                       (has_resolved $ (TYPE%alloc!vec.Vec. $ USIZE $ TYPE%alloc!alloc.Global.) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>.
                                                                                                                                                         right_part@
                                                                                                                                                       ))
                                                                                                                                                       (=>
                                                                                                                                                        (ens%core!num.impl&%11.wrapping_add. l_total@ r_total@ total$1@)
                                                                                                                                                        (=>
                                                                                                                                                         (= verus_tmp$8@1 (%Poly%vstd!seq.Seq<usize.>. (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec.
                                                                                                                                                             $ USIZE $ TYPE%alloc!alloc.Global.
                                                                                                                                                            ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. result_vec@1)
                                                                                                                                                         )))
                                                                                                                                                         (=>
                                                                                                                                                          (= verus_tmp_result_view@ verus_tmp$8@1)
                                                                                                                                                          (=>
                                                                                                                                                           (= result_view@1 verus_tmp_result_view@)
                                                                                                                                                           (=>
                                                                                                                                                            (= result_prefixes@ (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS./ArraySeqMtPerS
                                                                                                                                                              (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. result_vec@1)
                                                                                                                                                            ))
                                                                                                                                                            (=>
                                                                                                                                                             (= rp@ (%Poly%vstd!seq.Seq<usize.>. (vstd!seq.Seq.new.? $ USIZE (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_len.?
                                                                                                                                                                 $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE) $ USIZE (
                                                                                                                                                                  Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. result_prefixes@
                                                                                                                                                                 )
                                                                                                                                                                ) (Poly%fun%1. (mk_fun (%%lambda%%L $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
                                                                                                                                                                    $ USIZE
                                                                                                                                                                   ) $ USIZE (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. result_prefixes@)
                                                                                                                                                             ))))))
                                                                                                                                                             (=>
                                                                                                                                                              (= tmp%46 (ext_eq false (TYPE%vstd!seq.Seq. $ USIZE) (Poly%vstd!seq.Seq<usize.>. rp@)
                                                                                                                                                                (Poly%vstd!seq.Seq<usize.>. result_view@1)
                                                                                                                                                              ))
                                                                                                                                                              (and
                                                                                                                                                               (=>
                                                                                                                                                                %%location_label%%57
                                                                                                                                                                tmp%46
                                                                                                                                                               )
                                                                                                                                                               (=>
                                                                                                                                                                tmp%46
                                                                                                                                                                (=>
                                                                                                                                                                 (= tmp%47 (= (vstd!seq.Seq.len.? $ USIZE (Poly%vstd!seq.Seq<usize.>. result_view@1))
                                                                                                                                                                   n@
                                                                                                                                                                 ))
                                                                                                                                                                 (and
                                                                                                                                                                  (=>
                                                                                                                                                                   %%location_label%%58
                                                                                                                                                                   tmp%47
                                                                                                                                                                  )
                                                                                                                                                                  (=>
                                                                                                                                                                   tmp%47
                                                                                                                                                                   (=>
                                                                                                                                                                    (= tmp%48 (ext_eq false (TYPE%vstd!seq.Seq. $ USIZE) (Poly%vstd!seq.Seq<usize.>. left_input@1)
                                                                                                                                                                      (vstd!seq.Seq.subrange.? $ USIZE (Poly%vstd!seq.Seq<usize.>. input@1) (I 0) (I mid@))
                                                                                                                                                                    ))
                                                                                                                                                                    (and
                                                                                                                                                                     (=>
                                                                                                                                                                      %%location_label%%59
                                                                                                                                                                      tmp%48
                                                                                                                                                                     )
                                                                                                                                                                     (=>
                                                                                                                                                                      tmp%48
                                                                                                                                                                      (=>
                                                                                                                                                                       (= tmp%49 (ext_eq false (TYPE%vstd!seq.Seq. $ USIZE) (Poly%vstd!seq.Seq<usize.>. right_input@1)
                                                                                                                                                                         (vstd!seq.Seq.subrange.? $ USIZE (Poly%vstd!seq.Seq<usize.>. input@1) (I mid@) (I n@))
                                                                                                                                                                       ))
                                                                                                                                                                       (and
                                                                                                                                                                        (=>
                                                                                                                                                                         %%location_label%%60
                                                                                                                                                                         tmp%49
                                                                                                                                                                        )
                                                                                                                                                                        (=>
                                                                                                                                                                         tmp%49
                                                                                                                                                                         (and
                                                                                                                                                                          (=>
                                                                                                                                                                           %%location_label%%61
                                                                                                                                                                           (req%vstd!seq_lib.impl&%0.lemma_fold_left_split. $ USIZE $ USIZE (Poly%vstd!seq.Seq<usize.>.
                                                                                                                                                                             input@1
                                                                                                                                                                            ) (I (uClip SZ 0)) spec_f@1 mid@
                                                                                                                                                                          ))
                                                                                                                                                                          (=>
                                                                                                                                                                           (ens%vstd!seq_lib.impl&%0.lemma_fold_left_split. $ USIZE $ USIZE (Poly%vstd!seq.Seq<usize.>.
                                                                                                                                                                             input@1
                                                                                                                                                                            ) (I (uClip SZ 0)) spec_f@1 mid@
                                                                                                                                                                           )
                                                                                                                                                                           (and
                                                                                                                                                                            (=>
                                                                                                                                                                             %%location_label%%62
                                                                                                                                                                             (req%lib!Chap26.ScanDCMtPer.ScanDCMtPer.lemma_fold_left_monoid. right_input@1 l_total@
                                                                                                                                                                              spec_f@1 (uClip SZ 0)
                                                                                                                                                                            ))
                                                                                                                                                                            (=>
                                                                                                                                                                             (ens%lib!Chap26.ScanDCMtPer.ScanDCMtPer.lemma_fold_left_monoid. right_input@1 l_total@
                                                                                                                                                                              spec_f@1 (uClip SZ 0)
                                                                                                                                                                             )
                                                                                                                                                                             (and
                                                                                                                                                                              (=>
                                                                                                                                                                               (has_type i$14@ INT)
                                                                                                                                                                               (=>
                                                                                                                                                                                (let
                                                                                                                                                                                 ((tmp%%$41 0))
                                                                                                                                                                                 (let
                                                                                                                                                                                  ((tmp%%$42 (%I i$14@)))
                                                                                                                                                                                  (let
                                                                                                                                                                                   ((tmp%%$43 n@))
                                                                                                                                                                                   (and
                                                                                                                                                                                    (<= tmp%%$41 tmp%%$42)
                                                                                                                                                                                    (< tmp%%$42 tmp%%$43)
                                                                                                                                                                                ))))
                                                                                                                                                                                (or
                                                                                                                                                                                 (and
                                                                                                                                                                                  (=>
                                                                                                                                                                                   (< (%I i$14@) mid@)
                                                                                                                                                                                   (=>
                                                                                                                                                                                    (= tmp%50 (= (vstd!seq.Seq.index.? $ USIZE (Poly%vstd!seq.Seq<usize.>. result_view@1)
                                                                                                                                                                                       i$14@
                                                                                                                                                                                      ) (vstd!seq.Seq.index.? $ USIZE (Poly%vstd!seq.Seq<usize.>. l_pref_view@1) i$14@)
                                                                                                                                                                                    ))
                                                                                                                                                                                    (and
                                                                                                                                                                                     (=>
                                                                                                                                                                                      %%location_label%%63
                                                                                                                                                                                      tmp%50
                                                                                                                                                                                     )
                                                                                                                                                                                     (=>
                                                                                                                                                                                      tmp%50
                                                                                                                                                                                      (=>
                                                                                                                                                                                       (= tmp%51 (ext_eq false (TYPE%vstd!seq.Seq. $ USIZE) (vstd!seq.Seq.subrange.? $ USIZE
                                                                                                                                                                                          (Poly%vstd!seq.Seq<usize.>. input@1) (I 0) i$14@
                                                                                                                                                                                         ) (vstd!seq.Seq.subrange.? $ USIZE (Poly%vstd!seq.Seq<usize.>. left_input@1) (I 0)
                                                                                                                                                                                          i$14@
                                                                                                                                                                                       )))
                                                                                                                                                                                       (and
                                                                                                                                                                                        (=>
                                                                                                                                                                                         %%location_label%%64
                                                                                                                                                                                         tmp%51
                                                                                                                                                                                        )
                                                                                                                                                                                        (=>
                                                                                                                                                                                         tmp%51
                                                                                                                                                                                         %%switch_label%%0
                                                                                                                                                                                  )))))))
                                                                                                                                                                                  (=>
                                                                                                                                                                                   (not (< (%I i$14@) mid@))
                                                                                                                                                                                   (=>
                                                                                                                                                                                    (= j@ (Sub (%I i$14@) mid@))
                                                                                                                                                                                    (=>
                                                                                                                                                                                     (= tmp%52 (= (%I i$14@) (Add l_len@ j@)))
                                                                                                                                                                                     (and
                                                                                                                                                                                      (=>
                                                                                                                                                                                       %%location_label%%65
                                                                                                                                                                                       tmp%52
                                                                                                                                                                                      )
                                                                                                                                                                                      (=>
                                                                                                                                                                                       tmp%52
                                                                                                                                                                                       (=>
                                                                                                                                                                                        (= tmp%53 (= (%I (vstd!seq.Seq.index.? $ USIZE (Poly%vstd!seq.Seq<usize.>. result_view@1)
                                                                                                                                                                                            (I (Add l_len@ j@))
                                                                                                                                                                                           )
                                                                                                                                                                                          ) (lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_wrapping_add.? (I l_total@) (vstd!seq.Seq.index.?
                                                                                                                                                                                            $ USIZE (Poly%vstd!seq.Seq<usize.>. r_pref_view@1) (I j@)
                                                                                                                                                                                        ))))
                                                                                                                                                                                        (and
                                                                                                                                                                                         (=>
                                                                                                                                                                                          %%location_label%%66
                                                                                                                                                                                          tmp%53
                                                                                                                                                                                         )
                                                                                                                                                                                         (=>
                                                                                                                                                                                          tmp%53
                                                                                                                                                                                          (=>
                                                                                                                                                                                           (= tmp%54 (%Poly%vstd!seq.Seq<usize.>. (vstd!seq.Seq.subrange.? $ USIZE (Poly%vstd!seq.Seq<usize.>.
                                                                                                                                                                                               right_input@1
                                                                                                                                                                                              ) (I 0) (I j@)
                                                                                                                                                                                           )))
                                                                                                                                                                                           (and
                                                                                                                                                                                            (=>
                                                                                                                                                                                             %%location_label%%67
                                                                                                                                                                                             (req%lib!Chap26.ScanDCMtPer.ScanDCMtPer.lemma_fold_left_monoid. tmp%54 l_total@ spec_f@1
                                                                                                                                                                                              (uClip SZ 0)
                                                                                                                                                                                            ))
                                                                                                                                                                                            (=>
                                                                                                                                                                                             (ens%lib!Chap26.ScanDCMtPer.ScanDCMtPer.lemma_fold_left_monoid. tmp%54 l_total@ spec_f@1
                                                                                                                                                                                              (uClip SZ 0)
                                                                                                                                                                                             )
                                                                                                                                                                                             (=>
                                                                                                                                                                                              (= tmp%55 (ext_eq false (TYPE%vstd!seq.Seq. $ USIZE) (vstd!seq.Seq.subrange.? $ USIZE
                                                                                                                                                                                                 (vstd!seq.Seq.subrange.? $ USIZE (Poly%vstd!seq.Seq<usize.>. input@1) (I 0) i$14@)
                                                                                                                                                                                                 (I 0) (I mid@)
                                                                                                                                                                                                ) (Poly%vstd!seq.Seq<usize.>. left_input@1)
                                                                                                                                                                                              ))
                                                                                                                                                                                              (and
                                                                                                                                                                                               (=>
                                                                                                                                                                                                %%location_label%%68
                                                                                                                                                                                                tmp%55
                                                                                                                                                                                               )
                                                                                                                                                                                               (=>
                                                                                                                                                                                                tmp%55
                                                                                                                                                                                                (=>
                                                                                                                                                                                                 (= tmp%56 (ext_eq false (TYPE%vstd!seq.Seq. $ USIZE) (vstd!seq.Seq.subrange.? $ USIZE
                                                                                                                                                                                                    (vstd!seq.Seq.subrange.? $ USIZE (Poly%vstd!seq.Seq<usize.>. input@1) (I 0) i$14@)
                                                                                                                                                                                                    (I mid@) i$14@
                                                                                                                                                                                                   ) (vstd!seq.Seq.subrange.? $ USIZE (Poly%vstd!seq.Seq<usize.>. right_input@1) (I 0)
                                                                                                                                                                                                    (I j@)
                                                                                                                                                                                                 )))
                                                                                                                                                                                                 (and
                                                                                                                                                                                                  (=>
                                                                                                                                                                                                   %%location_label%%69
                                                                                                                                                                                                   tmp%56
                                                                                                                                                                                                  )
                                                                                                                                                                                                  (=>
                                                                                                                                                                                                   tmp%56
                                                                                                                                                                                                   (=>
                                                                                                                                                                                                    (= tmp%57 (%Poly%vstd!seq.Seq<usize.>. (vstd!seq.Seq.subrange.? $ USIZE (Poly%vstd!seq.Seq<usize.>.
                                                                                                                                                                                                        input@1
                                                                                                                                                                                                       ) (I 0) i$14@
                                                                                                                                                                                                    )))
                                                                                                                                                                                                    (and
                                                                                                                                                                                                     (=>
                                                                                                                                                                                                      %%location_label%%70
                                                                                                                                                                                                      (req%vstd!seq_lib.impl&%0.lemma_fold_left_split. $ USIZE $ USIZE (Poly%vstd!seq.Seq<usize.>.
                                                                                                                                                                                                        tmp%57
                                                                                                                                                                                                       ) (I (uClip SZ 0)) spec_f@1 mid@
                                                                                                                                                                                                     ))
                                                                                                                                                                                                     (=>
                                                                                                                                                                                                      (ens%vstd!seq_lib.impl&%0.lemma_fold_left_split. $ USIZE $ USIZE (Poly%vstd!seq.Seq<usize.>.
                                                                                                                                                                                                        tmp%57
                                                                                                                                                                                                       ) (I (uClip SZ 0)) spec_f@1 mid@
                                                                                                                                                                                                      )
                                                                                                                                                                                                      %%switch_label%%0
                                                                                                                                                                                 )))))))))))))))))))))
                                                                                                                                                                                 (and
                                                                                                                                                                                  (not %%switch_label%%0)
                                                                                                                                                                                  (=>
                                                                                                                                                                                   %%location_label%%71
                                                                                                                                                                                   (= (%I (vstd!seq.Seq.index.? $ USIZE (Poly%vstd!seq.Seq<usize.>. result_view@1) i$14@))
                                                                                                                                                                                    (lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_scan_at.? (Poly%vstd!seq.Seq<usize.>. input@1)
                                                                                                                                                                                     (Poly%fun%2. spec_f@1) (I (uClip SZ 0)) i$14@
                                                                                                                                                                              )))))))
                                                                                                                                                                              (=>
                                                                                                                                                                               (forall ((i$15 Poly)) (!
                                                                                                                                                                                 (=>
                                                                                                                                                                                  (has_type i$15 INT)
                                                                                                                                                                                  (=>
                                                                                                                                                                                   (let
                                                                                                                                                                                    ((tmp%%$44 0))
                                                                                                                                                                                    (let
                                                                                                                                                                                     ((tmp%%$45 (%I i$15)))
                                                                                                                                                                                     (let
                                                                                                                                                                                      ((tmp%%$46 n@))
                                                                                                                                                                                      (and
                                                                                                                                                                                       (<= tmp%%$44 tmp%%$45)
                                                                                                                                                                                       (< tmp%%$45 tmp%%$46)
                                                                                                                                                                                   ))))
                                                                                                                                                                                   (= (%I (vstd!seq.Seq.index.? $ USIZE (Poly%vstd!seq.Seq<usize.>. result_view@1) i$15))
                                                                                                                                                                                    (lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_scan_at.? (Poly%vstd!seq.Seq<usize.>. input@1)
                                                                                                                                                                                     (Poly%fun%2. spec_f@1) (I (uClip SZ 0)) i$15
                                                                                                                                                                                 ))))
                                                                                                                                                                                 :pattern ((vstd!seq.Seq.index.? $ USIZE (Poly%vstd!seq.Seq<usize.>. result_view@1)
                                                                                                                                                                                   i$15
                                                                                                                                                                                 ))
                                                                                                                                                                                 :qid user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_21
                                                                                                                                                                                 :skolemid skolem_user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_21
                                                                                                                                                                               ))
                                                                                                                                                                               (=>
                                                                                                                                                                                (= sums! (tuple%2./tuple%2 (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
                                                                                                                                                                                   result_prefixes@
                                                                                                                                                                                  ) (I total$1@)
                                                                                                                                                                                ))
                                                                                                                                                                                (=>
                                                                                                                                                                                 %%location_label%%72
                                                                                                                                                                                 (lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_scan_post.? (vstd!seq.Seq.new.? $ USIZE (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_len.?
                                                                                                                                                                                    $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE) $ USIZE (
                                                                                                                                                                                     Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. a!
                                                                                                                                                                                    )
                                                                                                                                                                                   ) (Poly%fun%1. (mk_fun (%%lambda%%L $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
                                                                                                                                                                                       $ USIZE
                                                                                                                                                                                      ) $ USIZE (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. a!)
                                                                                                                                                                                   )))
                                                                                                                                                                                  ) (Poly%fun%2. (lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_sum_fn.? (I 0))) (I 0) (vstd!seq.Seq.new.?
                                                                                                                                                                                   $ USIZE (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_len.?
                                                                                                                                                                                    $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE) $ USIZE (
                                                                                                                                                                                     tuple%2./tuple%2/0 (%Poly%tuple%2. (Poly%tuple%2. sums!))
                                                                                                                                                                                    )
                                                                                                                                                                                   ) (Poly%fun%1. (mk_fun (%%lambda%%L $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
                                                                                                                                                                                       $ USIZE
                                                                                                                                                                                      ) $ USIZE (tuple%2./tuple%2/0 (%Poly%tuple%2. (Poly%tuple%2. sums!)))
                                                                                                                                                                                   )))
                                                                                                                                                                                  ) (tuple%2./tuple%2/1 (%Poly%tuple%2. (Poly%tuple%2. sums!)))
 )))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
 (get-info :all-statistics)
 (get-info :version)
 (set-option :rlimit 30000000)
 (check-sat)
 (set-option :rlimit 0)
 (get-info :all-statistics)
