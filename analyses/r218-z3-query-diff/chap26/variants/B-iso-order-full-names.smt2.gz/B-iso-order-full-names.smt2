(set-option :auto_config false)
(set-option :smt.mbqi false)
(set-option :smt.case_split 3)
(set-option :smt.qi.eager_threshold 100.0)
(set-option :smt.delay_units true)
(set-option :smt.arith.solver 2)
(set-option :smt.arith.nl false)
(set-option :pi.enabled false)
(set-option :rewriter.sort_disjunctions false)

;; Prelude

;; AIR prelude
(declare-sort %%Function%% 0)

(declare-sort FuelId 0)
(declare-sort Fuel 0)
(declare-const zero Fuel)
(declare-fun succ (Fuel) Fuel)
(declare-fun fuel_bool (FuelId) Bool)
(declare-fun fuel_bool_default (FuelId) Bool)
(declare-const fuel_defaults Bool)
(assert
 (=>
  fuel_defaults
  (forall ((id FuelId)) (!
    (= (fuel_bool id) (fuel_bool_default id))
    :pattern ((fuel_bool id))
    :qid prelude_fuel_defaults
    :skolemid skolem_prelude_fuel_defaults
))))
(declare-datatypes ((fndef 0)) (((fndef_singleton))))
(declare-sort Poly 0)
(declare-sort Height 0)
(declare-fun I (Int) Poly)
(declare-fun B (Bool) Poly)
(declare-fun R (Real) Poly)
(declare-fun F (fndef) Poly)
(declare-fun %I (Poly) Int)
(declare-fun %B (Poly) Bool)
(declare-fun %R (Poly) Real)
(declare-fun %F (Poly) fndef)
(declare-sort Type 0)
(declare-const BOOL Type)
(declare-const INT Type)
(declare-const NAT Type)
(declare-const REAL Type)
(declare-const CHAR Type)
(declare-const USIZE Type)
(declare-const ISIZE Type)
(declare-const TYPE%tuple%0. Type)
(declare-fun UINT (Int) Type)
(declare-fun SINT (Int) Type)
(declare-fun FLOAT (Int) Type)
(declare-fun CONST_INT (Int) Type)
(declare-fun CONST_BOOL (Bool) Type)
(declare-sort Dcr 0)
(declare-const $ Dcr)
(declare-const $slice Dcr)
(declare-const $dyn Dcr)
(declare-fun DST (Dcr) Dcr)
(declare-fun REF (Dcr) Dcr)
(declare-fun BOX (Dcr Type Dcr) Dcr)
(declare-fun RC (Dcr Type Dcr) Dcr)
(declare-fun ARC (Dcr Type Dcr) Dcr)
(declare-fun GHOST (Dcr) Dcr)
(declare-fun TRACKED (Dcr) Dcr)
(declare-fun NEVER (Dcr) Dcr)
(declare-fun CONST_PTR (Dcr) Dcr)
(declare-fun ARRAY (Dcr Type Dcr Type) Type)
(declare-fun MUTREF (Dcr Type) Type)
(declare-fun SLICE (Dcr Type) Type)
(declare-const STRSLICE Type)
(declare-const ALLOCATOR_GLOBAL Type)
(declare-fun PTR (Dcr Type) Type)
(declare-fun has_type (Poly Type) Bool)
(declare-fun sized (Dcr) Bool)
(declare-fun as_type (Poly Type) Poly)
(declare-fun mk_fun (%%Function%%) %%Function%%)
(declare-fun const_int (Type) Int)
(declare-fun const_bool (Type) Bool)
(declare-fun mut_ref_current% (Poly) Poly)
(declare-fun mut_ref_future% (Poly) Poly)
(declare-fun mut_ref_update_current% (Poly Poly) Poly)
(assert
 (forall ((m Poly) (arg Poly)) (!
   (= (mut_ref_current% (mut_ref_update_current% m arg)) arg)
   :pattern ((mut_ref_update_current% m arg))
   :qid prelude_mut_ref_update_current_current
   :skolemid skolem_prelude_mut_ref_update_current_current
)))
(assert
 (forall ((m Poly) (arg Poly)) (!
   (= (mut_ref_future% (mut_ref_update_current% m arg)) (mut_ref_future% m))
   :pattern ((mut_ref_update_current% m arg))
   :qid prelude_mut_ref_update_current_future
   :skolemid skolem_prelude_mut_ref_update_current_future
)))
(assert
 (forall ((m Poly) (d Dcr) (t Type)) (!
   (=>
    (has_type m (MUTREF d t))
    (has_type (mut_ref_current% m) t)
   )
   :pattern ((has_type m (MUTREF d t)) (mut_ref_current% m))
   :qid prelude_mut_ref_current_has_type
   :skolemid skolem_prelude_mut_ref_current_has_type
)))
(assert
 (forall ((m Poly) (d Dcr) (t Type)) (!
   (=>
    (has_type m (MUTREF d t))
    (has_type (mut_ref_future% m) t)
   )
   :pattern ((has_type m (MUTREF d t)) (mut_ref_future% m))
   :qid prelude_mut_ref_future_has_type
   :skolemid skolem_prelude_mut_ref_future_has_type
)))
(assert
 (forall ((m Poly) (d Dcr) (t Type) (arg Poly)) (!
   (=>
    (and
     (has_type m (MUTREF d t))
     (has_type arg t)
    )
    (has_type (mut_ref_update_current% m arg) (MUTREF d t))
   )
   :pattern ((has_type m (MUTREF d t)) (mut_ref_update_current% m arg))
   :qid prelude_mut_ref_update_has_type
   :skolemid skolem_prelude_mut_ref_update_has_type
)))
(assert
 (forall ((d Dcr)) (!
   (=>
    (sized d)
    (sized (DST d))
   )
   :pattern ((sized (DST d)))
   :qid prelude_sized_decorate_struct_inherit
   :skolemid skolem_prelude_sized_decorate_struct_inherit
)))
(assert
 (forall ((d Dcr)) (!
   (sized (REF d))
   :pattern ((sized (REF d)))
   :qid prelude_sized_decorate_ref
   :skolemid skolem_prelude_sized_decorate_ref
)))
(assert
 (forall ((d Dcr) (t Type) (d2 Dcr)) (!
   (sized (BOX d t d2))
   :pattern ((sized (BOX d t d2)))
   :qid prelude_sized_decorate_box
   :skolemid skolem_prelude_sized_decorate_box
)))
(assert
 (forall ((d Dcr) (t Type) (d2 Dcr)) (!
   (sized (RC d t d2))
   :pattern ((sized (RC d t d2)))
   :qid prelude_sized_decorate_rc
   :skolemid skolem_prelude_sized_decorate_rc
)))
(assert
 (forall ((d Dcr) (t Type) (d2 Dcr)) (!
   (sized (ARC d t d2))
   :pattern ((sized (ARC d t d2)))
   :qid prelude_sized_decorate_arc
   :skolemid skolem_prelude_sized_decorate_arc
)))
(assert
 (forall ((d Dcr)) (!
   (sized (GHOST d))
   :pattern ((sized (GHOST d)))
   :qid prelude_sized_decorate_ghost
   :skolemid skolem_prelude_sized_decorate_ghost
)))
(assert
 (forall ((d Dcr)) (!
   (sized (TRACKED d))
   :pattern ((sized (TRACKED d)))
   :qid prelude_sized_decorate_tracked
   :skolemid skolem_prelude_sized_decorate_tracked
)))
(assert
 (forall ((d Dcr)) (!
   (sized (NEVER d))
   :pattern ((sized (NEVER d)))
   :qid prelude_sized_decorate_never
   :skolemid skolem_prelude_sized_decorate_never
)))
(assert
 (forall ((d Dcr)) (!
   (sized (CONST_PTR d))
   :pattern ((sized (CONST_PTR d)))
   :qid prelude_sized_decorate_const_ptr
   :skolemid skolem_prelude_sized_decorate_const_ptr
)))
(assert
 (sized $)
)
(assert
 (forall ((i Int)) (!
   (= i (const_int (CONST_INT i)))
   :pattern ((CONST_INT i))
   :qid prelude_type_id_const_int
   :skolemid skolem_prelude_type_id_const_int
)))
(assert
 (forall ((b Bool)) (!
   (= b (const_bool (CONST_BOOL b)))
   :pattern ((CONST_BOOL b))
   :qid prelude_type_id_const_bool
   :skolemid skolem_prelude_type_id_const_bool
)))
(assert
 (forall ((b Bool)) (!
   (has_type (B b) BOOL)
   :pattern ((has_type (B b) BOOL))
   :qid prelude_has_type_bool
   :skolemid skolem_prelude_has_type_bool
)))
(assert
 (forall ((r Real)) (!
   (has_type (R r) REAL)
   :pattern ((has_type (R r) REAL))
   :qid prelude_has_type_real
   :skolemid skolem_prelude_has_type_real
)))
(assert
 (forall ((x Poly) (t Type)) (!
   (and
    (has_type (as_type x t) t)
    (=>
     (has_type x t)
     (= x (as_type x t))
   ))
   :pattern ((as_type x t))
   :qid prelude_as_type
   :skolemid skolem_prelude_as_type
)))
(assert
 (forall ((x %%Function%%)) (!
   (= (mk_fun x) x)
   :pattern ((mk_fun x))
   :qid prelude_mk_fun
   :skolemid skolem_prelude_mk_fun
)))
(assert
 (forall ((x Bool)) (!
   (= x (%B (B x)))
   :pattern ((B x))
   :qid prelude_unbox_box_bool
   :skolemid skolem_prelude_unbox_box_bool
)))
(assert
 (forall ((x Int)) (!
   (= x (%I (I x)))
   :pattern ((I x))
   :qid prelude_unbox_box_int
   :skolemid skolem_prelude_unbox_box_int
)))
(assert
 (forall ((x Real)) (!
   (= x (%R (R x)))
   :pattern ((R x))
   :qid prelude_unbox_box_real
   :skolemid skolem_prelude_unbox_box_real
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x BOOL)
    (= x (B (%B x)))
   )
   :pattern ((has_type x BOOL))
   :qid prelude_box_unbox_bool
   :skolemid skolem_prelude_box_unbox_bool
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x INT)
    (= x (I (%I x)))
   )
   :pattern ((has_type x INT))
   :qid prelude_box_unbox_int
   :skolemid skolem_prelude_box_unbox_int
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x NAT)
    (= x (I (%I x)))
   )
   :pattern ((has_type x NAT))
   :qid prelude_box_unbox_nat
   :skolemid skolem_prelude_box_unbox_nat
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x USIZE)
    (= x (I (%I x)))
   )
   :pattern ((has_type x USIZE))
   :qid prelude_box_unbox_usize
   :skolemid skolem_prelude_box_unbox_usize
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x ISIZE)
    (= x (I (%I x)))
   )
   :pattern ((has_type x ISIZE))
   :qid prelude_box_unbox_isize
   :skolemid skolem_prelude_box_unbox_isize
)))
(assert
 (forall ((bits Int) (x Poly)) (!
   (=>
    (has_type x (UINT bits))
    (= x (I (%I x)))
   )
   :pattern ((has_type x (UINT bits)))
   :qid prelude_box_unbox_uint
   :skolemid skolem_prelude_box_unbox_uint
)))
(assert
 (forall ((bits Int) (x Poly)) (!
   (=>
    (has_type x (SINT bits))
    (= x (I (%I x)))
   )
   :pattern ((has_type x (SINT bits)))
   :qid prelude_box_unbox_sint
   :skolemid skolem_prelude_box_unbox_sint
)))
(assert
 (forall ((bits Int) (x Poly)) (!
   (=>
    (has_type x (FLOAT bits))
    (= x (I (%I x)))
   )
   :pattern ((has_type x (FLOAT bits)))
   :qid prelude_box_unbox_float
   :skolemid skolem_prelude_box_unbox_float
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x CHAR)
    (= x (I (%I x)))
   )
   :pattern ((has_type x CHAR))
   :qid prelude_box_unbox_char
   :skolemid skolem_prelude_box_unbox_char
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x REAL)
    (= x (R (%R x)))
   )
   :pattern ((has_type x REAL))
   :qid prelude_box_unbox_real
   :skolemid skolem_prelude_box_unbox_real
)))
(declare-fun ext_eq (Bool Type Poly Poly) Bool)
(assert
 (forall ((deep Bool) (t Type) (x Poly) (y Poly)) (!
   (= (= x y) (ext_eq deep t x y))
   :pattern ((ext_eq deep t x y))
   :qid prelude_ext_eq
   :skolemid skolem_prelude_ext_eq
)))
(declare-const SZ Int)
(assert
 (or
  (= SZ 32)
  (= SZ 64)
))
(declare-fun uHi (Int) Int)
(declare-fun iLo (Int) Int)
(declare-fun iHi (Int) Int)
(assert
 (= (uHi 8) 256)
)
(assert
 (= (uHi 16) 65536)
)
(assert
 (= (uHi 32) 4294967296)
)
(assert
 (= (uHi 64) 18446744073709551616)
)
(assert
 (= (uHi 128) (+ 1 340282366920938463463374607431768211455))
)
(assert
 (= (iLo 8) (- 128))
)
(assert
 (= (iLo 16) (- 32768))
)
(assert
 (= (iLo 32) (- 2147483648))
)
(assert
 (= (iLo 64) (- 9223372036854775808))
)
(assert
 (= (iLo 128) (- 170141183460469231731687303715884105728))
)
(assert
 (= (iHi 8) 128)
)
(assert
 (= (iHi 16) 32768)
)
(assert
 (= (iHi 32) 2147483648)
)
(assert
 (= (iHi 64) 9223372036854775808)
)
(assert
 (= (iHi 128) 170141183460469231731687303715884105728)
)
(declare-fun nClip (Int) Int)
(declare-fun uClip (Int Int) Int)
(declare-fun iClip (Int Int) Int)
(declare-fun charClip (Int) Int)
(assert
 (forall ((i Int)) (!
   (and
    (<= 0 (nClip i))
    (=>
     (<= 0 i)
     (= i (nClip i))
   ))
   :pattern ((nClip i))
   :qid prelude_nat_clip
   :skolemid skolem_prelude_nat_clip
)))
(assert
 (forall ((bits Int) (i Int)) (!
   (and
    (<= 0 (uClip bits i))
    (< (uClip bits i) (uHi bits))
    (=>
     (and
      (<= 0 i)
      (< i (uHi bits))
     )
     (= i (uClip bits i))
   ))
   :pattern ((uClip bits i))
   :qid prelude_u_clip
   :skolemid skolem_prelude_u_clip
)))
(assert
 (forall ((bits Int) (i Int)) (!
   (and
    (<= (iLo bits) (iClip bits i))
    (< (iClip bits i) (iHi bits))
    (=>
     (and
      (<= (iLo bits) i)
      (< i (iHi bits))
     )
     (= i (iClip bits i))
   ))
   :pattern ((iClip bits i))
   :qid prelude_i_clip
   :skolemid skolem_prelude_i_clip
)))
(assert
 (forall ((i Int)) (!
   (and
    (or
     (and
      (<= 0 (charClip i))
      (<= (charClip i) 55295)
     )
     (and
      (<= 57344 (charClip i))
      (<= (charClip i) 1114111)
    ))
    (=>
     (or
      (and
       (<= 0 i)
       (<= i 55295)
      )
      (and
       (<= 57344 i)
       (<= i 1114111)
     ))
     (= i (charClip i))
   ))
   :pattern ((charClip i))
   :qid prelude_char_clip
   :skolemid skolem_prelude_char_clip
)))
(declare-fun uInv (Int Int) Bool)
(declare-fun iInv (Int Int) Bool)
(declare-fun charInv (Int) Bool)
(assert
 (forall ((bits Int) (i Int)) (!
   (= (uInv bits i) (and
     (<= 0 i)
     (< i (uHi bits))
   ))
   :pattern ((uInv bits i))
   :qid prelude_u_inv
   :skolemid skolem_prelude_u_inv
)))
(assert
 (forall ((bits Int) (i Int)) (!
   (= (iInv bits i) (and
     (<= (iLo bits) i)
     (< i (iHi bits))
   ))
   :pattern ((iInv bits i))
   :qid prelude_i_inv
   :skolemid skolem_prelude_i_inv
)))
(assert
 (forall ((i Int)) (!
   (= (charInv i) (or
     (and
      (<= 0 i)
      (<= i 55295)
     )
     (and
      (<= 57344 i)
      (<= i 1114111)
   )))
   :pattern ((charInv i))
   :qid prelude_char_inv
   :skolemid skolem_prelude_char_inv
)))
(assert
 (forall ((x Int)) (!
   (has_type (I x) INT)
   :pattern ((has_type (I x) INT))
   :qid prelude_has_type_int
   :skolemid skolem_prelude_has_type_int
)))
(assert
 (forall ((x Int)) (!
   (=>
    (<= 0 x)
    (has_type (I x) NAT)
   )
   :pattern ((has_type (I x) NAT))
   :qid prelude_has_type_nat
   :skolemid skolem_prelude_has_type_nat
)))
(assert
 (forall ((x Int)) (!
   (=>
    (uInv SZ x)
    (has_type (I x) USIZE)
   )
   :pattern ((has_type (I x) USIZE))
   :qid prelude_has_type_usize
   :skolemid skolem_prelude_has_type_usize
)))
(assert
 (forall ((x Int)) (!
   (=>
    (iInv SZ x)
    (has_type (I x) ISIZE)
   )
   :pattern ((has_type (I x) ISIZE))
   :qid prelude_has_type_isize
   :skolemid skolem_prelude_has_type_isize
)))
(assert
 (forall ((bits Int) (x Int)) (!
   (=>
    (uInv bits x)
    (has_type (I x) (UINT bits))
   )
   :pattern ((has_type (I x) (UINT bits)))
   :qid prelude_has_type_uint
   :skolemid skolem_prelude_has_type_uint
)))
(assert
 (forall ((bits Int) (x Int)) (!
   (=>
    (iInv bits x)
    (has_type (I x) (SINT bits))
   )
   :pattern ((has_type (I x) (SINT bits)))
   :qid prelude_has_type_sint
   :skolemid skolem_prelude_has_type_sint
)))
(assert
 (forall ((bits Int) (x Int)) (!
   (=>
    (uInv bits x)
    (has_type (I x) (FLOAT bits))
   )
   :pattern ((has_type (I x) (FLOAT bits)))
   :qid prelude_has_type_float
   :skolemid skolem_prelude_has_type_float
)))
(assert
 (forall ((x Int)) (!
   (=>
    (charInv x)
    (has_type (I x) CHAR)
   )
   :pattern ((has_type (I x) CHAR))
   :qid prelude_has_type_char
   :skolemid skolem_prelude_has_type_char
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x NAT)
    (<= 0 (%I x))
   )
   :pattern ((has_type x NAT))
   :qid prelude_unbox_int
   :skolemid skolem_prelude_unbox_int
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x USIZE)
    (uInv SZ (%I x))
   )
   :pattern ((has_type x USIZE))
   :qid prelude_unbox_usize
   :skolemid skolem_prelude_unbox_usize
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x CHAR)
    (charInv (%I x))
   )
   :pattern ((has_type x CHAR))
   :qid prelude_unbox_char
   :skolemid skolem_prelude_unbox_char
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x ISIZE)
    (iInv SZ (%I x))
   )
   :pattern ((has_type x ISIZE))
   :qid prelude_unbox_isize
   :skolemid skolem_prelude_unbox_isize
)))
(assert
 (forall ((bits Int) (x Poly)) (!
   (=>
    (has_type x (UINT bits))
    (uInv bits (%I x))
   )
   :pattern ((has_type x (UINT bits)))
   :qid prelude_unbox_uint
   :skolemid skolem_prelude_unbox_uint
)))
(assert
 (forall ((bits Int) (x Poly)) (!
   (=>
    (has_type x (SINT bits))
    (iInv bits (%I x))
   )
   :pattern ((has_type x (SINT bits)))
   :qid prelude_unbox_sint
   :skolemid skolem_prelude_unbox_sint
)))
(assert
 (forall ((bits Int) (x Poly)) (!
   (=>
    (has_type x (FLOAT bits))
    (uInv bits (%I x))
   )
   :pattern ((has_type x (FLOAT bits)))
   :qid prelude_unbox_float
   :skolemid skolem_prelude_unbox_float
)))
(declare-fun Add (Int Int) Int)
(declare-fun Sub (Int Int) Int)
(declare-fun Mul (Int Int) Int)
(declare-fun EucDiv (Int Int) Int)
(declare-fun EucMod (Int Int) Int)
(declare-fun RAdd (Real Real) Real)
(declare-fun RSub (Real Real) Real)
(declare-fun RMul (Real Real) Real)
(declare-fun RDiv (Real Real) Real)
(assert
 (forall ((x Int) (y Int)) (!
   (= (Add x y) (+ x y))
   :pattern ((Add x y))
   :qid prelude_add
   :skolemid skolem_prelude_add
)))
(assert
 (forall ((x Int) (y Int)) (!
   (= (Sub x y) (- x y))
   :pattern ((Sub x y))
   :qid prelude_sub
   :skolemid skolem_prelude_sub
)))
(assert
 (forall ((x Int) (y Int)) (!
   (= (Mul x y) (* x y))
   :pattern ((Mul x y))
   :qid prelude_mul
   :skolemid skolem_prelude_mul
)))
(assert
 (forall ((x Int) (y Int)) (!
   (= (EucDiv x y) (div x y))
   :pattern ((EucDiv x y))
   :qid prelude_eucdiv
   :skolemid skolem_prelude_eucdiv
)))
(assert
 (forall ((x Int) (y Int)) (!
   (= (EucMod x y) (mod x y))
   :pattern ((EucMod x y))
   :qid prelude_eucmod
   :skolemid skolem_prelude_eucmod
)))
(assert
 (forall ((x Real) (y Real)) (!
   (= (RAdd x y) (+ x y))
   :pattern ((RAdd x y))
   :qid prelude_radd
   :skolemid skolem_prelude_radd
)))
(assert
 (forall ((x Real) (y Real)) (!
   (= (RSub x y) (- x y))
   :pattern ((RSub x y))
   :qid prelude_rsub
   :skolemid skolem_prelude_rsub
)))
(assert
 (forall ((x Real) (y Real)) (!
   (= (RMul x y) (* x y))
   :pattern ((RMul x y))
   :qid prelude_rmul
   :skolemid skolem_prelude_rmul
)))
(assert
 (forall ((x Real) (y Real)) (!
   (= (RDiv x y) (/ x y))
   :pattern ((RDiv x y))
   :qid prelude_rdiv
   :skolemid skolem_prelude_rdiv
)))
(assert
 (forall ((x Int) (y Int)) (!
   (=>
    (and
     (<= 0 x)
     (<= 0 y)
    )
    (<= 0 (Mul x y))
   )
   :pattern ((Mul x y))
   :qid prelude_mul_nats
   :skolemid skolem_prelude_mul_nats
)))
(assert
 (forall ((x Int) (y Int)) (!
   (=>
    (and
     (<= 0 x)
     (< 0 y)
    )
    (and
     (<= 0 (EucDiv x y))
     (<= (EucDiv x y) x)
   ))
   :pattern ((EucDiv x y))
   :qid prelude_div_unsigned_in_bounds
   :skolemid skolem_prelude_div_unsigned_in_bounds
)))
(assert
 (forall ((x Int) (y Int)) (!
   (=>
    (and
     (<= 0 x)
     (< 0 y)
    )
    (and
     (<= 0 (EucMod x y))
     (< (EucMod x y) y)
   ))
   :pattern ((EucMod x y))
   :qid prelude_mod_unsigned_in_bounds
   :skolemid skolem_prelude_mod_unsigned_in_bounds
)))
(declare-fun bitxor (Poly Poly) Int)
(declare-fun bitand (Poly Poly) Int)
(declare-fun bitor (Poly Poly) Int)
(declare-fun bitshr (Poly Poly) Int)
(declare-fun bitshl (Poly Poly) Int)
(declare-fun bitnot (Poly) Int)
(assert
 (forall ((x Poly) (y Poly) (bits Int)) (!
   (=>
    (and
     (uInv bits (%I x))
     (uInv bits (%I y))
    )
    (uInv bits (bitxor x y))
   )
   :pattern ((uClip bits (bitxor x y)))
   :qid prelude_bit_xor_u_inv
   :skolemid skolem_prelude_bit_xor_u_inv
)))
(assert
 (forall ((x Poly) (y Poly) (bits Int)) (!
   (=>
    (and
     (iInv bits (%I x))
     (iInv bits (%I y))
    )
    (iInv bits (bitxor x y))
   )
   :pattern ((iClip bits (bitxor x y)))
   :qid prelude_bit_xor_i_inv
   :skolemid skolem_prelude_bit_xor_i_inv
)))
(assert
 (forall ((x Poly) (y Poly) (bits Int)) (!
   (=>
    (and
     (uInv bits (%I x))
     (uInv bits (%I y))
    )
    (uInv bits (bitor x y))
   )
   :pattern ((uClip bits (bitor x y)))
   :qid prelude_bit_or_u_inv
   :skolemid skolem_prelude_bit_or_u_inv
)))
(assert
 (forall ((x Poly) (y Poly) (bits Int)) (!
   (=>
    (and
     (iInv bits (%I x))
     (iInv bits (%I y))
    )
    (iInv bits (bitor x y))
   )
   :pattern ((iClip bits (bitor x y)))
   :qid prelude_bit_or_i_inv
   :skolemid skolem_prelude_bit_or_i_inv
)))
(assert
 (forall ((x Poly) (y Poly) (bits Int)) (!
   (=>
    (and
     (uInv bits (%I x))
     (uInv bits (%I y))
    )
    (uInv bits (bitand x y))
   )
   :pattern ((uClip bits (bitand x y)))
   :qid prelude_bit_and_u_inv
   :skolemid skolem_prelude_bit_and_u_inv
)))
(assert
 (forall ((x Poly) (y Poly) (bits Int)) (!
   (=>
    (and
     (iInv bits (%I x))
     (iInv bits (%I y))
    )
    (iInv bits (bitand x y))
   )
   :pattern ((iClip bits (bitand x y)))
   :qid prelude_bit_and_i_inv
   :skolemid skolem_prelude_bit_and_i_inv
)))
(assert
 (forall ((x Poly) (y Poly) (bits Int)) (!
   (=>
    (and
     (uInv bits (%I x))
     (<= 0 (%I y))
    )
    (uInv bits (bitshr x y))
   )
   :pattern ((uClip bits (bitshr x y)))
   :qid prelude_bit_shr_u_inv
   :skolemid skolem_prelude_bit_shr_u_inv
)))
(assert
 (forall ((x Poly) (y Poly) (bits Int)) (!
   (=>
    (and
     (iInv bits (%I x))
     (<= 0 (%I y))
    )
    (iInv bits (bitshr x y))
   )
   :pattern ((iClip bits (bitshr x y)))
   :qid prelude_bit_shr_i_inv
   :skolemid skolem_prelude_bit_shr_i_inv
)))
(declare-fun singular_mod (Int Int) Int)
(assert
 (forall ((x Int) (y Int)) (!
   (=>
    (not (= y 0))
    (= (EucMod x y) (singular_mod x y))
   )
   :pattern ((singular_mod x y))
   :qid prelude_singularmod
   :skolemid skolem_prelude_singularmod
)))
(declare-fun has_resolved (Dcr Type Poly) Bool)
(declare-fun closure_req (Type Dcr Type Poly Poly) Bool)
(declare-fun closure_ens (Type Dcr Type Poly Poly Poly) Bool)
(declare-fun default_ens (Type Dcr Type Poly Poly Poly) Bool)
(declare-fun height (Poly) Height)
(declare-fun height_lt (Height Height) Bool)
(declare-fun fun_from_recursive_field (Poly) Poly)
(declare-fun check_decrease_height (Poly Poly Bool) Bool)
(assert
 (forall ((cur Poly) (prev Poly) (otherwise Bool)) (!
   (= (check_decrease_height cur prev otherwise) (or
     (height_lt (height cur) (height prev))
     (and
      (= (height cur) (height prev))
      otherwise
   )))
   :pattern ((check_decrease_height cur prev otherwise))
   :qid prelude_check_decrease_height
   :skolemid skolem_prelude_check_decrease_height
)))
(assert
 (forall ((cur Int) (prev Int)) (!
   (= (height_lt (height (I cur)) (height (I prev))) (and
     (<= 0 cur)
     (< cur prev)
   ))
   :pattern ((height_lt (height (I cur)) (height (I prev))))
   :qid prelude_check_decrease_int_height
   :skolemid skolem_prelude_check_decrease_int_height
)))
(assert
 (forall ((x Height) (y Height)) (!
   (= (height_lt x y) (and
     ((_ partial-order 0) x y)
     (not (= x y))
   ))
   :pattern ((height_lt x y))
   :qid prelude_height_lt
   :skolemid skolem_prelude_height_lt
)))

;; MODULE 'module Chap26::ScanDCMtPer::ScanDCMtPer'

;; Fuel
(declare-const fuel%vstd!wrapping.usize_specs.wrapping_add. FuelId)
(declare-const fuel%vstd!std_specs.vec.impl&%0.spec_index. FuelId)
(declare-const fuel%vstd!std_specs.vec.axiom_spec_len. FuelId)
(declare-const fuel%vstd!std_specs.vec.axiom_vec_index_decreases. FuelId)
(declare-const fuel%vstd!std_specs.vec.axiom_vec_has_resolved. FuelId)
(declare-const fuel%vstd!std_specs.vec.axiom_vec_decreases_to_view. FuelId)
(declare-const fuel%vstd!function.axiom_fn_mut_call_requires. FuelId)
(declare-const fuel%vstd!function.axiom_fn_mut_call_ensures. FuelId)
(declare-const fuel%vstd!pervasive.impl&%0.requires. FuelId)
(declare-const fuel%vstd!pervasive.impl&%0.ensures. FuelId)
(declare-const fuel%vstd!relations.associative. FuelId)
(declare-const fuel%vstd!seq.impl&%2.spec_index. FuelId)
(declare-const fuel%vstd!seq.impl&%2.take. FuelId)
(declare-const fuel%vstd!seq.impl&%2.skip. FuelId)
(declare-const fuel%vstd!seq.impl&%2.spec_add. FuelId)
(declare-const fuel%vstd!seq.Seq.last. FuelId)
(declare-const fuel%vstd!seq.lemma_seq_index_decreases. FuelId)
(declare-const fuel%vstd!seq.lemma_seq_subrange_decreases. FuelId)
(declare-const fuel%vstd!seq.lemma_seq_empty. FuelId)
(declare-const fuel%vstd!seq.lemma_seq_new_len. FuelId)
(declare-const fuel%vstd!seq.lemma_seq_new_index. FuelId)
(declare-const fuel%vstd!seq.lemma_seq_push_len. FuelId)
(declare-const fuel%vstd!seq.lemma_seq_push_index_same. FuelId)
(declare-const fuel%vstd!seq.lemma_seq_push_index_different. FuelId)
(declare-const fuel%vstd!seq.lemma_seq_ext_equal. FuelId)
(declare-const fuel%vstd!seq.lemma_seq_ext_equal_deep. FuelId)
(declare-const fuel%vstd!seq.lemma_seq_subrange_len. FuelId)
(declare-const fuel%vstd!seq.lemma_seq_subrange_index. FuelId)
(declare-const fuel%vstd!seq.lemma_seq_two_subranges_index. FuelId)
(declare-const fuel%vstd!seq.lemma_seq_add_len. FuelId)
(declare-const fuel%vstd!seq.lemma_seq_add_index1. FuelId)
(declare-const fuel%vstd!seq.lemma_seq_add_index2. FuelId)
(declare-const fuel%vstd!seq_lib.impl&%0.map. FuelId)
(declare-const fuel%vstd!seq_lib.impl&%0.add_empty_left. FuelId)
(declare-const fuel%vstd!seq_lib.impl&%0.add_empty_right. FuelId)
(declare-const fuel%vstd!seq_lib.impl&%0.push_distributes_over_add. FuelId)
(declare-const fuel%vstd!seq_lib.impl&%0.drop_last. FuelId)
(declare-const fuel%vstd!seq_lib.impl&%0.fold_left. FuelId)
(declare-const fuel%vstd!seq_lib.impl&%0.lemma_fold_left_split. FuelId)
(declare-const fuel%vstd!seq_lib.lemma_seq_empty_equality. FuelId)
(declare-const fuel%vstd!seq_lib.lemma_seq_take_len. FuelId)
(declare-const fuel%vstd!seq_lib.lemma_seq_take_index. FuelId)
(declare-const fuel%vstd!seq_lib.lemma_seq_skip_len. FuelId)
(declare-const fuel%vstd!seq_lib.lemma_seq_skip_index. FuelId)
(declare-const fuel%vstd!seq_lib.lemma_seq_skip_index2. FuelId)
(declare-const fuel%vstd!seq_lib.lemma_seq_append_take_skip. FuelId)
(declare-const fuel%vstd!seq_lib.lemma_seq_skip_build_commut. FuelId)
(declare-const fuel%vstd!seq_lib.lemma_seq_skip_nothing. FuelId)
(declare-const fuel%vstd!seq_lib.lemma_seq_take_nothing. FuelId)
(declare-const fuel%vstd!view.impl&%0.view. FuelId)
(declare-const fuel%vstd!view.impl&%2.view. FuelId)
(declare-const fuel%vstd!view.impl&%4.view. FuelId)
(declare-const fuel%vstd!view.impl&%6.view. FuelId)
(declare-const fuel%vstd!view.impl&%16.view. FuelId)
(declare-const fuel%vstd!view.impl&%18.view. FuelId)
(declare-const fuel%vstd!view.impl&%30.view. FuelId)
(declare-const fuel%vstd!view.impl&%48.view. FuelId)
(declare-const fuel%lib!vstdplus.monoid.monoid.spec_left_identity. FuelId)
(declare-const fuel%lib!vstdplus.monoid.monoid.spec_right_identity. FuelId)
(declare-const fuel%lib!vstdplus.monoid.monoid.spec_monoid. FuelId)
(declare-const fuel%lib!Chap18.ArraySeqSpecsAndLemmas.ArraySeqSpecsAndLemmas.spec_iterate.
 FuelId
)
(declare-const fuel%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.impl&%2.view. FuelId)
(declare-const fuel%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.impl&%3.spec_arrayseqmtper_wf.
 FuelId
)
(declare-const fuel%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.impl&%3.spec_len. FuelId)
(declare-const fuel%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.impl&%3.spec_index. FuelId)
(declare-const fuel%lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_wrapping_add. FuelId)
(declare-const fuel%lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_sum_fn. FuelId)
(declare-const fuel%lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_scan_at. FuelId)
(declare-const fuel%lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_scan_post. FuelId)
(declare-const fuel%vstd!array.group_array_axioms. FuelId)
(declare-const fuel%vstd!function.group_function_axioms. FuelId)
(declare-const fuel%vstd!imap.group_imap_lemmas. FuelId)
(declare-const fuel%vstd!iset.group_iset_lemmas. FuelId)
(declare-const fuel%vstd!laws_cmp.group_laws_cmp. FuelId)
(declare-const fuel%vstd!laws_eq.bool_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.u8_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.i8_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.u16_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.i16_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.u32_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.i32_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.u64_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.i64_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.u128_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.i128_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.usize_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.isize_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_1_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_2_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_3_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_4_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_5_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_6_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_7_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_8_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_9_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_10_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_11_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_12_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.group_laws_eq. FuelId)
(declare-const fuel%vstd!layout.group_align_properties. FuelId)
(declare-const fuel%vstd!layout.group_layout_axioms. FuelId)
(declare-const fuel%vstd!map.group_map_lemmas. FuelId)
(declare-const fuel%vstd!multiset.group_multiset_axioms. FuelId)
(declare-const fuel%vstd!mut_ref.group_mut_ref_axioms. FuelId)
(declare-const fuel%vstd!raw_ptr.group_raw_ptr_axioms. FuelId)
(declare-const fuel%vstd!seq.group_seq_axioms. FuelId)
(declare-const fuel%vstd!seq.group_seq_lemmas. FuelId)
(declare-const fuel%vstd!seq_lib.group_filter_ensures. FuelId)
(declare-const fuel%vstd!seq_lib.group_seq_lib_default. FuelId)
(declare-const fuel%vstd!seq_lib.group_to_multiset_ensures. FuelId)
(declare-const fuel%vstd!seq_lib.group_seq_properties. FuelId)
(declare-const fuel%vstd!set.group_set_lemmas. FuelId)
(declare-const fuel%vstd!set_lib.group_set_lib_default. FuelId)
(declare-const fuel%vstd!slice.group_slice_axioms. FuelId)
(declare-const fuel%vstd!string.group_string_axioms. FuelId)
(declare-const fuel%vstd!std_specs.bits.group_bits_axioms. FuelId)
(declare-const fuel%vstd!std_specs.control_flow.group_control_flow_axioms. FuelId)
(declare-const fuel%vstd!std_specs.fmt.group_fmt_axioms. FuelId)
(declare-const fuel%vstd!std_specs.iter.group_iter_axioms. FuelId)
(declare-const fuel%vstd!std_specs.manually_drop.group_manually_drop_axioms. FuelId)
(declare-const fuel%vstd!std_specs.btree.group_btree_axioms. FuelId)
(declare-const fuel%vstd!std_specs.hash.group_hash_axioms. FuelId)
(declare-const fuel%vstd!std_specs.range.group_range_axioms. FuelId)
(declare-const fuel%vstd!std_specs.vec.group_vec_axioms. FuelId)
(declare-const fuel%vstd!std_specs.vecdeque.group_vec_dequeue_axioms. FuelId)
(declare-const fuel%vstd!std_specs.nonzero.group_nonzero_axioms. FuelId)
(declare-const fuel%vstd!group_vstd_default. FuelId)
(declare-const fuel%lib!vstdplus.feq.feq.group_feq_axioms. FuelId)
(assert
 (distinct fuel%vstd!wrapping.usize_specs.wrapping_add. fuel%vstd!std_specs.vec.impl&%0.spec_index.
  fuel%vstd!std_specs.vec.axiom_spec_len. fuel%vstd!std_specs.vec.axiom_vec_index_decreases.
  fuel%vstd!std_specs.vec.axiom_vec_has_resolved. fuel%vstd!std_specs.vec.axiom_vec_decreases_to_view.
  fuel%vstd!function.axiom_fn_mut_call_requires. fuel%vstd!function.axiom_fn_mut_call_ensures.
  fuel%vstd!pervasive.impl&%0.requires. fuel%vstd!pervasive.impl&%0.ensures. fuel%vstd!relations.associative.
  fuel%vstd!seq.impl&%2.spec_index. fuel%vstd!seq.impl&%2.take. fuel%vstd!seq.impl&%2.skip.
  fuel%vstd!seq.impl&%2.spec_add. fuel%vstd!seq.Seq.last. fuel%vstd!seq.lemma_seq_index_decreases.
  fuel%vstd!seq.lemma_seq_subrange_decreases. fuel%vstd!seq.lemma_seq_empty. fuel%vstd!seq.lemma_seq_new_len.
  fuel%vstd!seq.lemma_seq_new_index. fuel%vstd!seq.lemma_seq_push_len. fuel%vstd!seq.lemma_seq_push_index_same.
  fuel%vstd!seq.lemma_seq_push_index_different. fuel%vstd!seq.lemma_seq_ext_equal.
  fuel%vstd!seq.lemma_seq_ext_equal_deep. fuel%vstd!seq.lemma_seq_subrange_len. fuel%vstd!seq.lemma_seq_subrange_index.
  fuel%vstd!seq.lemma_seq_two_subranges_index. fuel%vstd!seq.lemma_seq_add_len. fuel%vstd!seq.lemma_seq_add_index1.
  fuel%vstd!seq.lemma_seq_add_index2. fuel%vstd!seq_lib.impl&%0.map. fuel%vstd!seq_lib.impl&%0.add_empty_left.
  fuel%vstd!seq_lib.impl&%0.add_empty_right. fuel%vstd!seq_lib.impl&%0.push_distributes_over_add.
  fuel%vstd!seq_lib.impl&%0.drop_last. fuel%vstd!seq_lib.impl&%0.fold_left. fuel%vstd!seq_lib.impl&%0.lemma_fold_left_split.
  fuel%vstd!seq_lib.lemma_seq_empty_equality. fuel%vstd!seq_lib.lemma_seq_take_len.
  fuel%vstd!seq_lib.lemma_seq_take_index. fuel%vstd!seq_lib.lemma_seq_skip_len. fuel%vstd!seq_lib.lemma_seq_skip_index.
  fuel%vstd!seq_lib.lemma_seq_skip_index2. fuel%vstd!seq_lib.lemma_seq_append_take_skip.
  fuel%vstd!seq_lib.lemma_seq_skip_build_commut. fuel%vstd!seq_lib.lemma_seq_skip_nothing.
  fuel%vstd!seq_lib.lemma_seq_take_nothing. fuel%vstd!view.impl&%0.view. fuel%vstd!view.impl&%2.view.
  fuel%vstd!view.impl&%4.view. fuel%vstd!view.impl&%6.view. fuel%vstd!view.impl&%16.view.
  fuel%vstd!view.impl&%18.view. fuel%vstd!view.impl&%30.view. fuel%vstd!view.impl&%48.view.
  fuel%lib!vstdplus.monoid.monoid.spec_left_identity. fuel%lib!vstdplus.monoid.monoid.spec_right_identity.
  fuel%lib!vstdplus.monoid.monoid.spec_monoid. fuel%lib!Chap18.ArraySeqSpecsAndLemmas.ArraySeqSpecsAndLemmas.spec_iterate.
  fuel%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.impl&%2.view. fuel%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.impl&%3.spec_arrayseqmtper_wf.
  fuel%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.impl&%3.spec_len. fuel%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.impl&%3.spec_index.
  fuel%lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_wrapping_add. fuel%lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_sum_fn.
  fuel%lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_scan_at. fuel%lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_scan_post.
  fuel%vstd!array.group_array_axioms. fuel%vstd!function.group_function_axioms. fuel%vstd!imap.group_imap_lemmas.
  fuel%vstd!iset.group_iset_lemmas. fuel%vstd!laws_cmp.group_laws_cmp. fuel%vstd!laws_eq.bool_laws.group_laws_eq.
  fuel%vstd!laws_eq.u8_laws.group_laws_eq. fuel%vstd!laws_eq.i8_laws.group_laws_eq.
  fuel%vstd!laws_eq.u16_laws.group_laws_eq. fuel%vstd!laws_eq.i16_laws.group_laws_eq.
  fuel%vstd!laws_eq.u32_laws.group_laws_eq. fuel%vstd!laws_eq.i32_laws.group_laws_eq.
  fuel%vstd!laws_eq.u64_laws.group_laws_eq. fuel%vstd!laws_eq.i64_laws.group_laws_eq.
  fuel%vstd!laws_eq.u128_laws.group_laws_eq. fuel%vstd!laws_eq.i128_laws.group_laws_eq.
  fuel%vstd!laws_eq.usize_laws.group_laws_eq. fuel%vstd!laws_eq.isize_laws.group_laws_eq.
  fuel%vstd!laws_eq.tuple_1_laws.group_laws_eq. fuel%vstd!laws_eq.tuple_2_laws.group_laws_eq.
  fuel%vstd!laws_eq.tuple_3_laws.group_laws_eq. fuel%vstd!laws_eq.tuple_4_laws.group_laws_eq.
  fuel%vstd!laws_eq.tuple_5_laws.group_laws_eq. fuel%vstd!laws_eq.tuple_6_laws.group_laws_eq.
  fuel%vstd!laws_eq.tuple_7_laws.group_laws_eq. fuel%vstd!laws_eq.tuple_8_laws.group_laws_eq.
  fuel%vstd!laws_eq.tuple_9_laws.group_laws_eq. fuel%vstd!laws_eq.tuple_10_laws.group_laws_eq.
  fuel%vstd!laws_eq.tuple_11_laws.group_laws_eq. fuel%vstd!laws_eq.tuple_12_laws.group_laws_eq.
  fuel%vstd!laws_eq.group_laws_eq. fuel%vstd!layout.group_align_properties. fuel%vstd!layout.group_layout_axioms.
  fuel%vstd!map.group_map_lemmas. fuel%vstd!multiset.group_multiset_axioms. fuel%vstd!mut_ref.group_mut_ref_axioms.
  fuel%vstd!raw_ptr.group_raw_ptr_axioms. fuel%vstd!seq.group_seq_axioms. fuel%vstd!seq.group_seq_lemmas.
  fuel%vstd!seq_lib.group_filter_ensures. fuel%vstd!seq_lib.group_seq_lib_default.
  fuel%vstd!seq_lib.group_to_multiset_ensures. fuel%vstd!seq_lib.group_seq_properties.
  fuel%vstd!set.group_set_lemmas. fuel%vstd!set_lib.group_set_lib_default. fuel%vstd!slice.group_slice_axioms.
  fuel%vstd!string.group_string_axioms. fuel%vstd!std_specs.bits.group_bits_axioms.
  fuel%vstd!std_specs.control_flow.group_control_flow_axioms. fuel%vstd!std_specs.fmt.group_fmt_axioms.
  fuel%vstd!std_specs.iter.group_iter_axioms. fuel%vstd!std_specs.manually_drop.group_manually_drop_axioms.
  fuel%vstd!std_specs.btree.group_btree_axioms. fuel%vstd!std_specs.hash.group_hash_axioms.
  fuel%vstd!std_specs.range.group_range_axioms. fuel%vstd!std_specs.vec.group_vec_axioms.
  fuel%vstd!std_specs.vecdeque.group_vec_dequeue_axioms. fuel%vstd!std_specs.nonzero.group_nonzero_axioms.
  fuel%vstd!group_vstd_default. fuel%lib!vstdplus.feq.feq.group_feq_axioms.
))
(assert
 (=>
  (fuel_bool_default fuel%vstd!function.group_function_axioms.)
  (and
   (fuel_bool_default fuel%vstd!function.axiom_fn_mut_call_requires.)
   (fuel_bool_default fuel%vstd!function.axiom_fn_mut_call_ensures.)
)))
(assert
 (=>
  (fuel_bool_default fuel%vstd!laws_eq.group_laws_eq.)
  (and
   (fuel_bool_default fuel%vstd!laws_eq.bool_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.u8_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.i8_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.u16_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.i16_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.u32_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.i32_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.u64_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.i64_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.u128_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.i128_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.usize_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.isize_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_1_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_2_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_3_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_4_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_5_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_6_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_7_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_8_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_9_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_10_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_11_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_12_laws.group_laws_eq.)
)))
(assert
 (=>
  (fuel_bool_default fuel%vstd!layout.group_layout_axioms.)
  (fuel_bool_default fuel%vstd!layout.group_align_properties.)
))
(assert
 (=>
  (fuel_bool_default fuel%vstd!seq.group_seq_axioms.)
  (and
   (fuel_bool_default fuel%vstd!seq.lemma_seq_index_decreases.)
   (fuel_bool_default fuel%vstd!seq.lemma_seq_subrange_decreases.)
   (fuel_bool_default fuel%vstd!seq.lemma_seq_empty.)
   (fuel_bool_default fuel%vstd!seq.lemma_seq_new_len.)
   (fuel_bool_default fuel%vstd!seq.lemma_seq_new_index.)
   (fuel_bool_default fuel%vstd!seq.lemma_seq_push_len.)
   (fuel_bool_default fuel%vstd!seq.lemma_seq_push_index_same.)
   (fuel_bool_default fuel%vstd!seq.lemma_seq_push_index_different.)
   (fuel_bool_default fuel%vstd!seq.lemma_seq_ext_equal.)
   (fuel_bool_default fuel%vstd!seq.lemma_seq_ext_equal_deep.)
   (fuel_bool_default fuel%vstd!seq.lemma_seq_subrange_len.)
   (fuel_bool_default fuel%vstd!seq.lemma_seq_subrange_index.)
   (fuel_bool_default fuel%vstd!seq.lemma_seq_two_subranges_index.)
   (fuel_bool_default fuel%vstd!seq.lemma_seq_add_len.)
   (fuel_bool_default fuel%vstd!seq.lemma_seq_add_index1.)
   (fuel_bool_default fuel%vstd!seq.lemma_seq_add_index2.)
)))
(assert
 (=>
  (fuel_bool_default fuel%vstd!seq.group_seq_lemmas.)
  (and
   (fuel_bool_default fuel%vstd!seq.lemma_seq_index_decreases.)
   (fuel_bool_default fuel%vstd!seq.lemma_seq_subrange_decreases.)
   (fuel_bool_default fuel%vstd!seq.lemma_seq_empty.)
   (fuel_bool_default fuel%vstd!seq.lemma_seq_new_len.)
   (fuel_bool_default fuel%vstd!seq.lemma_seq_new_index.)
   (fuel_bool_default fuel%vstd!seq.lemma_seq_push_len.)
   (fuel_bool_default fuel%vstd!seq.lemma_seq_push_index_same.)
   (fuel_bool_default fuel%vstd!seq.lemma_seq_push_index_different.)
   (fuel_bool_default fuel%vstd!seq.lemma_seq_ext_equal.)
   (fuel_bool_default fuel%vstd!seq.lemma_seq_ext_equal_deep.)
   (fuel_bool_default fuel%vstd!seq.lemma_seq_subrange_len.)
   (fuel_bool_default fuel%vstd!seq.lemma_seq_subrange_index.)
   (fuel_bool_default fuel%vstd!seq.lemma_seq_two_subranges_index.)
   (fuel_bool_default fuel%vstd!seq.lemma_seq_add_len.)
   (fuel_bool_default fuel%vstd!seq.lemma_seq_add_index1.)
   (fuel_bool_default fuel%vstd!seq.lemma_seq_add_index2.)
)))
(assert
 (=>
  (fuel_bool_default fuel%vstd!seq_lib.group_seq_lib_default.)
  (and
   (fuel_bool_default fuel%vstd!seq_lib.group_filter_ensures.)
   (fuel_bool_default fuel%vstd!seq_lib.impl&%0.add_empty_left.)
   (fuel_bool_default fuel%vstd!seq_lib.impl&%0.add_empty_right.)
   (fuel_bool_default fuel%vstd!seq_lib.impl&%0.push_distributes_over_add.)
   (fuel_bool_default fuel%vstd!seq_lib.impl&%0.lemma_fold_left_split.)
)))
(assert
 (=>
  (fuel_bool_default fuel%vstd!seq_lib.group_seq_properties.)
  (and
   (fuel_bool_default fuel%vstd!seq_lib.lemma_seq_empty_equality.)
   (fuel_bool_default fuel%vstd!seq_lib.lemma_seq_take_len.)
   (fuel_bool_default fuel%vstd!seq_lib.lemma_seq_take_index.)
   (fuel_bool_default fuel%vstd!seq_lib.lemma_seq_skip_len.)
   (fuel_bool_default fuel%vstd!seq_lib.lemma_seq_skip_index.)
   (fuel_bool_default fuel%vstd!seq_lib.lemma_seq_skip_index2.)
   (fuel_bool_default fuel%vstd!seq_lib.lemma_seq_append_take_skip.)
   (fuel_bool_default fuel%vstd!seq_lib.lemma_seq_skip_build_commut.)
   (fuel_bool_default fuel%vstd!seq_lib.lemma_seq_skip_nothing.)
   (fuel_bool_default fuel%vstd!seq_lib.lemma_seq_take_nothing.)
   (fuel_bool_default fuel%vstd!seq_lib.group_to_multiset_ensures.)
)))
(assert
 (=>
  (fuel_bool_default fuel%vstd!std_specs.vec.group_vec_axioms.)
  (and
   (fuel_bool_default fuel%vstd!std_specs.vec.axiom_spec_len.)
   (fuel_bool_default fuel%vstd!std_specs.vec.axiom_vec_index_decreases.)
   (fuel_bool_default fuel%vstd!std_specs.vec.axiom_vec_has_resolved.)
   (fuel_bool_default fuel%vstd!std_specs.vec.axiom_vec_decreases_to_view.)
)))
(assert
 (fuel_bool_default fuel%vstd!group_vstd_default.)
)
(assert
 (=>
  (fuel_bool_default fuel%vstd!group_vstd_default.)
  (and
   (fuel_bool_default fuel%vstd!seq.group_seq_lemmas.)
   (fuel_bool_default fuel%vstd!seq_lib.group_seq_lib_default.)
   (fuel_bool_default fuel%vstd!map.group_map_lemmas.)
   (fuel_bool_default fuel%vstd!set.group_set_lemmas.)
   (fuel_bool_default fuel%vstd!imap.group_imap_lemmas.)
   (fuel_bool_default fuel%vstd!iset.group_iset_lemmas.)
   (fuel_bool_default fuel%vstd!set_lib.group_set_lib_default.)
   (fuel_bool_default fuel%vstd!multiset.group_multiset_axioms.)
   (fuel_bool_default fuel%vstd!function.group_function_axioms.)
   (fuel_bool_default fuel%vstd!laws_eq.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_cmp.group_laws_cmp.)
   (fuel_bool_default fuel%vstd!slice.group_slice_axioms.)
   (fuel_bool_default fuel%vstd!array.group_array_axioms.)
   (fuel_bool_default fuel%vstd!string.group_string_axioms.)
   (fuel_bool_default fuel%vstd!raw_ptr.group_raw_ptr_axioms.)
   (fuel_bool_default fuel%vstd!layout.group_layout_axioms.)
   (fuel_bool_default fuel%vstd!mut_ref.group_mut_ref_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.range.group_range_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.bits.group_bits_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.control_flow.group_control_flow_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.fmt.group_fmt_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.manually_drop.group_manually_drop_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.iter.group_iter_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.vec.group_vec_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.vecdeque.group_vec_dequeue_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.hash.group_hash_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.btree.group_btree_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.nonzero.group_nonzero_axioms.)
)))
(assert
 (and
  (fuel_bool_default fuel%vstd!std_specs.vec.group_vec_axioms.)
  (fuel_bool_default fuel%vstd!seq.group_seq_axioms.)
  (fuel_bool_default fuel%lib!vstdplus.feq.feq.group_feq_axioms.)
  (fuel_bool_default fuel%vstd!seq_lib.group_seq_properties.)
  (fuel_bool_default fuel%vstd!seq_lib.group_to_multiset_ensures.)
))

;; Trait-Decls
(declare-fun tr_bound%vstd!pervasive.FnWithRequiresEnsures. (Dcr Type Dcr Type Dcr
  Type
 ) Bool
)
(declare-fun tr_bound%vstd!view.View. (Dcr Type) Bool)
(declare-fun tr_bound%core!marker.Tuple. (Dcr Type) Bool)
(declare-fun tr_bound%core!ops.function.FnOnce. (Dcr Type Dcr Type) Bool)
(declare-fun tr_bound%core!ops.function.FnMut. (Dcr Type Dcr Type) Bool)
(declare-fun tr_bound%core!ops.function.Fn. (Dcr Type Dcr Type) Bool)
(declare-fun tr_bound%core!alloc.Allocator. (Dcr Type) Bool)
(declare-fun tr_bound%vstd!std_specs.vec.VecAdditionalSpecFns. (Dcr Type Dcr Type)
 Bool
)
(declare-fun tr_bound%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.
 (Dcr Type Dcr Type) Bool
)
(declare-fun tr_bound%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerRedefinableTrait.
 (Dcr Type Dcr Type) Bool
)
(declare-fun tr_bound%lib!Chap26.ScanDCMtPer.ScanDCMtPer.ScanDCMtTrait. (Dcr Type)
 Bool
)

;; Associated-Type-Decls
(declare-fun proj%%vstd!view.View./V (Dcr Type) Dcr)
(declare-fun proj%vstd!view.View./V (Dcr Type) Type)
(declare-fun proj%%core!ops.function.FnOnce./Output (Dcr Type Dcr Type) Dcr)
(declare-fun proj%core!ops.function.FnOnce./Output (Dcr Type Dcr Type) Type)

;; Datatypes
(declare-sort anonymous_closure%29498. 0)
(declare-sort anonymous_closure%29501. 0)
(declare-sort anonymous_closure%29504. 0)
(declare-sort anonymous_closure%29509. 0)
(declare-sort alloc!alloc.Global. 0)
(declare-sort alloc!vec.Vec<usize./alloc!alloc.Global.>. 0)
(declare-sort vstd!seq.Seq<usize.>. 0)
(declare-datatypes ((lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. 0) (tuple%0.
   0
  ) (tuple%2. 0)
 ) (((lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS./ArraySeqMtPerS (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS./ArraySeqMtPerS/?seq
     Poly
   ))
  ) ((tuple%0./tuple%0)) ((tuple%2./tuple%2 (tuple%2./tuple%2/?0 Poly) (tuple%2./tuple%2/?1
     Poly
)))))
(declare-fun lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS./ArraySeqMtPerS/seq
 (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.) Poly
)
(declare-fun tuple%2./tuple%2/0 (tuple%2.) Poly)
(declare-fun tuple%2./tuple%2/1 (tuple%2.) Poly)
(declare-fun TYPE%fun%1. (Dcr Type Dcr Type) Type)
(declare-fun TYPE%fun%2. (Dcr Type Dcr Type Dcr Type) Type)
(declare-const TYPE%alloc!alloc.Global. Type)
(declare-fun TYPE%alloc!vec.Vec. (Dcr Type Dcr Type) Type)
(declare-fun TYPE%vstd!seq.Seq. (Dcr Type) Type)
(declare-fun TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. (Dcr Type)
 Type
)
(declare-fun TYPE%tuple%2. (Dcr Type Dcr Type) Type)
(declare-const TYPE%anonymous_closure%29498. Type)
(declare-const TYPE%anonymous_closure%29501. Type)
(declare-const TYPE%anonymous_closure%29504. Type)
(declare-const TYPE%anonymous_closure%29509. Type)
(declare-fun Poly%fun%1. (%%Function%%) Poly)
(declare-fun %Poly%fun%1. (Poly) %%Function%%)
(declare-fun Poly%fun%2. (%%Function%%) Poly)
(declare-fun %Poly%fun%2. (Poly) %%Function%%)
(declare-fun Poly%anonymous_closure%29498. (anonymous_closure%29498.) Poly)
(declare-fun %Poly%anonymous_closure%29498. (Poly) anonymous_closure%29498.)
(declare-fun Poly%anonymous_closure%29501. (anonymous_closure%29501.) Poly)
(declare-fun %Poly%anonymous_closure%29501. (Poly) anonymous_closure%29501.)
(declare-fun Poly%anonymous_closure%29504. (anonymous_closure%29504.) Poly)
(declare-fun %Poly%anonymous_closure%29504. (Poly) anonymous_closure%29504.)
(declare-fun Poly%anonymous_closure%29509. (anonymous_closure%29509.) Poly)
(declare-fun %Poly%anonymous_closure%29509. (Poly) anonymous_closure%29509.)
(declare-fun Poly%alloc!alloc.Global. (alloc!alloc.Global.) Poly)
(declare-fun %Poly%alloc!alloc.Global. (Poly) alloc!alloc.Global.)
(declare-fun Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. (alloc!vec.Vec<usize./alloc!alloc.Global.>.)
 Poly
)
(declare-fun %Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. (Poly) alloc!vec.Vec<usize./alloc!alloc.Global.>.)
(declare-fun Poly%vstd!seq.Seq<usize.>. (vstd!seq.Seq<usize.>.) Poly)
(declare-fun %Poly%vstd!seq.Seq<usize.>. (Poly) vstd!seq.Seq<usize.>.)
(declare-fun Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.)
 Poly
)
(declare-fun %Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. (Poly) lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.)
(declare-fun Poly%tuple%0. (tuple%0.) Poly)
(declare-fun %Poly%tuple%0. (Poly) tuple%0.)
(declare-fun Poly%tuple%2. (tuple%2.) Poly)
(declare-fun %Poly%tuple%2. (Poly) tuple%2.)
(assert
 (forall ((x %%Function%%)) (!
   (= x (%Poly%fun%1. (Poly%fun%1. x)))
   :pattern ((Poly%fun%1. x))
   :qid internal_crate__fun__1_box_axiom_definition
   :skolemid skolem_internal_crate__fun__1_box_axiom_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%fun%1. T%0&. T%0& T%1&. T%1&))
    (= x (Poly%fun%1. (%Poly%fun%1. x)))
   )
   :pattern ((has_type x (TYPE%fun%1. T%0&. T%0& T%1&. T%1&)))
   :qid internal_crate__fun__1_unbox_axiom_definition
   :skolemid skolem_internal_crate__fun__1_unbox_axiom_definition
)))
(declare-fun %%apply%%0 (%%Function%% Poly) Poly)
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (x %%Function%%)) (!
   (=>
    (forall ((T%0 Poly)) (!
      (=>
       (has_type T%0 T%0&)
       (has_type (%%apply%%0 x T%0) T%1&)
      )
      :pattern ((has_type (%%apply%%0 x T%0) T%1&))
      :qid internal_crate__fun__1_constructor_inner_definition
      :skolemid skolem_internal_crate__fun__1_constructor_inner_definition
    ))
    (has_type (Poly%fun%1. (mk_fun x)) (TYPE%fun%1. T%0&. T%0& T%1&. T%1&))
   )
   :pattern ((has_type (Poly%fun%1. (mk_fun x)) (TYPE%fun%1. T%0&. T%0& T%1&. T%1&)))
   :qid internal_crate__fun__1_constructor_definition
   :skolemid skolem_internal_crate__fun__1_constructor_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (T%0 Poly) (x %%Function%%))
  (!
   (=>
    (and
     (has_type (Poly%fun%1. x) (TYPE%fun%1. T%0&. T%0& T%1&. T%1&))
     (has_type T%0 T%0&)
    )
    (has_type (%%apply%%0 x T%0) T%1&)
   )
   :pattern ((%%apply%%0 x T%0) (has_type (Poly%fun%1. x) (TYPE%fun%1. T%0&. T%0& T%1&.
      T%1&
   )))
   :qid internal_crate__fun__1_apply_definition
   :skolemid skolem_internal_crate__fun__1_apply_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (T%0 Poly) (x %%Function%%))
  (!
   (=>
    (and
     (has_type (Poly%fun%1. x) (TYPE%fun%1. T%0&. T%0& T%1&. T%1&))
     (has_type T%0 T%0&)
    )
    (height_lt (height (%%apply%%0 x T%0)) (height (fun_from_recursive_field (Poly%fun%1.
        (mk_fun x)
   )))))
   :pattern ((height (%%apply%%0 x T%0)) (has_type (Poly%fun%1. x) (TYPE%fun%1. T%0&. T%0&
      T%1&. T%1&
   )))
   :qid internal_crate__fun__1_height_apply_definition
   :skolemid skolem_internal_crate__fun__1_height_apply_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (deep Bool) (x Poly) (y Poly))
  (!
   (=>
    (and
     (has_type x (TYPE%fun%1. T%0&. T%0& T%1&. T%1&))
     (has_type y (TYPE%fun%1. T%0&. T%0& T%1&. T%1&))
     (forall ((T%0 Poly)) (!
       (=>
        (has_type T%0 T%0&)
        (ext_eq deep T%1& (%%apply%%0 (%Poly%fun%1. x) T%0) (%%apply%%0 (%Poly%fun%1. y) T%0))
       )
       :pattern ((ext_eq deep T%1& (%%apply%%0 (%Poly%fun%1. x) T%0) (%%apply%%0 (%Poly%fun%1.
           y
          ) T%0
       )))
       :qid internal_crate__fun__1_inner_ext_equal_definition
       :skolemid skolem_internal_crate__fun__1_inner_ext_equal_definition
    )))
    (ext_eq deep (TYPE%fun%1. T%0&. T%0& T%1&. T%1&) x y)
   )
   :pattern ((ext_eq deep (TYPE%fun%1. T%0&. T%0& T%1&. T%1&) x y))
   :qid internal_crate__fun__1_ext_equal_definition
   :skolemid skolem_internal_crate__fun__1_ext_equal_definition
)))
(assert
 (forall ((x %%Function%%)) (!
   (= x (%Poly%fun%2. (Poly%fun%2. x)))
   :pattern ((Poly%fun%2. x))
   :qid internal_crate__fun__2_box_axiom_definition
   :skolemid skolem_internal_crate__fun__2_box_axiom_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (T%2&. Dcr) (T%2& Type) (x
    Poly
   )
  ) (!
   (=>
    (has_type x (TYPE%fun%2. T%0&. T%0& T%1&. T%1& T%2&. T%2&))
    (= x (Poly%fun%2. (%Poly%fun%2. x)))
   )
   :pattern ((has_type x (TYPE%fun%2. T%0&. T%0& T%1&. T%1& T%2&. T%2&)))
   :qid internal_crate__fun__2_unbox_axiom_definition
   :skolemid skolem_internal_crate__fun__2_unbox_axiom_definition
)))
(declare-fun %%apply%%1 (%%Function%% Poly Poly) Poly)
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (T%2&. Dcr) (T%2& Type) (x
    %%Function%%
   )
  ) (!
   (=>
    (forall ((T%0 Poly) (T%1 Poly)) (!
      (=>
       (and
        (has_type T%0 T%0&)
        (has_type T%1 T%1&)
       )
       (has_type (%%apply%%1 x T%0 T%1) T%2&)
      )
      :pattern ((has_type (%%apply%%1 x T%0 T%1) T%2&))
      :qid internal_crate__fun__2_constructor_inner_definition
      :skolemid skolem_internal_crate__fun__2_constructor_inner_definition
    ))
    (has_type (Poly%fun%2. (mk_fun x)) (TYPE%fun%2. T%0&. T%0& T%1&. T%1& T%2&. T%2&))
   )
   :pattern ((has_type (Poly%fun%2. (mk_fun x)) (TYPE%fun%2. T%0&. T%0& T%1&. T%1& T%2&.
      T%2&
   )))
   :qid internal_crate__fun__2_constructor_definition
   :skolemid skolem_internal_crate__fun__2_constructor_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (T%2&. Dcr) (T%2& Type) (T%0
    Poly
   ) (T%1 Poly) (x %%Function%%)
  ) (!
   (=>
    (and
     (has_type (Poly%fun%2. x) (TYPE%fun%2. T%0&. T%0& T%1&. T%1& T%2&. T%2&))
     (has_type T%0 T%0&)
     (has_type T%1 T%1&)
    )
    (has_type (%%apply%%1 x T%0 T%1) T%2&)
   )
   :pattern ((%%apply%%1 x T%0 T%1) (has_type (Poly%fun%2. x) (TYPE%fun%2. T%0&. T%0& T%1&.
      T%1& T%2&. T%2&
   )))
   :qid internal_crate__fun__2_apply_definition
   :skolemid skolem_internal_crate__fun__2_apply_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (T%2&. Dcr) (T%2& Type) (T%0
    Poly
   ) (T%1 Poly) (x %%Function%%)
  ) (!
   (=>
    (and
     (has_type (Poly%fun%2. x) (TYPE%fun%2. T%0&. T%0& T%1&. T%1& T%2&. T%2&))
     (has_type T%0 T%0&)
     (has_type T%1 T%1&)
    )
    (height_lt (height (%%apply%%1 x T%0 T%1)) (height (fun_from_recursive_field (Poly%fun%2.
        (mk_fun x)
   )))))
   :pattern ((height (%%apply%%1 x T%0 T%1)) (has_type (Poly%fun%2. x) (TYPE%fun%2. T%0&.
      T%0& T%1&. T%1& T%2&. T%2&
   )))
   :qid internal_crate__fun__2_height_apply_definition
   :skolemid skolem_internal_crate__fun__2_height_apply_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (T%2&. Dcr) (T%2& Type) (deep
    Bool
   ) (x Poly) (y Poly)
  ) (!
   (=>
    (and
     (has_type x (TYPE%fun%2. T%0&. T%0& T%1&. T%1& T%2&. T%2&))
     (has_type y (TYPE%fun%2. T%0&. T%0& T%1&. T%1& T%2&. T%2&))
     (forall ((T%0 Poly) (T%1 Poly)) (!
       (=>
        (and
         (has_type T%0 T%0&)
         (has_type T%1 T%1&)
        )
        (ext_eq deep T%2& (%%apply%%1 (%Poly%fun%2. x) T%0 T%1) (%%apply%%1 (%Poly%fun%2. y)
          T%0 T%1
       )))
       :pattern ((ext_eq deep T%2& (%%apply%%1 (%Poly%fun%2. x) T%0 T%1) (%%apply%%1 (%Poly%fun%2.
           y
          ) T%0 T%1
       )))
       :qid internal_crate__fun__2_inner_ext_equal_definition
       :skolemid skolem_internal_crate__fun__2_inner_ext_equal_definition
    )))
    (ext_eq deep (TYPE%fun%2. T%0&. T%0& T%1&. T%1& T%2&. T%2&) x y)
   )
   :pattern ((ext_eq deep (TYPE%fun%2. T%0&. T%0& T%1&. T%1& T%2&. T%2&) x y))
   :qid internal_crate__fun__2_ext_equal_definition
   :skolemid skolem_internal_crate__fun__2_ext_equal_definition
)))
(assert
 (forall ((x anonymous_closure%29498.)) (!
   (= x (%Poly%anonymous_closure%29498. (Poly%anonymous_closure%29498. x)))
   :pattern ((Poly%anonymous_closure%29498. x))
   :qid internal_crate__anonymous_closure__29498_box_axiom_definition
   :skolemid skolem_internal_crate__anonymous_closure__29498_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%anonymous_closure%29498.)
    (= x (Poly%anonymous_closure%29498. (%Poly%anonymous_closure%29498. x)))
   )
   :pattern ((has_type x TYPE%anonymous_closure%29498.))
   :qid internal_crate__anonymous_closure__29498_unbox_axiom_definition
   :skolemid skolem_internal_crate__anonymous_closure__29498_unbox_axiom_definition
)))
(assert
 (forall ((x anonymous_closure%29498.)) (!
   (has_type (Poly%anonymous_closure%29498. x) TYPE%anonymous_closure%29498.)
   :pattern ((has_type (Poly%anonymous_closure%29498. x) TYPE%anonymous_closure%29498.))
   :qid internal_crate__anonymous_closure__29498_has_type_always_definition
   :skolemid skolem_internal_crate__anonymous_closure__29498_has_type_always_definition
)))
(assert
 (forall ((x anonymous_closure%29501.)) (!
   (= x (%Poly%anonymous_closure%29501. (Poly%anonymous_closure%29501. x)))
   :pattern ((Poly%anonymous_closure%29501. x))
   :qid internal_crate__anonymous_closure__29501_box_axiom_definition
   :skolemid skolem_internal_crate__anonymous_closure__29501_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%anonymous_closure%29501.)
    (= x (Poly%anonymous_closure%29501. (%Poly%anonymous_closure%29501. x)))
   )
   :pattern ((has_type x TYPE%anonymous_closure%29501.))
   :qid internal_crate__anonymous_closure__29501_unbox_axiom_definition
   :skolemid skolem_internal_crate__anonymous_closure__29501_unbox_axiom_definition
)))
(assert
 (forall ((x anonymous_closure%29501.)) (!
   (has_type (Poly%anonymous_closure%29501. x) TYPE%anonymous_closure%29501.)
   :pattern ((has_type (Poly%anonymous_closure%29501. x) TYPE%anonymous_closure%29501.))
   :qid internal_crate__anonymous_closure__29501_has_type_always_definition
   :skolemid skolem_internal_crate__anonymous_closure__29501_has_type_always_definition
)))
(assert
 (forall ((x anonymous_closure%29504.)) (!
   (= x (%Poly%anonymous_closure%29504. (Poly%anonymous_closure%29504. x)))
   :pattern ((Poly%anonymous_closure%29504. x))
   :qid internal_crate__anonymous_closure__29504_box_axiom_definition
   :skolemid skolem_internal_crate__anonymous_closure__29504_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%anonymous_closure%29504.)
    (= x (Poly%anonymous_closure%29504. (%Poly%anonymous_closure%29504. x)))
   )
   :pattern ((has_type x TYPE%anonymous_closure%29504.))
   :qid internal_crate__anonymous_closure__29504_unbox_axiom_definition
   :skolemid skolem_internal_crate__anonymous_closure__29504_unbox_axiom_definition
)))
(assert
 (forall ((x anonymous_closure%29504.)) (!
   (has_type (Poly%anonymous_closure%29504. x) TYPE%anonymous_closure%29504.)
   :pattern ((has_type (Poly%anonymous_closure%29504. x) TYPE%anonymous_closure%29504.))
   :qid internal_crate__anonymous_closure__29504_has_type_always_definition
   :skolemid skolem_internal_crate__anonymous_closure__29504_has_type_always_definition
)))
(assert
 (forall ((x anonymous_closure%29509.)) (!
   (= x (%Poly%anonymous_closure%29509. (Poly%anonymous_closure%29509. x)))
   :pattern ((Poly%anonymous_closure%29509. x))
   :qid internal_crate__anonymous_closure__29509_box_axiom_definition
   :skolemid skolem_internal_crate__anonymous_closure__29509_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%anonymous_closure%29509.)
    (= x (Poly%anonymous_closure%29509. (%Poly%anonymous_closure%29509. x)))
   )
   :pattern ((has_type x TYPE%anonymous_closure%29509.))
   :qid internal_crate__anonymous_closure__29509_unbox_axiom_definition
   :skolemid skolem_internal_crate__anonymous_closure__29509_unbox_axiom_definition
)))
(assert
 (forall ((x anonymous_closure%29509.)) (!
   (has_type (Poly%anonymous_closure%29509. x) TYPE%anonymous_closure%29509.)
   :pattern ((has_type (Poly%anonymous_closure%29509. x) TYPE%anonymous_closure%29509.))
   :qid internal_crate__anonymous_closure__29509_has_type_always_definition
   :skolemid skolem_internal_crate__anonymous_closure__29509_has_type_always_definition
)))
(assert
 (forall ((x alloc!alloc.Global.)) (!
   (= x (%Poly%alloc!alloc.Global. (Poly%alloc!alloc.Global. x)))
   :pattern ((Poly%alloc!alloc.Global. x))
   :qid internal_alloc__alloc__Global_box_axiom_definition
   :skolemid skolem_internal_alloc__alloc__Global_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%alloc!alloc.Global.)
    (= x (Poly%alloc!alloc.Global. (%Poly%alloc!alloc.Global. x)))
   )
   :pattern ((has_type x TYPE%alloc!alloc.Global.))
   :qid internal_alloc__alloc__Global_unbox_axiom_definition
   :skolemid skolem_internal_alloc__alloc__Global_unbox_axiom_definition
)))
(assert
 (forall ((x alloc!alloc.Global.)) (!
   (has_type (Poly%alloc!alloc.Global. x) TYPE%alloc!alloc.Global.)
   :pattern ((has_type (Poly%alloc!alloc.Global. x) TYPE%alloc!alloc.Global.))
   :qid internal_alloc__alloc__Global_has_type_always_definition
   :skolemid skolem_internal_alloc__alloc__Global_has_type_always_definition
)))
(assert
 (forall ((x alloc!vec.Vec<usize./alloc!alloc.Global.>.)) (!
   (= x (%Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>.
      x
   )))
   :pattern ((Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. x))
   :qid internal_alloc__vec__Vec<usize./alloc!alloc.Global.>_box_axiom_definition
   :skolemid skolem_internal_alloc__vec__Vec<usize./alloc!alloc.Global.>_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x (TYPE%alloc!vec.Vec. $ USIZE $ TYPE%alloc!alloc.Global.))
    (= x (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. (%Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>.
       x
   ))))
   :pattern ((has_type x (TYPE%alloc!vec.Vec. $ USIZE $ TYPE%alloc!alloc.Global.)))
   :qid internal_alloc__vec__Vec<usize./alloc!alloc.Global.>_unbox_axiom_definition
   :skolemid skolem_internal_alloc__vec__Vec<usize./alloc!alloc.Global.>_unbox_axiom_definition
)))
(assert
 (forall ((x alloc!vec.Vec<usize./alloc!alloc.Global.>.)) (!
   (has_type (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. x) (TYPE%alloc!vec.Vec.
     $ USIZE $ TYPE%alloc!alloc.Global.
   ))
   :pattern ((has_type (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. x) (TYPE%alloc!vec.Vec.
      $ USIZE $ TYPE%alloc!alloc.Global.
   )))
   :qid internal_alloc__vec__Vec<usize./alloc!alloc.Global.>_has_type_always_definition
   :skolemid skolem_internal_alloc__vec__Vec<usize./alloc!alloc.Global.>_has_type_always_definition
)))
(assert
 (forall ((x vstd!seq.Seq<usize.>.)) (!
   (= x (%Poly%vstd!seq.Seq<usize.>. (Poly%vstd!seq.Seq<usize.>. x)))
   :pattern ((Poly%vstd!seq.Seq<usize.>. x))
   :qid internal_vstd__seq__Seq<usize.>_box_axiom_definition
   :skolemid skolem_internal_vstd__seq__Seq<usize.>_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x (TYPE%vstd!seq.Seq. $ USIZE))
    (= x (Poly%vstd!seq.Seq<usize.>. (%Poly%vstd!seq.Seq<usize.>. x)))
   )
   :pattern ((has_type x (TYPE%vstd!seq.Seq. $ USIZE)))
   :qid internal_vstd__seq__Seq<usize.>_unbox_axiom_definition
   :skolemid skolem_internal_vstd__seq__Seq<usize.>_unbox_axiom_definition
)))
(assert
 (forall ((x vstd!seq.Seq<usize.>.)) (!
   (has_type (Poly%vstd!seq.Seq<usize.>. x) (TYPE%vstd!seq.Seq. $ USIZE))
   :pattern ((has_type (Poly%vstd!seq.Seq<usize.>. x) (TYPE%vstd!seq.Seq. $ USIZE)))
   :qid internal_vstd__seq__Seq<usize.>_has_type_always_definition
   :skolemid skolem_internal_vstd__seq__Seq<usize.>_has_type_always_definition
)))
(assert
 (forall ((x lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.)) (!
   (= x (%Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
      x
   )))
   :pattern ((Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. x))
   :qid internal_lib__Chap18__ArraySeqMtPer__ArraySeqMtPer__ArraySeqMtPerS_box_axiom_definition
   :skolemid skolem_internal_lib__Chap18__ArraySeqMtPer__ArraySeqMtPer__ArraySeqMtPerS_box_axiom_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. T&. T&))
    (= x (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. (%Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
       x
   ))))
   :pattern ((has_type x (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. T&.
      T&
   )))
   :qid internal_lib__Chap18__ArraySeqMtPer__ArraySeqMtPer__ArraySeqMtPerS_unbox_axiom_definition
   :skolemid skolem_internal_lib__Chap18__ArraySeqMtPer__ArraySeqMtPer__ArraySeqMtPerS_unbox_axiom_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (_seq! Poly)) (!
   (=>
    (has_type _seq! (TYPE%alloc!vec.Vec. T&. T& $ TYPE%alloc!alloc.Global.))
    (has_type (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS./ArraySeqMtPerS
       _seq!
      )
     ) (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. T&. T&)
   ))
   :pattern ((has_type (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS./ArraySeqMtPerS
       _seq!
      )
     ) (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. T&. T&)
   ))
   :qid internal_lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS./ArraySeqMtPerS_constructor_definition
   :skolemid skolem_internal_lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS./ArraySeqMtPerS_constructor_definition
)))
(assert
 (forall ((x lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.)) (!
   (= (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS./ArraySeqMtPerS/seq x) (
     lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS./ArraySeqMtPerS/?seq x
   ))
   :pattern ((lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS./ArraySeqMtPerS/seq
     x
   ))
   :qid internal_lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS./ArraySeqMtPerS/seq_accessor_definition
   :skolemid skolem_internal_lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS./ArraySeqMtPerS/seq_accessor_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. T&. T&))
    (has_type (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS./ArraySeqMtPerS/seq
      (%Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. x)
     ) (TYPE%alloc!vec.Vec. T&. T& $ TYPE%alloc!alloc.Global.)
   ))
   :pattern ((lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS./ArraySeqMtPerS/seq
     (%Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. x)
    ) (has_type x (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. T&. T&))
   )
   :qid internal_lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS./ArraySeqMtPerS/seq_invariant_definition
   :skolemid skolem_internal_lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS./ArraySeqMtPerS/seq_invariant_definition
)))
(assert
 (forall ((x lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.)) (!
   (=>
    (is-lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS./ArraySeqMtPerS x)
    (height_lt (height (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS./ArraySeqMtPerS/seq
       x
      )
     ) (height (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. x))
   ))
   :pattern ((height (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS./ArraySeqMtPerS/seq
      x
   )))
   :qid prelude_datatype_height_lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS./ArraySeqMtPerS/seq
   :skolemid skolem_prelude_datatype_height_lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS./ArraySeqMtPerS/seq
)))
(assert
 (forall ((x tuple%0.)) (!
   (= x (%Poly%tuple%0. (Poly%tuple%0. x)))
   :pattern ((Poly%tuple%0. x))
   :qid internal_crate__tuple__0_box_axiom_definition
   :skolemid skolem_internal_crate__tuple__0_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%tuple%0.)
    (= x (Poly%tuple%0. (%Poly%tuple%0. x)))
   )
   :pattern ((has_type x TYPE%tuple%0.))
   :qid internal_crate__tuple__0_unbox_axiom_definition
   :skolemid skolem_internal_crate__tuple__0_unbox_axiom_definition
)))
(assert
 (forall ((x tuple%0.)) (!
   (has_type (Poly%tuple%0. x) TYPE%tuple%0.)
   :pattern ((has_type (Poly%tuple%0. x) TYPE%tuple%0.))
   :qid internal_crate__tuple__0_has_type_always_definition
   :skolemid skolem_internal_crate__tuple__0_has_type_always_definition
)))
(assert
 (forall ((x tuple%2.)) (!
   (= x (%Poly%tuple%2. (Poly%tuple%2. x)))
   :pattern ((Poly%tuple%2. x))
   :qid internal_crate__tuple__2_box_axiom_definition
   :skolemid skolem_internal_crate__tuple__2_box_axiom_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%tuple%2. T%0&. T%0& T%1&. T%1&))
    (= x (Poly%tuple%2. (%Poly%tuple%2. x)))
   )
   :pattern ((has_type x (TYPE%tuple%2. T%0&. T%0& T%1&. T%1&)))
   :qid internal_crate__tuple__2_unbox_axiom_definition
   :skolemid skolem_internal_crate__tuple__2_unbox_axiom_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (_0! Poly) (_1! Poly)) (!
   (=>
    (and
     (has_type _0! T%0&)
     (has_type _1! T%1&)
    )
    (has_type (Poly%tuple%2. (tuple%2./tuple%2 _0! _1!)) (TYPE%tuple%2. T%0&. T%0& T%1&.
      T%1&
   )))
   :pattern ((has_type (Poly%tuple%2. (tuple%2./tuple%2 _0! _1!)) (TYPE%tuple%2. T%0&.
      T%0& T%1&. T%1&
   )))
   :qid internal_tuple__2./tuple__2_constructor_definition
   :skolemid skolem_internal_tuple__2./tuple__2_constructor_definition
)))
(assert
 (forall ((x tuple%2.)) (!
   (= (tuple%2./tuple%2/0 x) (tuple%2./tuple%2/?0 x))
   :pattern ((tuple%2./tuple%2/0 x))
   :qid internal_tuple__2./tuple__2/0_accessor_definition
   :skolemid skolem_internal_tuple__2./tuple__2/0_accessor_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%tuple%2. T%0&. T%0& T%1&. T%1&))
    (has_type (tuple%2./tuple%2/0 (%Poly%tuple%2. x)) T%0&)
   )
   :pattern ((tuple%2./tuple%2/0 (%Poly%tuple%2. x)) (has_type x (TYPE%tuple%2. T%0&. T%0&
      T%1&. T%1&
   )))
   :qid internal_tuple__2./tuple__2/0_invariant_definition
   :skolemid skolem_internal_tuple__2./tuple__2/0_invariant_definition
)))
(assert
 (forall ((x tuple%2.)) (!
   (= (tuple%2./tuple%2/1 x) (tuple%2./tuple%2/?1 x))
   :pattern ((tuple%2./tuple%2/1 x))
   :qid internal_tuple__2./tuple__2/1_accessor_definition
   :skolemid skolem_internal_tuple__2./tuple__2/1_accessor_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%tuple%2. T%0&. T%0& T%1&. T%1&))
    (has_type (tuple%2./tuple%2/1 (%Poly%tuple%2. x)) T%1&)
   )
   :pattern ((tuple%2./tuple%2/1 (%Poly%tuple%2. x)) (has_type x (TYPE%tuple%2. T%0&. T%0&
      T%1&. T%1&
   )))
   :qid internal_tuple__2./tuple__2/1_invariant_definition
   :skolemid skolem_internal_tuple__2./tuple__2/1_invariant_definition
)))
(assert
 (forall ((x tuple%2.)) (!
   (=>
    (is-tuple%2./tuple%2 x)
    (height_lt (height (tuple%2./tuple%2/0 x)) (height (Poly%tuple%2. x)))
   )
   :pattern ((height (tuple%2./tuple%2/0 x)))
   :qid prelude_datatype_height_tuple%2./tuple%2/0
   :skolemid skolem_prelude_datatype_height_tuple%2./tuple%2/0
)))
(assert
 (forall ((x tuple%2.)) (!
   (=>
    (is-tuple%2./tuple%2 x)
    (height_lt (height (tuple%2./tuple%2/1 x)) (height (Poly%tuple%2. x)))
   )
   :pattern ((height (tuple%2./tuple%2/1 x)))
   :qid prelude_datatype_height_tuple%2./tuple%2/1
   :skolemid skolem_prelude_datatype_height_tuple%2./tuple%2/1
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (deep Bool) (x Poly) (y Poly))
  (!
   (=>
    (and
     (has_type x (TYPE%tuple%2. T%0&. T%0& T%1&. T%1&))
     (has_type y (TYPE%tuple%2. T%0&. T%0& T%1&. T%1&))
     (ext_eq deep T%0& (tuple%2./tuple%2/0 (%Poly%tuple%2. x)) (tuple%2./tuple%2/0 (%Poly%tuple%2.
        y
     )))
     (ext_eq deep T%1& (tuple%2./tuple%2/1 (%Poly%tuple%2. x)) (tuple%2./tuple%2/1 (%Poly%tuple%2.
        y
    ))))
    (ext_eq deep (TYPE%tuple%2. T%0&. T%0& T%1&. T%1&) x y)
   )
   :pattern ((ext_eq deep (TYPE%tuple%2. T%0&. T%0& T%1&. T%1&) x y))
   :qid internal_tuple__2./tuple__2_ext_equal_definition
   :skolemid skolem_internal_tuple__2./tuple__2_ext_equal_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (x$ Poly)) (!
   (=>
    (has_type x$ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. T&. T&))
    (=>
     (has_resolved $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. T&. T&)
      x$
     )
     (has_resolved $ (TYPE%alloc!vec.Vec. T&. T& $ TYPE%alloc!alloc.Global.) (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS./ArraySeqMtPerS/seq
       (%Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. x$)
   ))))
   :pattern ((has_resolved $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
      T&. T&
     ) x$
    ) (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS./ArraySeqMtPerS/seq (%Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
      x$
   )))
   :qid user_no_function_0
   :skolemid skolem_user_no_function_0
)))

;; Trait-Bounds
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (Args&. Dcr) (Args& Type) (Output&. Dcr) (Output&
    Type
   )
  ) (!
   (=>
    (tr_bound%vstd!pervasive.FnWithRequiresEnsures. Self%&. Self%& Args&. Args& Output&.
     Output&
    )
    (and
     (sized Self%&.)
     (sized Args&.)
     (sized Output&.)
   ))
   :pattern ((tr_bound%vstd!pervasive.FnWithRequiresEnsures. Self%&. Self%& Args&. Args&
     Output&. Output&
   ))
   :qid internal_vstd__pervasive__FnWithRequiresEnsures_trait_type_bounds_definition
   :skolemid skolem_internal_vstd__pervasive__FnWithRequiresEnsures_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type)) (!
   (=>
    (tr_bound%vstd!view.View. Self%&. Self%&)
    (sized (proj%%vstd!view.View./V Self%&. Self%&))
   )
   :pattern ((tr_bound%vstd!view.View. Self%&. Self%&))
   :qid internal_vstd__view__View_trait_type_bounds_definition
   :skolemid skolem_internal_vstd__view__View_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type)) (!
   true
   :pattern ((tr_bound%core!marker.Tuple. Self%&. Self%&))
   :qid internal_core__marker__Tuple_trait_type_bounds_definition
   :skolemid skolem_internal_core__marker__Tuple_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (Args&. Dcr) (Args& Type)) (!
   (=>
    (tr_bound%core!ops.function.FnOnce. Self%&. Self%& Args&. Args&)
    (and
     (sized Args&.)
     (tr_bound%core!marker.Tuple. Args&. Args&)
     (sized (proj%%core!ops.function.FnOnce./Output Self%&. Self%& Args&. Args&))
   ))
   :pattern ((tr_bound%core!ops.function.FnOnce. Self%&. Self%& Args&. Args&))
   :qid internal_core__ops__function__FnOnce_trait_type_bounds_definition
   :skolemid skolem_internal_core__ops__function__FnOnce_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (Args&. Dcr) (Args& Type)) (!
   (=>
    (tr_bound%core!ops.function.FnMut. Self%&. Self%& Args&. Args&)
    (and
     (tr_bound%core!ops.function.FnOnce. Self%&. Self%& Args&. Args&)
     (sized Args&.)
     (tr_bound%core!marker.Tuple. Args&. Args&)
   ))
   :pattern ((tr_bound%core!ops.function.FnMut. Self%&. Self%& Args&. Args&))
   :qid internal_core__ops__function__FnMut_trait_type_bounds_definition
   :skolemid skolem_internal_core__ops__function__FnMut_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (Args&. Dcr) (Args& Type)) (!
   (=>
    (tr_bound%core!ops.function.Fn. Self%&. Self%& Args&. Args&)
    (and
     (tr_bound%core!ops.function.FnMut. Self%&. Self%& Args&. Args&)
     (sized Args&.)
     (tr_bound%core!marker.Tuple. Args&. Args&)
   ))
   :pattern ((tr_bound%core!ops.function.Fn. Self%&. Self%& Args&. Args&))
   :qid internal_core__ops__function__Fn_trait_type_bounds_definition
   :skolemid skolem_internal_core__ops__function__Fn_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type)) (!
   true
   :pattern ((tr_bound%core!alloc.Allocator. Self%&. Self%&))
   :qid internal_core__alloc__Allocator_trait_type_bounds_definition
   :skolemid skolem_internal_core__alloc__Allocator_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (T&. Dcr) (T& Type)) (!
   (=>
    (tr_bound%vstd!std_specs.vec.VecAdditionalSpecFns. Self%&. Self%& T&. T&)
    (and
     (tr_bound%vstd!view.View. Self%&. Self%&)
     (and
      (= $ (proj%%vstd!view.View./V Self%&. Self%&))
      (= (TYPE%vstd!seq.Seq. T&. T&) (proj%vstd!view.View./V Self%&. Self%&))
     )
     (sized T&.)
   ))
   :pattern ((tr_bound%vstd!std_specs.vec.VecAdditionalSpecFns. Self%&. Self%& T&. T&))
   :qid internal_vstd__std_specs__vec__VecAdditionalSpecFns_trait_type_bounds_definition
   :skolemid skolem_internal_vstd__std_specs__vec__VecAdditionalSpecFns_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (T&. Dcr) (T& Type)) (!
   (=>
    (tr_bound%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait. Self%&. Self%&
     T&. T&
    )
    (and
     (sized Self%&.)
     (sized T&.)
   ))
   :pattern ((tr_bound%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.
     Self%&. Self%& T&. T&
   ))
   :qid internal_lib__Chap18__ArraySeqMtPer__ArraySeqMtPer__ArraySeqMtPerBaseTrait_trait_type_bounds_definition
   :skolemid skolem_internal_lib__Chap18__ArraySeqMtPer__ArraySeqMtPer__ArraySeqMtPerBaseTrait_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (T&. Dcr) (T& Type)) (!
   (=>
    (tr_bound%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerRedefinableTrait. Self%&.
     Self%& T&. T&
    )
    (and
     (tr_bound%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait. Self%&. Self%&
      T&. T&
     )
     (sized T&.)
   ))
   :pattern ((tr_bound%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerRedefinableTrait.
     Self%&. Self%& T&. T&
   ))
   :qid internal_lib__Chap18__ArraySeqMtPer__ArraySeqMtPer__ArraySeqMtPerRedefinableTrait_trait_type_bounds_definition
   :skolemid skolem_internal_lib__Chap18__ArraySeqMtPer__ArraySeqMtPer__ArraySeqMtPerRedefinableTrait_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type)) (!
   true
   :pattern ((tr_bound%lib!Chap26.ScanDCMtPer.ScanDCMtPer.ScanDCMtTrait. Self%&. Self%&))
   :qid internal_lib__Chap26__ScanDCMtPer__ScanDCMtPer__ScanDCMtTrait_trait_type_bounds_definition
   :skolemid skolem_internal_lib__Chap26__ScanDCMtPer__ScanDCMtPer__ScanDCMtTrait_trait_type_bounds_definition
)))

;; Associated-Type-Impls
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (tr_bound%vstd!view.View. A&. A&)
    (= (proj%%vstd!view.View./V (REF A&.) A&) (proj%%vstd!view.View./V A&. A&))
   )
   :pattern ((proj%%vstd!view.View./V (REF A&.) A&))
   :qid internal_proj____vstd!view.View./V_vstd__view__impl&__0_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____vstd!view.View./V_vstd__view__impl&__0_assoc_type_impl_true_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (tr_bound%vstd!view.View. A&. A&)
    (= (proj%vstd!view.View./V (REF A&.) A&) (proj%vstd!view.View./V A&. A&))
   )
   :pattern ((proj%vstd!view.View./V (REF A&.) A&))
   :qid internal_proj__vstd!view.View./V_vstd__view__impl&__0_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__vstd!view.View./V_vstd__view__impl&__0_assoc_type_impl_false_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (tr_bound%vstd!view.View. A&. A&)
    (= (proj%%vstd!view.View./V (BOX $ TYPE%alloc!alloc.Global. A&.) A&) (proj%%vstd!view.View./V
      A&. A&
   )))
   :pattern ((proj%%vstd!view.View./V (BOX $ TYPE%alloc!alloc.Global. A&.) A&))
   :qid internal_proj____vstd!view.View./V_vstd__view__impl&__2_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____vstd!view.View./V_vstd__view__impl&__2_assoc_type_impl_true_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (tr_bound%vstd!view.View. A&. A&)
    (= (proj%vstd!view.View./V (BOX $ TYPE%alloc!alloc.Global. A&.) A&) (proj%vstd!view.View./V
      A&. A&
   )))
   :pattern ((proj%vstd!view.View./V (BOX $ TYPE%alloc!alloc.Global. A&.) A&))
   :qid internal_proj__vstd!view.View./V_vstd__view__impl&__2_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__vstd!view.View./V_vstd__view__impl&__2_assoc_type_impl_false_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%vstd!view.View. A&. A&)
    )
    (= (proj%%vstd!view.View./V (RC $ TYPE%alloc!alloc.Global. A&.) A&) (proj%%vstd!view.View./V
      A&. A&
   )))
   :pattern ((proj%%vstd!view.View./V (RC $ TYPE%alloc!alloc.Global. A&.) A&))
   :qid internal_proj____vstd!view.View./V_vstd__view__impl&__4_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____vstd!view.View./V_vstd__view__impl&__4_assoc_type_impl_true_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%vstd!view.View. A&. A&)
    )
    (= (proj%vstd!view.View./V (RC $ TYPE%alloc!alloc.Global. A&.) A&) (proj%vstd!view.View./V
      A&. A&
   )))
   :pattern ((proj%vstd!view.View./V (RC $ TYPE%alloc!alloc.Global. A&.) A&))
   :qid internal_proj__vstd!view.View./V_vstd__view__impl&__4_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__vstd!view.View./V_vstd__view__impl&__4_assoc_type_impl_false_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%vstd!view.View. A&. A&)
    )
    (= (proj%%vstd!view.View./V (ARC $ TYPE%alloc!alloc.Global. A&.) A&) (proj%%vstd!view.View./V
      A&. A&
   )))
   :pattern ((proj%%vstd!view.View./V (ARC $ TYPE%alloc!alloc.Global. A&.) A&))
   :qid internal_proj____vstd!view.View./V_vstd__view__impl&__6_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____vstd!view.View./V_vstd__view__impl&__6_assoc_type_impl_true_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%vstd!view.View. A&. A&)
    )
    (= (proj%vstd!view.View./V (ARC $ TYPE%alloc!alloc.Global. A&.) A&) (proj%vstd!view.View./V
      A&. A&
   )))
   :pattern ((proj%vstd!view.View./V (ARC $ TYPE%alloc!alloc.Global. A&.) A&))
   :qid internal_proj__vstd!view.View./V_vstd__view__impl&__6_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__vstd!view.View./V_vstd__view__impl&__6_assoc_type_impl_false_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized T&.)
     (sized A&.)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (= (proj%%vstd!view.View./V $ (TYPE%alloc!vec.Vec. T&. T& A&. A&)) $)
   )
   :pattern ((proj%%vstd!view.View./V $ (TYPE%alloc!vec.Vec. T&. T& A&. A&)))
   :qid internal_proj____vstd!view.View./V_vstd__view__impl&__8_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____vstd!view.View./V_vstd__view__impl&__8_assoc_type_impl_true_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized T&.)
     (sized A&.)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (= (proj%vstd!view.View./V $ (TYPE%alloc!vec.Vec. T&. T& A&. A&)) (TYPE%vstd!seq.Seq.
      T&. T&
   )))
   :pattern ((proj%vstd!view.View./V $ (TYPE%alloc!vec.Vec. T&. T& A&. A&)))
   :qid internal_proj__vstd!view.View./V_vstd__view__impl&__8_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__vstd!view.View./V_vstd__view__impl&__8_assoc_type_impl_false_definition
)))
(assert
 (= (proj%%vstd!view.View./V $ TYPE%tuple%0.) $)
)
(assert
 (= (proj%vstd!view.View./V $ TYPE%tuple%0.) TYPE%tuple%0.)
)
(assert
 (= (proj%%vstd!view.View./V $ BOOL) $)
)
(assert
 (= (proj%vstd!view.View./V $ BOOL) BOOL)
)
(assert
 (= (proj%%vstd!view.View./V $ USIZE) $)
)
(assert
 (= (proj%vstd!view.View./V $ USIZE) USIZE)
)
(assert
 (forall ((A0&. Dcr) (A0& Type) (A1&. Dcr) (A1& Type)) (!
   (=>
    (and
     (sized A0&.)
     (sized A1&.)
     (tr_bound%vstd!view.View. A0&. A0&)
     (tr_bound%vstd!view.View. A1&. A1&)
    )
    (= (proj%%vstd!view.View./V (DST A1&.) (TYPE%tuple%2. A0&. A0& A1&. A1&)) (DST (proj%%vstd!view.View./V
       A1&. A1&
   ))))
   :pattern ((proj%%vstd!view.View./V (DST A1&.) (TYPE%tuple%2. A0&. A0& A1&. A1&)))
   :qid internal_proj____vstd!view.View./V_vstd__view__impl&__48_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____vstd!view.View./V_vstd__view__impl&__48_assoc_type_impl_true_definition
)))
(assert
 (forall ((A0&. Dcr) (A0& Type) (A1&. Dcr) (A1& Type)) (!
   (=>
    (and
     (sized A0&.)
     (sized A1&.)
     (tr_bound%vstd!view.View. A0&. A0&)
     (tr_bound%vstd!view.View. A1&. A1&)
    )
    (= (proj%vstd!view.View./V (DST A1&.) (TYPE%tuple%2. A0&. A0& A1&. A1&)) (TYPE%tuple%2.
      (proj%%vstd!view.View./V A0&. A0&) (proj%vstd!view.View./V A0&. A0&) (proj%%vstd!view.View./V
       A1&. A1&
      ) (proj%vstd!view.View./V A1&. A1&)
   )))
   :pattern ((proj%vstd!view.View./V (DST A1&.) (TYPE%tuple%2. A0&. A0& A1&. A1&)))
   :qid internal_proj__vstd!view.View./V_vstd__view__impl&__48_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__vstd!view.View./V_vstd__view__impl&__48_assoc_type_impl_false_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.Fn. F&. F& A&. A&)
    )
    (= (proj%%core!ops.function.FnOnce./Output (REF F&.) F& A&. A&) (proj%%core!ops.function.FnOnce./Output
      F&. F& A&. A&
   )))
   :pattern ((proj%%core!ops.function.FnOnce./Output (REF F&.) F& A&. A&))
   :qid internal_proj____core!ops.function.FnOnce./Output_core__ops__function__impls__impl&__2_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____core!ops.function.FnOnce./Output_core__ops__function__impls__impl&__2_assoc_type_impl_true_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.Fn. F&. F& A&. A&)
    )
    (= (proj%core!ops.function.FnOnce./Output (REF F&.) F& A&. A&) (proj%core!ops.function.FnOnce./Output
      F&. F& A&. A&
   )))
   :pattern ((proj%core!ops.function.FnOnce./Output (REF F&.) F& A&. A&))
   :qid internal_proj__core!ops.function.FnOnce./Output_core__ops__function__impls__impl&__2_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__core!ops.function.FnOnce./Output_core__ops__function__impls__impl&__2_assoc_type_impl_false_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.FnMut. F&. F& A&. A&)
    )
    (= (proj%%core!ops.function.FnOnce./Output $ (MUTREF F&. F&) A&. A&) (proj%%core!ops.function.FnOnce./Output
      F&. F& A&. A&
   )))
   :pattern ((proj%%core!ops.function.FnOnce./Output $ (MUTREF F&. F&) A&. A&))
   :qid internal_proj____core!ops.function.FnOnce./Output_core__ops__function__impls__impl&__4_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____core!ops.function.FnOnce./Output_core__ops__function__impls__impl&__4_assoc_type_impl_true_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.FnMut. F&. F& A&. A&)
    )
    (= (proj%core!ops.function.FnOnce./Output $ (MUTREF F&. F&) A&. A&) (proj%core!ops.function.FnOnce./Output
      F&. F& A&. A&
   )))
   :pattern ((proj%core!ops.function.FnOnce./Output $ (MUTREF F&. F&) A&. A&))
   :qid internal_proj__core!ops.function.FnOnce./Output_core__ops__function__impls__impl&__4_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__core!ops.function.FnOnce./Output_core__ops__function__impls__impl&__4_assoc_type_impl_false_definition
)))
(assert
 (forall ((Args&. Dcr) (Args& Type) (F&. Dcr) (F& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized Args&.)
     (sized A&.)
     (tr_bound%core!marker.Tuple. Args&. Args&)
     (tr_bound%core!ops.function.FnOnce. F&. F& Args&. Args&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (= (proj%%core!ops.function.FnOnce./Output (BOX A&. A& F&.) F& Args&. Args&) (proj%%core!ops.function.FnOnce./Output
      F&. F& Args&. Args&
   )))
   :pattern ((proj%%core!ops.function.FnOnce./Output (BOX A&. A& F&.) F& Args&. Args&))
   :qid internal_proj____core!ops.function.FnOnce./Output_alloc__boxed__impl&__31_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____core!ops.function.FnOnce./Output_alloc__boxed__impl&__31_assoc_type_impl_true_definition
)))
(assert
 (forall ((Args&. Dcr) (Args& Type) (F&. Dcr) (F& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized Args&.)
     (sized A&.)
     (tr_bound%core!marker.Tuple. Args&. Args&)
     (tr_bound%core!ops.function.FnOnce. F&. F& Args&. Args&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (= (proj%core!ops.function.FnOnce./Output (BOX A&. A& F&.) F& Args&. Args&) (proj%core!ops.function.FnOnce./Output
      F&. F& Args&. Args&
   )))
   :pattern ((proj%core!ops.function.FnOnce./Output (BOX A&. A& F&.) F& Args&. Args&))
   :qid internal_proj__core!ops.function.FnOnce./Output_alloc__boxed__impl&__31_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__core!ops.function.FnOnce./Output_alloc__boxed__impl&__31_assoc_type_impl_false_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (and
     (sized T&.)
     (tr_bound%vstd!view.View. T&. T&)
    )
    (= (proj%%vstd!view.View./V $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
       T&. T&
      )
     ) $
   ))
   :pattern ((proj%%vstd!view.View./V $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
      T&. T&
   )))
   :qid internal_proj____vstd!view.View./V_lib__Chap18__ArraySeqMtPer__ArraySeqMtPer__impl&__2_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____vstd!view.View./V_lib__Chap18__ArraySeqMtPer__ArraySeqMtPer__impl&__2_assoc_type_impl_true_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (and
     (sized T&.)
     (tr_bound%vstd!view.View. T&. T&)
    )
    (= (proj%vstd!view.View./V $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
       T&. T&
      )
     ) (TYPE%vstd!seq.Seq. (proj%%vstd!view.View./V T&. T&) (proj%vstd!view.View./V T&.
       T&
   ))))
   :pattern ((proj%vstd!view.View./V $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
      T&. T&
   )))
   :qid internal_proj__vstd!view.View./V_lib__Chap18__ArraySeqMtPer__ArraySeqMtPer__impl&__2_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__vstd!view.View./V_lib__Chap18__ArraySeqMtPer__ArraySeqMtPer__impl&__2_assoc_type_impl_false_definition
)))
(assert
 (= (proj%%core!ops.function.FnOnce./Output $ TYPE%anonymous_closure%29498. $ TYPE%tuple%0.)
  (DST $)
))
(assert
 (= (proj%core!ops.function.FnOnce./Output $ TYPE%anonymous_closure%29498. $ TYPE%tuple%0.)
  (TYPE%tuple%2. $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE)
   $ USIZE
)))
(assert
 (= (proj%%core!ops.function.FnOnce./Output $ TYPE%anonymous_closure%29501. $ TYPE%tuple%0.)
  (DST $)
))
(assert
 (= (proj%core!ops.function.FnOnce./Output $ TYPE%anonymous_closure%29501. $ TYPE%tuple%0.)
  (TYPE%tuple%2. $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE)
   $ USIZE
)))
(assert
 (= (proj%%core!ops.function.FnOnce./Output $ TYPE%anonymous_closure%29504. $ TYPE%tuple%0.)
  $
))
(assert
 (= (proj%core!ops.function.FnOnce./Output $ TYPE%anonymous_closure%29504. $ TYPE%tuple%0.)
  (TYPE%alloc!vec.Vec. $ USIZE $ TYPE%alloc!alloc.Global.)
))
(assert
 (= (proj%%core!ops.function.FnOnce./Output $ TYPE%anonymous_closure%29509. $ TYPE%tuple%0.)
  $
))
(assert
 (= (proj%core!ops.function.FnOnce./Output $ TYPE%anonymous_closure%29509. $ TYPE%tuple%0.)
  (TYPE%alloc!vec.Vec. $ USIZE $ TYPE%alloc!alloc.Global.)
))

;; Function-Decl vstd::seq::Seq::len
(declare-fun vstd!seq.Seq.len.? (Dcr Type Poly) Int)

;; Function-Decl vstd::seq::Seq::index
(declare-fun vstd!seq.Seq.index.? (Dcr Type Poly Poly) Poly)

;; Function-Decl vstd::seq::impl&%2::spec_index
(declare-fun vstd!seq.impl&%2.spec_index.? (Dcr Type Poly Poly) Poly)

;; Function-Decl vstd::seq::Seq::subrange
(declare-fun vstd!seq.Seq.subrange.? (Dcr Type Poly Poly Poly) Poly)

;; Function-Decl vstd::seq::Seq::empty
(declare-fun vstd!seq.Seq.empty.? (Dcr Type) Poly)

;; Function-Decl vstd::seq::Seq::new
(declare-fun vstd!seq.Seq.new.? (Dcr Type Poly Poly) Poly)

;; Function-Decl vstd::seq::Seq::push
(declare-fun vstd!seq.Seq.push.? (Dcr Type Poly Poly) Poly)

;; Function-Decl vstd::seq::Seq::add
(declare-fun vstd!seq.Seq.add.? (Dcr Type Poly Poly) Poly)

;; Function-Decl vstd::seq::impl&%2::spec_add
(declare-fun vstd!seq.impl&%2.spec_add.? (Dcr Type Poly Poly) Poly)

;; Function-Decl vstd::seq_lib::impl&%0::drop_last
(declare-fun vstd!seq_lib.impl&%0.drop_last.? (Dcr Type Poly) Poly)

;; Function-Decl vstd::seq::Seq::last
(declare-fun vstd!seq.Seq.last.? (Dcr Type Poly) Poly)

;; Function-Decl vstd::seq_lib::impl&%0::fold_left
(declare-fun vstd!seq_lib.impl&%0.fold_left.? (Dcr Type Dcr Type Poly Poly Poly) Poly)
(declare-fun vstd!seq_lib.impl&%0.rec%fold_left.? (Dcr Type Dcr Type Poly Poly Poly
  Fuel
 ) Poly
)

;; Function-Decl vstd::view::View::view
(declare-fun vstd!view.View.view.? (Dcr Type Poly) Poly)
(declare-fun vstd!view.View.view%default%.? (Dcr Type Poly) Poly)

;; Function-Decl vstd::std_specs::vec::spec_vec_len
(declare-fun vstd!std_specs.vec.spec_vec_len.? (Dcr Type Dcr Type Poly) Int)

;; Function-Decl vstd::std_specs::vec::VecAdditionalSpecFns::spec_index
(declare-fun vstd!std_specs.vec.VecAdditionalSpecFns.spec_index.? (Dcr Type Dcr Type
  Poly Poly
 ) Poly
)
(declare-fun vstd!std_specs.vec.VecAdditionalSpecFns.spec_index%default%.? (Dcr Type
  Dcr Type Poly Poly
 ) Poly
)

;; Function-Decl vstd::seq::impl&%2::take
(declare-fun vstd!seq.impl&%2.take.? (Dcr Type Poly Poly) Poly)

;; Function-Decl vstd::seq::impl&%2::skip
(declare-fun vstd!seq.impl&%2.skip.? (Dcr Type Poly Poly) Poly)

;; Function-Decl vstd::pervasive::FnWithRequiresEnsures::requires
(declare-fun vstd!pervasive.FnWithRequiresEnsures.requires.? (Dcr Type Dcr Type Dcr
  Type Poly Poly
 ) Poly
)
(declare-fun vstd!pervasive.FnWithRequiresEnsures.requires%default%.? (Dcr Type Dcr
  Type Dcr Type Poly Poly
 ) Poly
)

;; Function-Decl vstd::pervasive::FnWithRequiresEnsures::ensures
(declare-fun vstd!pervasive.FnWithRequiresEnsures.ensures.? (Dcr Type Dcr Type Dcr
  Type Poly Poly Poly
 ) Poly
)
(declare-fun vstd!pervasive.FnWithRequiresEnsures.ensures%default%.? (Dcr Type Dcr
  Type Dcr Type Poly Poly Poly
 ) Poly
)

;; Function-Decl lib::Chap18::ArraySeqSpecsAndLemmas::ArraySeqSpecsAndLemmas::spec_iterate
(declare-fun lib!Chap18.ArraySeqSpecsAndLemmas.ArraySeqSpecsAndLemmas.spec_iterate.?
 (Dcr Type Dcr Type Poly Poly Poly) Poly
)

;; Function-Decl vstd::relations::associative
(declare-fun vstd!relations.associative.? (Dcr Type Poly) Bool)

;; Function-Decl lib::vstdplus::monoid::monoid::spec_left_identity
(declare-fun lib!vstdplus.monoid.monoid.spec_left_identity.? (Dcr Type Poly Poly)
 Bool
)

;; Function-Decl lib::vstdplus::monoid::monoid::spec_right_identity
(declare-fun lib!vstdplus.monoid.monoid.spec_right_identity.? (Dcr Type Poly Poly)
 Bool
)

;; Function-Decl lib::vstdplus::monoid::monoid::spec_monoid
(declare-fun lib!vstdplus.monoid.monoid.spec_monoid.? (Dcr Type Poly Poly) Bool)

;; Function-Decl lib::Chap18::ArraySeqMtPer::ArraySeqMtPer::ArraySeqMtPerBaseTrait::spec_arrayseqmtper_wf
(declare-fun lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_arrayseqmtper_wf.?
 (Dcr Type Dcr Type Poly) Poly
)
(declare-fun lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_arrayseqmtper_wf%default%.?
 (Dcr Type Dcr Type Poly) Poly
)

;; Function-Decl lib::Chap18::ArraySeqMtPer::ArraySeqMtPer::ArraySeqMtPerBaseTrait::spec_len
(declare-fun lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_len.?
 (Dcr Type Dcr Type Poly) Poly
)
(declare-fun lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_len%default%.?
 (Dcr Type Dcr Type Poly) Poly
)

;; Function-Decl lib::Chap18::ArraySeqMtPer::ArraySeqMtPer::ArraySeqMtPerBaseTrait::spec_index
(declare-fun lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_index.?
 (Dcr Type Dcr Type Poly Poly) Poly
)
(declare-fun lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_index%default%.?
 (Dcr Type Dcr Type Poly Poly) Poly
)

;; Function-Decl vstd::wrapping::usize_specs::wrapping_add
(declare-fun vstd!wrapping.usize_specs.wrapping_add.? (Poly Poly) Int)

;; Function-Decl lib::Chap26::ScanDCMtPer::ScanDCMtPer::spec_scan_at
(declare-fun lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_scan_at.? (Poly Poly Poly Poly)
 Int
)

;; Function-Decl lib::Chap26::ScanDCMtPer::ScanDCMtPer::spec_scan_post
(declare-fun lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_scan_post.? (Poly Poly Poly Poly
  Poly
 ) Bool
)

;; Function-Decl lib::Chap26::ScanDCMtPer::ScanDCMtPer::spec_wrapping_add
(declare-fun lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_wrapping_add.? (Poly Poly) Int)

;; Function-Decl lib::Chap26::ScanDCMtPer::ScanDCMtPer::spec_sum_fn
(declare-fun lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_sum_fn.? (Poly) %%Function%%)

;; Function-Decl vstd::seq_lib::impl&%0::map
(declare-fun vstd!seq_lib.impl&%0.map.? (Dcr Type Dcr Type Poly Poly) Poly)

;; Function-Axioms vstd::seq::Seq::len
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly)) (!
   (=>
    (has_type self! (TYPE%vstd!seq.Seq. A&. A&))
    (<= 0 (vstd!seq.Seq.len.? A&. A& self!))
   )
   :pattern ((vstd!seq.Seq.len.? A&. A& self!))
   :qid internal_vstd!seq.Seq.len.?_pre_post_definition
   :skolemid skolem_internal_vstd!seq.Seq.len.?_pre_post_definition
)))

;; Function-Specs vstd::seq::Seq::index
(declare-fun req%vstd!seq.Seq.index. (Dcr Type Poly Poly) Bool)
(declare-const %%global_location_label%%0 Bool)
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly) (i! Poly)) (!
   (= (req%vstd!seq.Seq.index. A&. A& self! i!) (=>
     %%global_location_label%%0
     (let
      ((tmp%%$ 0))
      (let
       ((tmp%%$1 (%I i!)))
       (let
        ((tmp%%$2 (vstd!seq.Seq.len.? A&. A& self!)))
        (and
         (<= tmp%%$ tmp%%$1)
         (< tmp%%$1 tmp%%$2)
   ))))))
   :pattern ((req%vstd!seq.Seq.index. A&. A& self! i!))
   :qid internal_req__vstd!seq.Seq.index._definition
   :skolemid skolem_internal_req__vstd!seq.Seq.index._definition
)))

;; Function-Axioms vstd::seq::Seq::index
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly) (i! Poly)) (!
   (=>
    (and
     (has_type self! (TYPE%vstd!seq.Seq. A&. A&))
     (has_type i! INT)
    )
    (has_type (vstd!seq.Seq.index.? A&. A& self! i!) A&)
   )
   :pattern ((vstd!seq.Seq.index.? A&. A& self! i!))
   :qid internal_vstd!seq.Seq.index.?_pre_post_definition
   :skolemid skolem_internal_vstd!seq.Seq.index.?_pre_post_definition
)))

;; Function-Specs vstd::seq::impl&%2::spec_index
(declare-fun req%vstd!seq.impl&%2.spec_index. (Dcr Type Poly Poly) Bool)
(declare-const %%global_location_label%%1 Bool)
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly) (i! Poly)) (!
   (= (req%vstd!seq.impl&%2.spec_index. A&. A& self! i!) (=>
     %%global_location_label%%1
     (let
      ((tmp%%$ 0))
      (let
       ((tmp%%$1 (%I i!)))
       (let
        ((tmp%%$2 (vstd!seq.Seq.len.? A&. A& self!)))
        (and
         (<= tmp%%$ tmp%%$1)
         (< tmp%%$1 tmp%%$2)
   ))))))
   :pattern ((req%vstd!seq.impl&%2.spec_index. A&. A& self! i!))
   :qid internal_req__vstd!seq.impl&__2.spec_index._definition
   :skolemid skolem_internal_req__vstd!seq.impl&__2.spec_index._definition
)))

;; Function-Axioms vstd::seq::impl&%2::spec_index
(assert
 (fuel_bool_default fuel%vstd!seq.impl&%2.spec_index.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!seq.impl&%2.spec_index.)
  (forall ((A&. Dcr) (A& Type) (self! Poly) (i! Poly)) (!
    (= (vstd!seq.impl&%2.spec_index.? A&. A& self! i!) (vstd!seq.Seq.index.? A&. A& self!
      i!
    ))
    :pattern ((vstd!seq.impl&%2.spec_index.? A&. A& self! i!))
    :qid internal_vstd!seq.impl&__2.spec_index.?_definition
    :skolemid skolem_internal_vstd!seq.impl&__2.spec_index.?_definition
))))
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly) (i! Poly)) (!
   (=>
    (and
     (has_type self! (TYPE%vstd!seq.Seq. A&. A&))
     (has_type i! INT)
    )
    (has_type (vstd!seq.impl&%2.spec_index.? A&. A& self! i!) A&)
   )
   :pattern ((vstd!seq.impl&%2.spec_index.? A&. A& self! i!))
   :qid internal_vstd!seq.impl&__2.spec_index.?_pre_post_definition
   :skolemid skolem_internal_vstd!seq.impl&__2.spec_index.?_pre_post_definition
)))

;; Broadcast vstd::seq::lemma_seq_index_decreases
(assert
 (=>
  (fuel_bool fuel%vstd!seq.lemma_seq_index_decreases.)
  (forall ((A&. Dcr) (A& Type) (s! Poly) (i! Poly)) (!
    (=>
     (and
      (has_type s! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type i! INT)
     )
     (=>
      (and
       (sized A&.)
       (let
        ((tmp%%$ 0))
        (let
         ((tmp%%$1 (%I i!)))
         (let
          ((tmp%%$2 (vstd!seq.Seq.len.? A&. A& s!)))
          (and
           (<= tmp%%$ tmp%%$1)
           (< tmp%%$1 tmp%%$2)
      )))))
      (height_lt (height (vstd!seq.Seq.index.? A&. A& s! i!)) (height s!))
    ))
    :pattern ((height (vstd!seq.Seq.index.? A&. A& s! i!)))
    :qid user_vstd__seq__lemma_seq_index_decreases_0
    :skolemid skolem_user_vstd__seq__lemma_seq_index_decreases_0
))))

;; Function-Specs vstd::seq::Seq::subrange
(declare-fun req%vstd!seq.Seq.subrange. (Dcr Type Poly Poly Poly) Bool)
(declare-const %%global_location_label%%2 Bool)
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly) (start_inclusive! Poly) (end_exclusive! Poly))
  (!
   (= (req%vstd!seq.Seq.subrange. A&. A& self! start_inclusive! end_exclusive!) (=>
     %%global_location_label%%2
     (let
      ((tmp%%$ 0))
      (let
       ((tmp%%$1 (%I start_inclusive!)))
       (let
        ((tmp%%$2 (%I end_exclusive!)))
        (let
         ((tmp%%$3 (vstd!seq.Seq.len.? A&. A& self!)))
         (and
          (and
           (<= tmp%%$ tmp%%$1)
           (<= tmp%%$1 tmp%%$2)
          )
          (<= tmp%%$2 tmp%%$3)
   )))))))
   :pattern ((req%vstd!seq.Seq.subrange. A&. A& self! start_inclusive! end_exclusive!))
   :qid internal_req__vstd!seq.Seq.subrange._definition
   :skolemid skolem_internal_req__vstd!seq.Seq.subrange._definition
)))

;; Function-Axioms vstd::seq::Seq::subrange
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly) (start_inclusive! Poly) (end_exclusive! Poly))
  (!
   (=>
    (and
     (has_type self! (TYPE%vstd!seq.Seq. A&. A&))
     (has_type start_inclusive! INT)
     (has_type end_exclusive! INT)
    )
    (has_type (vstd!seq.Seq.subrange.? A&. A& self! start_inclusive! end_exclusive!) (
      TYPE%vstd!seq.Seq. A&. A&
   )))
   :pattern ((vstd!seq.Seq.subrange.? A&. A& self! start_inclusive! end_exclusive!))
   :qid internal_vstd!seq.Seq.subrange.?_pre_post_definition
   :skolemid skolem_internal_vstd!seq.Seq.subrange.?_pre_post_definition
)))

;; Broadcast vstd::seq::lemma_seq_subrange_decreases
(assert
 (=>
  (fuel_bool fuel%vstd!seq.lemma_seq_subrange_decreases.)
  (forall ((A&. Dcr) (A& Type) (s! Poly) (i! Poly) (j! Poly)) (!
    (=>
     (and
      (has_type s! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type i! INT)
      (has_type j! INT)
     )
     (=>
      (and
       (and
        (sized A&.)
        (let
         ((tmp%%$ 0))
         (let
          ((tmp%%$1 (%I i!)))
          (let
           ((tmp%%$2 (%I j!)))
           (let
            ((tmp%%$3 (vstd!seq.Seq.len.? A&. A& s!)))
            (and
             (and
              (<= tmp%%$ tmp%%$1)
              (<= tmp%%$1 tmp%%$2)
             )
             (<= tmp%%$2 tmp%%$3)
       ))))))
       (< (vstd!seq.Seq.len.? A&. A& (vstd!seq.Seq.subrange.? A&. A& s! i! j!)) (vstd!seq.Seq.len.?
         A&. A& s!
      )))
      (height_lt (height (vstd!seq.Seq.subrange.? A&. A& s! i! j!)) (height s!))
    ))
    :pattern ((height (vstd!seq.Seq.subrange.? A&. A& s! i! j!)))
    :qid user_vstd__seq__lemma_seq_subrange_decreases_0
    :skolemid skolem_user_vstd__seq__lemma_seq_subrange_decreases_0
))))

;; Function-Axioms vstd::seq::Seq::empty
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (has_type (vstd!seq.Seq.empty.? A&. A&) (TYPE%vstd!seq.Seq. A&. A&))
   :pattern ((vstd!seq.Seq.empty.? A&. A&))
   :qid internal_vstd!seq.Seq.empty.?_pre_post_definition
   :skolemid skolem_internal_vstd!seq.Seq.empty.?_pre_post_definition
)))

;; Broadcast vstd::seq::lemma_seq_empty
(assert
 (=>
  (fuel_bool fuel%vstd!seq.lemma_seq_empty.)
  (forall ((A&. Dcr) (A& Type)) (!
    (=>
     (sized A&.)
     (= (vstd!seq.Seq.len.? A&. A& (vstd!seq.Seq.empty.? A&. A&)) 0)
    )
    :pattern ((vstd!seq.Seq.len.? A&. A& (vstd!seq.Seq.empty.? A&. A&)))
    :qid user_vstd__seq__lemma_seq_empty_0
    :skolemid skolem_user_vstd__seq__lemma_seq_empty_0
))))

;; Function-Axioms vstd::seq::Seq::new
(assert
 (forall ((A&. Dcr) (A& Type) (len! Poly) (f! Poly)) (!
   (=>
    (and
     (has_type len! NAT)
     (has_type f! (TYPE%fun%1. $ INT A&. A&))
    )
    (has_type (vstd!seq.Seq.new.? A&. A& len! f!) (TYPE%vstd!seq.Seq. A&. A&))
   )
   :pattern ((vstd!seq.Seq.new.? A&. A& len! f!))
   :qid internal_vstd!seq.Seq.new.?_pre_post_definition
   :skolemid skolem_internal_vstd!seq.Seq.new.?_pre_post_definition
)))

;; Broadcast vstd::seq::lemma_seq_new_len
(assert
 (=>
  (fuel_bool fuel%vstd!seq.lemma_seq_new_len.)
  (forall ((A&. Dcr) (A& Type) (len! Poly) (f! Poly)) (!
    (=>
     (and
      (has_type len! NAT)
      (has_type f! (TYPE%fun%1. $ INT A&. A&))
     )
     (=>
      (sized A&.)
      (= (vstd!seq.Seq.len.? A&. A& (vstd!seq.Seq.new.? A&. A& len! f!)) (%I len!))
    ))
    :pattern ((vstd!seq.Seq.len.? A&. A& (vstd!seq.Seq.new.? A&. A& len! f!)))
    :qid user_vstd__seq__lemma_seq_new_len_0
    :skolemid skolem_user_vstd__seq__lemma_seq_new_len_0
))))

;; Broadcast vstd::seq::lemma_seq_new_index
(assert
 (=>
  (fuel_bool fuel%vstd!seq.lemma_seq_new_index.)
  (forall ((A&. Dcr) (A& Type) (len! Poly) (f! Poly) (i! Poly)) (!
    (=>
     (and
      (has_type len! NAT)
      (has_type f! (TYPE%fun%1. $ INT A&. A&))
      (has_type i! INT)
     )
     (=>
      (and
       (sized A&.)
       (let
        ((tmp%%$ 0))
        (let
         ((tmp%%$1 (%I i!)))
         (let
          ((tmp%%$2 (%I len!)))
          (and
           (<= tmp%%$ tmp%%$1)
           (< tmp%%$1 tmp%%$2)
      )))))
      (= (vstd!seq.Seq.index.? A&. A& (vstd!seq.Seq.new.? A&. A& len! f!) i!) (%%apply%%0
        (%Poly%fun%1. f!) i!
    ))))
    :pattern ((vstd!seq.Seq.index.? A&. A& (vstd!seq.Seq.new.? A&. A& len! f!) i!))
    :qid user_vstd__seq__lemma_seq_new_index_0
    :skolemid skolem_user_vstd__seq__lemma_seq_new_index_0
))))

;; Function-Axioms vstd::seq::Seq::push
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly) (a! Poly)) (!
   (=>
    (and
     (has_type self! (TYPE%vstd!seq.Seq. A&. A&))
     (has_type a! A&)
    )
    (has_type (vstd!seq.Seq.push.? A&. A& self! a!) (TYPE%vstd!seq.Seq. A&. A&))
   )
   :pattern ((vstd!seq.Seq.push.? A&. A& self! a!))
   :qid internal_vstd!seq.Seq.push.?_pre_post_definition
   :skolemid skolem_internal_vstd!seq.Seq.push.?_pre_post_definition
)))

;; Broadcast vstd::seq::lemma_seq_push_len
(assert
 (=>
  (fuel_bool fuel%vstd!seq.lemma_seq_push_len.)
  (forall ((A&. Dcr) (A& Type) (s! Poly) (a! Poly)) (!
    (=>
     (and
      (has_type s! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type a! A&)
     )
     (=>
      (sized A&.)
      (= (vstd!seq.Seq.len.? A&. A& (vstd!seq.Seq.push.? A&. A& s! a!)) (nClip (Add (vstd!seq.Seq.len.?
          A&. A& s!
         ) 1
    )))))
    :pattern ((vstd!seq.Seq.len.? A&. A& (vstd!seq.Seq.push.? A&. A& s! a!)))
    :qid user_vstd__seq__lemma_seq_push_len_0
    :skolemid skolem_user_vstd__seq__lemma_seq_push_len_0
))))

;; Broadcast vstd::seq::lemma_seq_push_index_same
(assert
 (=>
  (fuel_bool fuel%vstd!seq.lemma_seq_push_index_same.)
  (forall ((A&. Dcr) (A& Type) (s! Poly) (a! Poly) (i! Poly)) (!
    (=>
     (and
      (has_type s! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type a! A&)
      (has_type i! INT)
     )
     (=>
      (and
       (sized A&.)
       (= (%I i!) (vstd!seq.Seq.len.? A&. A& s!))
      )
      (= (vstd!seq.Seq.index.? A&. A& (vstd!seq.Seq.push.? A&. A& s! a!) i!) a!)
    ))
    :pattern ((vstd!seq.Seq.index.? A&. A& (vstd!seq.Seq.push.? A&. A& s! a!) i!))
    :qid user_vstd__seq__lemma_seq_push_index_same_0
    :skolemid skolem_user_vstd__seq__lemma_seq_push_index_same_0
))))

;; Broadcast vstd::seq::lemma_seq_push_index_different
(assert
 (=>
  (fuel_bool fuel%vstd!seq.lemma_seq_push_index_different.)
  (forall ((A&. Dcr) (A& Type) (s! Poly) (a! Poly) (i! Poly)) (!
    (=>
     (and
      (has_type s! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type a! A&)
      (has_type i! INT)
     )
     (=>
      (and
       (sized A&.)
       (< (%I i!) (vstd!seq.Seq.len.? A&. A& s!))
      )
      (= (vstd!seq.Seq.index.? A&. A& (vstd!seq.Seq.push.? A&. A& s! a!) i!) (vstd!seq.Seq.index.?
        A&. A& s! i!
    ))))
    :pattern ((vstd!seq.Seq.index.? A&. A& (vstd!seq.Seq.push.? A&. A& s! a!) i!))
    :qid user_vstd__seq__lemma_seq_push_index_different_0
    :skolemid skolem_user_vstd__seq__lemma_seq_push_index_different_0
))))

;; Broadcast vstd::seq::lemma_seq_ext_equal
(assert
 (=>
  (fuel_bool fuel%vstd!seq.lemma_seq_ext_equal.)
  (forall ((A&. Dcr) (A& Type) (s1! Poly) (s2! Poly)) (!
    (=>
     (and
      (has_type s1! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type s2! (TYPE%vstd!seq.Seq. A&. A&))
     )
     (=>
      (sized A&.)
      (= (ext_eq false (TYPE%vstd!seq.Seq. A&. A&) s1! s2!) (and
        (= (vstd!seq.Seq.len.? A&. A& s1!) (vstd!seq.Seq.len.? A&. A& s2!))
        (forall ((i$ Poly)) (!
          (=>
           (has_type i$ INT)
           (=>
            (let
             ((tmp%%$ 0))
             (let
              ((tmp%%$1 (%I i$)))
              (let
               ((tmp%%$2 (vstd!seq.Seq.len.? A&. A& s1!)))
               (and
                (<= tmp%%$ tmp%%$1)
                (< tmp%%$1 tmp%%$2)
            ))))
            (= (vstd!seq.Seq.index.? A&. A& s1! i$) (vstd!seq.Seq.index.? A&. A& s2! i$))
          ))
          :pattern ((vstd!seq.Seq.index.? A&. A& s1! i$))
          :pattern ((vstd!seq.Seq.index.? A&. A& s2! i$))
          :qid user_vstd__seq__lemma_seq_ext_equal_0
          :skolemid skolem_user_vstd__seq__lemma_seq_ext_equal_0
    ))))))
    :pattern ((ext_eq false (TYPE%vstd!seq.Seq. A&. A&) s1! s2!))
    :qid user_vstd__seq__lemma_seq_ext_equal_1
    :skolemid skolem_user_vstd__seq__lemma_seq_ext_equal_1
))))

;; Broadcast vstd::seq::lemma_seq_ext_equal_deep
(assert
 (=>
  (fuel_bool fuel%vstd!seq.lemma_seq_ext_equal_deep.)
  (forall ((A&. Dcr) (A& Type) (s1! Poly) (s2! Poly)) (!
    (=>
     (and
      (has_type s1! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type s2! (TYPE%vstd!seq.Seq. A&. A&))
     )
     (=>
      (sized A&.)
      (= (ext_eq true (TYPE%vstd!seq.Seq. A&. A&) s1! s2!) (and
        (= (vstd!seq.Seq.len.? A&. A& s1!) (vstd!seq.Seq.len.? A&. A& s2!))
        (forall ((i$ Poly)) (!
          (=>
           (has_type i$ INT)
           (=>
            (let
             ((tmp%%$ 0))
             (let
              ((tmp%%$1 (%I i$)))
              (let
               ((tmp%%$2 (vstd!seq.Seq.len.? A&. A& s1!)))
               (and
                (<= tmp%%$ tmp%%$1)
                (< tmp%%$1 tmp%%$2)
            ))))
            (ext_eq true A& (vstd!seq.Seq.index.? A&. A& s1! i$) (vstd!seq.Seq.index.? A&. A& s2!
              i$
          ))))
          :pattern ((vstd!seq.Seq.index.? A&. A& s1! i$))
          :pattern ((vstd!seq.Seq.index.? A&. A& s2! i$))
          :qid user_vstd__seq__lemma_seq_ext_equal_deep_0
          :skolemid skolem_user_vstd__seq__lemma_seq_ext_equal_deep_0
    ))))))
    :pattern ((ext_eq true (TYPE%vstd!seq.Seq. A&. A&) s1! s2!))
    :qid user_vstd__seq__lemma_seq_ext_equal_deep_1
    :skolemid skolem_user_vstd__seq__lemma_seq_ext_equal_deep_1
))))

;; Broadcast vstd::seq::lemma_seq_subrange_len
(assert
 (=>
  (fuel_bool fuel%vstd!seq.lemma_seq_subrange_len.)
  (forall ((A&. Dcr) (A& Type) (s! Poly) (j! Poly) (k! Poly)) (!
    (=>
     (and
      (has_type s! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type j! INT)
      (has_type k! INT)
     )
     (=>
      (and
       (sized A&.)
       (let
        ((tmp%%$ 0))
        (let
         ((tmp%%$1 (%I j!)))
         (let
          ((tmp%%$2 (%I k!)))
          (let
           ((tmp%%$3 (vstd!seq.Seq.len.? A&. A& s!)))
           (and
            (and
             (<= tmp%%$ tmp%%$1)
             (<= tmp%%$1 tmp%%$2)
            )
            (<= tmp%%$2 tmp%%$3)
      ))))))
      (= (vstd!seq.Seq.len.? A&. A& (vstd!seq.Seq.subrange.? A&. A& s! j! k!)) (Sub (%I k!)
        (%I j!)
    ))))
    :pattern ((vstd!seq.Seq.len.? A&. A& (vstd!seq.Seq.subrange.? A&. A& s! j! k!)))
    :qid user_vstd__seq__lemma_seq_subrange_len_0
    :skolemid skolem_user_vstd__seq__lemma_seq_subrange_len_0
))))

;; Broadcast vstd::seq::lemma_seq_subrange_index
(assert
 (=>
  (fuel_bool fuel%vstd!seq.lemma_seq_subrange_index.)
  (forall ((A&. Dcr) (A& Type) (s! Poly) (j! Poly) (k! Poly) (i! Poly)) (!
    (=>
     (and
      (has_type s! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type j! INT)
      (has_type k! INT)
      (has_type i! INT)
     )
     (=>
      (and
       (and
        (sized A&.)
        (let
         ((tmp%%$ 0))
         (let
          ((tmp%%$1 (%I j!)))
          (let
           ((tmp%%$2 (%I k!)))
           (let
            ((tmp%%$3 (vstd!seq.Seq.len.? A&. A& s!)))
            (and
             (and
              (<= tmp%%$ tmp%%$1)
              (<= tmp%%$1 tmp%%$2)
             )
             (<= tmp%%$2 tmp%%$3)
       ))))))
       (let
        ((tmp%%$ 0))
        (let
         ((tmp%%$5 (%I i!)))
         (let
          ((tmp%%$6 (Sub (%I k!) (%I j!))))
          (and
           (<= tmp%%$ tmp%%$5)
           (< tmp%%$5 tmp%%$6)
      )))))
      (= (vstd!seq.Seq.index.? A&. A& (vstd!seq.Seq.subrange.? A&. A& s! j! k!) i!) (vstd!seq.Seq.index.?
        A&. A& s! (I (Add (%I i!) (%I j!)))
    ))))
    :pattern ((vstd!seq.Seq.index.? A&. A& (vstd!seq.Seq.subrange.? A&. A& s! j! k!) i!))
    :qid user_vstd__seq__lemma_seq_subrange_index_0
    :skolemid skolem_user_vstd__seq__lemma_seq_subrange_index_0
))))

;; Broadcast vstd::seq::lemma_seq_two_subranges_index
(assert
 (=>
  (fuel_bool fuel%vstd!seq.lemma_seq_two_subranges_index.)
  (forall ((A&. Dcr) (A& Type) (s! Poly) (j! Poly) (k1! Poly) (k2! Poly) (i! Poly))
   (!
    (=>
     (and
      (has_type s! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type j! INT)
      (has_type k1! INT)
      (has_type k2! INT)
      (has_type i! INT)
     )
     (=>
      (and
       (and
        (and
         (and
          (sized A&.)
          (let
           ((tmp%%$ 0))
           (let
            ((tmp%%$1 (%I j!)))
            (let
             ((tmp%%$2 (%I k1!)))
             (let
              ((tmp%%$3 (vstd!seq.Seq.len.? A&. A& s!)))
              (and
               (and
                (<= tmp%%$ tmp%%$1)
                (<= tmp%%$1 tmp%%$2)
               )
               (<= tmp%%$2 tmp%%$3)
         ))))))
         (let
          ((tmp%%$ 0))
          (let
           ((tmp%%$5 (%I j!)))
           (let
            ((tmp%%$6 (%I k2!)))
            (let
             ((tmp%%$7 (vstd!seq.Seq.len.? A&. A& s!)))
             (and
              (and
               (<= tmp%%$ tmp%%$5)
               (<= tmp%%$5 tmp%%$6)
              )
              (<= tmp%%$6 tmp%%$7)
        ))))))
        (let
         ((tmp%%$ 0))
         (let
          ((tmp%%$9 (%I i!)))
          (let
           ((tmp%%$10 (Sub (%I k1!) (%I j!))))
           (and
            (<= tmp%%$ tmp%%$9)
            (< tmp%%$9 tmp%%$10)
       )))))
       (let
        ((tmp%%$ 0))
        (let
         ((tmp%%$12 (%I i!)))
         (let
          ((tmp%%$13 (Sub (%I k2!) (%I j!))))
          (and
           (<= tmp%%$ tmp%%$12)
           (< tmp%%$12 tmp%%$13)
      )))))
      (= (vstd!seq.Seq.index.? A&. A& (vstd!seq.Seq.subrange.? A&. A& s! j! k1!) i!) (vstd!seq.Seq.index.?
        A&. A& (vstd!seq.Seq.subrange.? A&. A& s! j! k2!) i!
    ))))
    :pattern ((vstd!seq.Seq.index.? A&. A& (vstd!seq.Seq.subrange.? A&. A& s! j! k1!) i!)
     (vstd!seq.Seq.subrange.? A&. A& s! j! k2!)
    )
    :qid user_vstd__seq__lemma_seq_two_subranges_index_0
    :skolemid skolem_user_vstd__seq__lemma_seq_two_subranges_index_0
))))

;; Function-Axioms vstd::seq::Seq::add
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly) (rhs! Poly)) (!
   (=>
    (and
     (has_type self! (TYPE%vstd!seq.Seq. A&. A&))
     (has_type rhs! (TYPE%vstd!seq.Seq. A&. A&))
    )
    (has_type (vstd!seq.Seq.add.? A&. A& self! rhs!) (TYPE%vstd!seq.Seq. A&. A&))
   )
   :pattern ((vstd!seq.Seq.add.? A&. A& self! rhs!))
   :qid internal_vstd!seq.Seq.add.?_pre_post_definition
   :skolemid skolem_internal_vstd!seq.Seq.add.?_pre_post_definition
)))

;; Broadcast vstd::seq::lemma_seq_add_len
(assert
 (=>
  (fuel_bool fuel%vstd!seq.lemma_seq_add_len.)
  (forall ((A&. Dcr) (A& Type) (s1! Poly) (s2! Poly)) (!
    (=>
     (and
      (has_type s1! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type s2! (TYPE%vstd!seq.Seq. A&. A&))
     )
     (=>
      (sized A&.)
      (= (vstd!seq.Seq.len.? A&. A& (vstd!seq.Seq.add.? A&. A& s1! s2!)) (nClip (Add (vstd!seq.Seq.len.?
          A&. A& s1!
         ) (vstd!seq.Seq.len.? A&. A& s2!)
    )))))
    :pattern ((vstd!seq.Seq.len.? A&. A& (vstd!seq.Seq.add.? A&. A& s1! s2!)))
    :qid user_vstd__seq__lemma_seq_add_len_0
    :skolemid skolem_user_vstd__seq__lemma_seq_add_len_0
))))

;; Broadcast vstd::seq::lemma_seq_add_index1
(assert
 (=>
  (fuel_bool fuel%vstd!seq.lemma_seq_add_index1.)
  (forall ((A&. Dcr) (A& Type) (s1! Poly) (s2! Poly) (i! Poly)) (!
    (=>
     (and
      (has_type s1! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type s2! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type i! INT)
     )
     (=>
      (and
       (sized A&.)
       (< (%I i!) (vstd!seq.Seq.len.? A&. A& s1!))
      )
      (= (vstd!seq.Seq.index.? A&. A& (vstd!seq.Seq.add.? A&. A& s1! s2!) i!) (vstd!seq.Seq.index.?
        A&. A& s1! i!
    ))))
    :pattern ((vstd!seq.Seq.index.? A&. A& (vstd!seq.Seq.add.? A&. A& s1! s2!) i!))
    :qid user_vstd__seq__lemma_seq_add_index1_0
    :skolemid skolem_user_vstd__seq__lemma_seq_add_index1_0
))))

;; Broadcast vstd::seq::lemma_seq_add_index2
(assert
 (=>
  (fuel_bool fuel%vstd!seq.lemma_seq_add_index2.)
  (forall ((A&. Dcr) (A& Type) (s1! Poly) (s2! Poly) (i! Poly)) (!
    (=>
     (and
      (has_type s1! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type s2! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type i! INT)
     )
     (=>
      (and
       (sized A&.)
       (let
        ((tmp%%$ (vstd!seq.Seq.len.? A&. A& s1!)))
        (let
         ((tmp%%$1 (%I i!)))
         (let
          ((tmp%%$2 (nClip (Add (vstd!seq.Seq.len.? A&. A& s1!) (vstd!seq.Seq.len.? A&. A& s2!)))))
          (and
           (<= tmp%%$ tmp%%$1)
           (< tmp%%$1 tmp%%$2)
      )))))
      (= (vstd!seq.Seq.index.? A&. A& (vstd!seq.Seq.add.? A&. A& s1! s2!) i!) (vstd!seq.Seq.index.?
        A&. A& s2! (I (Sub (%I i!) (vstd!seq.Seq.len.? A&. A& s1!)))
    ))))
    :pattern ((vstd!seq.Seq.index.? A&. A& (vstd!seq.Seq.add.? A&. A& s1! s2!) i!))
    :qid user_vstd__seq__lemma_seq_add_index2_0
    :skolemid skolem_user_vstd__seq__lemma_seq_add_index2_0
))))

;; Function-Axioms vstd::seq::impl&%2::spec_add
(assert
 (fuel_bool_default fuel%vstd!seq.impl&%2.spec_add.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!seq.impl&%2.spec_add.)
  (forall ((A&. Dcr) (A& Type) (self! Poly) (rhs! Poly)) (!
    (= (vstd!seq.impl&%2.spec_add.? A&. A& self! rhs!) (vstd!seq.Seq.add.? A&. A& self!
      rhs!
    ))
    :pattern ((vstd!seq.impl&%2.spec_add.? A&. A& self! rhs!))
    :qid internal_vstd!seq.impl&__2.spec_add.?_definition
    :skolemid skolem_internal_vstd!seq.impl&__2.spec_add.?_definition
))))
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly) (rhs! Poly)) (!
   (=>
    (and
     (has_type self! (TYPE%vstd!seq.Seq. A&. A&))
     (has_type rhs! (TYPE%vstd!seq.Seq. A&. A&))
    )
    (has_type (vstd!seq.impl&%2.spec_add.? A&. A& self! rhs!) (TYPE%vstd!seq.Seq. A&. A&))
   )
   :pattern ((vstd!seq.impl&%2.spec_add.? A&. A& self! rhs!))
   :qid internal_vstd!seq.impl&__2.spec_add.?_pre_post_definition
   :skolemid skolem_internal_vstd!seq.impl&__2.spec_add.?_pre_post_definition
)))

;; Broadcast vstd::seq_lib::impl&%0::add_empty_left
(assert
 (=>
  (fuel_bool fuel%vstd!seq_lib.impl&%0.add_empty_left.)
  (forall ((A&. Dcr) (A& Type) (a! Poly) (b! Poly)) (!
    (=>
     (and
      (has_type a! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type b! (TYPE%vstd!seq.Seq. A&. A&))
     )
     (=>
      (and
       (sized A&.)
       (= (vstd!seq.Seq.len.? A&. A& a!) 0)
      )
      (= (vstd!seq.Seq.add.? A&. A& a! b!) b!)
    ))
    :pattern ((vstd!seq.Seq.add.? A&. A& a! b!))
    :qid user_vstd__seq_lib__impl&%0__add_empty_left_0
    :skolemid skolem_user_vstd__seq_lib__impl&%0__add_empty_left_0
))))

;; Broadcast vstd::seq_lib::impl&%0::add_empty_right
(assert
 (=>
  (fuel_bool fuel%vstd!seq_lib.impl&%0.add_empty_right.)
  (forall ((A&. Dcr) (A& Type) (a! Poly) (b! Poly)) (!
    (=>
     (and
      (has_type a! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type b! (TYPE%vstd!seq.Seq. A&. A&))
     )
     (=>
      (and
       (sized A&.)
       (= (vstd!seq.Seq.len.? A&. A& b!) 0)
      )
      (= (vstd!seq.Seq.add.? A&. A& a! b!) a!)
    ))
    :pattern ((vstd!seq.Seq.add.? A&. A& a! b!))
    :qid user_vstd__seq_lib__impl&%0__add_empty_right_0
    :skolemid skolem_user_vstd__seq_lib__impl&%0__add_empty_right_0
))))

;; Broadcast vstd::seq_lib::impl&%0::push_distributes_over_add
(assert
 (=>
  (fuel_bool fuel%vstd!seq_lib.impl&%0.push_distributes_over_add.)
  (forall ((A&. Dcr) (A& Type) (a! Poly) (b! Poly) (elt! Poly)) (!
    (=>
     (and
      (has_type a! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type b! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type elt! A&)
     )
     (=>
      (sized A&.)
      (= (vstd!seq.Seq.push.? A&. A& (vstd!seq.Seq.add.? A&. A& a! b!) elt!) (vstd!seq.Seq.add.?
        A&. A& a! (vstd!seq.Seq.push.? A&. A& b! elt!)
    ))))
    :pattern ((vstd!seq.Seq.push.? A&. A& (vstd!seq.Seq.add.? A&. A& a! b!) elt!))
    :qid user_vstd__seq_lib__impl&%0__push_distributes_over_add_0
    :skolemid skolem_user_vstd__seq_lib__impl&%0__push_distributes_over_add_0
))))

;; Function-Specs vstd::seq_lib::impl&%0::drop_last
(declare-fun req%vstd!seq_lib.impl&%0.drop_last. (Dcr Type Poly) Bool)
(declare-const %%global_location_label%%3 Bool)
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly)) (!
   (= (req%vstd!seq_lib.impl&%0.drop_last. A&. A& self!) (=>
     %%global_location_label%%3
     (>= (vstd!seq.Seq.len.? A&. A& self!) 1)
   ))
   :pattern ((req%vstd!seq_lib.impl&%0.drop_last. A&. A& self!))
   :qid internal_req__vstd!seq_lib.impl&__0.drop_last._definition
   :skolemid skolem_internal_req__vstd!seq_lib.impl&__0.drop_last._definition
)))

;; Function-Axioms vstd::seq_lib::impl&%0::drop_last
(assert
 (fuel_bool_default fuel%vstd!seq_lib.impl&%0.drop_last.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!seq_lib.impl&%0.drop_last.)
  (forall ((A&. Dcr) (A& Type) (self! Poly)) (!
    (= (vstd!seq_lib.impl&%0.drop_last.? A&. A& self!) (vstd!seq.Seq.subrange.? A&. A&
      self! (I 0) (I (Sub (vstd!seq.Seq.len.? A&. A& self!) 1))
    ))
    :pattern ((vstd!seq_lib.impl&%0.drop_last.? A&. A& self!))
    :qid internal_vstd!seq_lib.impl&__0.drop_last.?_definition
    :skolemid skolem_internal_vstd!seq_lib.impl&__0.drop_last.?_definition
))))
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly)) (!
   (=>
    (has_type self! (TYPE%vstd!seq.Seq. A&. A&))
    (has_type (vstd!seq_lib.impl&%0.drop_last.? A&. A& self!) (TYPE%vstd!seq.Seq. A&. A&))
   )
   :pattern ((vstd!seq_lib.impl&%0.drop_last.? A&. A& self!))
   :qid internal_vstd!seq_lib.impl&__0.drop_last.?_pre_post_definition
   :skolemid skolem_internal_vstd!seq_lib.impl&__0.drop_last.?_pre_post_definition
)))

;; Function-Specs vstd::seq::Seq::last
(declare-fun req%vstd!seq.Seq.last. (Dcr Type Poly) Bool)
(declare-const %%global_location_label%%4 Bool)
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly)) (!
   (= (req%vstd!seq.Seq.last. A&. A& self!) (=>
     %%global_location_label%%4
     (< 0 (vstd!seq.Seq.len.? A&. A& self!))
   ))
   :pattern ((req%vstd!seq.Seq.last. A&. A& self!))
   :qid internal_req__vstd!seq.Seq.last._definition
   :skolemid skolem_internal_req__vstd!seq.Seq.last._definition
)))

;; Function-Axioms vstd::seq::Seq::last
(assert
 (fuel_bool_default fuel%vstd!seq.Seq.last.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!seq.Seq.last.)
  (forall ((A&. Dcr) (A& Type) (self! Poly)) (!
    (= (vstd!seq.Seq.last.? A&. A& self!) (vstd!seq.Seq.index.? A&. A& self! (I (Sub (vstd!seq.Seq.len.?
         A&. A& self!
        ) 1
    ))))
    :pattern ((vstd!seq.Seq.last.? A&. A& self!))
    :qid internal_vstd!seq.Seq.last.?_definition
    :skolemid skolem_internal_vstd!seq.Seq.last.?_definition
))))
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly)) (!
   (=>
    (has_type self! (TYPE%vstd!seq.Seq. A&. A&))
    (has_type (vstd!seq.Seq.last.? A&. A& self!) A&)
   )
   :pattern ((vstd!seq.Seq.last.? A&. A& self!))
   :qid internal_vstd!seq.Seq.last.?_pre_post_definition
   :skolemid skolem_internal_vstd!seq.Seq.last.?_pre_post_definition
)))

;; Function-Axioms vstd::seq_lib::impl&%0::fold_left
(assert
 (fuel_bool_default fuel%vstd!seq_lib.impl&%0.fold_left.)
)
(declare-const fuel_nat%vstd!seq_lib.impl&%0.fold_left. Fuel)
(assert
 (forall ((A&. Dcr) (A& Type) (B&. Dcr) (B& Type) (self! Poly) (b! Poly) (f! Poly) (
    fuel% Fuel
   )
  ) (!
   (= (vstd!seq_lib.impl&%0.rec%fold_left.? A&. A& B&. B& self! b! f! fuel%) (vstd!seq_lib.impl&%0.rec%fold_left.?
     A&. A& B&. B& self! b! f! zero
   ))
   :pattern ((vstd!seq_lib.impl&%0.rec%fold_left.? A&. A& B&. B& self! b! f! fuel%))
   :qid internal_vstd!seq_lib.impl&__0.fold_left._fuel_to_zero_definition
   :skolemid skolem_internal_vstd!seq_lib.impl&__0.fold_left._fuel_to_zero_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (B&. Dcr) (B& Type) (self! Poly) (b! Poly) (f! Poly) (
    fuel% Fuel
   )
  ) (!
   (=>
    (and
     (sized A&.)
     (sized B&.)
     (has_type self! (TYPE%vstd!seq.Seq. A&. A&))
     (has_type b! B&)
     (has_type f! (TYPE%fun%2. B&. B& A&. A& B&. B&))
    )
    (= (vstd!seq_lib.impl&%0.rec%fold_left.? A&. A& B&. B& self! b! f! (succ fuel%)) (
      ite
      (= (vstd!seq.Seq.len.? A&. A& self!) 0)
      b!
      (%%apply%%1 (%Poly%fun%2. f!) (vstd!seq_lib.impl&%0.rec%fold_left.? A&. A& B&. B& (
         vstd!seq_lib.impl&%0.drop_last.? A&. A& self!
        ) b! f! fuel%
       ) (vstd!seq.Seq.last.? A&. A& self!)
   ))))
   :pattern ((vstd!seq_lib.impl&%0.rec%fold_left.? A&. A& B&. B& self! b! f! (succ fuel%)))
   :qid internal_vstd!seq_lib.impl&__0.fold_left._fuel_to_body_definition
   :skolemid skolem_internal_vstd!seq_lib.impl&__0.fold_left._fuel_to_body_definition
)))
(assert
 (=>
  (fuel_bool fuel%vstd!seq_lib.impl&%0.fold_left.)
  (forall ((A&. Dcr) (A& Type) (B&. Dcr) (B& Type) (self! Poly) (b! Poly) (f! Poly))
   (!
    (=>
     (and
      (sized A&.)
      (sized B&.)
      (has_type self! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type b! B&)
      (has_type f! (TYPE%fun%2. B&. B& A&. A& B&. B&))
     )
     (= (vstd!seq_lib.impl&%0.fold_left.? A&. A& B&. B& self! b! f!) (vstd!seq_lib.impl&%0.rec%fold_left.?
       A&. A& B&. B& self! b! f! (succ fuel_nat%vstd!seq_lib.impl&%0.fold_left.)
    )))
    :pattern ((vstd!seq_lib.impl&%0.fold_left.? A&. A& B&. B& self! b! f!))
    :qid internal_vstd!seq_lib.impl&__0.fold_left.?_definition
    :skolemid skolem_internal_vstd!seq_lib.impl&__0.fold_left.?_definition
))))
(assert
 (forall ((A&. Dcr) (A& Type) (B&. Dcr) (B& Type) (self! Poly) (b! Poly) (f! Poly))
  (!
   (=>
    (and
     (has_type self! (TYPE%vstd!seq.Seq. A&. A&))
     (has_type b! B&)
     (has_type f! (TYPE%fun%2. B&. B& A&. A& B&. B&))
    )
    (has_type (vstd!seq_lib.impl&%0.fold_left.? A&. A& B&. B& self! b! f!) B&)
   )
   :pattern ((vstd!seq_lib.impl&%0.fold_left.? A&. A& B&. B& self! b! f!))
   :qid internal_vstd!seq_lib.impl&__0.fold_left.?_pre_post_definition
   :skolemid skolem_internal_vstd!seq_lib.impl&__0.fold_left.?_pre_post_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (B&. Dcr) (B& Type) (self! Poly) (b! Poly) (f! Poly) (
    fuel% Fuel
   )
  ) (!
   (=>
    (and
     (has_type self! (TYPE%vstd!seq.Seq. A&. A&))
     (has_type b! B&)
     (has_type f! (TYPE%fun%2. B&. B& A&. A& B&. B&))
    )
    (has_type (vstd!seq_lib.impl&%0.rec%fold_left.? A&. A& B&. B& self! b! f! fuel%) B&)
   )
   :pattern ((vstd!seq_lib.impl&%0.rec%fold_left.? A&. A& B&. B& self! b! f! fuel%))
   :qid internal_vstd!seq_lib.impl&__0.rec__fold_left.?_pre_post_rec_definition
   :skolemid skolem_internal_vstd!seq_lib.impl&__0.rec__fold_left.?_pre_post_rec_definition
)))

;; Function-Specs vstd::seq_lib::impl&%0::lemma_fold_left_split
(declare-fun req%vstd!seq_lib.impl&%0.lemma_fold_left_split. (Dcr Type Dcr Type Poly
  Poly %%Function%% Int
 ) Bool
)
(declare-const %%global_location_label%%5 Bool)
(assert
 (forall ((A&. Dcr) (A& Type) (B&. Dcr) (B& Type) (self! Poly) (b! Poly) (f! %%Function%%)
   (k! Int)
  ) (!
   (= (req%vstd!seq_lib.impl&%0.lemma_fold_left_split. A&. A& B&. B& self! b! f! k!)
    (=>
     %%global_location_label%%5
     (let
      ((tmp%%$ 0))
      (let
       ((tmp%%$1 k!))
       (let
        ((tmp%%$2 (vstd!seq.Seq.len.? A&. A& self!)))
        (and
         (<= tmp%%$ tmp%%$1)
         (<= tmp%%$1 tmp%%$2)
   ))))))
   :pattern ((req%vstd!seq_lib.impl&%0.lemma_fold_left_split. A&. A& B&. B& self! b! f!
     k!
   ))
   :qid internal_req__vstd!seq_lib.impl&__0.lemma_fold_left_split._definition
   :skolemid skolem_internal_req__vstd!seq_lib.impl&__0.lemma_fold_left_split._definition
)))
(declare-fun ens%vstd!seq_lib.impl&%0.lemma_fold_left_split. (Dcr Type Dcr Type Poly
  Poly %%Function%% Int
 ) Bool
)
(assert
 (forall ((A&. Dcr) (A& Type) (B&. Dcr) (B& Type) (self! Poly) (b! Poly) (f! %%Function%%)
   (k! Int)
  ) (!
   (= (ens%vstd!seq_lib.impl&%0.lemma_fold_left_split. A&. A& B&. B& self! b! f! k!)
    (= (vstd!seq_lib.impl&%0.fold_left.? A&. A& B&. B& (vstd!seq.Seq.subrange.? A&. A& self!
       (I k!) (I (vstd!seq.Seq.len.? A&. A& self!))
      ) (vstd!seq_lib.impl&%0.fold_left.? A&. A& B&. B& (vstd!seq.Seq.subrange.? A&. A& self!
        (I 0) (I k!)
       ) b! (Poly%fun%2. f!)
      ) (Poly%fun%2. f!)
     ) (vstd!seq_lib.impl&%0.fold_left.? A&. A& B&. B& self! b! (Poly%fun%2. f!))
   ))
   :pattern ((ens%vstd!seq_lib.impl&%0.lemma_fold_left_split. A&. A& B&. B& self! b! f!
     k!
   ))
   :qid internal_ens__vstd!seq_lib.impl&__0.lemma_fold_left_split._definition
   :skolemid skolem_internal_ens__vstd!seq_lib.impl&__0.lemma_fold_left_split._definition
)))

;; Broadcast vstd::seq_lib::impl&%0::lemma_fold_left_split
(assert
 (=>
  (fuel_bool fuel%vstd!seq_lib.impl&%0.lemma_fold_left_split.)
  (forall ((A&. Dcr) (A& Type) (B&. Dcr) (B& Type) (self! Poly) (b! Poly) (f! Poly) (
     k! Poly
    )
   ) (!
    (=>
     (and
      (has_type self! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type b! B&)
      (has_type f! (TYPE%fun%2. B&. B& A&. A& B&. B&))
      (has_type k! INT)
     )
     (=>
      (and
       (and
        (sized A&.)
        (sized B&.)
       )
       (let
        ((tmp%%$ 0))
        (let
         ((tmp%%$1 (%I k!)))
         (let
          ((tmp%%$2 (vstd!seq.Seq.len.? A&. A& self!)))
          (and
           (<= tmp%%$ tmp%%$1)
           (<= tmp%%$1 tmp%%$2)
      )))))
      (= (vstd!seq_lib.impl&%0.fold_left.? A&. A& B&. B& (vstd!seq.Seq.subrange.? A&. A& self!
         k! (I (vstd!seq.Seq.len.? A&. A& self!))
        ) (vstd!seq_lib.impl&%0.fold_left.? A&. A& B&. B& (vstd!seq.Seq.subrange.? A&. A& self!
          (I 0) k!
         ) b! f!
        ) f!
       ) (vstd!seq_lib.impl&%0.fold_left.? A&. A& B&. B& self! b! f!)
    )))
    :pattern ((vstd!seq_lib.impl&%0.fold_left.? A&. A& B&. B& (vstd!seq.Seq.subrange.? A&.
       A& self! (I 0) k!
      ) b! f!
    ))
    :qid user_vstd__seq_lib__impl&%0__lemma_fold_left_split_0
    :skolemid skolem_user_vstd__seq_lib__impl&%0__lemma_fold_left_split_0
))))

;; Trait-Impl-Axiom
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.FnMut. F&. F& A&. A&)
    )
    (tr_bound%core!ops.function.FnOnce. $ (MUTREF F&. F&) A&. A&)
   )
   :pattern ((tr_bound%core!ops.function.FnOnce. $ (MUTREF F&. F&) A&. A&))
   :qid internal_core__ops__function__impls__impl&__4_trait_impl_definition
   :skolemid skolem_internal_core__ops__function__impls__impl&__4_trait_impl_definition
)))

;; Broadcast vstd::function::axiom_fn_mut_call_requires
(assert
 (=>
  (fuel_bool fuel%vstd!function.axiom_fn_mut_call_requires.)
  (forall ((Args&. Dcr) (Args& Type) (F&. Dcr) (F& Type) (f! Poly) (args! Poly)) (!
    (=>
     (and
      (has_type f! (MUTREF F&. F&))
      (has_type args! Args&)
     )
     (=>
      (and
       (and
        (and
         (and
          (sized Args&.)
          (sized F&.)
         )
         (tr_bound%core!marker.Tuple. Args&. Args&)
        )
        (tr_bound%core!ops.function.FnMut. F&. F& Args&. Args&)
       )
       (closure_req F& Args&. Args& (mut_ref_current% f!) args!)
      )
      (closure_req (MUTREF F&. F&) Args&. Args& f! args!)
    ))
    :pattern ((closure_req (MUTREF F&. F&) Args&. Args& f! args!))
    :qid user_vstd__function__axiom_fn_mut_call_requires_0
    :skolemid skolem_user_vstd__function__axiom_fn_mut_call_requires_0
))))

;; Broadcast vstd::function::axiom_fn_mut_call_ensures
(assert
 (=>
  (fuel_bool fuel%vstd!function.axiom_fn_mut_call_ensures.)
  (forall ((Args&. Dcr) (Args& Type) (F&. Dcr) (F& Type) (f! Poly) (args! Poly) (output!
     Poly
    )
   ) (!
    (=>
     (and
      (has_type f! (MUTREF F&. F&))
      (has_type args! Args&)
      (has_type output! (proj%core!ops.function.FnOnce./Output F&. F& Args&. Args&))
     )
     (=>
      (and
       (and
        (and
         (and
          (sized Args&.)
          (sized F&.)
         )
         (tr_bound%core!marker.Tuple. Args&. Args&)
        )
        (tr_bound%core!ops.function.FnMut. F&. F& Args&. Args&)
       )
       (closure_ens (MUTREF F&. F&) Args&. Args& f! args! output!)
      )
      (and
       (closure_ens F& Args&. Args& (mut_ref_current% f!) args! output!)
       (= (mut_ref_current% f!) (mut_ref_future% f!))
    )))
    :pattern ((closure_ens (MUTREF F&. F&) Args&. Args& f! args! output!))
    :qid user_vstd__function__axiom_fn_mut_call_ensures_0
    :skolemid skolem_user_vstd__function__axiom_fn_mut_call_ensures_0
))))

;; Function-Axioms vstd::view::View::view
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (self! Poly)) (!
   (=>
    (has_type self! Self%&)
    (has_type (vstd!view.View.view.? Self%&. Self%& self!) (proj%vstd!view.View./V Self%&.
      Self%&
   )))
   :pattern ((vstd!view.View.view.? Self%&. Self%& self!))
   :qid internal_vstd!view.View.view.?_pre_post_definition
   :skolemid skolem_internal_vstd!view.View.view.?_pre_post_definition
)))

;; Function-Axioms vstd::view::impl&%18::view
(assert
 (fuel_bool_default fuel%vstd!view.impl&%18.view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%18.view.)
  (forall ((self! Poly)) (!
    (= (vstd!view.View.view.? $ BOOL self!) self!)
    :pattern ((vstd!view.View.view.? $ BOOL self!))
    :qid internal_vstd!view.impl&__18.view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__18.view.?_definition
))))

;; Trait-Impl-Axiom
(assert
 (tr_bound%vstd!view.View. $ BOOL)
)

;; Function-Axioms vstd::view::impl&%30::view
(assert
 (fuel_bool_default fuel%vstd!view.impl&%30.view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%30.view.)
  (forall ((self! Poly)) (!
    (= (vstd!view.View.view.? $ USIZE self!) self!)
    :pattern ((vstd!view.View.view.? $ USIZE self!))
    :qid internal_vstd!view.impl&__30.view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__30.view.?_definition
))))

;; Trait-Impl-Axiom
(assert
 (tr_bound%vstd!view.View. $ USIZE)
)

;; Function-Axioms vstd::view::impl&%48::view
(assert
 (fuel_bool_default fuel%vstd!view.impl&%48.view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%48.view.)
  (forall ((A0&. Dcr) (A0& Type) (A1&. Dcr) (A1& Type) (self! Poly)) (!
    (=>
     (and
      (sized A0&.)
      (sized A1&.)
      (tr_bound%vstd!view.View. A0&. A0&)
      (tr_bound%vstd!view.View. A1&. A1&)
     )
     (= (vstd!view.View.view.? (DST A1&.) (TYPE%tuple%2. A0&. A0& A1&. A1&) self!) (Poly%tuple%2.
       (tuple%2./tuple%2 (vstd!view.View.view.? A0&. A0& (tuple%2./tuple%2/0 (%Poly%tuple%2.
           self!
         ))
        ) (vstd!view.View.view.? A1&. A1& (tuple%2./tuple%2/1 (%Poly%tuple%2. self!)))
    ))))
    :pattern ((vstd!view.View.view.? (DST A1&.) (TYPE%tuple%2. A0&. A0& A1&. A1&) self!))
    :qid internal_vstd!view.impl&__48.view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__48.view.?_definition
))))

;; Trait-Impl-Axiom
(assert
 (forall ((A0&. Dcr) (A0& Type) (A1&. Dcr) (A1& Type)) (!
   (=>
    (and
     (sized A0&.)
     (sized A1&.)
     (tr_bound%vstd!view.View. A0&. A0&)
     (tr_bound%vstd!view.View. A1&. A1&)
    )
    (tr_bound%vstd!view.View. (DST A1&.) (TYPE%tuple%2. A0&. A0& A1&. A1&))
   )
   :pattern ((tr_bound%vstd!view.View. (DST A1&.) (TYPE%tuple%2. A0&. A0& A1&. A1&)))
   :qid internal_vstd__view__impl&__48_trait_impl_definition
   :skolemid skolem_internal_vstd__view__impl&__48_trait_impl_definition
)))

;; Function-Axioms vstd::view::impl&%0::view
(assert
 (fuel_bool_default fuel%vstd!view.impl&%0.view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%0.view.)
  (forall ((A&. Dcr) (A& Type) (self! Poly)) (!
    (=>
     (tr_bound%vstd!view.View. A&. A&)
     (= (vstd!view.View.view.? (REF A&.) A& self!) (vstd!view.View.view.? A&. A& self!))
    )
    :pattern ((vstd!view.View.view.? (REF A&.) A& self!))
    :qid internal_vstd!view.impl&__0.view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__0.view.?_definition
))))

;; Trait-Impl-Axiom
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (tr_bound%vstd!view.View. A&. A&)
    (tr_bound%vstd!view.View. (REF A&.) A&)
   )
   :pattern ((tr_bound%vstd!view.View. (REF A&.) A&))
   :qid internal_vstd__view__impl&__0_trait_impl_definition
   :skolemid skolem_internal_vstd__view__impl&__0_trait_impl_definition
)))

;; Function-Axioms vstd::std_specs::vec::spec_vec_len
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type) (v! Poly)) (!
   (=>
    (has_type v! (TYPE%alloc!vec.Vec. T&. T& A&. A&))
    (uInv SZ (vstd!std_specs.vec.spec_vec_len.? T&. T& A&. A& v!))
   )
   :pattern ((vstd!std_specs.vec.spec_vec_len.? T&. T& A&. A& v!))
   :qid internal_vstd!std_specs.vec.spec_vec_len.?_pre_post_definition
   :skolemid skolem_internal_vstd!std_specs.vec.spec_vec_len.?_pre_post_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized T&.)
     (sized A&.)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (tr_bound%vstd!view.View. $ (TYPE%alloc!vec.Vec. T&. T& A&. A&))
   )
   :pattern ((tr_bound%vstd!view.View. $ (TYPE%alloc!vec.Vec. T&. T& A&. A&)))
   :qid internal_vstd__view__impl&__8_trait_impl_definition
   :skolemid skolem_internal_vstd__view__impl&__8_trait_impl_definition
)))

;; Broadcast vstd::std_specs::vec::axiom_spec_len
(assert
 (=>
  (fuel_bool fuel%vstd!std_specs.vec.axiom_spec_len.)
  (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type) (v! Poly)) (!
    (=>
     (has_type v! (TYPE%alloc!vec.Vec. T&. T& A&. A&))
     (=>
      (and
       (and
        (sized T&.)
        (sized A&.)
       )
       (tr_bound%core!alloc.Allocator. A&. A&)
      )
      (= (vstd!std_specs.vec.spec_vec_len.? T&. T& A&. A& v!) (vstd!seq.Seq.len.? T&. T&
        (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. T&. T& A&. A&) v!)
    ))))
    :pattern ((vstd!std_specs.vec.spec_vec_len.? T&. T& A&. A& v!))
    :qid user_vstd__std_specs__vec__axiom_spec_len_0
    :skolemid skolem_user_vstd__std_specs__vec__axiom_spec_len_0
))))

;; Trait-Impl-Axiom
(assert
 (tr_bound%core!alloc.Allocator. $ TYPE%alloc!alloc.Global.)
)

;; Function-Specs vstd::std_specs::vec::VecAdditionalSpecFns::spec_index
(declare-fun req%vstd!std_specs.vec.VecAdditionalSpecFns.spec_index. (Dcr Type Dcr
  Type Poly Poly
 ) Bool
)
(declare-const %%global_location_label%%6 Bool)
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (T&. Dcr) (T& Type) (self! Poly) (i! Poly)) (
   !
   (= (req%vstd!std_specs.vec.VecAdditionalSpecFns.spec_index. Self%&. Self%& T&. T& self!
     i!
    ) (=>
     %%global_location_label%%6
     (let
      ((tmp%%$ 0))
      (let
       ((tmp%%$1 (%I i!)))
       (let
        ((tmp%%$2 (vstd!seq.Seq.len.? T&. T& (vstd!view.View.view.? Self%&. Self%& self!))))
        (and
         (<= tmp%%$ tmp%%$1)
         (< tmp%%$1 tmp%%$2)
   ))))))
   :pattern ((req%vstd!std_specs.vec.VecAdditionalSpecFns.spec_index. Self%&. Self%& T&.
     T& self! i!
   ))
   :qid internal_req__vstd!std_specs.vec.VecAdditionalSpecFns.spec_index._definition
   :skolemid skolem_internal_req__vstd!std_specs.vec.VecAdditionalSpecFns.spec_index._definition
)))

;; Function-Axioms vstd::std_specs::vec::VecAdditionalSpecFns::spec_index
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (T&. Dcr) (T& Type) (self! Poly) (i! Poly)) (
   !
   (=>
    (and
     (has_type self! Self%&)
     (has_type i! INT)
    )
    (has_type (vstd!std_specs.vec.VecAdditionalSpecFns.spec_index.? Self%&. Self%& T&.
      T& self! i!
     ) T&
   ))
   :pattern ((vstd!std_specs.vec.VecAdditionalSpecFns.spec_index.? Self%&. Self%& T&.
     T& self! i!
   ))
   :qid internal_vstd!std_specs.vec.VecAdditionalSpecFns.spec_index.?_pre_post_definition
   :skolemid skolem_internal_vstd!std_specs.vec.VecAdditionalSpecFns.spec_index.?_pre_post_definition
)))

;; Function-Axioms vstd::std_specs::vec::impl&%0::spec_index
(assert
 (fuel_bool_default fuel%vstd!std_specs.vec.impl&%0.spec_index.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!std_specs.vec.impl&%0.spec_index.)
  (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type) (self! Poly) (i! Poly)) (!
    (=>
     (and
      (sized T&.)
      (sized A&.)
      (tr_bound%core!alloc.Allocator. A&. A&)
     )
     (= (vstd!std_specs.vec.VecAdditionalSpecFns.spec_index.? $ (TYPE%alloc!vec.Vec. T&.
        T& A&. A&
       ) T&. T& self! i!
      ) (vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. T&. T&
         A&. A&
        ) self!
       ) i!
    )))
    :pattern ((vstd!std_specs.vec.VecAdditionalSpecFns.spec_index.? $ (TYPE%alloc!vec.Vec.
       T&. T& A&. A&
      ) T&. T& self! i!
    ))
    :qid internal_vstd!std_specs.vec.impl&__0.spec_index.?_definition
    :skolemid skolem_internal_vstd!std_specs.vec.impl&__0.spec_index.?_definition
))))

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized T&.)
     (sized A&.)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (tr_bound%vstd!std_specs.vec.VecAdditionalSpecFns. $ (TYPE%alloc!vec.Vec. T&. T& A&.
      A&
     ) T&. T&
   ))
   :pattern ((tr_bound%vstd!std_specs.vec.VecAdditionalSpecFns. $ (TYPE%alloc!vec.Vec.
      T&. T& A&. A&
     ) T&. T&
   ))
   :qid internal_vstd__std_specs__vec__impl&__0_trait_impl_definition
   :skolemid skolem_internal_vstd__std_specs__vec__impl&__0_trait_impl_definition
)))

;; Broadcast vstd::std_specs::vec::axiom_vec_index_decreases
(assert
 (=>
  (fuel_bool fuel%vstd!std_specs.vec.axiom_vec_index_decreases.)
  (forall ((A&. Dcr) (A& Type) (v! Poly) (i! Poly)) (!
    (=>
     (and
      (has_type v! (TYPE%alloc!vec.Vec. A&. A& $ TYPE%alloc!alloc.Global.))
      (has_type i! INT)
     )
     (=>
      (and
       (sized A&.)
       (let
        ((tmp%%$ 0))
        (let
         ((tmp%%$1 (%I i!)))
         (let
          ((tmp%%$2 (vstd!std_specs.vec.spec_vec_len.? A&. A& $ TYPE%alloc!alloc.Global. v!)))
          (and
           (<= tmp%%$ tmp%%$1)
           (< tmp%%$1 tmp%%$2)
      )))))
      (height_lt (height (vstd!seq.Seq.index.? A&. A& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec.
           A&. A& $ TYPE%alloc!alloc.Global.
          ) v!
         ) i!
        )
       ) (height v!)
    )))
    :pattern ((height (vstd!seq.Seq.index.? A&. A& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec.
         A&. A& $ TYPE%alloc!alloc.Global.
        ) v!
       ) i!
    )))
    :qid user_vstd__std_specs__vec__axiom_vec_index_decreases_0
    :skolemid skolem_user_vstd__std_specs__vec__axiom_vec_index_decreases_0
))))

;; Broadcast vstd::std_specs::vec::axiom_vec_has_resolved
(assert
 (=>
  (fuel_bool fuel%vstd!std_specs.vec.axiom_vec_has_resolved.)
  (forall ((T&. Dcr) (T& Type) (vec! Poly) (i! Poly)) (!
    (=>
     (and
      (has_type vec! (TYPE%alloc!vec.Vec. T&. T& $ TYPE%alloc!alloc.Global.))
      (has_type i! INT)
     )
     (=>
      (sized T&.)
      (=>
       (let
        ((tmp%%$ 0))
        (let
         ((tmp%%$1 (%I i!)))
         (let
          ((tmp%%$2 (vstd!std_specs.vec.spec_vec_len.? T&. T& $ TYPE%alloc!alloc.Global. vec!)))
          (and
           (<= tmp%%$ tmp%%$1)
           (< tmp%%$1 tmp%%$2)
       ))))
       (=>
        (has_resolved $ (TYPE%alloc!vec.Vec. T&. T& $ TYPE%alloc!alloc.Global.) vec!)
        (has_resolved T&. T& (vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec.
            T&. T& $ TYPE%alloc!alloc.Global.
           ) vec!
          ) i!
    ))))))
    :pattern ((has_resolved $ (TYPE%alloc!vec.Vec. T&. T& $ TYPE%alloc!alloc.Global.) vec!)
     (vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. T&. T& $
        TYPE%alloc!alloc.Global.
       ) vec!
      ) i!
    ))
    :qid user_vstd__std_specs__vec__axiom_vec_has_resolved_0
    :skolemid skolem_user_vstd__std_specs__vec__axiom_vec_has_resolved_0
))))

;; Broadcast vstd::std_specs::vec::axiom_vec_decreases_to_view
(assert
 (=>
  (fuel_bool fuel%vstd!std_specs.vec.axiom_vec_decreases_to_view.)
  (forall ((T&. Dcr) (T& Type) (v! Poly)) (!
    (=>
     (has_type v! (TYPE%alloc!vec.Vec. T&. T& $ TYPE%alloc!alloc.Global.))
     (=>
      (sized T&.)
      (height_lt (height (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. T&. T& $ TYPE%alloc!alloc.Global.)
         v!
        )
       ) (height v!)
    )))
    :pattern ((height (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. T&. T& $ TYPE%alloc!alloc.Global.)
       v!
    )))
    :qid user_vstd__std_specs__vec__axiom_vec_decreases_to_view_0
    :skolemid skolem_user_vstd__std_specs__vec__axiom_vec_decreases_to_view_0
))))

;; Trait-Impl-Axiom
(assert
 (tr_bound%core!marker.Tuple. $ TYPE%tuple%0.)
)

;; Trait-Impl-Axiom
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type)) (!
   (tr_bound%core!marker.Tuple. (DST T%1&.) (TYPE%tuple%2. T%0&. T%0& T%1&. T%1&))
   :pattern ((tr_bound%core!marker.Tuple. (DST T%1&.) (TYPE%tuple%2. T%0&. T%0& T%1&. T%1&)))
   :qid internal_crate__impl_tuple&__Tuple2_trait_impl_definition
   :skolemid skolem_internal_crate__impl_tuple&__Tuple2_trait_impl_definition
)))

;; Broadcast vstd::seq_lib::lemma_seq_empty_equality
(assert
 (=>
  (fuel_bool fuel%vstd!seq_lib.lemma_seq_empty_equality.)
  (forall ((A&. Dcr) (A& Type) (s! Poly)) (!
    (=>
     (has_type s! (TYPE%vstd!seq.Seq. A&. A&))
     (=>
      (sized A&.)
      (=>
       (= (vstd!seq.Seq.len.? A&. A& s!) 0)
       (ext_eq false (TYPE%vstd!seq.Seq. A&. A&) s! (vstd!seq.Seq.empty.? A&. A&))
    )))
    :pattern ((vstd!seq.Seq.len.? A&. A& s!))
    :qid user_vstd__seq_lib__lemma_seq_empty_equality_0
    :skolemid skolem_user_vstd__seq_lib__lemma_seq_empty_equality_0
))))

;; Function-Axioms vstd::seq::impl&%2::take
(assert
 (fuel_bool_default fuel%vstd!seq.impl&%2.take.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!seq.impl&%2.take.)
  (forall ((A&. Dcr) (A& Type) (self! Poly) (n! Poly)) (!
    (= (vstd!seq.impl&%2.take.? A&. A& self! n!) (vstd!seq.Seq.subrange.? A&. A& self!
      (I 0) n!
    ))
    :pattern ((vstd!seq.impl&%2.take.? A&. A& self! n!))
    :qid internal_vstd!seq.impl&__2.take.?_definition
    :skolemid skolem_internal_vstd!seq.impl&__2.take.?_definition
))))
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly) (n! Poly)) (!
   (=>
    (and
     (has_type self! (TYPE%vstd!seq.Seq. A&. A&))
     (has_type n! INT)
    )
    (has_type (vstd!seq.impl&%2.take.? A&. A& self! n!) (TYPE%vstd!seq.Seq. A&. A&))
   )
   :pattern ((vstd!seq.impl&%2.take.? A&. A& self! n!))
   :qid internal_vstd!seq.impl&__2.take.?_pre_post_definition
   :skolemid skolem_internal_vstd!seq.impl&__2.take.?_pre_post_definition
)))

;; Broadcast vstd::seq_lib::lemma_seq_take_len
(assert
 (=>
  (fuel_bool fuel%vstd!seq_lib.lemma_seq_take_len.)
  (forall ((A&. Dcr) (A& Type) (s! Poly) (n! Poly)) (!
    (=>
     (and
      (has_type s! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type n! INT)
     )
     (=>
      (sized A&.)
      (=>
       (let
        ((tmp%%$ 0))
        (let
         ((tmp%%$1 (%I n!)))
         (let
          ((tmp%%$2 (vstd!seq.Seq.len.? A&. A& s!)))
          (and
           (<= tmp%%$ tmp%%$1)
           (<= tmp%%$1 tmp%%$2)
       ))))
       (= (vstd!seq.Seq.len.? A&. A& (vstd!seq.Seq.subrange.? A&. A& s! (I 0) n!)) (%I n!))
    )))
    :pattern ((vstd!seq.Seq.len.? A&. A& (vstd!seq.Seq.subrange.? A&. A& s! (I 0) n!)))
    :qid user_vstd__seq_lib__lemma_seq_take_len_0
    :skolemid skolem_user_vstd__seq_lib__lemma_seq_take_len_0
))))

;; Broadcast vstd::seq_lib::lemma_seq_take_index
(assert
 (=>
  (fuel_bool fuel%vstd!seq_lib.lemma_seq_take_index.)
  (forall ((A&. Dcr) (A& Type) (s! Poly) (n! Poly) (j! Poly)) (!
    (=>
     (and
      (has_type s! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type n! INT)
      (has_type j! INT)
     )
     (=>
      (sized A&.)
      (=>
       (let
        ((tmp%%$ 0))
        (let
         ((tmp%%$1 (%I j!)))
         (let
          ((tmp%%$2 (%I n!)))
          (let
           ((tmp%%$3 (vstd!seq.Seq.len.? A&. A& s!)))
           (and
            (and
             (<= tmp%%$ tmp%%$1)
             (< tmp%%$1 tmp%%$2)
            )
            (<= tmp%%$2 tmp%%$3)
       )))))
       (= (vstd!seq.Seq.index.? A&. A& (vstd!seq.Seq.subrange.? A&. A& s! (I 0) n!) j!) (
         vstd!seq.Seq.index.? A&. A& s! j!
    )))))
    :pattern ((vstd!seq.Seq.index.? A&. A& (vstd!seq.Seq.subrange.? A&. A& s! (I 0) n!)
      j!
    ))
    :qid user_vstd__seq_lib__lemma_seq_take_index_0
    :skolemid skolem_user_vstd__seq_lib__lemma_seq_take_index_0
))))

;; Function-Axioms vstd::seq::impl&%2::skip
(assert
 (fuel_bool_default fuel%vstd!seq.impl&%2.skip.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!seq.impl&%2.skip.)
  (forall ((A&. Dcr) (A& Type) (self! Poly) (n! Poly)) (!
    (= (vstd!seq.impl&%2.skip.? A&. A& self! n!) (vstd!seq.Seq.subrange.? A&. A& self!
      n! (I (vstd!seq.Seq.len.? A&. A& self!))
    ))
    :pattern ((vstd!seq.impl&%2.skip.? A&. A& self! n!))
    :qid internal_vstd!seq.impl&__2.skip.?_definition
    :skolemid skolem_internal_vstd!seq.impl&__2.skip.?_definition
))))
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly) (n! Poly)) (!
   (=>
    (and
     (has_type self! (TYPE%vstd!seq.Seq. A&. A&))
     (has_type n! INT)
    )
    (has_type (vstd!seq.impl&%2.skip.? A&. A& self! n!) (TYPE%vstd!seq.Seq. A&. A&))
   )
   :pattern ((vstd!seq.impl&%2.skip.? A&. A& self! n!))
   :qid internal_vstd!seq.impl&__2.skip.?_pre_post_definition
   :skolemid skolem_internal_vstd!seq.impl&__2.skip.?_pre_post_definition
)))

;; Broadcast vstd::seq_lib::lemma_seq_skip_len
(assert
 (=>
  (fuel_bool fuel%vstd!seq_lib.lemma_seq_skip_len.)
  (forall ((A&. Dcr) (A& Type) (s! Poly) (n! Poly)) (!
    (=>
     (and
      (has_type s! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type n! INT)
     )
     (=>
      (sized A&.)
      (=>
       (let
        ((tmp%%$ 0))
        (let
         ((tmp%%$1 (%I n!)))
         (let
          ((tmp%%$2 (vstd!seq.Seq.len.? A&. A& s!)))
          (and
           (<= tmp%%$ tmp%%$1)
           (<= tmp%%$1 tmp%%$2)
       ))))
       (= (vstd!seq.Seq.len.? A&. A& (vstd!seq.Seq.subrange.? A&. A& s! n! (I (vstd!seq.Seq.len.?
            A&. A& s!
         )))
        ) (Sub (vstd!seq.Seq.len.? A&. A& s!) (%I n!))
    ))))
    :pattern ((vstd!seq.Seq.len.? A&. A& (vstd!seq.Seq.subrange.? A&. A& s! n! (I (vstd!seq.Seq.len.?
         A&. A& s!
    )))))
    :qid user_vstd__seq_lib__lemma_seq_skip_len_0
    :skolemid skolem_user_vstd__seq_lib__lemma_seq_skip_len_0
))))

;; Broadcast vstd::seq_lib::lemma_seq_skip_index
(assert
 (=>
  (fuel_bool fuel%vstd!seq_lib.lemma_seq_skip_index.)
  (forall ((A&. Dcr) (A& Type) (s! Poly) (n! Poly) (j! Poly)) (!
    (=>
     (and
      (has_type s! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type n! INT)
      (has_type j! INT)
     )
     (=>
      (sized A&.)
      (=>
       (and
        (<= 0 (%I n!))
        (let
         ((tmp%%$ 0))
         (let
          ((tmp%%$1 (%I j!)))
          (let
           ((tmp%%$2 (Sub (vstd!seq.Seq.len.? A&. A& s!) (%I n!))))
           (and
            (<= tmp%%$ tmp%%$1)
            (< tmp%%$1 tmp%%$2)
       )))))
       (= (vstd!seq.Seq.index.? A&. A& (vstd!seq.Seq.subrange.? A&. A& s! n! (I (vstd!seq.Seq.len.?
            A&. A& s!
          ))
         ) j!
        ) (vstd!seq.Seq.index.? A&. A& s! (I (Add (%I j!) (%I n!))))
    ))))
    :pattern ((vstd!seq.Seq.index.? A&. A& (vstd!seq.Seq.subrange.? A&. A& s! n! (I (vstd!seq.Seq.len.?
         A&. A& s!
       ))
      ) j!
    ))
    :qid user_vstd__seq_lib__lemma_seq_skip_index_0
    :skolemid skolem_user_vstd__seq_lib__lemma_seq_skip_index_0
))))

;; Broadcast vstd::seq_lib::lemma_seq_skip_index2
(assert
 (=>
  (fuel_bool fuel%vstd!seq_lib.lemma_seq_skip_index2.)
  (forall ((A&. Dcr) (A& Type) (s! Poly) (n! Poly) (k! Poly)) (!
    (=>
     (and
      (has_type s! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type n! INT)
      (has_type k! INT)
     )
     (=>
      (sized A&.)
      (=>
       (let
        ((tmp%%$ 0))
        (let
         ((tmp%%$1 (%I n!)))
         (let
          ((tmp%%$2 (%I k!)))
          (let
           ((tmp%%$3 (vstd!seq.Seq.len.? A&. A& s!)))
           (and
            (and
             (<= tmp%%$ tmp%%$1)
             (<= tmp%%$1 tmp%%$2)
            )
            (< tmp%%$2 tmp%%$3)
       )))))
       (= (vstd!seq.Seq.index.? A&. A& (vstd!seq.Seq.subrange.? A&. A& s! n! (I (vstd!seq.Seq.len.?
            A&. A& s!
          ))
         ) (I (Sub (%I k!) (%I n!)))
        ) (vstd!seq.Seq.index.? A&. A& s! k!)
    ))))
    :pattern ((vstd!seq.Seq.subrange.? A&. A& s! n! (I (vstd!seq.Seq.len.? A&. A& s!)))
     (vstd!seq.Seq.index.? A&. A& s! k!)
    )
    :qid user_vstd__seq_lib__lemma_seq_skip_index2_0
    :skolemid skolem_user_vstd__seq_lib__lemma_seq_skip_index2_0
))))

;; Broadcast vstd::seq_lib::lemma_seq_append_take_skip
(assert
 (=>
  (fuel_bool fuel%vstd!seq_lib.lemma_seq_append_take_skip.)
  (forall ((A&. Dcr) (A& Type) (a! Poly) (b! Poly) (n! Poly)) (!
    (=>
     (and
      (has_type a! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type b! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type n! INT)
     )
     (=>
      (sized A&.)
      (=>
       (= (%I n!) (vstd!seq.Seq.len.? A&. A& a!))
       (and
        (ext_eq false (TYPE%vstd!seq.Seq. A&. A&) (vstd!seq.Seq.subrange.? A&. A& (vstd!seq.Seq.add.?
           A&. A& a! b!
          ) (I 0) n!
         ) a!
        )
        (ext_eq false (TYPE%vstd!seq.Seq. A&. A&) (vstd!seq.Seq.subrange.? A&. A& (vstd!seq.Seq.add.?
           A&. A& a! b!
          ) n! (I (vstd!seq.Seq.len.? A&. A& (vstd!seq.Seq.add.? A&. A& a! b!)))
         ) b!
    )))))
    :pattern ((vstd!seq.Seq.subrange.? A&. A& (vstd!seq.Seq.add.? A&. A& a! b!) (I 0) n!))
    :pattern ((vstd!seq.Seq.subrange.? A&. A& (vstd!seq.Seq.add.? A&. A& a! b!) n! (I (vstd!seq.Seq.len.?
        A&. A& (vstd!seq.Seq.add.? A&. A& a! b!)
    ))))
    :qid user_vstd__seq_lib__lemma_seq_append_take_skip_0
    :skolemid skolem_user_vstd__seq_lib__lemma_seq_append_take_skip_0
))))

;; Broadcast vstd::seq_lib::lemma_seq_skip_build_commut
(assert
 (=>
  (fuel_bool fuel%vstd!seq_lib.lemma_seq_skip_build_commut.)
  (forall ((A&. Dcr) (A& Type) (s! Poly) (v! Poly) (n! Poly)) (!
    (=>
     (and
      (has_type s! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type v! A&)
      (has_type n! INT)
     )
     (=>
      (sized A&.)
      (=>
       (let
        ((tmp%%$ 0))
        (let
         ((tmp%%$1 (%I n!)))
         (let
          ((tmp%%$2 (vstd!seq.Seq.len.? A&. A& s!)))
          (and
           (<= tmp%%$ tmp%%$1)
           (<= tmp%%$1 tmp%%$2)
       ))))
       (ext_eq false (TYPE%vstd!seq.Seq. A&. A&) (vstd!seq.Seq.subrange.? A&. A& (vstd!seq.Seq.push.?
          A&. A& s! v!
         ) n! (I (vstd!seq.Seq.len.? A&. A& (vstd!seq.Seq.push.? A&. A& s! v!)))
        ) (vstd!seq.Seq.push.? A&. A& (vstd!seq.Seq.subrange.? A&. A& s! n! (I (vstd!seq.Seq.len.?
            A&. A& s!
          ))
         ) v!
    )))))
    :pattern ((vstd!seq.Seq.subrange.? A&. A& (vstd!seq.Seq.push.? A&. A& s! v!) n! (I (
        vstd!seq.Seq.len.? A&. A& (vstd!seq.Seq.push.? A&. A& s! v!)
    ))))
    :qid user_vstd__seq_lib__lemma_seq_skip_build_commut_0
    :skolemid skolem_user_vstd__seq_lib__lemma_seq_skip_build_commut_0
))))

;; Broadcast vstd::seq_lib::lemma_seq_skip_nothing
(assert
 (=>
  (fuel_bool fuel%vstd!seq_lib.lemma_seq_skip_nothing.)
  (forall ((A&. Dcr) (A& Type) (s! Poly) (n! Poly)) (!
    (=>
     (and
      (has_type s! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type n! INT)
     )
     (=>
      (sized A&.)
      (=>
       (= (%I n!) 0)
       (ext_eq false (TYPE%vstd!seq.Seq. A&. A&) (vstd!seq.Seq.subrange.? A&. A& s! n! (I (
           vstd!seq.Seq.len.? A&. A& s!
         ))
        ) s!
    ))))
    :pattern ((vstd!seq.Seq.subrange.? A&. A& s! n! (I (vstd!seq.Seq.len.? A&. A& s!))))
    :qid user_vstd__seq_lib__lemma_seq_skip_nothing_0
    :skolemid skolem_user_vstd__seq_lib__lemma_seq_skip_nothing_0
))))

;; Broadcast vstd::seq_lib::lemma_seq_take_nothing
(assert
 (=>
  (fuel_bool fuel%vstd!seq_lib.lemma_seq_take_nothing.)
  (forall ((A&. Dcr) (A& Type) (s! Poly) (n! Poly)) (!
    (=>
     (and
      (has_type s! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type n! INT)
     )
     (=>
      (sized A&.)
      (=>
       (= (%I n!) 0)
       (ext_eq false (TYPE%vstd!seq.Seq. A&. A&) (vstd!seq.Seq.subrange.? A&. A& s! (I 0)
         n!
        ) (vstd!seq.Seq.empty.? A&. A&)
    ))))
    :pattern ((vstd!seq.Seq.subrange.? A&. A& s! (I 0) n!))
    :qid user_vstd__seq_lib__lemma_seq_take_nothing_0
    :skolemid skolem_user_vstd__seq_lib__lemma_seq_take_nothing_0
))))

;; Trait-Impl-Axiom
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.Fn. F&. F& A&. A&)
    )
    (tr_bound%core!ops.function.FnOnce. (REF F&.) F& A&. A&)
   )
   :pattern ((tr_bound%core!ops.function.FnOnce. (REF F&.) F& A&. A&))
   :qid internal_core__ops__function__impls__impl&__2_trait_impl_definition
   :skolemid skolem_internal_core__ops__function__impls__impl&__2_trait_impl_definition
)))

;; Function-Axioms vstd::pervasive::FnWithRequiresEnsures::requires
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (Args&. Dcr) (Args& Type) (Output&. Dcr) (Output&
    Type
   ) (self! Poly) (args! Poly)
  ) (!
   (=>
    (and
     (has_type self! Self%&)
     (has_type args! Args&)
    )
    (has_type (vstd!pervasive.FnWithRequiresEnsures.requires.? Self%&. Self%& Args&. Args&
      Output&. Output& self! args!
     ) BOOL
   ))
   :pattern ((vstd!pervasive.FnWithRequiresEnsures.requires.? Self%&. Self%& Args&. Args&
     Output&. Output& self! args!
   ))
   :qid internal_vstd!pervasive.FnWithRequiresEnsures.requires.?_pre_post_definition
   :skolemid skolem_internal_vstd!pervasive.FnWithRequiresEnsures.requires.?_pre_post_definition
)))

;; Function-Axioms vstd::pervasive::FnWithRequiresEnsures::ensures
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (Args&. Dcr) (Args& Type) (Output&. Dcr) (Output&
    Type
   ) (self! Poly) (args! Poly) (output! Poly)
  ) (!
   (=>
    (and
     (has_type self! Self%&)
     (has_type args! Args&)
     (has_type output! Output&)
    )
    (has_type (vstd!pervasive.FnWithRequiresEnsures.ensures.? Self%&. Self%& Args&. Args&
      Output&. Output& self! args! output!
     ) BOOL
   ))
   :pattern ((vstd!pervasive.FnWithRequiresEnsures.ensures.? Self%&. Self%& Args&. Args&
     Output&. Output& self! args! output!
   ))
   :qid internal_vstd!pervasive.FnWithRequiresEnsures.ensures.?_pre_post_definition
   :skolemid skolem_internal_vstd!pervasive.FnWithRequiresEnsures.ensures.?_pre_post_definition
)))

;; Function-Axioms vstd::pervasive::impl&%0::requires
(assert
 (fuel_bool_default fuel%vstd!pervasive.impl&%0.requires.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!pervasive.impl&%0.requires.)
  (forall ((Args&. Dcr) (Args& Type) (Output&. Dcr) (Output& Type) (F&. Dcr) (F& Type)
    (self! Poly) (args! Poly)
   ) (!
    (=>
     (and
      (and
       (= Output&. (proj%%core!ops.function.FnOnce./Output F&. F& Args&. Args&))
       (= Output& (proj%core!ops.function.FnOnce./Output F&. F& Args&. Args&))
      )
      (sized Output&.)
      (sized F&.)
      (tr_bound%core!marker.Tuple. Args&. Args&)
      (tr_bound%core!ops.function.FnOnce. F&. F& Args&. Args&)
      (sized Args&.)
     )
     (= (vstd!pervasive.FnWithRequiresEnsures.requires.? F&. F& Args&. Args& Output&. Output&
       self! args!
      ) (B (closure_req F& Args&. Args& self! args!))
    ))
    :pattern ((vstd!pervasive.FnWithRequiresEnsures.requires.? F&. F& Args&. Args& Output&.
      Output& self! args!
    ))
    :qid internal_vstd!pervasive.impl&__0.requires.?_definition
    :skolemid skolem_internal_vstd!pervasive.impl&__0.requires.?_definition
))))

;; Function-Axioms vstd::pervasive::impl&%0::ensures
(assert
 (fuel_bool_default fuel%vstd!pervasive.impl&%0.ensures.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!pervasive.impl&%0.ensures.)
  (forall ((Args&. Dcr) (Args& Type) (Output&. Dcr) (Output& Type) (F&. Dcr) (F& Type)
    (self! Poly) (args! Poly) (output! Poly)
   ) (!
    (=>
     (and
      (and
       (= Output&. (proj%%core!ops.function.FnOnce./Output F&. F& Args&. Args&))
       (= Output& (proj%core!ops.function.FnOnce./Output F&. F& Args&. Args&))
      )
      (sized Output&.)
      (sized F&.)
      (tr_bound%core!marker.Tuple. Args&. Args&)
      (tr_bound%core!ops.function.FnOnce. F&. F& Args&. Args&)
      (sized Args&.)
     )
     (= (vstd!pervasive.FnWithRequiresEnsures.ensures.? F&. F& Args&. Args& Output&. Output&
       self! args! output!
      ) (B (closure_ens F& Args&. Args& self! args! output!))
    ))
    :pattern ((vstd!pervasive.FnWithRequiresEnsures.ensures.? F&. F& Args&. Args& Output&.
      Output& self! args! output!
    ))
    :qid internal_vstd!pervasive.impl&__0.ensures.?_definition
    :skolemid skolem_internal_vstd!pervasive.impl&__0.ensures.?_definition
))))

;; Trait-Impl-Axiom
(assert
 (forall ((Args&. Dcr) (Args& Type) (Output&. Dcr) (Output& Type) (F&. Dcr) (F& Type))
  (!
   (=>
    (and
     (and
      (= Output&. (proj%%core!ops.function.FnOnce./Output F&. F& Args&. Args&))
      (= Output& (proj%core!ops.function.FnOnce./Output F&. F& Args&. Args&))
     )
     (sized Output&.)
     (sized F&.)
     (tr_bound%core!marker.Tuple. Args&. Args&)
     (tr_bound%core!ops.function.FnOnce. F&. F& Args&. Args&)
     (sized Args&.)
    )
    (tr_bound%vstd!pervasive.FnWithRequiresEnsures. F&. F& Args&. Args& Output&. Output&)
   )
   :pattern ((tr_bound%vstd!pervasive.FnWithRequiresEnsures. F&. F& Args&. Args& Output&.
     Output&
   ))
   :qid internal_vstd__pervasive__impl&__0_trait_impl_definition
   :skolemid skolem_internal_vstd__pervasive__impl&__0_trait_impl_definition
)))

;; Function-Axioms lib::Chap18::ArraySeqSpecsAndLemmas::ArraySeqSpecsAndLemmas::spec_iterate
(assert
 (fuel_bool_default fuel%lib!Chap18.ArraySeqSpecsAndLemmas.ArraySeqSpecsAndLemmas.spec_iterate.)
)
(assert
 (=>
  (fuel_bool fuel%lib!Chap18.ArraySeqSpecsAndLemmas.ArraySeqSpecsAndLemmas.spec_iterate.)
  (forall ((A&. Dcr) (A& Type) (T&. Dcr) (T& Type) (s! Poly) (f! Poly) (start_x! Poly))
   (!
    (= (lib!Chap18.ArraySeqSpecsAndLemmas.ArraySeqSpecsAndLemmas.spec_iterate.? A&. A&
      T&. T& s! f! start_x!
     ) (vstd!seq_lib.impl&%0.fold_left.? T&. T& A&. A& s! start_x! f!)
    )
    :pattern ((lib!Chap18.ArraySeqSpecsAndLemmas.ArraySeqSpecsAndLemmas.spec_iterate.?
      A&. A& T&. T& s! f! start_x!
    ))
    :qid internal_lib!Chap18.ArraySeqSpecsAndLemmas.ArraySeqSpecsAndLemmas.spec_iterate.?_definition
    :skolemid skolem_internal_lib!Chap18.ArraySeqSpecsAndLemmas.ArraySeqSpecsAndLemmas.spec_iterate.?_definition
))))
(assert
 (forall ((A&. Dcr) (A& Type) (T&. Dcr) (T& Type) (s! Poly) (f! Poly) (start_x! Poly))
  (!
   (=>
    (and
     (has_type s! (TYPE%vstd!seq.Seq. T&. T&))
     (has_type f! (TYPE%fun%2. A&. A& T&. T& A&. A&))
     (has_type start_x! A&)
    )
    (has_type (lib!Chap18.ArraySeqSpecsAndLemmas.ArraySeqSpecsAndLemmas.spec_iterate.?
      A&. A& T&. T& s! f! start_x!
     ) A&
   ))
   :pattern ((lib!Chap18.ArraySeqSpecsAndLemmas.ArraySeqSpecsAndLemmas.spec_iterate.?
     A&. A& T&. T& s! f! start_x!
   ))
   :qid internal_lib!Chap18.ArraySeqSpecsAndLemmas.ArraySeqSpecsAndLemmas.spec_iterate.?_pre_post_definition
   :skolemid skolem_internal_lib!Chap18.ArraySeqSpecsAndLemmas.ArraySeqSpecsAndLemmas.spec_iterate.?_pre_post_definition
)))

;; Function-Axioms vstd::relations::associative
(assert
 (fuel_bool_default fuel%vstd!relations.associative.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!relations.associative.)
  (forall ((T&. Dcr) (T& Type) (r! Poly)) (!
    (= (vstd!relations.associative.? T&. T& r!) (forall ((x$ Poly) (y$ Poly) (z$ Poly))
      (!
       (=>
        (and
         (has_type x$ T&)
         (has_type y$ T&)
         (has_type z$ T&)
        )
        (= (%%apply%%1 (%Poly%fun%2. r!) x$ (%%apply%%1 (%Poly%fun%2. r!) y$ z$)) (%%apply%%1
          (%Poly%fun%2. r!) (%%apply%%1 (%Poly%fun%2. r!) x$ y$) z$
       )))
       :pattern ((%%apply%%1 (%Poly%fun%2. r!) x$ (%%apply%%1 (%Poly%fun%2. r!) y$ z$)) (
         %%apply%%1 (%Poly%fun%2. r!) (%%apply%%1 (%Poly%fun%2. r!) x$ y$) z$
       ))
       :qid user_vstd__relations__associative_0
       :skolemid skolem_user_vstd__relations__associative_0
    )))
    :pattern ((vstd!relations.associative.? T&. T& r!))
    :qid internal_vstd!relations.associative.?_definition
    :skolemid skolem_internal_vstd!relations.associative.?_definition
))))

;; Function-Axioms lib::vstdplus::monoid::monoid::spec_left_identity
(assert
 (fuel_bool_default fuel%lib!vstdplus.monoid.monoid.spec_left_identity.)
)
(assert
 (=>
  (fuel_bool fuel%lib!vstdplus.monoid.monoid.spec_left_identity.)
  (forall ((T&. Dcr) (T& Type) (f! Poly) (id! Poly)) (!
    (= (lib!vstdplus.monoid.monoid.spec_left_identity.? T&. T& f! id!) (forall ((x$ Poly))
      (!
       (=>
        (has_type x$ T&)
        (= (%%apply%%1 (%Poly%fun%2. f!) id! x$) x$)
       )
       :pattern ((%%apply%%1 (%Poly%fun%2. f!) id! x$))
       :qid user_lib__vstdplus__monoid__monoid__spec_left_identity_0
       :skolemid skolem_user_lib__vstdplus__monoid__monoid__spec_left_identity_0
    )))
    :pattern ((lib!vstdplus.monoid.monoid.spec_left_identity.? T&. T& f! id!))
    :qid internal_lib!vstdplus.monoid.monoid.spec_left_identity.?_definition
    :skolemid skolem_internal_lib!vstdplus.monoid.monoid.spec_left_identity.?_definition
))))

;; Function-Axioms lib::vstdplus::monoid::monoid::spec_right_identity
(assert
 (fuel_bool_default fuel%lib!vstdplus.monoid.monoid.spec_right_identity.)
)
(assert
 (=>
  (fuel_bool fuel%lib!vstdplus.monoid.monoid.spec_right_identity.)
  (forall ((T&. Dcr) (T& Type) (f! Poly) (id! Poly)) (!
    (= (lib!vstdplus.monoid.monoid.spec_right_identity.? T&. T& f! id!) (forall ((x$ Poly))
      (!
       (=>
        (has_type x$ T&)
        (= (%%apply%%1 (%Poly%fun%2. f!) x$ id!) x$)
       )
       :pattern ((%%apply%%1 (%Poly%fun%2. f!) x$ id!))
       :qid user_lib__vstdplus__monoid__monoid__spec_right_identity_0
       :skolemid skolem_user_lib__vstdplus__monoid__monoid__spec_right_identity_0
    )))
    :pattern ((lib!vstdplus.monoid.monoid.spec_right_identity.? T&. T& f! id!))
    :qid internal_lib!vstdplus.monoid.monoid.spec_right_identity.?_definition
    :skolemid skolem_internal_lib!vstdplus.monoid.monoid.spec_right_identity.?_definition
))))

;; Function-Axioms lib::vstdplus::monoid::monoid::spec_monoid
(assert
 (fuel_bool_default fuel%lib!vstdplus.monoid.monoid.spec_monoid.)
)
(assert
 (=>
  (fuel_bool fuel%lib!vstdplus.monoid.monoid.spec_monoid.)
  (forall ((T&. Dcr) (T& Type) (f! Poly) (id! Poly)) (!
    (= (lib!vstdplus.monoid.monoid.spec_monoid.? T&. T& f! id!) (and
      (and
       (vstd!relations.associative.? T&. T& f!)
       (lib!vstdplus.monoid.monoid.spec_left_identity.? T&. T& f! id!)
      )
      (lib!vstdplus.monoid.monoid.spec_right_identity.? T&. T& f! id!)
    ))
    :pattern ((lib!vstdplus.monoid.monoid.spec_monoid.? T&. T& f! id!))
    :qid internal_lib!vstdplus.monoid.monoid.spec_monoid.?_definition
    :skolemid skolem_internal_lib!vstdplus.monoid.monoid.spec_monoid.?_definition
))))

;; Function-Specs vstd::std_specs::vec::vec_index
(declare-fun req%vstd!std_specs.vec.vec_index. (Dcr Type Dcr Type Poly Int) Bool)
(declare-const %%global_location_label%%7 Bool)
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type) (vec! Poly) (i! Int)) (!
   (= (req%vstd!std_specs.vec.vec_index. T&. T& A&. A& vec! i!) (=>
     %%global_location_label%%7
     (< i! (vstd!seq.Seq.len.? T&. T& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. T&. T&
         A&. A&
        ) vec!
   )))))
   :pattern ((req%vstd!std_specs.vec.vec_index. T&. T& A&. A& vec! i!))
   :qid internal_req__vstd!std_specs.vec.vec_index._definition
   :skolemid skolem_internal_req__vstd!std_specs.vec.vec_index._definition
)))
(declare-fun ens%vstd!std_specs.vec.vec_index. (Dcr Type Dcr Type Poly Int Poly) Bool)
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type) (vec! Poly) (i! Int) (element! Poly))
  (!
   (= (ens%vstd!std_specs.vec.vec_index. T&. T& A&. A& vec! i! element!) (and
     (has_type element! T&)
     (= element! (vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec.
         T&. T& A&. A&
        ) vec!
       ) (I i!)
   ))))
   :pattern ((ens%vstd!std_specs.vec.vec_index. T&. T& A&. A& vec! i! element!))
   :qid internal_ens__vstd!std_specs.vec.vec_index._definition
   :skolemid skolem_internal_ens__vstd!std_specs.vec.vec_index._definition
)))

;; Function-Specs alloc::vec::impl&%0::with_capacity
(declare-fun ens%alloc!vec.impl&%0.with_capacity. (Dcr Type Int Poly) Bool)
(assert
 (forall ((T&. Dcr) (T& Type) (capacity! Int) (v! Poly)) (!
   (= (ens%alloc!vec.impl&%0.with_capacity. T&. T& capacity! v!) (and
     (has_type v! (TYPE%alloc!vec.Vec. T&. T& $ TYPE%alloc!alloc.Global.))
     (= (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. T&. T& $ TYPE%alloc!alloc.Global.)
       v!
      ) (vstd!seq.Seq.empty.? T&. T&)
   )))
   :pattern ((ens%alloc!vec.impl&%0.with_capacity. T&. T& capacity! v!))
   :qid internal_ens__alloc!vec.impl&__0.with_capacity._definition
   :skolemid skolem_internal_ens__alloc!vec.impl&__0.with_capacity._definition
)))

;; Function-Specs alloc::vec::impl&%43::push
(declare-fun ens%alloc!vec.impl&%43.push. (Dcr Type Dcr Type Poly Poly) Bool)
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type) (vec! Poly) (value! Poly)) (!
   (= (ens%alloc!vec.impl&%43.push. T&. T& A&. A& vec! value!) (= (vstd!view.View.view.?
      $ (TYPE%alloc!vec.Vec. T&. T& A&. A&) (mut_ref_future% vec!)
     ) (vstd!seq.Seq.push.? T&. T& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. T&. T& A&.
        A&
       ) (mut_ref_current% vec!)
      ) value!
   )))
   :pattern ((ens%alloc!vec.impl&%43.push. T&. T& A&. A& vec! value!))
   :qid internal_ens__alloc!vec.impl&__43.push._definition
   :skolemid skolem_internal_ens__alloc!vec.impl&__43.push._definition
)))

;; Function-Axioms lib::Chap18::ArraySeqMtPer::ArraySeqMtPer::ArraySeqMtPerBaseTrait::spec_arrayseqmtper_wf
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (T&. Dcr) (T& Type) (self! Poly)) (!
   (=>
    (has_type self! Self%&)
    (has_type (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_arrayseqmtper_wf.?
      Self%&. Self%& T&. T& self!
     ) BOOL
   ))
   :pattern ((lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_arrayseqmtper_wf.?
     Self%&. Self%& T&. T& self!
   ))
   :qid internal_lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_arrayseqmtper_wf.?_pre_post_definition
   :skolemid skolem_internal_lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_arrayseqmtper_wf.?_pre_post_definition
)))

;; Function-Axioms lib::Chap18::ArraySeqMtPer::ArraySeqMtPer::ArraySeqMtPerBaseTrait::spec_len
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (T&. Dcr) (T& Type) (self! Poly)) (!
   (=>
    (has_type self! Self%&)
    (has_type (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_len.?
      Self%&. Self%& T&. T& self!
     ) NAT
   ))
   :pattern ((lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_len.?
     Self%&. Self%& T&. T& self!
   ))
   :qid internal_lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_len.?_pre_post_definition
   :skolemid skolem_internal_lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_len.?_pre_post_definition
)))

;; Function-Specs lib::Chap18::ArraySeqMtPer::ArraySeqMtPer::ArraySeqMtPerBaseTrait::spec_index
(declare-fun req%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_index.
 (Dcr Type Dcr Type Poly Poly) Bool
)
(declare-const %%global_location_label%%8 Bool)
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (T&. Dcr) (T& Type) (self! Poly) (i! Poly)) (
   !
   (= (req%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_index. Self%&.
     Self%& T&. T& self! i!
    ) (=>
     %%global_location_label%%8
     (< (%I i!) (%I (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_len.?
        Self%&. Self%& T&. T& self!
   )))))
   :pattern ((req%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_index.
     Self%&. Self%& T&. T& self! i!
   ))
   :qid internal_req__lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_index._definition
   :skolemid skolem_internal_req__lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_index._definition
)))

;; Function-Axioms lib::Chap18::ArraySeqMtPer::ArraySeqMtPer::ArraySeqMtPerBaseTrait::spec_index
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (T&. Dcr) (T& Type) (self! Poly) (i! Poly)) (
   !
   (=>
    (and
     (has_type self! Self%&)
     (has_type i! INT)
    )
    (has_type (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_index.?
      Self%&. Self%& T&. T& self! i!
     ) T&
   ))
   :pattern ((lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_index.?
     Self%&. Self%& T&. T& self! i!
   ))
   :qid internal_lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_index.?_pre_post_definition
   :skolemid skolem_internal_lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_index.?_pre_post_definition
)))

;; Function-Specs lib::Chap18::ArraySeqMtPer::ArraySeqMtPer::ArraySeqMtPerBaseTrait::length
(declare-fun ens%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.length.
 (Dcr Type Dcr Type Poly Poly) Bool
)
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (T&. Dcr) (T& Type) (self! Poly) (len! Poly))
  (!
   (= (ens%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.length. Self%&.
     Self%& T&. T& self! len!
    ) (and
     (has_type len! USIZE)
     (= len! (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_len.? Self%&.
       Self%& T&. T& self!
   ))))
   :pattern ((ens%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.length.
     Self%&. Self%& T&. T& self! len!
   ))
   :qid internal_ens__lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.length._definition
   :skolemid skolem_internal_ens__lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.length._definition
)))

;; Function-Specs lib::Chap18::ArraySeqMtPer::ArraySeqMtPer::ArraySeqMtPerBaseTrait::nth
(declare-fun req%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.nth.
 (Dcr Type Dcr Type Poly Poly) Bool
)
(declare-const %%global_location_label%%9 Bool)
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (T&. Dcr) (T& Type) (self! Poly) (index! Poly))
  (!
   (= (req%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.nth. Self%&.
     Self%& T&. T& self! index!
    ) (=>
     %%global_location_label%%9
     (< (%I index!) (%I (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_len.?
        Self%&. Self%& T&. T& self!
   )))))
   :pattern ((req%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.nth. Self%&.
     Self%& T&. T& self! index!
   ))
   :qid internal_req__lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.nth._definition
   :skolemid skolem_internal_req__lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.nth._definition
)))
(declare-fun ens%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.nth.
 (Dcr Type Dcr Type Poly Poly Poly) Bool
)
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (T&. Dcr) (T& Type) (self! Poly) (index! Poly)
   (nth_elem! Poly)
  ) (!
   (= (ens%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.nth. Self%&.
     Self%& T&. T& self! index! nth_elem!
    ) (and
     (has_type nth_elem! T&)
     (= nth_elem! (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_index.?
       Self%&. Self%& T&. T& self! index!
   ))))
   :pattern ((ens%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.nth. Self%&.
     Self%& T&. T& self! index! nth_elem!
   ))
   :qid internal_ens__lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.nth._definition
   :skolemid skolem_internal_ens__lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.nth._definition
)))

;; Function-Specs lib::Chap18::ArraySeqMtPer::ArraySeqMtPer::ArraySeqMtPerRedefinableTrait::empty
(declare-fun ens%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerRedefinableTrait.empty.
 (Dcr Type Dcr Type Poly) Bool
)
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (T&. Dcr) (T& Type) (empty_seq! Poly)) (!
   (= (ens%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerRedefinableTrait.empty.
     Self%&. Self%& T&. T& empty_seq!
    ) (and
     (has_type empty_seq! Self%&)
     (%B (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_arrayseqmtper_wf.?
       Self%&. Self%& T&. T& empty_seq!
     ))
     (= (%I (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_len.? Self%&.
        Self%& T&. T& empty_seq!
       )
      ) 0
   )))
   :pattern ((ens%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerRedefinableTrait.empty.
     Self%&. Self%& T&. T& empty_seq!
   ))
   :qid internal_ens__lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerRedefinableTrait.empty._definition
   :skolemid skolem_internal_ens__lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerRedefinableTrait.empty._definition
)))

;; Function-Specs lib::Chap18::ArraySeqMtPer::ArraySeqMtPer::ArraySeqMtPerRedefinableTrait::singleton
(declare-fun ens%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerRedefinableTrait.singleton.
 (Dcr Type Dcr Type Poly Poly) Bool
)
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (T&. Dcr) (T& Type) (item! Poly) (singleton! Poly))
  (!
   (= (ens%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerRedefinableTrait.singleton.
     Self%&. Self%& T&. T& item! singleton!
    ) (and
     (has_type singleton! Self%&)
     (%B (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_arrayseqmtper_wf.?
       Self%&. Self%& T&. T& singleton!
     ))
     (= (%I (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_len.? Self%&.
        Self%& T&. T& singleton!
       )
      ) 1
     )
     (= (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_index.? Self%&.
       Self%& T&. T& singleton! (I 0)
      ) item!
   )))
   :pattern ((ens%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerRedefinableTrait.singleton.
     Self%&. Self%& T&. T& item! singleton!
   ))
   :qid internal_ens__lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerRedefinableTrait.singleton._definition
   :skolemid skolem_internal_ens__lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerRedefinableTrait.singleton._definition
)))

;; Function-Axioms lib::Chap18::ArraySeqMtPer::ArraySeqMtPer::ArraySeqMtPerS::spec_len
(assert
 (fuel_bool_default fuel%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.impl&%3.spec_len.)
)
(assert
 (=>
  (fuel_bool fuel%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.impl&%3.spec_len.)
  (forall ((T&. Dcr) (T& Type) (self! Poly)) (!
    (=>
     (sized T&.)
     (= (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_len.? $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
        T&. T&
       ) T&. T& self!
      ) (I (vstd!seq.Seq.len.? T&. T& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. T&. T&
          $ TYPE%alloc!alloc.Global.
         ) (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS./ArraySeqMtPerS/seq (%Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
           self!
    )))))))
    :pattern ((lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_len.?
      $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. T&. T&) T&. T& self!
    ))
    :qid internal_lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.impl&__3.spec_len.?_definition
    :skolemid skolem_internal_lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.impl&__3.spec_len.?_definition
))))

;; Function-Axioms lib::Chap18::ArraySeqMtPer::ArraySeqMtPer::ArraySeqMtPerS::spec_index
(assert
 (fuel_bool_default fuel%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.impl&%3.spec_index.)
)
(assert
 (=>
  (fuel_bool fuel%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.impl&%3.spec_index.)
  (forall ((T&. Dcr) (T& Type) (self! Poly) (i! Poly)) (!
    (=>
     (sized T&.)
     (= (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_index.? $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
        T&. T&
       ) T&. T& self! i!
      ) (vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. T&. T&
         $ TYPE%alloc!alloc.Global.
        ) (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS./ArraySeqMtPerS/seq (%Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
          self!
        ))
       ) i!
    )))
    :pattern ((lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_index.?
      $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. T&. T&) T&. T& self!
      i!
    ))
    :qid internal_lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.impl&__3.spec_index.?_definition
    :skolemid skolem_internal_lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.impl&__3.spec_index.?_definition
))))

;; Function-Axioms lib::Chap18::ArraySeqMtPer::ArraySeqMtPer::ArraySeqMtPerS::spec_arrayseqmtper_wf
(assert
 (fuel_bool_default fuel%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.impl&%3.spec_arrayseqmtper_wf.)
)
(assert
 (=>
  (fuel_bool fuel%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.impl&%3.spec_arrayseqmtper_wf.)
  (forall ((T&. Dcr) (T& Type) (self! Poly)) (!
    (=>
     (sized T&.)
     (= (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_arrayseqmtper_wf.?
       $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. T&. T&) T&. T& self!
      ) (B true)
    ))
    :pattern ((lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_arrayseqmtper_wf.?
      $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. T&. T&) T&. T& self!
    ))
    :qid internal_lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.impl&__3.spec_arrayseqmtper_wf.?_definition
    :skolemid skolem_internal_lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.impl&__3.spec_arrayseqmtper_wf.?_definition
))))

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (sized T&.)
    (tr_bound%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait. $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
      T&. T&
     ) T&. T&
   ))
   :pattern ((tr_bound%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.
     $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. T&. T&) T&. T&
   ))
   :qid internal_lib__Chap18__ArraySeqMtPer__ArraySeqMtPer__impl&__3_trait_impl_definition
   :skolemid skolem_internal_lib__Chap18__ArraySeqMtPer__ArraySeqMtPer__impl&__3_trait_impl_definition
)))

;; Function-Axioms vstd::wrapping::usize_specs::wrapping_add
(assert
 (fuel_bool_default fuel%vstd!wrapping.usize_specs.wrapping_add.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!wrapping.usize_specs.wrapping_add.)
  (forall ((x! Poly) (y! Poly)) (!
    (= (vstd!wrapping.usize_specs.wrapping_add.? x! y!) (ite
      (> (Add (%I x!) (%I y!)) (- (uHi SZ) 1))
      (uClip SZ (Sub (Add (%I x!) (%I y!)) (Add (Sub (- (uHi SZ) 1) 0) 1)))
      (uClip SZ (Add (%I x!) (%I y!)))
    ))
    :pattern ((vstd!wrapping.usize_specs.wrapping_add.? x! y!))
    :qid internal_vstd!wrapping.usize_specs.wrapping_add.?_definition
    :skolemid skolem_internal_vstd!wrapping.usize_specs.wrapping_add.?_definition
))))
(assert
 (forall ((x! Poly) (y! Poly)) (!
   (=>
    (and
     (has_type x! USIZE)
     (has_type y! USIZE)
    )
    (uInv SZ (vstd!wrapping.usize_specs.wrapping_add.? x! y!))
   )
   :pattern ((vstd!wrapping.usize_specs.wrapping_add.? x! y!))
   :qid internal_vstd!wrapping.usize_specs.wrapping_add.?_pre_post_definition
   :skolemid skolem_internal_vstd!wrapping.usize_specs.wrapping_add.?_pre_post_definition
)))

;; Function-Specs core::num::impl&%11::wrapping_add
(declare-fun ens%core!num.impl&%11.wrapping_add. (Int Int Int) Bool)
(assert
 (forall ((x! Int) (y! Int) (%return! Int)) (!
   (= (ens%core!num.impl&%11.wrapping_add. x! y! %return!) (and
     (uInv SZ %return!)
     (= %return! (vstd!wrapping.usize_specs.wrapping_add.? (I x!) (I y!)))
   ))
   :pattern ((ens%core!num.impl&%11.wrapping_add. x! y! %return!))
   :qid internal_ens__core!num.impl&__11.wrapping_add._definition
   :skolemid skolem_internal_ens__core!num.impl&__11.wrapping_add._definition
)))

;; Function-Axioms vstd::view::impl&%6::view
(assert
 (fuel_bool_default fuel%vstd!view.impl&%6.view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%6.view.)
  (forall ((A&. Dcr) (A& Type) (self! Poly)) (!
    (=>
     (and
      (sized A&.)
      (tr_bound%vstd!view.View. A&. A&)
     )
     (= (vstd!view.View.view.? (ARC $ TYPE%alloc!alloc.Global. A&.) A& self!) (vstd!view.View.view.?
       A&. A& self!
    )))
    :pattern ((vstd!view.View.view.? (ARC $ TYPE%alloc!alloc.Global. A&.) A& self!))
    :qid internal_vstd!view.impl&__6.view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__6.view.?_definition
))))

;; Trait-Impl-Axiom
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%vstd!view.View. A&. A&)
    )
    (tr_bound%vstd!view.View. (ARC $ TYPE%alloc!alloc.Global. A&.) A&)
   )
   :pattern ((tr_bound%vstd!view.View. (ARC $ TYPE%alloc!alloc.Global. A&.) A&))
   :qid internal_vstd__view__impl&__6_trait_impl_definition
   :skolemid skolem_internal_vstd__view__impl&__6_trait_impl_definition
)))

;; Function-Specs lib::Chap02::HFSchedulerMtEph::HFSchedulerMtEph::join
(declare-fun req%lib!Chap02.HFSchedulerMtEph.HFSchedulerMtEph.join. (Dcr Type Dcr Type
  Dcr Type Dcr Type Poly Poly
 ) Bool
)
(declare-const %%global_location_label%%10 Bool)
(declare-const %%global_location_label%%11 Bool)
(assert
 (forall ((A&. Dcr) (A& Type) (B&. Dcr) (B& Type) (FA&. Dcr) (FA& Type) (FB&. Dcr) (
    FB& Type
   ) (fa! Poly) (fb! Poly)
  ) (!
   (= (req%lib!Chap02.HFSchedulerMtEph.HFSchedulerMtEph.join. A&. A& B&. B& FA&. FA& FB&.
     FB& fa! fb!
    ) (and
     (=>
      %%global_location_label%%10
      (closure_req FA& $ TYPE%tuple%0. fa! (Poly%tuple%0. tuple%0./tuple%0))
     )
     (=>
      %%global_location_label%%11
      (closure_req FB& $ TYPE%tuple%0. fb! (Poly%tuple%0. tuple%0./tuple%0))
   )))
   :pattern ((req%lib!Chap02.HFSchedulerMtEph.HFSchedulerMtEph.join. A&. A& B&. B& FA&.
     FA& FB&. FB& fa! fb!
   ))
   :qid internal_req__lib!Chap02.HFSchedulerMtEph.HFSchedulerMtEph.join._definition
   :skolemid skolem_internal_req__lib!Chap02.HFSchedulerMtEph.HFSchedulerMtEph.join._definition
)))
(declare-fun ens%lib!Chap02.HFSchedulerMtEph.HFSchedulerMtEph.join. (Dcr Type Dcr Type
  Dcr Type Dcr Type Poly Poly tuple%2.
 ) Bool
)
(assert
 (forall ((A&. Dcr) (A& Type) (B&. Dcr) (B& Type) (FA&. Dcr) (FA& Type) (FB&. Dcr) (
    FB& Type
   ) (fa! Poly) (fb! Poly) (joined_pair! tuple%2.)
  ) (!
   (= (ens%lib!Chap02.HFSchedulerMtEph.HFSchedulerMtEph.join. A&. A& B&. B& FA&. FA& FB&.
     FB& fa! fb! joined_pair!
    ) (and
     (has_type (Poly%tuple%2. joined_pair!) (TYPE%tuple%2. A&. A& B&. B&))
     (closure_ens FA& $ TYPE%tuple%0. fa! (Poly%tuple%0. tuple%0./tuple%0) (tuple%2./tuple%2/0
       (%Poly%tuple%2. (Poly%tuple%2. joined_pair!))
     ))
     (closure_ens FB& $ TYPE%tuple%0. fb! (Poly%tuple%0. tuple%0./tuple%0) (tuple%2./tuple%2/1
       (%Poly%tuple%2. (Poly%tuple%2. joined_pair!))
   ))))
   :pattern ((ens%lib!Chap02.HFSchedulerMtEph.HFSchedulerMtEph.join. A&. A& B&. B& FA&.
     FA& FB&. FB& fa! fb! joined_pair!
   ))
   :qid internal_ens__lib!Chap02.HFSchedulerMtEph.HFSchedulerMtEph.join._definition
   :skolemid skolem_internal_ens__lib!Chap02.HFSchedulerMtEph.HFSchedulerMtEph.join._definition
)))

;; Function-Specs lib::Chap26::ScanDCMtPer::ScanDCMtPer::spec_scan_at
(declare-fun req%lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_scan_at. (Poly Poly Poly Poly)
 Bool
)
(declare-const %%global_location_label%%12 Bool)
(assert
 (forall ((s! Poly) (spec_f! Poly) (id! Poly) (i! Poly)) (!
   (= (req%lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_scan_at. s! spec_f! id! i!) (=>
     %%global_location_label%%12
     (let
      ((tmp%%$ 0))
      (let
       ((tmp%%$1 (%I i!)))
       (let
        ((tmp%%$2 (vstd!seq.Seq.len.? $ USIZE s!)))
        (and
         (<= tmp%%$ tmp%%$1)
         (<= tmp%%$1 tmp%%$2)
   ))))))
   :pattern ((req%lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_scan_at. s! spec_f! id! i!))
   :qid internal_req__lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_scan_at._definition
   :skolemid skolem_internal_req__lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_scan_at._definition
)))

;; Function-Axioms lib::Chap26::ScanDCMtPer::ScanDCMtPer::spec_scan_at
(assert
 (fuel_bool_default fuel%lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_scan_at.)
)
(assert
 (=>
  (fuel_bool fuel%lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_scan_at.)
  (forall ((s! Poly) (spec_f! Poly) (id! Poly) (i! Poly)) (!
    (= (lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_scan_at.? s! spec_f! id! i!) (%I (vstd!seq_lib.impl&%0.fold_left.?
       $ USIZE $ USIZE (vstd!seq.Seq.subrange.? $ USIZE s! (I 0) i!) id! spec_f!
    )))
    :pattern ((lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_scan_at.? s! spec_f! id! i!))
    :qid internal_lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_scan_at.?_definition
    :skolemid skolem_internal_lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_scan_at.?_definition
))))
(assert
 (forall ((s! Poly) (spec_f! Poly) (id! Poly) (i! Poly)) (!
   (=>
    (and
     (has_type s! (TYPE%vstd!seq.Seq. $ USIZE))
     (has_type spec_f! (TYPE%fun%2. $ USIZE $ USIZE $ USIZE))
     (has_type id! USIZE)
     (has_type i! INT)
    )
    (uInv SZ (lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_scan_at.? s! spec_f! id! i!))
   )
   :pattern ((lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_scan_at.? s! spec_f! id! i!))
   :qid internal_lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_scan_at.?_pre_post_definition
   :skolemid skolem_internal_lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_scan_at.?_pre_post_definition
)))

;; Function-Axioms lib::Chap26::ScanDCMtPer::ScanDCMtPer::spec_scan_post
(assert
 (fuel_bool_default fuel%lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_scan_post.)
)
(assert
 (=>
  (fuel_bool fuel%lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_scan_post.)
  (forall ((input! Poly) (spec_f! Poly) (id! Poly) (prefixes! Poly) (total! Poly)) (
    !
    (= (lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_scan_post.? input! spec_f! id! prefixes!
      total!
     ) (and
      (and
       (= (vstd!seq.Seq.len.? $ USIZE prefixes!) (vstd!seq.Seq.len.? $ USIZE input!))
       (forall ((i$ Poly)) (!
         (=>
          (has_type i$ INT)
          (=>
           (let
            ((tmp%%$ 0))
            (let
             ((tmp%%$1 (%I i$)))
             (let
              ((tmp%%$2 (vstd!seq.Seq.len.? $ USIZE input!)))
              (and
               (<= tmp%%$ tmp%%$1)
               (< tmp%%$1 tmp%%$2)
           ))))
           (= (%I (vstd!seq.Seq.index.? $ USIZE prefixes! i$)) (lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_scan_at.?
             input! spec_f! id! i$
         ))))
         :pattern ((vstd!seq.Seq.index.? $ USIZE prefixes! i$))
         :qid user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__spec_scan_post_0
         :skolemid skolem_user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__spec_scan_post_0
      )))
      (= total! (lib!Chap18.ArraySeqSpecsAndLemmas.ArraySeqSpecsAndLemmas.spec_iterate.?
        $ USIZE $ USIZE input! spec_f! id!
    ))))
    :pattern ((lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_scan_post.? input! spec_f! id! prefixes!
      total!
    ))
    :qid internal_lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_scan_post.?_definition
    :skolemid skolem_internal_lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_scan_post.?_definition
))))

;; Function-Axioms lib::Chap26::ScanDCMtPer::ScanDCMtPer::spec_wrapping_add
(assert
 (fuel_bool_default fuel%lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_wrapping_add.)
)
(assert
 (=>
  (fuel_bool fuel%lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_wrapping_add.)
  (forall ((x! Poly) (y! Poly)) (!
    (= (lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_wrapping_add.? x! y!) (ite
      (> (Add (%I x!) (%I y!)) (- (uHi SZ) 1))
      (uClip SZ (Sub (Add (%I x!) (%I y!)) (Add (- (uHi SZ) 1) 1)))
      (uClip SZ (Add (%I x!) (%I y!)))
    ))
    :pattern ((lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_wrapping_add.? x! y!))
    :qid internal_lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_wrapping_add.?_definition
    :skolemid skolem_internal_lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_wrapping_add.?_definition
))))
(assert
 (forall ((x! Poly) (y! Poly)) (!
   (=>
    (and
     (has_type x! USIZE)
     (has_type y! USIZE)
    )
    (uInv SZ (lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_wrapping_add.? x! y!))
   )
   :pattern ((lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_wrapping_add.? x! y!))
   :qid internal_lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_wrapping_add.?_pre_post_definition
   :skolemid skolem_internal_lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_wrapping_add.?_pre_post_definition
)))

;; Function-Axioms lib::Chap26::ScanDCMtPer::ScanDCMtPer::spec_sum_fn
(assert
 (fuel_bool_default fuel%lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_sum_fn.)
)
(declare-fun %%lambda%%0 () %%Function%%)
(assert
 (forall ((x$ Poly) (y$ Poly)) (!
   (= (%%apply%%1 %%lambda%%0 x$ y$) (I (lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_wrapping_add.?
      x$ y$
   )))
   :pattern ((%%apply%%1 %%lambda%%0 x$ y$))
)))
(assert
 (=>
  (fuel_bool fuel%lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_sum_fn.)
  (forall ((no%param Poly)) (!
    (= (lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_sum_fn.? no%param) (mk_fun %%lambda%%0))
    :pattern ((lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_sum_fn.? no%param))
    :qid internal_lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_sum_fn.?_definition
    :skolemid skolem_internal_lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_sum_fn.?_definition
))))
(assert
 (forall ((no%param Poly)) (!
   (=>
    (has_type no%param INT)
    (has_type (Poly%fun%2. (lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_sum_fn.? no%param))
     (TYPE%fun%2. $ USIZE $ USIZE $ USIZE)
   ))
   :pattern ((lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_sum_fn.? no%param))
   :qid internal_lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_sum_fn.?_pre_post_definition
   :skolemid skolem_internal_lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_sum_fn.?_pre_post_definition
)))

;; Function-Specs lib::Chap26::ScanDCMtPer::ScanDCMtPer::ScanDCMtTrait::prefix_sums_dc_parallel
(declare-fun req%lib!Chap26.ScanDCMtPer.ScanDCMtPer.ScanDCMtTrait.prefix_sums_dc_parallel.
 (Dcr Type Poly) Bool
)
(declare-const %%global_location_label%%13 Bool)
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (a! Poly)) (!
   (= (req%lib!Chap26.ScanDCMtPer.ScanDCMtPer.ScanDCMtTrait.prefix_sums_dc_parallel. Self%&.
     Self%& a!
    ) (=>
     %%global_location_label%%13
     (<= (%I (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_len.? $
        (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE) $ USIZE a!
       )
      ) (- (uHi SZ) 1)
   )))
   :pattern ((req%lib!Chap26.ScanDCMtPer.ScanDCMtPer.ScanDCMtTrait.prefix_sums_dc_parallel.
     Self%&. Self%& a!
   ))
   :qid internal_req__lib!Chap26.ScanDCMtPer.ScanDCMtPer.ScanDCMtTrait.prefix_sums_dc_parallel._definition
   :skolemid skolem_internal_req__lib!Chap26.ScanDCMtPer.ScanDCMtPer.ScanDCMtTrait.prefix_sums_dc_parallel._definition
)))
(declare-fun ens%lib!Chap26.ScanDCMtPer.ScanDCMtPer.ScanDCMtTrait.prefix_sums_dc_parallel.
 (Dcr Type Poly Poly) Bool
)
(declare-fun %%lambda%%1 (Dcr Type Dcr Type Poly) %%Function%%)
(assert
 (forall ((%%hole%%0 Dcr) (%%hole%%1 Type) (%%hole%%2 Dcr) (%%hole%%3 Type) (%%hole%%4
    Poly
   ) (i$ Poly)
  ) (!
   (= (%%apply%%0 (%%lambda%%1 %%hole%%0 %%hole%%1 %%hole%%2 %%hole%%3 %%hole%%4) i$)
    (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_index.? %%hole%%0
     %%hole%%1 %%hole%%2 %%hole%%3 %%hole%%4 i$
   ))
   :pattern ((%%apply%%0 (%%lambda%%1 %%hole%%0 %%hole%%1 %%hole%%2 %%hole%%3 %%hole%%4)
     i$
)))))
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (a! Poly) (sums! Poly)) (!
   (= (ens%lib!Chap26.ScanDCMtPer.ScanDCMtPer.ScanDCMtTrait.prefix_sums_dc_parallel. Self%&.
     Self%& a! sums!
    ) (and
     (has_type sums! (TYPE%tuple%2. $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
        $ USIZE
       ) $ USIZE
     ))
     (lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_scan_post.? (vstd!seq.Seq.new.? $ USIZE (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_len.?
        $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE) $ USIZE a!
       ) (Poly%fun%1. (mk_fun (%%lambda%%1 $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
           $ USIZE
          ) $ USIZE a!
       )))
      ) (Poly%fun%2. (lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_sum_fn.? (I 0))) (I 0) (vstd!seq.Seq.new.?
       $ USIZE (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_len.?
        $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE) $ USIZE (
         tuple%2./tuple%2/0 (%Poly%tuple%2. sums!)
        )
       ) (Poly%fun%1. (mk_fun (%%lambda%%1 $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
           $ USIZE
          ) $ USIZE (tuple%2./tuple%2/0 (%Poly%tuple%2. sums!))
       )))
      ) (tuple%2./tuple%2/1 (%Poly%tuple%2. sums!))
   )))
   :pattern ((ens%lib!Chap26.ScanDCMtPer.ScanDCMtPer.ScanDCMtTrait.prefix_sums_dc_parallel.
     Self%&. Self%& a! sums!
   ))
   :qid internal_ens__lib!Chap26.ScanDCMtPer.ScanDCMtPer.ScanDCMtTrait.prefix_sums_dc_parallel._definition
   :skolemid skolem_internal_ens__lib!Chap26.ScanDCMtPer.ScanDCMtPer.ScanDCMtTrait.prefix_sums_dc_parallel._definition
)))

;; Function-Axioms vstd::seq_lib::impl&%0::map
(assert
 (fuel_bool_default fuel%vstd!seq_lib.impl&%0.map.)
)
(declare-fun %%lambda%%2 (Dcr Type Poly %%Function%%) %%Function%%)
(assert
 (forall ((%%hole%%0 Dcr) (%%hole%%1 Type) (%%hole%%2 Poly) (%%hole%%3 %%Function%%)
   (i$ Poly)
  ) (!
   (= (%%apply%%0 (%%lambda%%2 %%hole%%0 %%hole%%1 %%hole%%2 %%hole%%3) i$) (%%apply%%1
     %%hole%%3 i$ (vstd!seq.Seq.index.? %%hole%%0 %%hole%%1 %%hole%%2 i$)
   ))
   :pattern ((%%apply%%0 (%%lambda%%2 %%hole%%0 %%hole%%1 %%hole%%2 %%hole%%3) i$))
)))
(assert
 (=>
  (fuel_bool fuel%vstd!seq_lib.impl&%0.map.)
  (forall ((A&. Dcr) (A& Type) (B&. Dcr) (B& Type) (self! Poly) (f! Poly)) (!
    (= (vstd!seq_lib.impl&%0.map.? A&. A& B&. B& self! f!) (vstd!seq.Seq.new.? B&. B& (
       I (vstd!seq.Seq.len.? A&. A& self!)
      ) (Poly%fun%1. (mk_fun (%%lambda%%2 A&. A& self! (%Poly%fun%2. f!))))
    ))
    :pattern ((vstd!seq_lib.impl&%0.map.? A&. A& B&. B& self! f!))
    :qid internal_vstd!seq_lib.impl&__0.map.?_definition
    :skolemid skolem_internal_vstd!seq_lib.impl&__0.map.?_definition
))))
(assert
 (forall ((A&. Dcr) (A& Type) (B&. Dcr) (B& Type) (self! Poly) (f! Poly)) (!
   (=>
    (and
     (has_type self! (TYPE%vstd!seq.Seq. A&. A&))
     (has_type f! (TYPE%fun%2. $ INT A&. A& B&. B&))
    )
    (has_type (vstd!seq_lib.impl&%0.map.? A&. A& B&. B& self! f!) (TYPE%vstd!seq.Seq. B&.
      B&
   )))
   :pattern ((vstd!seq_lib.impl&%0.map.? A&. A& B&. B& self! f!))
   :qid internal_vstd!seq_lib.impl&__0.map.?_pre_post_definition
   :skolemid skolem_internal_vstd!seq_lib.impl&__0.map.?_pre_post_definition
)))

;; Function-Axioms vstd::view::impl&%2::view
(assert
 (fuel_bool_default fuel%vstd!view.impl&%2.view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%2.view.)
  (forall ((A&. Dcr) (A& Type) (self! Poly)) (!
    (=>
     (tr_bound%vstd!view.View. A&. A&)
     (= (vstd!view.View.view.? (BOX $ TYPE%alloc!alloc.Global. A&.) A& self!) (vstd!view.View.view.?
       A&. A& self!
    )))
    :pattern ((vstd!view.View.view.? (BOX $ TYPE%alloc!alloc.Global. A&.) A& self!))
    :qid internal_vstd!view.impl&__2.view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__2.view.?_definition
))))

;; Function-Axioms vstd::view::impl&%4::view
(assert
 (fuel_bool_default fuel%vstd!view.impl&%4.view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%4.view.)
  (forall ((A&. Dcr) (A& Type) (self! Poly)) (!
    (=>
     (and
      (sized A&.)
      (tr_bound%vstd!view.View. A&. A&)
     )
     (= (vstd!view.View.view.? (RC $ TYPE%alloc!alloc.Global. A&.) A& self!) (vstd!view.View.view.?
       A&. A& self!
    )))
    :pattern ((vstd!view.View.view.? (RC $ TYPE%alloc!alloc.Global. A&.) A& self!))
    :qid internal_vstd!view.impl&__4.view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__4.view.?_definition
))))

;; Function-Axioms vstd::view::impl&%16::view
(assert
 (fuel_bool_default fuel%vstd!view.impl&%16.view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%16.view.)
  (forall ((self! Poly)) (!
    (= (vstd!view.View.view.? $ TYPE%tuple%0. self!) self!)
    :pattern ((vstd!view.View.view.? $ TYPE%tuple%0. self!))
    :qid internal_vstd!view.impl&__16.view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__16.view.?_definition
))))

;; Function-Axioms lib::Chap18::ArraySeqMtPer::ArraySeqMtPer::ArraySeqMtPerS::view
(assert
 (fuel_bool_default fuel%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.impl&%2.view.)
)
(declare-fun %%lambda%%3 (Dcr Type) %%Function%%)
(assert
 (forall ((%%hole%%0 Dcr) (%%hole%%1 Type) (_i$ Poly) (t$ Poly)) (!
   (= (%%apply%%1 (%%lambda%%3 %%hole%%0 %%hole%%1) _i$ t$) (vstd!view.View.view.? %%hole%%0
     %%hole%%1 t$
   ))
   :pattern ((%%apply%%1 (%%lambda%%3 %%hole%%0 %%hole%%1) _i$ t$))
)))
(assert
 (=>
  (fuel_bool fuel%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.impl&%2.view.)
  (forall ((T&. Dcr) (T& Type) (self! Poly)) (!
    (=>
     (and
      (sized T&.)
      (tr_bound%vstd!view.View. T&. T&)
     )
     (= (vstd!view.View.view.? $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
        T&. T&
       ) self!
      ) (vstd!seq_lib.impl&%0.map.? T&. T& (proj%%vstd!view.View./V T&. T&) (proj%vstd!view.View./V
        T&. T&
       ) (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. T&. T& $ TYPE%alloc!alloc.Global.)
        (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS./ArraySeqMtPerS/seq (%Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
          self!
        ))
       ) (Poly%fun%2. (mk_fun (%%lambda%%3 T&. T&)))
    )))
    :pattern ((vstd!view.View.view.? $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
       T&. T&
      ) self!
    ))
    :qid internal_lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.impl&__2.view.?_definition
    :skolemid skolem_internal_lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.impl&__2.view.?_definition
))))

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (and
     (sized T&.)
     (tr_bound%vstd!view.View. T&. T&)
    )
    (tr_bound%vstd!view.View. $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
      T&. T&
   )))
   :pattern ((tr_bound%vstd!view.View. $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
      T&. T&
   )))
   :qid internal_lib__Chap18__ArraySeqMtPer__ArraySeqMtPer__impl&__2_trait_impl_definition
   :skolemid skolem_internal_lib__Chap18__ArraySeqMtPer__ArraySeqMtPer__impl&__2_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (tr_bound%vstd!view.View. A&. A&)
    (tr_bound%vstd!view.View. (BOX $ TYPE%alloc!alloc.Global. A&.) A&)
   )
   :pattern ((tr_bound%vstd!view.View. (BOX $ TYPE%alloc!alloc.Global. A&.) A&))
   :qid internal_vstd__view__impl&__2_trait_impl_definition
   :skolemid skolem_internal_vstd__view__impl&__2_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%vstd!view.View. A&. A&)
    )
    (tr_bound%vstd!view.View. (RC $ TYPE%alloc!alloc.Global. A&.) A&)
   )
   :pattern ((tr_bound%vstd!view.View. (RC $ TYPE%alloc!alloc.Global. A&.) A&))
   :qid internal_vstd__view__impl&__4_trait_impl_definition
   :skolemid skolem_internal_vstd__view__impl&__4_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (tr_bound%vstd!view.View. $ TYPE%tuple%0.)
)

;; Trait-Impl-Axiom
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.Fn. F&. F& A&. A&)
    )
    (tr_bound%core!ops.function.FnMut. (REF F&.) F& A&. A&)
   )
   :pattern ((tr_bound%core!ops.function.FnMut. (REF F&.) F& A&. A&))
   :qid internal_core__ops__function__impls__impl&__1_trait_impl_definition
   :skolemid skolem_internal_core__ops__function__impls__impl&__1_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.Fn. F&. F& A&. A&)
    )
    (tr_bound%core!ops.function.Fn. (REF F&.) F& A&. A&)
   )
   :pattern ((tr_bound%core!ops.function.Fn. (REF F&.) F& A&. A&))
   :qid internal_core__ops__function__impls__impl&__0_trait_impl_definition
   :skolemid skolem_internal_core__ops__function__impls__impl&__0_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((Args&. Dcr) (Args& Type) (F&. Dcr) (F& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized Args&.)
     (sized A&.)
     (tr_bound%core!marker.Tuple. Args&. Args&)
     (tr_bound%core!ops.function.FnOnce. F&. F& Args&. Args&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (tr_bound%core!ops.function.FnOnce. (BOX A&. A& F&.) F& Args&. Args&)
   )
   :pattern ((tr_bound%core!ops.function.FnOnce. (BOX A&. A& F&.) F& Args&. Args&))
   :qid internal_alloc__boxed__impl&__31_trait_impl_definition
   :skolemid skolem_internal_alloc__boxed__impl&__31_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((Args&. Dcr) (Args& Type) (F&. Dcr) (F& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized Args&.)
     (sized A&.)
     (tr_bound%core!marker.Tuple. Args&. Args&)
     (tr_bound%core!ops.function.FnMut. F&. F& Args&. Args&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (tr_bound%core!ops.function.FnMut. (BOX A&. A& F&.) F& Args&. Args&)
   )
   :pattern ((tr_bound%core!ops.function.FnMut. (BOX A&. A& F&.) F& Args&. Args&))
   :qid internal_alloc__boxed__impl&__32_trait_impl_definition
   :skolemid skolem_internal_alloc__boxed__impl&__32_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((Args&. Dcr) (Args& Type) (F&. Dcr) (F& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized Args&.)
     (sized A&.)
     (tr_bound%core!marker.Tuple. Args&. Args&)
     (tr_bound%core!ops.function.Fn. F&. F& Args&. Args&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (tr_bound%core!ops.function.Fn. (BOX A&. A& F&.) F& Args&. Args&)
   )
   :pattern ((tr_bound%core!ops.function.Fn. (BOX A&. A& F&.) F& Args&. Args&))
   :qid internal_alloc__boxed__impl&__33_trait_impl_definition
   :skolemid skolem_internal_alloc__boxed__impl&__33_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.FnMut. F&. F& A&. A&)
    )
    (tr_bound%core!ops.function.FnMut. $ (MUTREF F&. F&) A&. A&)
   )
   :pattern ((tr_bound%core!ops.function.FnMut. $ (MUTREF F&. F&) A&. A&))
   :qid internal_core__ops__function__impls__impl&__3_trait_impl_definition
   :skolemid skolem_internal_core__ops__function__impls__impl&__3_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (tr_bound%core!alloc.Allocator. A&. A&)
    (tr_bound%core!alloc.Allocator. (REF A&.) A&)
   )
   :pattern ((tr_bound%core!alloc.Allocator. (REF A&.) A&))
   :qid internal_core__alloc__impl&__2_trait_impl_definition
   :skolemid skolem_internal_core__alloc__impl&__2_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (tr_bound%core!alloc.Allocator. A&. A&)
    (tr_bound%core!alloc.Allocator. $ (MUTREF A&. A&))
   )
   :pattern ((tr_bound%core!alloc.Allocator. $ (MUTREF A&. A&)))
   :qid internal_core__alloc__impl&__3_trait_impl_definition
   :skolemid skolem_internal_core__alloc__impl&__3_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!alloc.Allocator. T&. T&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (tr_bound%core!alloc.Allocator. (BOX A&. A& T&.) T&)
   )
   :pattern ((tr_bound%core!alloc.Allocator. (BOX A&. A& T&.) T&))
   :qid internal_alloc__boxed__impl&__49_trait_impl_definition
   :skolemid skolem_internal_alloc__boxed__impl&__49_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!alloc.Allocator. T&. T&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (tr_bound%core!alloc.Allocator. (RC A&. A& T&.) T&)
   )
   :pattern ((tr_bound%core!alloc.Allocator. (RC A&. A& T&.) T&))
   :qid internal_alloc__rc__impl&__116_trait_impl_definition
   :skolemid skolem_internal_alloc__rc__impl&__116_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!alloc.Allocator. T&. T&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (tr_bound%core!alloc.Allocator. (ARC A&. A& T&.) T&)
   )
   :pattern ((tr_bound%core!alloc.Allocator. (ARC A&. A& T&.) T&))
   :qid internal_alloc__sync__impl&__118_trait_impl_definition
   :skolemid skolem_internal_alloc__sync__impl&__118_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (sized T&.)
    (tr_bound%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerRedefinableTrait. $
     (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. T&. T&) T&. T&
   ))
   :pattern ((tr_bound%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerRedefinableTrait.
     $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. T&. T&) T&. T&
   ))
   :qid internal_lib__Chap18__ArraySeqMtPer__ArraySeqMtPer__impl&__4_trait_impl_definition
   :skolemid skolem_internal_lib__Chap18__ArraySeqMtPer__ArraySeqMtPer__impl&__4_trait_impl_definition
)))

;; Function-Specs lib::Chap26::ScanDCMtPer::ScanDCMtPer::lemma_fold_left_monoid
(declare-fun req%lib!Chap26.ScanDCMtPer.ScanDCMtPer.lemma_fold_left_monoid. (vstd!seq.Seq<usize.>.
  Int %%Function%% Int
 ) Bool
)
(declare-const %%global_location_label%%14 Bool)
(assert
 (forall ((s! vstd!seq.Seq<usize.>.) (x! Int) (f! %%Function%%) (id! Int)) (!
   (= (req%lib!Chap26.ScanDCMtPer.ScanDCMtPer.lemma_fold_left_monoid. s! x! f! id!) (
     =>
     %%global_location_label%%14
     (lib!vstdplus.monoid.monoid.spec_monoid.? $ USIZE (Poly%fun%2. f!) (I id!))
   ))
   :pattern ((req%lib!Chap26.ScanDCMtPer.ScanDCMtPer.lemma_fold_left_monoid. s! x! f!
     id!
   ))
   :qid internal_req__lib!Chap26.ScanDCMtPer.ScanDCMtPer.lemma_fold_left_monoid._definition
   :skolemid skolem_internal_req__lib!Chap26.ScanDCMtPer.ScanDCMtPer.lemma_fold_left_monoid._definition
)))
(declare-fun ens%lib!Chap26.ScanDCMtPer.ScanDCMtPer.lemma_fold_left_monoid. (vstd!seq.Seq<usize.>.
  Int %%Function%% Int
 ) Bool
)
(assert
 (forall ((s! vstd!seq.Seq<usize.>.) (x! Int) (f! %%Function%%) (id! Int)) (!
   (= (ens%lib!Chap26.ScanDCMtPer.ScanDCMtPer.lemma_fold_left_monoid. s! x! f! id!) (
     = (vstd!seq_lib.impl&%0.fold_left.? $ USIZE $ USIZE (Poly%vstd!seq.Seq<usize.>. s!)
      (I x!) (Poly%fun%2. f!)
     ) (%%apply%%1 f! (I x!) (vstd!seq_lib.impl&%0.fold_left.? $ USIZE $ USIZE (Poly%vstd!seq.Seq<usize.>.
        s!
       ) (I id!) (Poly%fun%2. f!)
   ))))
   :pattern ((ens%lib!Chap26.ScanDCMtPer.ScanDCMtPer.lemma_fold_left_monoid. s! x! f!
     id!
   ))
   :qid internal_ens__lib!Chap26.ScanDCMtPer.ScanDCMtPer.lemma_fold_left_monoid._definition
   :skolemid skolem_internal_ens__lib!Chap26.ScanDCMtPer.ScanDCMtPer.lemma_fold_left_monoid._definition
)))

;; Function-Def lib::Chap26::ScanDCMtPer::ScanDCMtPer::lemma_fold_left_monoid
;; src/Chap26/ScanDCMtPer.rs:82:11: 82:107 (#0)
(push)
 (get-info :all-statistics)
 (declare-const s! vstd!seq.Seq<usize.>.)
 (declare-const x! Int)
 (declare-const f! %%Function%%)
 (declare-const id! Int)
 (declare-const tmp%1 vstd!seq.Seq<usize.>.)
 (declare-const tmp%2 vstd!seq.Seq<usize.>.)
 (declare-const decrease%init0 Int)
 (assert
  fuel_defaults
 )
 (assert
  (uInv SZ x!)
 )
 (assert
  (has_type (Poly%fun%2. f!) (TYPE%fun%2. $ USIZE $ USIZE $ USIZE))
 )
 (assert
  (uInv SZ id!)
 )
 (assert
  (lib!vstdplus.monoid.monoid.spec_monoid.? $ USIZE (Poly%fun%2. f!) (I id!))
 )
 (declare-const %%switch_label%%0 Bool)
 ;; could not prove termination
 (declare-const %%location_label%%0 Bool)
 ;; precondition not satisfied
 (declare-const %%location_label%%1 Bool)
 ;; could not prove termination
 (declare-const %%location_label%%2 Bool)
 ;; precondition not satisfied
 (declare-const %%location_label%%3 Bool)
 ;; postcondition not satisfied
 (declare-const %%location_label%%4 Bool)
 (assert
  (not (=>
    (= decrease%init0 (vstd!seq.Seq.len.? $ USIZE (Poly%vstd!seq.Seq<usize.>. s!)))
    (=>
     (fuel_bool fuel%vstd!seq_lib.impl&%0.fold_left.)
     (or
      (and
       (=>
        (= (vstd!seq.Seq.len.? $ USIZE (Poly%vstd!seq.Seq<usize.>. s!)) 0)
        %%switch_label%%0
       )
       (=>
        (not (= (vstd!seq.Seq.len.? $ USIZE (Poly%vstd!seq.Seq<usize.>. s!)) 0))
        (=>
         (= tmp%1 (%Poly%vstd!seq.Seq<usize.>. (vstd!seq_lib.impl&%0.drop_last.? $ USIZE (Poly%vstd!seq.Seq<usize.>.
             s!
         ))))
         (and
          (=>
           %%location_label%%0
           (check_decrease_height (I (let
              ((s!$0 tmp%1) (x!$1 x!) (f!$2 f!) (id!$3 id!))
              (vstd!seq.Seq.len.? $ USIZE (Poly%vstd!seq.Seq<usize.>. s!$0))
             )
            ) (I decrease%init0) false
          ))
          (and
           (=>
            %%location_label%%1
            (req%lib!Chap26.ScanDCMtPer.ScanDCMtPer.lemma_fold_left_monoid. tmp%1 x! f! id!)
           )
           (=>
            (ens%lib!Chap26.ScanDCMtPer.ScanDCMtPer.lemma_fold_left_monoid. tmp%1 x! f! id!)
            (=>
             (= tmp%2 (%Poly%vstd!seq.Seq<usize.>. (vstd!seq_lib.impl&%0.drop_last.? $ USIZE (Poly%vstd!seq.Seq<usize.>.
                 s!
             ))))
             (and
              (=>
               %%location_label%%2
               (check_decrease_height (I (let
                  ((s!$0 tmp%2) (x!$1 id!) (f!$2 f!) (id!$3 id!))
                  (vstd!seq.Seq.len.? $ USIZE (Poly%vstd!seq.Seq<usize.>. s!$0))
                 )
                ) (I decrease%init0) false
              ))
              (and
               (=>
                %%location_label%%3
                (req%lib!Chap26.ScanDCMtPer.ScanDCMtPer.lemma_fold_left_monoid. tmp%2 id! f! id!)
               )
               (=>
                (ens%lib!Chap26.ScanDCMtPer.ScanDCMtPer.lemma_fold_left_monoid. tmp%2 id! f! id!)
                %%switch_label%%0
      ))))))))))
      (and
       (not %%switch_label%%0)
       (=>
        %%location_label%%4
        (= (vstd!seq_lib.impl&%0.fold_left.? $ USIZE $ USIZE (Poly%vstd!seq.Seq<usize.>. s!)
          (I x!) (Poly%fun%2. f!)
         ) (%%apply%%1 f! (I x!) (vstd!seq_lib.impl&%0.fold_left.? $ USIZE $ USIZE (Poly%vstd!seq.Seq<usize.>.
            s!
           ) (I id!) (Poly%fun%2. f!)
 ))))))))))
 (get-info :all-statistics)
 (get-info :version)
 (set-option :rlimit 30000000)
 (check-sat)
 (set-option :rlimit 0)
 (get-info :all-statistics)
(pop)

;; Function-Specs lib::Chap26::ScanDCMtPer::ScanDCMtPer::prefix_sums_dc_inner
(declare-fun req%lib!Chap26.ScanDCMtPer.ScanDCMtPer.prefix_sums_dc_inner. (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.)
 Bool
)
(declare-const %%global_location_label%%15 Bool)
(assert
 (forall ((a! lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.)) (!
   (= (req%lib!Chap26.ScanDCMtPer.ScanDCMtPer.prefix_sums_dc_inner. a!) (=>
     %%global_location_label%%15
     (<= (%I (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_len.? $
        (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE) $ USIZE (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
         a!
       ))
      ) (- (uHi SZ) 1)
   )))
   :pattern ((req%lib!Chap26.ScanDCMtPer.ScanDCMtPer.prefix_sums_dc_inner. a!))
   :qid internal_req__lib!Chap26.ScanDCMtPer.ScanDCMtPer.prefix_sums_dc_inner._definition
   :skolemid skolem_internal_req__lib!Chap26.ScanDCMtPer.ScanDCMtPer.prefix_sums_dc_inner._definition
)))
(declare-fun ens%lib!Chap26.ScanDCMtPer.ScanDCMtPer.prefix_sums_dc_inner. (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
  tuple%2.
 ) Bool
)
(assert
 (forall ((a! lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.) (sums! tuple%2.))
  (!
   (= (ens%lib!Chap26.ScanDCMtPer.ScanDCMtPer.prefix_sums_dc_inner. a! sums!) (and
     (has_type (Poly%tuple%2. sums!) (TYPE%tuple%2. $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
        $ USIZE
       ) $ USIZE
     ))
     (lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_scan_post.? (vstd!seq.Seq.new.? $ USIZE (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_len.?
        $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE) $ USIZE (
         Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. a!
        )
       ) (Poly%fun%1. (mk_fun (%%lambda%%1 $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
           $ USIZE
          ) $ USIZE (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. a!)
       )))
      ) (Poly%fun%2. (lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_sum_fn.? (I 0))) (I 0) (vstd!seq.Seq.new.?
       $ USIZE (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_len.?
        $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE) $ USIZE (
         tuple%2./tuple%2/0 (%Poly%tuple%2. (Poly%tuple%2. sums!))
        )
       ) (Poly%fun%1. (mk_fun (%%lambda%%1 $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
           $ USIZE
          ) $ USIZE (tuple%2./tuple%2/0 (%Poly%tuple%2. (Poly%tuple%2. sums!)))
       )))
      ) (tuple%2./tuple%2/1 (%Poly%tuple%2. (Poly%tuple%2. sums!)))
   )))
   :pattern ((ens%lib!Chap26.ScanDCMtPer.ScanDCMtPer.prefix_sums_dc_inner. a! sums!))
   :qid internal_ens__lib!Chap26.ScanDCMtPer.ScanDCMtPer.prefix_sums_dc_inner._definition
   :skolemid skolem_internal_ens__lib!Chap26.ScanDCMtPer.ScanDCMtPer.prefix_sums_dc_inner._definition
)))

;; Function-Def lib::Chap26::ScanDCMtPer::ScanDCMtPer::prefix_sums_dc_inner
;; src/Chap26/ScanDCMtPer.rs:165:9: 165:22 (#921)
(push)
 (get-info :all-statistics)
 (declare-const sums! tuple%2.)
 (declare-const a! lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.)
 (declare-const tmp%1 Poly)
 (declare-const verus_tmp_input@ vstd!seq.Seq<usize.>.)
 (declare-const verus_tmp_spec_f@ %%Function%%)
 (declare-const tmp%2 Poly)
 (declare-const tmp%3 Poly)
 (declare-const tmp%4 Bool)
 (declare-const tmp%5 Bool)
 (declare-const tmp%6 Bool)
 (declare-const tmp%7 Bool)
 (declare-const tmp%8 Bool)
 (declare-const tmp%9 Poly)
 (declare-const total@ Int)
 (declare-const tmp%10 Poly)
 (declare-const tmp%11 Poly)
 (declare-const tmp%12 Poly)
 (declare-const tmp%13 Poly)
 (declare-const tmp%14 Int)
 (declare-const decrease%init0%0 Int)
 (declare-const tmp%15 Poly)
 (declare-const tmp%16 Poly)
 (declare-const tmp%17 Poly)
 (declare-const tmp%18 Poly)
 (declare-const tmp%19 Poly)
 (declare-const tmp%20 Poly)
 (declare-const tmp%21 Int)
 (declare-const decrease%init1%0 Int)
 (declare-const verus_tmp_left_input@ vstd!seq.Seq<usize.>.)
 (declare-const verus_tmp_right_input@ vstd!seq.Seq<usize.>.)
 (declare-const tmp%22 Bool)
 (declare-const tmp%23 Bool)
 (declare-const tmp%24 Bool)
 (declare-const r~1222 tuple%2.)
 (declare-const tmp%25 tuple%2.)
 (declare-const tmp%%7 anonymous_closure%29498.)
 (declare-const r~1325 tuple%2.)
 (declare-const tmp%26 tuple%2.)
 (declare-const tmp%%8 anonymous_closure%29501.)
 (declare-const verus_tmp_l_pref_view@ vstd!seq.Seq<usize.>.)
 (declare-const verus_tmp_r_pref_view@ vstd!seq.Seq<usize.>.)
 (declare-const tmp%27 Poly)
 (declare-const tmp%28 Poly)
 (declare-const verus_tmp_l_pv@ vstd!seq.Seq<usize.>.)
 (declare-const verus_tmp_r_pv@ vstd!seq.Seq<usize.>.)
 (declare-const r~1633 alloc!vec.Vec<usize./alloc!alloc.Global.>.)
 (declare-const tmp%29 Poly)
 (declare-const tmp%30 Poly)
 (declare-const tmp%31 Poly)
 (declare-const tmp%32 Poly)
 (declare-const tmp%33 Poly)
 (declare-const tmp%34 Int)
 (declare-const decrease%init2%0 Int)
 (declare-const ll@ Int)
 (declare-const v@0 alloc!vec.Vec<usize./alloc!alloc.Global.>.)
 (declare-const i$10@0 Int)
 (declare-const tmp%%19 anonymous_closure%29504.)
 (declare-const r~2121 alloc!vec.Vec<usize./alloc!alloc.Global.>.)
 (declare-const tmp%35 Poly)
 (declare-const tmp%36 Poly)
 (declare-const tmp%37 Poly)
 (declare-const tmp%38 Int)
 (declare-const tmp%39 Poly)
 (declare-const tmp%40 Poly)
 (declare-const tmp%41 Int)
 (declare-const val@ Int)
 (declare-const decrease%init3%0 Int)
 (declare-const rl@ Int)
 (declare-const v$1@0 alloc!vec.Vec<usize./alloc!alloc.Global.>.)
 (declare-const i$11@0 Int)
 (declare-const tmp%%29 anonymous_closure%29509.)
 (declare-const tmp%42 Poly)
 (declare-const tmp%43 Poly)
 (declare-const tmp%44 Poly)
 (declare-const tmp%45 Int)
 (declare-const decrease%init4%0 Int)
 (declare-const verus_tmp_result_view@ vstd!seq.Seq<usize.>.)
 (declare-const tmp%46 Bool)
 (declare-const tmp%47 Bool)
 (declare-const tmp%48 Bool)
 (declare-const tmp%49 Bool)
 (declare-const i$14@ Poly)
 (declare-const tmp%50 Bool)
 (declare-const tmp%51 Bool)
 (declare-const tmp%52 Bool)
 (declare-const tmp%53 Bool)
 (declare-const tmp%54 vstd!seq.Seq<usize.>.)
 (declare-const tmp%55 Bool)
 (declare-const tmp%56 Bool)
 (declare-const tmp%57 vstd!seq.Seq<usize.>.)
 (declare-const j@ Int)
 (declare-const rp@ vstd!seq.Seq<usize.>.)
 (declare-const n@ Int)
 (declare-const verus_tmp@0 vstd!seq.Seq<usize.>.)
 (declare-const input@0 vstd!seq.Seq<usize.>.)
 (declare-const verus_tmp$1@0 %%Function%%)
 (declare-const spec_f@0 %%Function%%)
 (declare-const mid@ Int)
 (declare-const left_vec@0 alloc!vec.Vec<usize./alloc!alloc.Global.>.)
 (declare-const i@0 Int)
 (declare-const left@ lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.)
 (declare-const right_len@ Int)
 (declare-const right_vec@0 alloc!vec.Vec<usize./alloc!alloc.Global.>.)
 (declare-const i$1@0 Int)
 (declare-const right@ lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.)
 (declare-const verus_tmp$2@0 vstd!seq.Seq<usize.>.)
 (declare-const left_input@0 vstd!seq.Seq<usize.>.)
 (declare-const verus_tmp$3@0 vstd!seq.Seq<usize.>.)
 (declare-const right_input@0 vstd!seq.Seq<usize.>.)
 (declare-const f1@ anonymous_closure%29498.)
 (declare-const f2@ anonymous_closure%29501.)
 (declare-const tmp%%$6@ tuple%2.)
 (declare-const left_result@ tuple%2.)
 (declare-const right_result@ tuple%2.)
 (declare-const l_prefixes@ lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.)
 (declare-const l_total@ Int)
 (declare-const r_prefixes@ lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.)
 (declare-const r_total@ Int)
 (declare-const verus_tmp$4@0 vstd!seq.Seq<usize.>.)
 (declare-const l_pref_view@0 vstd!seq.Seq<usize.>.)
 (declare-const verus_tmp$5@0 vstd!seq.Seq<usize.>.)
 (declare-const r_pref_view@0 vstd!seq.Seq<usize.>.)
 (declare-const l_len@ Int)
 (declare-const r_len@ Int)
 (declare-const verus_tmp$6@0 vstd!seq.Seq<usize.>.)
 (declare-const l_pv@0 vstd!seq.Seq<usize.>.)
 (declare-const verus_tmp$7@0 vstd!seq.Seq<usize.>.)
 (declare-const r_pv@0 vstd!seq.Seq<usize.>.)
 (declare-const lt@ Int)
 (declare-const copy_left@ anonymous_closure%29504.)
 (declare-const adjust_right@ anonymous_closure%29509.)
 (declare-const tmp%%$31@ tuple%2.)
 (declare-const left_part@ alloc!vec.Vec<usize./alloc!alloc.Global.>.)
 (declare-const right_part@ alloc!vec.Vec<usize./alloc!alloc.Global.>.)
 (declare-const result_vec@0 alloc!vec.Vec<usize./alloc!alloc.Global.>.)
 (declare-const i$12@0 Int)
 (declare-const total$1@ Int)
 (declare-const verus_tmp$8@0 vstd!seq.Seq<usize.>.)
 (declare-const result_view@0 vstd!seq.Seq<usize.>.)
 (declare-const result_prefixes@ lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.)
 (declare-const decrease%init0 Int)
 (assert
  fuel_defaults
 )
 (assert
  (has_type (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. a!) (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
    $ USIZE
 )))
 (assert
  (has_type tmp%1 USIZE)
 )
 (assert
  (uInv SZ n@)
 )
 (assert
  (has_type (Poly%fun%2. verus_tmp$1@0) (TYPE%fun%2. $ USIZE $ USIZE $ USIZE))
 )
 (assert
  (has_type (Poly%fun%2. verus_tmp_spec_f@) (TYPE%fun%2. $ USIZE $ USIZE $ USIZE))
 )
 (assert
  (has_type (Poly%fun%2. spec_f@0) (TYPE%fun%2. $ USIZE $ USIZE $ USIZE))
 )
 (assert
  (uInv SZ mid@)
 )
 (assert
  (has_type tmp%10 (TYPE%alloc!vec.Vec. $ USIZE $ TYPE%alloc!alloc.Global.))
 )
 (assert
  (uInv SZ i@0)
 )
 (declare-const left_vec@1 alloc!vec.Vec<usize./alloc!alloc.Global.>.)
 (declare-const i@1 Int)
 ;; precondition not satisfied
 (declare-const %%location_label%%0 Bool)
 ;; possible arithmetic underflow/overflow
 (declare-const %%location_label%%1 Bool)
 ;; invariant not satisfied at end of loop body
 (declare-const %%location_label%%2 Bool)
 ;; invariant not satisfied at end of loop body
 (declare-const %%location_label%%3 Bool)
 ;; invariant not satisfied at end of loop body
 (declare-const %%location_label%%4 Bool)
 ;; invariant not satisfied at end of loop body
 (declare-const %%location_label%%5 Bool)
 ;; invariant not satisfied at end of loop body
 (declare-const %%location_label%%6 Bool)
 ;; decreases not satisfied at end of loop
 (declare-const %%location_label%%7 Bool)
 (assert
  (not (=>
    (= decrease%init0 (%I (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_len.?
       $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE) $ USIZE (
        Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. a!
    ))))
    (=>
     (<= i@0 mid@)
     (=>
      (<= mid@ n@)
      (=>
       (= n@ (%I (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_len.?
          $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE) $ USIZE (
           Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. a!
       ))))
       (=>
        (= (vstd!seq.Seq.len.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ USIZE
            $ TYPE%alloc!alloc.Global.
           ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. left_vec@0)
          )
         ) i@0
        )
        (=>
         (forall ((j$ Poly)) (!
           (=>
            (has_type j$ INT)
            (=>
             (let
              ((tmp%%$ 0))
              (let
               ((tmp%%$1 (%I j$)))
               (let
                ((tmp%%$2 i@0))
                (and
                 (<= tmp%%$ tmp%%$1)
                 (< tmp%%$1 tmp%%$2)
             ))))
             (= (vstd!seq.Seq.index.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ USIZE
                 $ TYPE%alloc!alloc.Global.
                ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. left_vec@0)
               ) j$
              ) (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_index.? $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
                $ USIZE
               ) $ USIZE (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. a!) j$
           ))))
           :pattern ((vstd!seq.Seq.index.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec.
               $ USIZE $ TYPE%alloc!alloc.Global.
              ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. left_vec@0)
             ) j$
           ))
           :qid user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_0
           :skolemid skolem_user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_0
         ))
         (=>
          (= decrease%init0%0 (Sub mid@ i@0))
          (=>
           (< i@0 mid@)
           (=>
            (has_type tmp%11 (MUTREF $ (TYPE%alloc!vec.Vec. $ USIZE $ TYPE%alloc!alloc.Global.)))
            (=>
             (= (%Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. (mut_ref_current% tmp%11)) left_vec@0)
             (=>
              (= tmp%13 tmp%11)
              (and
               (=>
                %%location_label%%0
                (req%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.nth. $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
                  $ USIZE
                 ) $ USIZE (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. a!) (I i@0)
               ))
               (=>
                (ens%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.nth. $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
                  $ USIZE
                 ) $ USIZE (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. a!) (I i@0)
                 tmp%12
                )
                (=>
                 (= tmp%14 (%I tmp%12))
                 (=>
                  (= left_vec@1 (%Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. (mut_ref_future% tmp%11)))
                  (=>
                   (ens%alloc!vec.impl&%43.push. $ USIZE $ TYPE%alloc!alloc.Global. tmp%13 (I tmp%14))
                   (and
                    (=>
                     %%location_label%%1
                     (uInv SZ (Add i@0 1))
                    )
                    (=>
                     (uInv SZ (Add i@0 1))
                     (=>
                      (= i@1 (uClip SZ (Add i@0 1)))
                      (and
                       (=>
                        %%location_label%%2
                        (<= i@1 mid@)
                       )
                       (and
                        (=>
                         %%location_label%%3
                         (<= mid@ n@)
                        )
                        (and
                         (=>
                          %%location_label%%4
                          (= n@ (%I (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_len.?
                             $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE) $ USIZE (
                              Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. a!
                         )))))
                         (and
                          (=>
                           %%location_label%%5
                           (= (vstd!seq.Seq.len.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ USIZE
                               $ TYPE%alloc!alloc.Global.
                              ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. left_vec@1)
                             )
                            ) i@1
                          ))
                          (and
                           (=>
                            %%location_label%%6
                            (forall ((j$ Poly)) (!
                              (=>
                               (has_type j$ INT)
                               (=>
                                (let
                                 ((tmp%%$ 0))
                                 (let
                                  ((tmp%%$1 (%I j$)))
                                  (let
                                   ((tmp%%$2 i@1))
                                   (and
                                    (<= tmp%%$ tmp%%$1)
                                    (< tmp%%$1 tmp%%$2)
                                ))))
                                (= (vstd!seq.Seq.index.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ USIZE
                                    $ TYPE%alloc!alloc.Global.
                                   ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. left_vec@1)
                                  ) j$
                                 ) (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_index.? $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
                                   $ USIZE
                                  ) $ USIZE (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. a!) j$
                              ))))
                              :pattern ((vstd!seq.Seq.index.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec.
                                  $ USIZE $ TYPE%alloc!alloc.Global.
                                 ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. left_vec@1)
                                ) j$
                              ))
                              :qid user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_0
                              :skolemid skolem_user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_0
                           )))
                           (=>
                            %%location_label%%7
                            (check_decrease_height (I (Sub mid@ i@1)) (I decrease%init0%0) false)
 )))))))))))))))))))))))))))
 (get-info :all-statistics)
 (get-info :version)
 (set-option :rlimit 30000000)
 (check-sat)
 (set-option :rlimit 0)
 (get-info :all-statistics)
(pop)

;; Function-Def lib::Chap26::ScanDCMtPer::ScanDCMtPer::prefix_sums_dc_inner
;; src/Chap26/ScanDCMtPer.rs:181:9: 181:28 (#922)
(push)
 (get-info :all-statistics)
 (declare-const sums! tuple%2.)
 (declare-const a! lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.)
 (declare-const tmp%1 Poly)
 (declare-const verus_tmp_input@ vstd!seq.Seq<usize.>.)
 (declare-const verus_tmp_spec_f@ %%Function%%)
 (declare-const tmp%2 Poly)
 (declare-const tmp%3 Poly)
 (declare-const tmp%4 Bool)
 (declare-const tmp%5 Bool)
 (declare-const tmp%6 Bool)
 (declare-const tmp%7 Bool)
 (declare-const tmp%8 Bool)
 (declare-const tmp%9 Poly)
 (declare-const total@ Int)
 (declare-const tmp%10 Poly)
 (declare-const tmp%11 Poly)
 (declare-const tmp%12 Poly)
 (declare-const tmp%13 Poly)
 (declare-const tmp%14 Int)
 (declare-const decrease%init0%0 Int)
 (declare-const tmp%15 Poly)
 (declare-const tmp%16 Poly)
 (declare-const tmp%17 Poly)
 (declare-const tmp%18 Poly)
 (declare-const tmp%19 Poly)
 (declare-const tmp%20 Poly)
 (declare-const tmp%21 Int)
 (declare-const decrease%init1%0 Int)
 (declare-const verus_tmp_left_input@ vstd!seq.Seq<usize.>.)
 (declare-const verus_tmp_right_input@ vstd!seq.Seq<usize.>.)
 (declare-const tmp%22 Bool)
 (declare-const tmp%23 Bool)
 (declare-const tmp%24 Bool)
 (declare-const r~1222 tuple%2.)
 (declare-const tmp%25 tuple%2.)
 (declare-const tmp%%7 anonymous_closure%29498.)
 (declare-const r~1325 tuple%2.)
 (declare-const tmp%26 tuple%2.)
 (declare-const tmp%%8 anonymous_closure%29501.)
 (declare-const verus_tmp_l_pref_view@ vstd!seq.Seq<usize.>.)
 (declare-const verus_tmp_r_pref_view@ vstd!seq.Seq<usize.>.)
 (declare-const tmp%27 Poly)
 (declare-const tmp%28 Poly)
 (declare-const verus_tmp_l_pv@ vstd!seq.Seq<usize.>.)
 (declare-const verus_tmp_r_pv@ vstd!seq.Seq<usize.>.)
 (declare-const r~1633 alloc!vec.Vec<usize./alloc!alloc.Global.>.)
 (declare-const tmp%29 Poly)
 (declare-const tmp%30 Poly)
 (declare-const tmp%31 Poly)
 (declare-const tmp%32 Poly)
 (declare-const tmp%33 Poly)
 (declare-const tmp%34 Int)
 (declare-const decrease%init2%0 Int)
 (declare-const ll@ Int)
 (declare-const v@0 alloc!vec.Vec<usize./alloc!alloc.Global.>.)
 (declare-const i$10@0 Int)
 (declare-const tmp%%19 anonymous_closure%29504.)
 (declare-const r~2121 alloc!vec.Vec<usize./alloc!alloc.Global.>.)
 (declare-const tmp%35 Poly)
 (declare-const tmp%36 Poly)
 (declare-const tmp%37 Poly)
 (declare-const tmp%38 Int)
 (declare-const tmp%39 Poly)
 (declare-const tmp%40 Poly)
 (declare-const tmp%41 Int)
 (declare-const val@ Int)
 (declare-const decrease%init3%0 Int)
 (declare-const rl@ Int)
 (declare-const v$1@0 alloc!vec.Vec<usize./alloc!alloc.Global.>.)
 (declare-const i$11@0 Int)
 (declare-const tmp%%29 anonymous_closure%29509.)
 (declare-const tmp%42 Poly)
 (declare-const tmp%43 Poly)
 (declare-const tmp%44 Poly)
 (declare-const tmp%45 Int)
 (declare-const decrease%init4%0 Int)
 (declare-const verus_tmp_result_view@ vstd!seq.Seq<usize.>.)
 (declare-const tmp%46 Bool)
 (declare-const tmp%47 Bool)
 (declare-const tmp%48 Bool)
 (declare-const tmp%49 Bool)
 (declare-const i$14@ Poly)
 (declare-const tmp%50 Bool)
 (declare-const tmp%51 Bool)
 (declare-const tmp%52 Bool)
 (declare-const tmp%53 Bool)
 (declare-const tmp%54 vstd!seq.Seq<usize.>.)
 (declare-const tmp%55 Bool)
 (declare-const tmp%56 Bool)
 (declare-const tmp%57 vstd!seq.Seq<usize.>.)
 (declare-const j@ Int)
 (declare-const rp@ vstd!seq.Seq<usize.>.)
 (declare-const n@ Int)
 (declare-const verus_tmp@0 vstd!seq.Seq<usize.>.)
 (declare-const input@0 vstd!seq.Seq<usize.>.)
 (declare-const verus_tmp$1@0 %%Function%%)
 (declare-const spec_f@0 %%Function%%)
 (declare-const mid@ Int)
 (declare-const left_vec@0 alloc!vec.Vec<usize./alloc!alloc.Global.>.)
 (declare-const i@0 Int)
 (declare-const left@ lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.)
 (declare-const right_len@ Int)
 (declare-const right_vec@0 alloc!vec.Vec<usize./alloc!alloc.Global.>.)
 (declare-const i$1@0 Int)
 (declare-const right@ lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.)
 (declare-const verus_tmp$2@0 vstd!seq.Seq<usize.>.)
 (declare-const left_input@0 vstd!seq.Seq<usize.>.)
 (declare-const verus_tmp$3@0 vstd!seq.Seq<usize.>.)
 (declare-const right_input@0 vstd!seq.Seq<usize.>.)
 (declare-const f1@ anonymous_closure%29498.)
 (declare-const f2@ anonymous_closure%29501.)
 (declare-const tmp%%$6@ tuple%2.)
 (declare-const left_result@ tuple%2.)
 (declare-const right_result@ tuple%2.)
 (declare-const l_prefixes@ lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.)
 (declare-const l_total@ Int)
 (declare-const r_prefixes@ lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.)
 (declare-const r_total@ Int)
 (declare-const verus_tmp$4@0 vstd!seq.Seq<usize.>.)
 (declare-const l_pref_view@0 vstd!seq.Seq<usize.>.)
 (declare-const verus_tmp$5@0 vstd!seq.Seq<usize.>.)
 (declare-const r_pref_view@0 vstd!seq.Seq<usize.>.)
 (declare-const l_len@ Int)
 (declare-const r_len@ Int)
 (declare-const verus_tmp$6@0 vstd!seq.Seq<usize.>.)
 (declare-const l_pv@0 vstd!seq.Seq<usize.>.)
 (declare-const verus_tmp$7@0 vstd!seq.Seq<usize.>.)
 (declare-const r_pv@0 vstd!seq.Seq<usize.>.)
 (declare-const lt@ Int)
 (declare-const copy_left@ anonymous_closure%29504.)
 (declare-const adjust_right@ anonymous_closure%29509.)
 (declare-const tmp%%$31@ tuple%2.)
 (declare-const left_part@ alloc!vec.Vec<usize./alloc!alloc.Global.>.)
 (declare-const right_part@ alloc!vec.Vec<usize./alloc!alloc.Global.>.)
 (declare-const result_vec@0 alloc!vec.Vec<usize./alloc!alloc.Global.>.)
 (declare-const i$12@0 Int)
 (declare-const total$1@ Int)
 (declare-const verus_tmp$8@0 vstd!seq.Seq<usize.>.)
 (declare-const result_view@0 vstd!seq.Seq<usize.>.)
 (declare-const result_prefixes@ lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.)
 (declare-const decrease%init0 Int)
 (assert
  fuel_defaults
 )
 (assert
  (has_type (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. a!) (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
    $ USIZE
 )))
 (assert
  (has_type tmp%1 USIZE)
 )
 (assert
  (uInv SZ n@)
 )
 (assert
  (has_type (Poly%fun%2. verus_tmp$1@0) (TYPE%fun%2. $ USIZE $ USIZE $ USIZE))
 )
 (assert
  (has_type (Poly%fun%2. verus_tmp_spec_f@) (TYPE%fun%2. $ USIZE $ USIZE $ USIZE))
 )
 (assert
  (has_type (Poly%fun%2. spec_f@0) (TYPE%fun%2. $ USIZE $ USIZE $ USIZE))
 )
 (assert
  (uInv SZ mid@)
 )
 (assert
  (has_type tmp%10 (TYPE%alloc!vec.Vec. $ USIZE $ TYPE%alloc!alloc.Global.))
 )
 (assert
  (uInv SZ i@0)
 )
 (assert
  (has_type (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. left@) (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
    $ USIZE
 )))
 (assert
  (uInv SZ right_len@)
 )
 (assert
  (has_type tmp%15 (TYPE%alloc!vec.Vec. $ USIZE $ TYPE%alloc!alloc.Global.))
 )
 (assert
  (uInv SZ i$1@0)
 )
 (declare-const right_vec@1 alloc!vec.Vec<usize./alloc!alloc.Global.>.)
 (declare-const i$1@1 Int)
 ;; possible arithmetic underflow/overflow
 (declare-const %%location_label%%0 Bool)
 ;; precondition not satisfied
 (declare-const %%location_label%%1 Bool)
 ;; possible arithmetic underflow/overflow
 (declare-const %%location_label%%2 Bool)
 ;; invariant not satisfied at end of loop body
 (declare-const %%location_label%%3 Bool)
 ;; invariant not satisfied at end of loop body
 (declare-const %%location_label%%4 Bool)
 ;; invariant not satisfied at end of loop body
 (declare-const %%location_label%%5 Bool)
 ;; invariant not satisfied at end of loop body
 (declare-const %%location_label%%6 Bool)
 ;; invariant not satisfied at end of loop body
 (declare-const %%location_label%%7 Bool)
 ;; invariant not satisfied at end of loop body
 (declare-const %%location_label%%8 Bool)
 ;; decreases not satisfied at end of loop
 (declare-const %%location_label%%9 Bool)
 (assert
  (not (=>
    (= decrease%init0 (%I (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_len.?
       $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE) $ USIZE (
        Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. a!
    ))))
    (=>
     (<= i$1@0 right_len@)
     (=>
      (= right_len@ (Sub n@ mid@))
      (=>
       (<= mid@ n@)
       (=>
        (= n@ (%I (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_len.?
           $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE) $ USIZE (
            Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. a!
        ))))
        (=>
         (= (vstd!seq.Seq.len.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ USIZE
             $ TYPE%alloc!alloc.Global.
            ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. right_vec@0)
           )
          ) i$1@0
         )
         (=>
          (forall ((j$ Poly)) (!
            (=>
             (has_type j$ INT)
             (=>
              (let
               ((tmp%%$ 0))
               (let
                ((tmp%%$4 (%I j$)))
                (let
                 ((tmp%%$5 i$1@0))
                 (and
                  (<= tmp%%$ tmp%%$4)
                  (< tmp%%$4 tmp%%$5)
              ))))
              (= (vstd!seq.Seq.index.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ USIZE
                  $ TYPE%alloc!alloc.Global.
                 ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. right_vec@0)
                ) j$
               ) (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_index.? $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
                 $ USIZE
                ) $ USIZE (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. a!) (I (Add
                  mid@ (%I j$)
            ))))))
            :pattern ((vstd!seq.Seq.index.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec.
                $ USIZE $ TYPE%alloc!alloc.Global.
               ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. right_vec@0)
              ) j$
            ))
            :qid user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_1
            :skolemid skolem_user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_1
          ))
          (=>
           (= decrease%init1%0 (Sub right_len@ i$1@0))
           (=>
            (has_resolved $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE)
             (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. left@)
            )
            (=>
             (< i$1@0 right_len@)
             (=>
              (has_type tmp%16 (MUTREF $ (TYPE%alloc!vec.Vec. $ USIZE $ TYPE%alloc!alloc.Global.)))
              (=>
               (= (%Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. (mut_ref_current% tmp%16)) right_vec@0)
               (=>
                (= tmp%20 tmp%16)
                (=>
                 (= tmp%17 (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. a!))
                 (and
                  (=>
                   %%location_label%%0
                   (uInv SZ (Add mid@ i$1@0))
                  )
                  (=>
                   (uInv SZ (Add mid@ i$1@0))
                   (=>
                    (= tmp%19 (I (uClip SZ (Add mid@ i$1@0))))
                    (and
                     (=>
                      %%location_label%%1
                      (req%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.nth. $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
                        $ USIZE
                       ) $ USIZE tmp%17 tmp%19
                     ))
                     (=>
                      (ens%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.nth. $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
                        $ USIZE
                       ) $ USIZE tmp%17 tmp%19 tmp%18
                      )
                      (=>
                       (= tmp%21 (%I tmp%18))
                       (=>
                        (= right_vec@1 (%Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. (mut_ref_future% tmp%16)))
                        (=>
                         (ens%alloc!vec.impl&%43.push. $ USIZE $ TYPE%alloc!alloc.Global. tmp%20 (I tmp%21))
                         (and
                          (=>
                           %%location_label%%2
                           (uInv SZ (Add i$1@0 1))
                          )
                          (=>
                           (uInv SZ (Add i$1@0 1))
                           (=>
                            (= i$1@1 (uClip SZ (Add i$1@0 1)))
                            (and
                             (=>
                              %%location_label%%3
                              (<= i$1@1 right_len@)
                             )
                             (and
                              (=>
                               %%location_label%%4
                               (= right_len@ (Sub n@ mid@))
                              )
                              (and
                               (=>
                                %%location_label%%5
                                (<= mid@ n@)
                               )
                               (and
                                (=>
                                 %%location_label%%6
                                 (= n@ (%I (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_len.?
                                    $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE) $ USIZE (
                                     Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. a!
                                )))))
                                (and
                                 (=>
                                  %%location_label%%7
                                  (= (vstd!seq.Seq.len.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ USIZE
                                      $ TYPE%alloc!alloc.Global.
                                     ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. right_vec@1)
                                    )
                                   ) i$1@1
                                 ))
                                 (and
                                  (=>
                                   %%location_label%%8
                                   (forall ((j$ Poly)) (!
                                     (=>
                                      (has_type j$ INT)
                                      (=>
                                       (let
                                        ((tmp%%$ 0))
                                        (let
                                         ((tmp%%$4 (%I j$)))
                                         (let
                                          ((tmp%%$5 i$1@1))
                                          (and
                                           (<= tmp%%$ tmp%%$4)
                                           (< tmp%%$4 tmp%%$5)
                                       ))))
                                       (= (vstd!seq.Seq.index.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ USIZE
                                           $ TYPE%alloc!alloc.Global.
                                          ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. right_vec@1)
                                         ) j$
                                        ) (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_index.? $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
                                          $ USIZE
                                         ) $ USIZE (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. a!) (I (Add
                                           mid@ (%I j$)
                                     ))))))
                                     :pattern ((vstd!seq.Seq.index.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec.
                                         $ USIZE $ TYPE%alloc!alloc.Global.
                                        ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. right_vec@1)
                                       ) j$
                                     ))
                                     :qid user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_1
                                     :skolemid skolem_user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_1
                                  )))
                                  (=>
                                   %%location_label%%9
                                   (check_decrease_height (I (Sub right_len@ i$1@1)) (I decrease%init1%0) false)
 ))))))))))))))))))))))))))))))))))
 (get-info :all-statistics)
 (get-info :version)
 (set-option :rlimit 30000000)
 (check-sat)
 (set-option :rlimit 0)
 (get-info :all-statistics)
(pop)

;; Function-Def lib::Chap26::ScanDCMtPer::ScanDCMtPer::prefix_sums_dc_inner
;; src/Chap26/ScanDCMtPer.rs:239:13: 239:25 (#923)
(push)
 (get-info :all-statistics)
 (declare-const sums! tuple%2.)
 (declare-const a! lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.)
 (declare-const tmp%1 Poly)
 (declare-const verus_tmp_input@ vstd!seq.Seq<usize.>.)
 (declare-const verus_tmp_spec_f@ %%Function%%)
 (declare-const tmp%2 Poly)
 (declare-const tmp%3 Poly)
 (declare-const tmp%4 Bool)
 (declare-const tmp%5 Bool)
 (declare-const tmp%6 Bool)
 (declare-const tmp%7 Bool)
 (declare-const tmp%8 Bool)
 (declare-const tmp%9 Poly)
 (declare-const total@ Int)
 (declare-const tmp%10 Poly)
 (declare-const tmp%11 Poly)
 (declare-const tmp%12 Poly)
 (declare-const tmp%13 Poly)
 (declare-const tmp%14 Int)
 (declare-const decrease%init0%0 Int)
 (declare-const tmp%15 Poly)
 (declare-const tmp%16 Poly)
 (declare-const tmp%17 Poly)
 (declare-const tmp%18 Poly)
 (declare-const tmp%19 Poly)
 (declare-const tmp%20 Poly)
 (declare-const tmp%21 Int)
 (declare-const decrease%init1%0 Int)
 (declare-const verus_tmp_left_input@ vstd!seq.Seq<usize.>.)
 (declare-const verus_tmp_right_input@ vstd!seq.Seq<usize.>.)
 (declare-const tmp%22 Bool)
 (declare-const tmp%23 Bool)
 (declare-const tmp%24 Bool)
 (declare-const r~1222 tuple%2.)
 (declare-const tmp%25 tuple%2.)
 (declare-const tmp%%7 anonymous_closure%29498.)
 (declare-const r~1325 tuple%2.)
 (declare-const tmp%26 tuple%2.)
 (declare-const tmp%%8 anonymous_closure%29501.)
 (declare-const verus_tmp_l_pref_view@ vstd!seq.Seq<usize.>.)
 (declare-const verus_tmp_r_pref_view@ vstd!seq.Seq<usize.>.)
 (declare-const tmp%27 Poly)
 (declare-const tmp%28 Poly)
 (declare-const verus_tmp_l_pv@ vstd!seq.Seq<usize.>.)
 (declare-const verus_tmp_r_pv@ vstd!seq.Seq<usize.>.)
 (declare-const r~1633 alloc!vec.Vec<usize./alloc!alloc.Global.>.)
 (declare-const tmp%29 Poly)
 (declare-const tmp%30 Poly)
 (declare-const tmp%31 Poly)
 (declare-const tmp%32 Poly)
 (declare-const tmp%33 Poly)
 (declare-const tmp%34 Int)
 (declare-const decrease%init2%0 Int)
 (declare-const ll@ Int)
 (declare-const v@0 alloc!vec.Vec<usize./alloc!alloc.Global.>.)
 (declare-const i$10@0 Int)
 (declare-const tmp%%19 anonymous_closure%29504.)
 (declare-const r~2121 alloc!vec.Vec<usize./alloc!alloc.Global.>.)
 (declare-const tmp%35 Poly)
 (declare-const tmp%36 Poly)
 (declare-const tmp%37 Poly)
 (declare-const tmp%38 Int)
 (declare-const tmp%39 Poly)
 (declare-const tmp%40 Poly)
 (declare-const tmp%41 Int)
 (declare-const val@ Int)
 (declare-const decrease%init3%0 Int)
 (declare-const rl@ Int)
 (declare-const v$1@0 alloc!vec.Vec<usize./alloc!alloc.Global.>.)
 (declare-const i$11@0 Int)
 (declare-const tmp%%29 anonymous_closure%29509.)
 (declare-const tmp%42 Poly)
 (declare-const tmp%43 Poly)
 (declare-const tmp%44 Poly)
 (declare-const tmp%45 Int)
 (declare-const decrease%init4%0 Int)
 (declare-const verus_tmp_result_view@ vstd!seq.Seq<usize.>.)
 (declare-const tmp%46 Bool)
 (declare-const tmp%47 Bool)
 (declare-const tmp%48 Bool)
 (declare-const tmp%49 Bool)
 (declare-const i$14@ Poly)
 (declare-const tmp%50 Bool)
 (declare-const tmp%51 Bool)
 (declare-const tmp%52 Bool)
 (declare-const tmp%53 Bool)
 (declare-const tmp%54 vstd!seq.Seq<usize.>.)
 (declare-const tmp%55 Bool)
 (declare-const tmp%56 Bool)
 (declare-const tmp%57 vstd!seq.Seq<usize.>.)
 (declare-const j@ Int)
 (declare-const rp@ vstd!seq.Seq<usize.>.)
 (declare-const n@ Int)
 (declare-const verus_tmp@0 vstd!seq.Seq<usize.>.)
 (declare-const input@0 vstd!seq.Seq<usize.>.)
 (declare-const verus_tmp$1@0 %%Function%%)
 (declare-const spec_f@0 %%Function%%)
 (declare-const mid@ Int)
 (declare-const left_vec@0 alloc!vec.Vec<usize./alloc!alloc.Global.>.)
 (declare-const i@0 Int)
 (declare-const left@ lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.)
 (declare-const right_len@ Int)
 (declare-const right_vec@0 alloc!vec.Vec<usize./alloc!alloc.Global.>.)
 (declare-const i$1@0 Int)
 (declare-const right@ lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.)
 (declare-const verus_tmp$2@0 vstd!seq.Seq<usize.>.)
 (declare-const left_input@0 vstd!seq.Seq<usize.>.)
 (declare-const verus_tmp$3@0 vstd!seq.Seq<usize.>.)
 (declare-const right_input@0 vstd!seq.Seq<usize.>.)
 (declare-const f1@ anonymous_closure%29498.)
 (declare-const f2@ anonymous_closure%29501.)
 (declare-const tmp%%$6@ tuple%2.)
 (declare-const left_result@ tuple%2.)
 (declare-const right_result@ tuple%2.)
 (declare-const l_prefixes@ lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.)
 (declare-const l_total@ Int)
 (declare-const r_prefixes@ lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.)
 (declare-const r_total@ Int)
 (declare-const verus_tmp$4@0 vstd!seq.Seq<usize.>.)
 (declare-const l_pref_view@0 vstd!seq.Seq<usize.>.)
 (declare-const verus_tmp$5@0 vstd!seq.Seq<usize.>.)
 (declare-const r_pref_view@0 vstd!seq.Seq<usize.>.)
 (declare-const l_len@ Int)
 (declare-const r_len@ Int)
 (declare-const verus_tmp$6@0 vstd!seq.Seq<usize.>.)
 (declare-const l_pv@0 vstd!seq.Seq<usize.>.)
 (declare-const verus_tmp$7@0 vstd!seq.Seq<usize.>.)
 (declare-const r_pv@0 vstd!seq.Seq<usize.>.)
 (declare-const lt@ Int)
 (declare-const copy_left@ anonymous_closure%29504.)
 (declare-const adjust_right@ anonymous_closure%29509.)
 (declare-const tmp%%$31@ tuple%2.)
 (declare-const left_part@ alloc!vec.Vec<usize./alloc!alloc.Global.>.)
 (declare-const right_part@ alloc!vec.Vec<usize./alloc!alloc.Global.>.)
 (declare-const result_vec@0 alloc!vec.Vec<usize./alloc!alloc.Global.>.)
 (declare-const i$12@0 Int)
 (declare-const total$1@ Int)
 (declare-const verus_tmp$8@0 vstd!seq.Seq<usize.>.)
 (declare-const result_view@0 vstd!seq.Seq<usize.>.)
 (declare-const result_prefixes@ lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.)
 (declare-const decrease%init0 Int)
 (assert
  fuel_defaults
 )
 (assert
  (has_type (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. a!) (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
    $ USIZE
 )))
 (assert
  (has_type tmp%1 USIZE)
 )
 (assert
  (uInv SZ n@)
 )
 (assert
  (has_type (Poly%fun%2. verus_tmp$1@0) (TYPE%fun%2. $ USIZE $ USIZE $ USIZE))
 )
 (assert
  (has_type (Poly%fun%2. verus_tmp_spec_f@) (TYPE%fun%2. $ USIZE $ USIZE $ USIZE))
 )
 (assert
  (has_type (Poly%fun%2. spec_f@0) (TYPE%fun%2. $ USIZE $ USIZE $ USIZE))
 )
 (assert
  (uInv SZ mid@)
 )
 (assert
  (has_type tmp%10 (TYPE%alloc!vec.Vec. $ USIZE $ TYPE%alloc!alloc.Global.))
 )
 (assert
  (uInv SZ i@0)
 )
 (assert
  (has_type (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. left@) (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
    $ USIZE
 )))
 (assert
  (uInv SZ right_len@)
 )
 (assert
  (has_type tmp%15 (TYPE%alloc!vec.Vec. $ USIZE $ TYPE%alloc!alloc.Global.))
 )
 (assert
  (uInv SZ i$1@0)
 )
 (assert
  (has_type (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. right@) (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
    $ USIZE
 )))
 (assert
  (has_type (Poly%tuple%2. tmp%%$6@) (TYPE%tuple%2. (DST $) (TYPE%tuple%2. $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
      $ USIZE
     ) $ USIZE
    ) (DST $) (TYPE%tuple%2. $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
      $ USIZE
     ) $ USIZE
 ))))
 (assert
  (has_type (Poly%tuple%2. left_result@) (TYPE%tuple%2. $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
     $ USIZE
    ) $ USIZE
 )))
 (assert
  (has_type (Poly%tuple%2. right_result@) (TYPE%tuple%2. $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
     $ USIZE
    ) $ USIZE
 )))
 (assert
  (has_type (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. l_prefixes@)
   (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE)
 ))
 (assert
  (uInv SZ l_total@)
 )
 (assert
  (has_type (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. r_prefixes@)
   (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE)
 ))
 (assert
  (uInv SZ r_total@)
 )
 (assert
  (has_type tmp%27 USIZE)
 )
 (assert
  (uInv SZ l_len@)
 )
 (assert
  (has_type tmp%28 USIZE)
 )
 (assert
  (uInv SZ r_len@)
 )
 (assert
  (uInv SZ lt@)
 )
 (assert
  (has_type tmp%29 USIZE)
 )
 (assert
  (uInv SZ ll@)
 )
 (assert
  (has_type tmp%30 (TYPE%alloc!vec.Vec. $ USIZE $ TYPE%alloc!alloc.Global.))
 )
 (assert
  (uInv SZ i$10@0)
 )
 (declare-const v@1 alloc!vec.Vec<usize./alloc!alloc.Global.>.)
 (declare-const i$10@1 Int)
 ;; precondition not satisfied
 (declare-const %%location_label%%0 Bool)
 ;; possible arithmetic underflow/overflow
 (declare-const %%location_label%%1 Bool)
 ;; invariant not satisfied at end of loop body
 (declare-const %%location_label%%2 Bool)
 ;; invariant not satisfied at end of loop body
 (declare-const %%location_label%%3 Bool)
 ;; invariant not satisfied at end of loop body
 (declare-const %%location_label%%4 Bool)
 ;; invariant not satisfied at end of loop body
 (declare-const %%location_label%%5 Bool)
 ;; invariant not satisfied at end of loop body
 (declare-const %%location_label%%6 Bool)
 ;; invariant not satisfied at end of loop body
 (declare-const %%location_label%%7 Bool)
 ;; decreases not satisfied at end of loop
 (declare-const %%location_label%%8 Bool)
 (assert
  (not (=>
    (= decrease%init0 (%I (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_len.?
       $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE) $ USIZE (
        Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. a!
    ))))
    (=>
     (<= i$10@0 ll@)
     (=>
      (= ll@ (%I (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_len.?
         $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE) $ USIZE (
          Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. l_prefixes@
      ))))
      (=>
       (= (vstd!seq.Seq.len.? $ USIZE (Poly%vstd!seq.Seq<usize.>. l_pv@0)) ll@)
       (=>
        (= (vstd!seq.Seq.len.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ USIZE
            $ TYPE%alloc!alloc.Global.
           ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. v@0)
          )
         ) i$10@0
        )
        (=>
         (forall ((j$ Poly)) (!
           (=>
            (has_type j$ INT)
            (=>
             (let
              ((tmp%%$10 0))
              (let
               ((tmp%%$11 (%I j$)))
               (let
                ((tmp%%$12 ll@))
                (and
                 (<= tmp%%$10 tmp%%$11)
                 (< tmp%%$11 tmp%%$12)
             ))))
             (= (vstd!seq.Seq.index.? $ USIZE (Poly%vstd!seq.Seq<usize.>. l_pv@0) j$) (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_index.?
               $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE) $ USIZE (
                Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. l_prefixes@
               ) j$
           ))))
           :pattern ((vstd!seq.Seq.index.? $ USIZE (Poly%vstd!seq.Seq<usize.>. l_pv@0) j$))
           :qid user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_6
           :skolemid skolem_user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_6
         ))
         (=>
          (forall ((j$ Poly)) (!
            (=>
             (has_type j$ INT)
             (=>
              (let
               ((tmp%%$13 0))
               (let
                ((tmp%%$14 (%I j$)))
                (let
                 ((tmp%%$15 i$10@0))
                 (and
                  (<= tmp%%$13 tmp%%$14)
                  (< tmp%%$14 tmp%%$15)
              ))))
              (= (vstd!seq.Seq.index.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ USIZE
                  $ TYPE%alloc!alloc.Global.
                 ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. v@0)
                ) j$
               ) (vstd!seq.Seq.index.? $ USIZE (Poly%vstd!seq.Seq<usize.>. l_pv@0) j$)
            )))
            :pattern ((vstd!seq.Seq.index.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec.
                $ USIZE $ TYPE%alloc!alloc.Global.
               ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. v@0)
              ) j$
            ))
            :qid user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_7
            :skolemid skolem_user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_7
          ))
          (=>
           (= decrease%init2%0 (Sub ll@ i$10@0))
           (=>
            (< i$10@0 ll@)
            (=>
             (has_type tmp%31 (MUTREF $ (TYPE%alloc!vec.Vec. $ USIZE $ TYPE%alloc!alloc.Global.)))
             (=>
              (= (%Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. (mut_ref_current% tmp%31)) v@0)
              (=>
               (= tmp%33 tmp%31)
               (and
                (=>
                 %%location_label%%0
                 (req%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.nth. $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
                   $ USIZE
                  ) $ USIZE (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. l_prefixes@)
                  (I i$10@0)
                ))
                (=>
                 (ens%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.nth. $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
                   $ USIZE
                  ) $ USIZE (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. l_prefixes@)
                  (I i$10@0) tmp%32
                 )
                 (=>
                  (= tmp%34 (%I tmp%32))
                  (=>
                   (= v@1 (%Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. (mut_ref_future% tmp%31)))
                   (=>
                    (ens%alloc!vec.impl&%43.push. $ USIZE $ TYPE%alloc!alloc.Global. tmp%33 (I tmp%34))
                    (and
                     (=>
                      %%location_label%%1
                      (uInv SZ (Add i$10@0 1))
                     )
                     (=>
                      (uInv SZ (Add i$10@0 1))
                      (=>
                       (= i$10@1 (uClip SZ (Add i$10@0 1)))
                       (and
                        (=>
                         %%location_label%%2
                         (<= i$10@1 ll@)
                        )
                        (and
                         (=>
                          %%location_label%%3
                          (= ll@ (%I (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_len.?
                             $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE) $ USIZE (
                              Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. l_prefixes@
                         )))))
                         (and
                          (=>
                           %%location_label%%4
                           (= (vstd!seq.Seq.len.? $ USIZE (Poly%vstd!seq.Seq<usize.>. l_pv@0)) ll@)
                          )
                          (and
                           (=>
                            %%location_label%%5
                            (= (vstd!seq.Seq.len.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ USIZE
                                $ TYPE%alloc!alloc.Global.
                               ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. v@1)
                              )
                             ) i$10@1
                           ))
                           (and
                            (=>
                             %%location_label%%6
                             (forall ((j$ Poly)) (!
                               (=>
                                (has_type j$ INT)
                                (=>
                                 (let
                                  ((tmp%%$10 0))
                                  (let
                                   ((tmp%%$11 (%I j$)))
                                   (let
                                    ((tmp%%$12 ll@))
                                    (and
                                     (<= tmp%%$10 tmp%%$11)
                                     (< tmp%%$11 tmp%%$12)
                                 ))))
                                 (= (vstd!seq.Seq.index.? $ USIZE (Poly%vstd!seq.Seq<usize.>. l_pv@0) j$) (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_index.?
                                   $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE) $ USIZE (
                                    Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. l_prefixes@
                                   ) j$
                               ))))
                               :pattern ((vstd!seq.Seq.index.? $ USIZE (Poly%vstd!seq.Seq<usize.>. l_pv@0) j$))
                               :qid user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_6
                               :skolemid skolem_user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_6
                            )))
                            (and
                             (=>
                              %%location_label%%7
                              (forall ((j$ Poly)) (!
                                (=>
                                 (has_type j$ INT)
                                 (=>
                                  (let
                                   ((tmp%%$13 0))
                                   (let
                                    ((tmp%%$14 (%I j$)))
                                    (let
                                     ((tmp%%$15 i$10@1))
                                     (and
                                      (<= tmp%%$13 tmp%%$14)
                                      (< tmp%%$14 tmp%%$15)
                                  ))))
                                  (= (vstd!seq.Seq.index.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ USIZE
                                      $ TYPE%alloc!alloc.Global.
                                     ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. v@1)
                                    ) j$
                                   ) (vstd!seq.Seq.index.? $ USIZE (Poly%vstd!seq.Seq<usize.>. l_pv@0) j$)
                                )))
                                :pattern ((vstd!seq.Seq.index.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec.
                                    $ USIZE $ TYPE%alloc!alloc.Global.
                                   ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. v@1)
                                  ) j$
                                ))
                                :qid user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_7
                                :skolemid skolem_user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_7
                             )))
                             (=>
                              %%location_label%%8
                              (check_decrease_height (I (Sub ll@ i$10@1)) (I decrease%init2%0) false)
 )))))))))))))))))))))))))))))
 (get-info :all-statistics)
 (get-info :version)
 (set-option :rlimit 30000000)
 (check-sat)
 (set-option :rlimit 0)
 (get-info :all-statistics)
(pop)

;; Function-Def lib::Chap26::ScanDCMtPer::ScanDCMtPer::prefix_sums_dc_inner
;; src/Chap26/ScanDCMtPer.rs:262:13: 262:25 (#924)
(push)
 (get-info :all-statistics)
 (declare-const sums! tuple%2.)
 (declare-const a! lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.)
 (declare-const tmp%1 Poly)
 (declare-const verus_tmp_input@ vstd!seq.Seq<usize.>.)
 (declare-const verus_tmp_spec_f@ %%Function%%)
 (declare-const tmp%2 Poly)
 (declare-const tmp%3 Poly)
 (declare-const tmp%4 Bool)
 (declare-const tmp%5 Bool)
 (declare-const tmp%6 Bool)
 (declare-const tmp%7 Bool)
 (declare-const tmp%8 Bool)
 (declare-const tmp%9 Poly)
 (declare-const total@ Int)
 (declare-const tmp%10 Poly)
 (declare-const tmp%11 Poly)
 (declare-const tmp%12 Poly)
 (declare-const tmp%13 Poly)
 (declare-const tmp%14 Int)
 (declare-const decrease%init0%0 Int)
 (declare-const tmp%15 Poly)
 (declare-const tmp%16 Poly)
 (declare-const tmp%17 Poly)
 (declare-const tmp%18 Poly)
 (declare-const tmp%19 Poly)
 (declare-const tmp%20 Poly)
 (declare-const tmp%21 Int)
 (declare-const decrease%init1%0 Int)
 (declare-const verus_tmp_left_input@ vstd!seq.Seq<usize.>.)
 (declare-const verus_tmp_right_input@ vstd!seq.Seq<usize.>.)
 (declare-const tmp%22 Bool)
 (declare-const tmp%23 Bool)
 (declare-const tmp%24 Bool)
 (declare-const r~1222 tuple%2.)
 (declare-const tmp%25 tuple%2.)
 (declare-const tmp%%7 anonymous_closure%29498.)
 (declare-const r~1325 tuple%2.)
 (declare-const tmp%26 tuple%2.)
 (declare-const tmp%%8 anonymous_closure%29501.)
 (declare-const verus_tmp_l_pref_view@ vstd!seq.Seq<usize.>.)
 (declare-const verus_tmp_r_pref_view@ vstd!seq.Seq<usize.>.)
 (declare-const tmp%27 Poly)
 (declare-const tmp%28 Poly)
 (declare-const verus_tmp_l_pv@ vstd!seq.Seq<usize.>.)
 (declare-const verus_tmp_r_pv@ vstd!seq.Seq<usize.>.)
 (declare-const r~1633 alloc!vec.Vec<usize./alloc!alloc.Global.>.)
 (declare-const tmp%29 Poly)
 (declare-const tmp%30 Poly)
 (declare-const tmp%31 Poly)
 (declare-const tmp%32 Poly)
 (declare-const tmp%33 Poly)
 (declare-const tmp%34 Int)
 (declare-const decrease%init2%0 Int)
 (declare-const ll@ Int)
 (declare-const v@0 alloc!vec.Vec<usize./alloc!alloc.Global.>.)
 (declare-const i$10@0 Int)
 (declare-const tmp%%19 anonymous_closure%29504.)
 (declare-const r~2121 alloc!vec.Vec<usize./alloc!alloc.Global.>.)
 (declare-const tmp%35 Poly)
 (declare-const tmp%36 Poly)
 (declare-const tmp%37 Poly)
 (declare-const tmp%38 Int)
 (declare-const tmp%39 Poly)
 (declare-const tmp%40 Poly)
 (declare-const tmp%41 Int)
 (declare-const val@ Int)
 (declare-const decrease%init3%0 Int)
 (declare-const rl@ Int)
 (declare-const v$1@0 alloc!vec.Vec<usize./alloc!alloc.Global.>.)
 (declare-const i$11@0 Int)
 (declare-const tmp%%29 anonymous_closure%29509.)
 (declare-const tmp%42 Poly)
 (declare-const tmp%43 Poly)
 (declare-const tmp%44 Poly)
 (declare-const tmp%45 Int)
 (declare-const decrease%init4%0 Int)
 (declare-const verus_tmp_result_view@ vstd!seq.Seq<usize.>.)
 (declare-const tmp%46 Bool)
 (declare-const tmp%47 Bool)
 (declare-const tmp%48 Bool)
 (declare-const tmp%49 Bool)
 (declare-const i$14@ Poly)
 (declare-const tmp%50 Bool)
 (declare-const tmp%51 Bool)
 (declare-const tmp%52 Bool)
 (declare-const tmp%53 Bool)
 (declare-const tmp%54 vstd!seq.Seq<usize.>.)
 (declare-const tmp%55 Bool)
 (declare-const tmp%56 Bool)
 (declare-const tmp%57 vstd!seq.Seq<usize.>.)
 (declare-const j@ Int)
 (declare-const rp@ vstd!seq.Seq<usize.>.)
 (declare-const n@ Int)
 (declare-const verus_tmp@0 vstd!seq.Seq<usize.>.)
 (declare-const input@0 vstd!seq.Seq<usize.>.)
 (declare-const verus_tmp$1@0 %%Function%%)
 (declare-const spec_f@0 %%Function%%)
 (declare-const mid@ Int)
 (declare-const left_vec@0 alloc!vec.Vec<usize./alloc!alloc.Global.>.)
 (declare-const i@0 Int)
 (declare-const left@ lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.)
 (declare-const right_len@ Int)
 (declare-const right_vec@0 alloc!vec.Vec<usize./alloc!alloc.Global.>.)
 (declare-const i$1@0 Int)
 (declare-const right@ lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.)
 (declare-const verus_tmp$2@0 vstd!seq.Seq<usize.>.)
 (declare-const left_input@0 vstd!seq.Seq<usize.>.)
 (declare-const verus_tmp$3@0 vstd!seq.Seq<usize.>.)
 (declare-const right_input@0 vstd!seq.Seq<usize.>.)
 (declare-const f1@ anonymous_closure%29498.)
 (declare-const f2@ anonymous_closure%29501.)
 (declare-const tmp%%$6@ tuple%2.)
 (declare-const left_result@ tuple%2.)
 (declare-const right_result@ tuple%2.)
 (declare-const l_prefixes@ lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.)
 (declare-const l_total@ Int)
 (declare-const r_prefixes@ lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.)
 (declare-const r_total@ Int)
 (declare-const verus_tmp$4@0 vstd!seq.Seq<usize.>.)
 (declare-const l_pref_view@0 vstd!seq.Seq<usize.>.)
 (declare-const verus_tmp$5@0 vstd!seq.Seq<usize.>.)
 (declare-const r_pref_view@0 vstd!seq.Seq<usize.>.)
 (declare-const l_len@ Int)
 (declare-const r_len@ Int)
 (declare-const verus_tmp$6@0 vstd!seq.Seq<usize.>.)
 (declare-const l_pv@0 vstd!seq.Seq<usize.>.)
 (declare-const verus_tmp$7@0 vstd!seq.Seq<usize.>.)
 (declare-const r_pv@0 vstd!seq.Seq<usize.>.)
 (declare-const lt@ Int)
 (declare-const copy_left@ anonymous_closure%29504.)
 (declare-const adjust_right@ anonymous_closure%29509.)
 (declare-const tmp%%$31@ tuple%2.)
 (declare-const left_part@ alloc!vec.Vec<usize./alloc!alloc.Global.>.)
 (declare-const right_part@ alloc!vec.Vec<usize./alloc!alloc.Global.>.)
 (declare-const result_vec@0 alloc!vec.Vec<usize./alloc!alloc.Global.>.)
 (declare-const i$12@0 Int)
 (declare-const total$1@ Int)
 (declare-const verus_tmp$8@0 vstd!seq.Seq<usize.>.)
 (declare-const result_view@0 vstd!seq.Seq<usize.>.)
 (declare-const result_prefixes@ lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.)
 (declare-const decrease%init0 Int)
 (assert
  fuel_defaults
 )
 (assert
  (has_type (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. a!) (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
    $ USIZE
 )))
 (assert
  (has_type tmp%1 USIZE)
 )
 (assert
  (uInv SZ n@)
 )
 (assert
  (has_type (Poly%fun%2. verus_tmp$1@0) (TYPE%fun%2. $ USIZE $ USIZE $ USIZE))
 )
 (assert
  (has_type (Poly%fun%2. verus_tmp_spec_f@) (TYPE%fun%2. $ USIZE $ USIZE $ USIZE))
 )
 (assert
  (has_type (Poly%fun%2. spec_f@0) (TYPE%fun%2. $ USIZE $ USIZE $ USIZE))
 )
 (assert
  (uInv SZ mid@)
 )
 (assert
  (has_type tmp%10 (TYPE%alloc!vec.Vec. $ USIZE $ TYPE%alloc!alloc.Global.))
 )
 (assert
  (uInv SZ i@0)
 )
 (assert
  (has_type (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. left@) (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
    $ USIZE
 )))
 (assert
  (uInv SZ right_len@)
 )
 (assert
  (has_type tmp%15 (TYPE%alloc!vec.Vec. $ USIZE $ TYPE%alloc!alloc.Global.))
 )
 (assert
  (uInv SZ i$1@0)
 )
 (assert
  (has_type (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. right@) (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
    $ USIZE
 )))
 (assert
  (has_type (Poly%tuple%2. tmp%%$6@) (TYPE%tuple%2. (DST $) (TYPE%tuple%2. $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
      $ USIZE
     ) $ USIZE
    ) (DST $) (TYPE%tuple%2. $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
      $ USIZE
     ) $ USIZE
 ))))
 (assert
  (has_type (Poly%tuple%2. left_result@) (TYPE%tuple%2. $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
     $ USIZE
    ) $ USIZE
 )))
 (assert
  (has_type (Poly%tuple%2. right_result@) (TYPE%tuple%2. $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
     $ USIZE
    ) $ USIZE
 )))
 (assert
  (has_type (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. l_prefixes@)
   (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE)
 ))
 (assert
  (uInv SZ l_total@)
 )
 (assert
  (has_type (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. r_prefixes@)
   (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE)
 ))
 (assert
  (uInv SZ r_total@)
 )
 (assert
  (has_type tmp%27 USIZE)
 )
 (assert
  (uInv SZ l_len@)
 )
 (assert
  (has_type tmp%28 USIZE)
 )
 (assert
  (uInv SZ r_len@)
 )
 (assert
  (uInv SZ lt@)
 )
 (assert
  (has_type tmp%35 USIZE)
 )
 (assert
  (uInv SZ rl@)
 )
 (assert
  (has_type tmp%36 (TYPE%alloc!vec.Vec. $ USIZE $ TYPE%alloc!alloc.Global.))
 )
 (assert
  (uInv SZ i$11@0)
 )
 (declare-const v$1@1 alloc!vec.Vec<usize./alloc!alloc.Global.>.)
 (declare-const i$11@1 Int)
 ;; precondition not satisfied
 (declare-const %%location_label%%0 Bool)
 ;; possible arithmetic underflow/overflow
 (declare-const %%location_label%%1 Bool)
 ;; invariant not satisfied at end of loop body
 (declare-const %%location_label%%2 Bool)
 ;; invariant not satisfied at end of loop body
 (declare-const %%location_label%%3 Bool)
 ;; invariant not satisfied at end of loop body
 (declare-const %%location_label%%4 Bool)
 ;; invariant not satisfied at end of loop body
 (declare-const %%location_label%%5 Bool)
 ;; invariant not satisfied at end of loop body
 (declare-const %%location_label%%6 Bool)
 ;; invariant not satisfied at end of loop body
 (declare-const %%location_label%%7 Bool)
 ;; decreases not satisfied at end of loop
 (declare-const %%location_label%%8 Bool)
 (assert
  (not (=>
    (= decrease%init0 (%I (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_len.?
       $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE) $ USIZE (
        Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. a!
    ))))
    (=>
     (<= i$11@0 rl@)
     (=>
      (= rl@ (%I (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_len.?
         $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE) $ USIZE (
          Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. r_prefixes@
      ))))
      (=>
       (= (vstd!seq.Seq.len.? $ USIZE (Poly%vstd!seq.Seq<usize.>. r_pv@0)) rl@)
       (=>
        (= (vstd!seq.Seq.len.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ USIZE
            $ TYPE%alloc!alloc.Global.
           ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. v$1@0)
          )
         ) i$11@0
        )
        (=>
         (forall ((j$ Poly)) (!
           (=>
            (has_type j$ INT)
            (=>
             (let
              ((tmp%%$22 0))
              (let
               ((tmp%%$23 (%I j$)))
               (let
                ((tmp%%$24 rl@))
                (and
                 (<= tmp%%$22 tmp%%$23)
                 (< tmp%%$23 tmp%%$24)
             ))))
             (= (vstd!seq.Seq.index.? $ USIZE (Poly%vstd!seq.Seq<usize.>. r_pv@0) j$) (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_index.?
               $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE) $ USIZE (
                Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. r_prefixes@
               ) j$
           ))))
           :pattern ((vstd!seq.Seq.index.? $ USIZE (Poly%vstd!seq.Seq<usize.>. r_pv@0) j$))
           :qid user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_12
           :skolemid skolem_user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_12
         ))
         (=>
          (forall ((j$ Poly)) (!
            (=>
             (has_type j$ INT)
             (=>
              (let
               ((tmp%%$25 0))
               (let
                ((tmp%%$26 (%I j$)))
                (let
                 ((tmp%%$27 i$11@0))
                 (and
                  (<= tmp%%$25 tmp%%$26)
                  (< tmp%%$26 tmp%%$27)
              ))))
              (= (%I (vstd!seq.Seq.index.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ USIZE
                   $ TYPE%alloc!alloc.Global.
                  ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. v$1@0)
                 ) j$
                )
               ) (lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_wrapping_add.? (I lt@) (vstd!seq.Seq.index.?
                 $ USIZE (Poly%vstd!seq.Seq<usize.>. r_pv@0) j$
            )))))
            :pattern ((vstd!seq.Seq.index.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec.
                $ USIZE $ TYPE%alloc!alloc.Global.
               ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. v$1@0)
              ) j$
            ))
            :qid user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_13
            :skolemid skolem_user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_13
          ))
          (=>
           (= decrease%init3%0 (Sub rl@ i$11@0))
           (=>
            (< i$11@0 rl@)
            (=>
             (= tmp%38 lt@)
             (and
              (=>
               %%location_label%%0
               (req%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.nth. $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
                 $ USIZE
                ) $ USIZE (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. r_prefixes@)
                (I i$11@0)
              ))
              (=>
               (ens%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.nth. $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
                 $ USIZE
                ) $ USIZE (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. r_prefixes@)
                (I i$11@0) tmp%37
               )
               (=>
                (ens%core!num.impl&%11.wrapping_add. tmp%38 (%I tmp%37) val@)
                (=>
                 (has_type tmp%39 (MUTREF $ (TYPE%alloc!vec.Vec. $ USIZE $ TYPE%alloc!alloc.Global.)))
                 (=>
                  (= (%Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. (mut_ref_current% tmp%39)) v$1@0)
                  (=>
                   (= tmp%40 tmp%39)
                   (=>
                    (= tmp%41 val@)
                    (=>
                     (= v$1@1 (%Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. (mut_ref_future% tmp%39)))
                     (=>
                      (ens%alloc!vec.impl&%43.push. $ USIZE $ TYPE%alloc!alloc.Global. tmp%40 (I tmp%41))
                      (and
                       (=>
                        %%location_label%%1
                        (uInv SZ (Add i$11@0 1))
                       )
                       (=>
                        (uInv SZ (Add i$11@0 1))
                        (=>
                         (= i$11@1 (uClip SZ (Add i$11@0 1)))
                         (and
                          (=>
                           %%location_label%%2
                           (<= i$11@1 rl@)
                          )
                          (and
                           (=>
                            %%location_label%%3
                            (= rl@ (%I (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_len.?
                               $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE) $ USIZE (
                                Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. r_prefixes@
                           )))))
                           (and
                            (=>
                             %%location_label%%4
                             (= (vstd!seq.Seq.len.? $ USIZE (Poly%vstd!seq.Seq<usize.>. r_pv@0)) rl@)
                            )
                            (and
                             (=>
                              %%location_label%%5
                              (= (vstd!seq.Seq.len.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ USIZE
                                  $ TYPE%alloc!alloc.Global.
                                 ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. v$1@1)
                                )
                               ) i$11@1
                             ))
                             (and
                              (=>
                               %%location_label%%6
                               (forall ((j$ Poly)) (!
                                 (=>
                                  (has_type j$ INT)
                                  (=>
                                   (let
                                    ((tmp%%$22 0))
                                    (let
                                     ((tmp%%$23 (%I j$)))
                                     (let
                                      ((tmp%%$24 rl@))
                                      (and
                                       (<= tmp%%$22 tmp%%$23)
                                       (< tmp%%$23 tmp%%$24)
                                   ))))
                                   (= (vstd!seq.Seq.index.? $ USIZE (Poly%vstd!seq.Seq<usize.>. r_pv@0) j$) (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_index.?
                                     $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE) $ USIZE (
                                      Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. r_prefixes@
                                     ) j$
                                 ))))
                                 :pattern ((vstd!seq.Seq.index.? $ USIZE (Poly%vstd!seq.Seq<usize.>. r_pv@0) j$))
                                 :qid user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_12
                                 :skolemid skolem_user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_12
                              )))
                              (and
                               (=>
                                %%location_label%%7
                                (forall ((j$ Poly)) (!
                                  (=>
                                   (has_type j$ INT)
                                   (=>
                                    (let
                                     ((tmp%%$25 0))
                                     (let
                                      ((tmp%%$26 (%I j$)))
                                      (let
                                       ((tmp%%$27 i$11@1))
                                       (and
                                        (<= tmp%%$25 tmp%%$26)
                                        (< tmp%%$26 tmp%%$27)
                                    ))))
                                    (= (%I (vstd!seq.Seq.index.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ USIZE
                                         $ TYPE%alloc!alloc.Global.
                                        ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. v$1@1)
                                       ) j$
                                      )
                                     ) (lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_wrapping_add.? (I lt@) (vstd!seq.Seq.index.?
                                       $ USIZE (Poly%vstd!seq.Seq<usize.>. r_pv@0) j$
                                  )))))
                                  :pattern ((vstd!seq.Seq.index.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec.
                                      $ USIZE $ TYPE%alloc!alloc.Global.
                                     ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. v$1@1)
                                    ) j$
                                  ))
                                  :qid user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_13
                                  :skolemid skolem_user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_13
                               )))
                               (=>
                                %%location_label%%8
                                (check_decrease_height (I (Sub rl@ i$11@1)) (I decrease%init3%0) false)
 )))))))))))))))))))))))))))))))
 (get-info :all-statistics)
 (get-info :version)
 (set-option :rlimit 30000000)
 (check-sat)
 (set-option :rlimit 0)
 (get-info :all-statistics)
(pop)

;; Function-Def lib::Chap26::ScanDCMtPer::ScanDCMtPer::prefix_sums_dc_inner
;; src/Chap26/ScanDCMtPer.rs:285:9: 285:24 (#925)
(push)
 (get-info :all-statistics)
 (declare-const sums! tuple%2.)
 (declare-const a! lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.)
 (declare-const tmp%1 Poly)
 (declare-const verus_tmp_input@ vstd!seq.Seq<usize.>.)
 (declare-const verus_tmp_spec_f@ %%Function%%)
 (declare-const tmp%2 Poly)
 (declare-const tmp%3 Poly)
 (declare-const tmp%4 Bool)
 (declare-const tmp%5 Bool)
 (declare-const tmp%6 Bool)
 (declare-const tmp%7 Bool)
 (declare-const tmp%8 Bool)
 (declare-const tmp%9 Poly)
 (declare-const total@ Int)
 (declare-const tmp%10 Poly)
 (declare-const tmp%11 Poly)
 (declare-const tmp%12 Poly)
 (declare-const tmp%13 Poly)
 (declare-const tmp%14 Int)
 (declare-const decrease%init0%0 Int)
 (declare-const tmp%15 Poly)
 (declare-const tmp%16 Poly)
 (declare-const tmp%17 Poly)
 (declare-const tmp%18 Poly)
 (declare-const tmp%19 Poly)
 (declare-const tmp%20 Poly)
 (declare-const tmp%21 Int)
 (declare-const decrease%init1%0 Int)
 (declare-const verus_tmp_left_input@ vstd!seq.Seq<usize.>.)
 (declare-const verus_tmp_right_input@ vstd!seq.Seq<usize.>.)
 (declare-const tmp%22 Bool)
 (declare-const tmp%23 Bool)
 (declare-const tmp%24 Bool)
 (declare-const r~1222 tuple%2.)
 (declare-const tmp%25 tuple%2.)
 (declare-const tmp%%7 anonymous_closure%29498.)
 (declare-const r~1325 tuple%2.)
 (declare-const tmp%26 tuple%2.)
 (declare-const tmp%%8 anonymous_closure%29501.)
 (declare-const verus_tmp_l_pref_view@ vstd!seq.Seq<usize.>.)
 (declare-const verus_tmp_r_pref_view@ vstd!seq.Seq<usize.>.)
 (declare-const tmp%27 Poly)
 (declare-const tmp%28 Poly)
 (declare-const verus_tmp_l_pv@ vstd!seq.Seq<usize.>.)
 (declare-const verus_tmp_r_pv@ vstd!seq.Seq<usize.>.)
 (declare-const r~1633 alloc!vec.Vec<usize./alloc!alloc.Global.>.)
 (declare-const tmp%29 Poly)
 (declare-const tmp%30 Poly)
 (declare-const tmp%31 Poly)
 (declare-const tmp%32 Poly)
 (declare-const tmp%33 Poly)
 (declare-const tmp%34 Int)
 (declare-const decrease%init2%0 Int)
 (declare-const ll@ Int)
 (declare-const v@0 alloc!vec.Vec<usize./alloc!alloc.Global.>.)
 (declare-const i$10@0 Int)
 (declare-const tmp%%19 anonymous_closure%29504.)
 (declare-const r~2121 alloc!vec.Vec<usize./alloc!alloc.Global.>.)
 (declare-const tmp%35 Poly)
 (declare-const tmp%36 Poly)
 (declare-const tmp%37 Poly)
 (declare-const tmp%38 Int)
 (declare-const tmp%39 Poly)
 (declare-const tmp%40 Poly)
 (declare-const tmp%41 Int)
 (declare-const val@ Int)
 (declare-const decrease%init3%0 Int)
 (declare-const rl@ Int)
 (declare-const v$1@0 alloc!vec.Vec<usize./alloc!alloc.Global.>.)
 (declare-const i$11@0 Int)
 (declare-const tmp%%29 anonymous_closure%29509.)
 (declare-const tmp%42 Poly)
 (declare-const tmp%43 Poly)
 (declare-const tmp%44 Poly)
 (declare-const tmp%45 Int)
 (declare-const decrease%init4%0 Int)
 (declare-const verus_tmp_result_view@ vstd!seq.Seq<usize.>.)
 (declare-const tmp%46 Bool)
 (declare-const tmp%47 Bool)
 (declare-const tmp%48 Bool)
 (declare-const tmp%49 Bool)
 (declare-const i$14@ Poly)
 (declare-const tmp%50 Bool)
 (declare-const tmp%51 Bool)
 (declare-const tmp%52 Bool)
 (declare-const tmp%53 Bool)
 (declare-const tmp%54 vstd!seq.Seq<usize.>.)
 (declare-const tmp%55 Bool)
 (declare-const tmp%56 Bool)
 (declare-const tmp%57 vstd!seq.Seq<usize.>.)
 (declare-const j@ Int)
 (declare-const rp@ vstd!seq.Seq<usize.>.)
 (declare-const n@ Int)
 (declare-const verus_tmp@0 vstd!seq.Seq<usize.>.)
 (declare-const input@0 vstd!seq.Seq<usize.>.)
 (declare-const verus_tmp$1@0 %%Function%%)
 (declare-const spec_f@0 %%Function%%)
 (declare-const mid@ Int)
 (declare-const left_vec@0 alloc!vec.Vec<usize./alloc!alloc.Global.>.)
 (declare-const i@0 Int)
 (declare-const left@ lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.)
 (declare-const right_len@ Int)
 (declare-const right_vec@0 alloc!vec.Vec<usize./alloc!alloc.Global.>.)
 (declare-const i$1@0 Int)
 (declare-const right@ lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.)
 (declare-const verus_tmp$2@0 vstd!seq.Seq<usize.>.)
 (declare-const left_input@0 vstd!seq.Seq<usize.>.)
 (declare-const verus_tmp$3@0 vstd!seq.Seq<usize.>.)
 (declare-const right_input@0 vstd!seq.Seq<usize.>.)
 (declare-const f1@ anonymous_closure%29498.)
 (declare-const f2@ anonymous_closure%29501.)
 (declare-const tmp%%$6@ tuple%2.)
 (declare-const left_result@ tuple%2.)
 (declare-const right_result@ tuple%2.)
 (declare-const l_prefixes@ lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.)
 (declare-const l_total@ Int)
 (declare-const r_prefixes@ lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.)
 (declare-const r_total@ Int)
 (declare-const verus_tmp$4@0 vstd!seq.Seq<usize.>.)
 (declare-const l_pref_view@0 vstd!seq.Seq<usize.>.)
 (declare-const verus_tmp$5@0 vstd!seq.Seq<usize.>.)
 (declare-const r_pref_view@0 vstd!seq.Seq<usize.>.)
 (declare-const l_len@ Int)
 (declare-const r_len@ Int)
 (declare-const verus_tmp$6@0 vstd!seq.Seq<usize.>.)
 (declare-const l_pv@0 vstd!seq.Seq<usize.>.)
 (declare-const verus_tmp$7@0 vstd!seq.Seq<usize.>.)
 (declare-const r_pv@0 vstd!seq.Seq<usize.>.)
 (declare-const lt@ Int)
 (declare-const copy_left@ anonymous_closure%29504.)
 (declare-const adjust_right@ anonymous_closure%29509.)
 (declare-const tmp%%$31@ tuple%2.)
 (declare-const left_part@ alloc!vec.Vec<usize./alloc!alloc.Global.>.)
 (declare-const right_part@ alloc!vec.Vec<usize./alloc!alloc.Global.>.)
 (declare-const result_vec@0 alloc!vec.Vec<usize./alloc!alloc.Global.>.)
 (declare-const i$12@0 Int)
 (declare-const total$1@ Int)
 (declare-const verus_tmp$8@0 vstd!seq.Seq<usize.>.)
 (declare-const result_view@0 vstd!seq.Seq<usize.>.)
 (declare-const result_prefixes@ lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.)
 (declare-const decrease%init0 Int)
 (assert
  fuel_defaults
 )
 (assert
  (has_type (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. a!) (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
    $ USIZE
 )))
 (assert
  (has_type tmp%1 USIZE)
 )
 (assert
  (uInv SZ n@)
 )
 (assert
  (has_type (Poly%fun%2. verus_tmp$1@0) (TYPE%fun%2. $ USIZE $ USIZE $ USIZE))
 )
 (assert
  (has_type (Poly%fun%2. verus_tmp_spec_f@) (TYPE%fun%2. $ USIZE $ USIZE $ USIZE))
 )
 (assert
  (has_type (Poly%fun%2. spec_f@0) (TYPE%fun%2. $ USIZE $ USIZE $ USIZE))
 )
 (assert
  (uInv SZ mid@)
 )
 (assert
  (has_type tmp%10 (TYPE%alloc!vec.Vec. $ USIZE $ TYPE%alloc!alloc.Global.))
 )
 (assert
  (uInv SZ i@0)
 )
 (assert
  (has_type (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. left@) (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
    $ USIZE
 )))
 (assert
  (uInv SZ right_len@)
 )
 (assert
  (has_type tmp%15 (TYPE%alloc!vec.Vec. $ USIZE $ TYPE%alloc!alloc.Global.))
 )
 (assert
  (uInv SZ i$1@0)
 )
 (assert
  (has_type (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. right@) (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
    $ USIZE
 )))
 (assert
  (has_type (Poly%tuple%2. tmp%%$6@) (TYPE%tuple%2. (DST $) (TYPE%tuple%2. $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
      $ USIZE
     ) $ USIZE
    ) (DST $) (TYPE%tuple%2. $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
      $ USIZE
     ) $ USIZE
 ))))
 (assert
  (has_type (Poly%tuple%2. left_result@) (TYPE%tuple%2. $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
     $ USIZE
    ) $ USIZE
 )))
 (assert
  (has_type (Poly%tuple%2. right_result@) (TYPE%tuple%2. $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
     $ USIZE
    ) $ USIZE
 )))
 (assert
  (has_type (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. l_prefixes@)
   (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE)
 ))
 (assert
  (uInv SZ l_total@)
 )
 (assert
  (has_type (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. r_prefixes@)
   (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE)
 ))
 (assert
  (uInv SZ r_total@)
 )
 (assert
  (has_type tmp%27 USIZE)
 )
 (assert
  (uInv SZ l_len@)
 )
 (assert
  (has_type tmp%28 USIZE)
 )
 (assert
  (uInv SZ r_len@)
 )
 (assert
  (uInv SZ lt@)
 )
 (assert
  (has_type (Poly%tuple%2. tmp%%$31@) (TYPE%tuple%2. $ (TYPE%alloc!vec.Vec. $ USIZE $
     TYPE%alloc!alloc.Global.
    ) $ (TYPE%alloc!vec.Vec. $ USIZE $ TYPE%alloc!alloc.Global.)
 )))
 (assert
  (uInv SZ i$12@0)
 )
 (declare-const result_vec@1 alloc!vec.Vec<usize./alloc!alloc.Global.>.)
 (declare-const i$12@1 Int)
 ;; precondition not satisfied
 (declare-const %%location_label%%0 Bool)
 ;; possible arithmetic underflow/overflow
 (declare-const %%location_label%%1 Bool)
 ;; invariant not satisfied at end of loop body
 (declare-const %%location_label%%2 Bool)
 ;; invariant not satisfied at end of loop body
 (declare-const %%location_label%%3 Bool)
 ;; invariant not satisfied at end of loop body
 (declare-const %%location_label%%4 Bool)
 ;; invariant not satisfied at end of loop body
 (declare-const %%location_label%%5 Bool)
 ;; invariant not satisfied at end of loop body
 (declare-const %%location_label%%6 Bool)
 ;; invariant not satisfied at end of loop body
 (declare-const %%location_label%%7 Bool)
 ;; invariant not satisfied at end of loop body
 (declare-const %%location_label%%8 Bool)
 ;; invariant not satisfied at end of loop body
 (declare-const %%location_label%%9 Bool)
 ;; invariant not satisfied at end of loop body
 (declare-const %%location_label%%10 Bool)
 ;; decreases not satisfied at end of loop
 (declare-const %%location_label%%11 Bool)
 (assert
  (not (=>
    (= decrease%init0 (%I (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_len.?
       $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE) $ USIZE (
        Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. a!
    ))))
    (=>
     (<= i$12@0 r_len@)
     (=>
      (= r_len@ (vstd!seq.Seq.len.? $ USIZE (Poly%vstd!seq.Seq<usize.>. r_pref_view@0)))
      (=>
       (= l_len@ (vstd!seq.Seq.len.? $ USIZE (Poly%vstd!seq.Seq<usize.>. l_pref_view@0)))
       (=>
        (= l_len@ mid@)
        (=>
         (= (vstd!seq.Seq.len.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ USIZE
             $ TYPE%alloc!alloc.Global.
            ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. right_part@)
           )
          ) r_len@
         )
         (=>
          (= (vstd!seq.Seq.len.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ USIZE
              $ TYPE%alloc!alloc.Global.
             ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. result_vec@0)
            )
           ) (Add l_len@ i$12@0)
          )
          (=>
           (forall ((j$ Poly)) (!
             (=>
              (has_type j$ INT)
              (=>
               (let
                ((tmp%%$32 0))
                (let
                 ((tmp%%$33 (%I j$)))
                 (let
                  ((tmp%%$34 r_len@))
                  (and
                   (<= tmp%%$32 tmp%%$33)
                   (< tmp%%$33 tmp%%$34)
               ))))
               (= (%I (vstd!seq.Seq.index.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ USIZE
                    $ TYPE%alloc!alloc.Global.
                   ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. right_part@)
                  ) j$
                 )
                ) (lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_wrapping_add.? (I l_total@) (vstd!seq.Seq.index.?
                  $ USIZE (Poly%vstd!seq.Seq<usize.>. r_pref_view@0) j$
             )))))
             :pattern ((vstd!seq.Seq.index.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec.
                 $ USIZE $ TYPE%alloc!alloc.Global.
                ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. right_part@)
               ) j$
             ))
             :qid user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_18
             :skolemid skolem_user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_18
           ))
           (=>
            (forall ((j$ Poly)) (!
              (=>
               (has_type j$ INT)
               (=>
                (let
                 ((tmp%%$35 0))
                 (let
                  ((tmp%%$36 (%I j$)))
                  (let
                   ((tmp%%$37 l_len@))
                   (and
                    (<= tmp%%$35 tmp%%$36)
                    (< tmp%%$36 tmp%%$37)
                ))))
                (= (vstd!seq.Seq.index.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ USIZE
                    $ TYPE%alloc!alloc.Global.
                   ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. result_vec@0)
                  ) j$
                 ) (vstd!seq.Seq.index.? $ USIZE (Poly%vstd!seq.Seq<usize.>. l_pref_view@0) j$)
              )))
              :pattern ((vstd!seq.Seq.index.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec.
                  $ USIZE $ TYPE%alloc!alloc.Global.
                 ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. result_vec@0)
                ) j$
              ))
              :qid user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_19
              :skolemid skolem_user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_19
            ))
            (=>
             (forall ((j$ Int)) (!
               (=>
                (let
                 ((tmp%%$38 0))
                 (let
                  ((tmp%%$39 j$))
                  (let
                   ((tmp%%$40 i$12@0))
                   (and
                    (<= tmp%%$38 tmp%%$39)
                    (< tmp%%$39 tmp%%$40)
                ))))
                (= (%I (vstd!seq.Seq.index.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ USIZE
                     $ TYPE%alloc!alloc.Global.
                    ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. result_vec@0)
                   ) (I (Add l_len@ j$))
                  )
                 ) (lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_wrapping_add.? (I l_total@) (vstd!seq.Seq.index.?
                   $ USIZE (Poly%vstd!seq.Seq<usize.>. r_pref_view@0) (I j$)
               ))))
               :pattern ((vstd!seq.Seq.index.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec.
                   $ USIZE $ TYPE%alloc!alloc.Global.
                  ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. result_vec@0)
                 ) (I (Add l_len@ j$))
               ))
               :qid user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_20
               :skolemid skolem_user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_20
             ))
             (=>
              (= decrease%init4%0 (Sub r_len@ i$12@0))
              (=>
               (has_resolved $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE)
                (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. left@)
               )
               (=>
                (has_resolved $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE)
                 (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. right@)
                )
                (=>
                 (has_resolved $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE)
                  (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. l_prefixes@)
                 )
                 (=>
                  (has_resolved $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE)
                   (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. r_prefixes@)
                  )
                  (=>
                   (has_resolved $ (TYPE%alloc!vec.Vec. $ USIZE $ TYPE%alloc!alloc.Global.) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>.
                     right_part@
                   ))
                   (=>
                    (< i$12@0 r_len@)
                    (=>
                     (has_type tmp%42 (MUTREF $ (TYPE%alloc!vec.Vec. $ USIZE $ TYPE%alloc!alloc.Global.)))
                     (=>
                      (= (%Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. (mut_ref_current% tmp%42)) result_vec@0)
                      (=>
                       (= tmp%44 tmp%42)
                       (and
                        (=>
                         %%location_label%%0
                         (req%vstd!std_specs.vec.vec_index. $ USIZE $ TYPE%alloc!alloc.Global. (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>.
                           right_part@
                          ) i$12@0
                        ))
                        (=>
                         (ens%vstd!std_specs.vec.vec_index. $ USIZE $ TYPE%alloc!alloc.Global. (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>.
                           right_part@
                          ) i$12@0 tmp%43
                         )
                         (=>
                          (= tmp%45 (%I tmp%43))
                          (=>
                           (= result_vec@1 (%Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. (mut_ref_future% tmp%42)))
                           (=>
                            (ens%alloc!vec.impl&%43.push. $ USIZE $ TYPE%alloc!alloc.Global. tmp%44 (I tmp%45))
                            (and
                             (=>
                              %%location_label%%1
                              (uInv SZ (Add i$12@0 1))
                             )
                             (=>
                              (uInv SZ (Add i$12@0 1))
                              (=>
                               (= i$12@1 (uClip SZ (Add i$12@0 1)))
                               (and
                                (=>
                                 %%location_label%%2
                                 (<= i$12@1 r_len@)
                                )
                                (and
                                 (=>
                                  %%location_label%%3
                                  (= r_len@ (vstd!seq.Seq.len.? $ USIZE (Poly%vstd!seq.Seq<usize.>. r_pref_view@0)))
                                 )
                                 (and
                                  (=>
                                   %%location_label%%4
                                   (= l_len@ (vstd!seq.Seq.len.? $ USIZE (Poly%vstd!seq.Seq<usize.>. l_pref_view@0)))
                                  )
                                  (and
                                   (=>
                                    %%location_label%%5
                                    (= l_len@ mid@)
                                   )
                                   (and
                                    (=>
                                     %%location_label%%6
                                     (= (vstd!seq.Seq.len.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ USIZE
                                         $ TYPE%alloc!alloc.Global.
                                        ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. right_part@)
                                       )
                                      ) r_len@
                                    ))
                                    (and
                                     (=>
                                      %%location_label%%7
                                      (= (vstd!seq.Seq.len.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ USIZE
                                          $ TYPE%alloc!alloc.Global.
                                         ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. result_vec@1)
                                        )
                                       ) (Add l_len@ i$12@1)
                                     ))
                                     (and
                                      (=>
                                       %%location_label%%8
                                       (forall ((j$ Poly)) (!
                                         (=>
                                          (has_type j$ INT)
                                          (=>
                                           (let
                                            ((tmp%%$32 0))
                                            (let
                                             ((tmp%%$33 (%I j$)))
                                             (let
                                              ((tmp%%$34 r_len@))
                                              (and
                                               (<= tmp%%$32 tmp%%$33)
                                               (< tmp%%$33 tmp%%$34)
                                           ))))
                                           (= (%I (vstd!seq.Seq.index.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ USIZE
                                                $ TYPE%alloc!alloc.Global.
                                               ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. right_part@)
                                              ) j$
                                             )
                                            ) (lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_wrapping_add.? (I l_total@) (vstd!seq.Seq.index.?
                                              $ USIZE (Poly%vstd!seq.Seq<usize.>. r_pref_view@0) j$
                                         )))))
                                         :pattern ((vstd!seq.Seq.index.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec.
                                             $ USIZE $ TYPE%alloc!alloc.Global.
                                            ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. right_part@)
                                           ) j$
                                         ))
                                         :qid user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_18
                                         :skolemid skolem_user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_18
                                      )))
                                      (and
                                       (=>
                                        %%location_label%%9
                                        (forall ((j$ Poly)) (!
                                          (=>
                                           (has_type j$ INT)
                                           (=>
                                            (let
                                             ((tmp%%$35 0))
                                             (let
                                              ((tmp%%$36 (%I j$)))
                                              (let
                                               ((tmp%%$37 l_len@))
                                               (and
                                                (<= tmp%%$35 tmp%%$36)
                                                (< tmp%%$36 tmp%%$37)
                                            ))))
                                            (= (vstd!seq.Seq.index.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ USIZE
                                                $ TYPE%alloc!alloc.Global.
                                               ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. result_vec@1)
                                              ) j$
                                             ) (vstd!seq.Seq.index.? $ USIZE (Poly%vstd!seq.Seq<usize.>. l_pref_view@0) j$)
                                          )))
                                          :pattern ((vstd!seq.Seq.index.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec.
                                              $ USIZE $ TYPE%alloc!alloc.Global.
                                             ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. result_vec@1)
                                            ) j$
                                          ))
                                          :qid user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_19
                                          :skolemid skolem_user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_19
                                       )))
                                       (and
                                        (=>
                                         %%location_label%%10
                                         (forall ((j$ Int)) (!
                                           (=>
                                            (let
                                             ((tmp%%$38 0))
                                             (let
                                              ((tmp%%$39 j$))
                                              (let
                                               ((tmp%%$40 i$12@1))
                                               (and
                                                (<= tmp%%$38 tmp%%$39)
                                                (< tmp%%$39 tmp%%$40)
                                            ))))
                                            (= (%I (vstd!seq.Seq.index.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ USIZE
                                                 $ TYPE%alloc!alloc.Global.
                                                ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. result_vec@1)
                                               ) (I (Add l_len@ j$))
                                              )
                                             ) (lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_wrapping_add.? (I l_total@) (vstd!seq.Seq.index.?
                                               $ USIZE (Poly%vstd!seq.Seq<usize.>. r_pref_view@0) (I j$)
                                           ))))
                                           :pattern ((vstd!seq.Seq.index.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec.
                                               $ USIZE $ TYPE%alloc!alloc.Global.
                                              ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. result_vec@1)
                                             ) (I (Add l_len@ j$))
                                           ))
                                           :qid user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_20
                                           :skolemid skolem_user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_20
                                        )))
                                        (=>
                                         %%location_label%%11
                                         (check_decrease_height (I (Sub r_len@ i$12@1)) (I decrease%init4%0) false)
 ))))))))))))))))))))))))))))))))))))))))
 (get-info :all-statistics)
 (get-info :version)
 (set-option :rlimit 30000000)
 (check-sat)
 (set-option :rlimit 0)
 (get-info :all-statistics)
(pop)

;; Function-Def lib::Chap26::ScanDCMtPer::ScanDCMtPer::prefix_sums_dc_inner
;; src/Chap26/ScanDCMtPer.rs:119:5: 119:96 (#0)
(push)
 (get-info :all-statistics)
 (declare-const sums! tuple%2.)
 (declare-const a! lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.)
 (declare-const tmp%1 Poly)
 (declare-const verus_tmp_input@ vstd!seq.Seq<usize.>.)
 (declare-const verus_tmp_spec_f@ %%Function%%)
 (declare-const tmp%2 Poly)
 (declare-const tmp%3 Poly)
 (declare-const tmp%4 Bool)
 (declare-const tmp%5 Bool)
 (declare-const tmp%6 Bool)
 (declare-const tmp%7 Bool)
 (declare-const tmp%8 Bool)
 (declare-const tmp%9 Poly)
 (declare-const total@ Int)
 (declare-const tmp%10 Poly)
 (declare-const tmp%11 Poly)
 (declare-const tmp%12 Poly)
 (declare-const tmp%13 Poly)
 (declare-const tmp%14 Int)
 (declare-const decrease%init0%0 Int)
 (declare-const tmp%15 Poly)
 (declare-const tmp%16 Poly)
 (declare-const tmp%17 Poly)
 (declare-const tmp%18 Poly)
 (declare-const tmp%19 Poly)
 (declare-const tmp%20 Poly)
 (declare-const tmp%21 Int)
 (declare-const decrease%init1%0 Int)
 (declare-const verus_tmp_left_input@ vstd!seq.Seq<usize.>.)
 (declare-const verus_tmp_right_input@ vstd!seq.Seq<usize.>.)
 (declare-const tmp%22 Bool)
 (declare-const tmp%23 Bool)
 (declare-const tmp%24 Bool)
 (declare-const r~1222 tuple%2.)
 (declare-const tmp%25 tuple%2.)
 (declare-const tmp%%7 anonymous_closure%29498.)
 (declare-const r~1325 tuple%2.)
 (declare-const tmp%26 tuple%2.)
 (declare-const tmp%%8 anonymous_closure%29501.)
 (declare-const verus_tmp_l_pref_view@ vstd!seq.Seq<usize.>.)
 (declare-const verus_tmp_r_pref_view@ vstd!seq.Seq<usize.>.)
 (declare-const tmp%27 Poly)
 (declare-const tmp%28 Poly)
 (declare-const verus_tmp_l_pv@ vstd!seq.Seq<usize.>.)
 (declare-const verus_tmp_r_pv@ vstd!seq.Seq<usize.>.)
 (declare-const r~1633 alloc!vec.Vec<usize./alloc!alloc.Global.>.)
 (declare-const tmp%29 Poly)
 (declare-const tmp%30 Poly)
 (declare-const tmp%31 Poly)
 (declare-const tmp%32 Poly)
 (declare-const tmp%33 Poly)
 (declare-const tmp%34 Int)
 (declare-const decrease%init2%0 Int)
 (declare-const ll@ Int)
 (declare-const v@0 alloc!vec.Vec<usize./alloc!alloc.Global.>.)
 (declare-const i$10@0 Int)
 (declare-const tmp%%19 anonymous_closure%29504.)
 (declare-const r~2121 alloc!vec.Vec<usize./alloc!alloc.Global.>.)
 (declare-const tmp%35 Poly)
 (declare-const tmp%36 Poly)
 (declare-const tmp%37 Poly)
 (declare-const tmp%38 Int)
 (declare-const tmp%39 Poly)
 (declare-const tmp%40 Poly)
 (declare-const tmp%41 Int)
 (declare-const val@ Int)
 (declare-const decrease%init3%0 Int)
 (declare-const rl@ Int)
 (declare-const v$1@0 alloc!vec.Vec<usize./alloc!alloc.Global.>.)
 (declare-const i$11@0 Int)
 (declare-const tmp%%29 anonymous_closure%29509.)
 (declare-const tmp%42 Poly)
 (declare-const tmp%43 Poly)
 (declare-const tmp%44 Poly)
 (declare-const tmp%45 Int)
 (declare-const decrease%init4%0 Int)
 (declare-const verus_tmp_result_view@ vstd!seq.Seq<usize.>.)
 (declare-const tmp%46 Bool)
 (declare-const tmp%47 Bool)
 (declare-const tmp%48 Bool)
 (declare-const tmp%49 Bool)
 (declare-const i$14@ Poly)
 (declare-const tmp%50 Bool)
 (declare-const tmp%51 Bool)
 (declare-const tmp%52 Bool)
 (declare-const tmp%53 Bool)
 (declare-const tmp%54 vstd!seq.Seq<usize.>.)
 (declare-const tmp%55 Bool)
 (declare-const tmp%56 Bool)
 (declare-const tmp%57 vstd!seq.Seq<usize.>.)
 (declare-const j@ Int)
 (declare-const rp@ vstd!seq.Seq<usize.>.)
 (declare-const n@ Int)
 (declare-const verus_tmp@0 vstd!seq.Seq<usize.>.)
 (declare-const input@0 vstd!seq.Seq<usize.>.)
 (declare-const verus_tmp$1@0 %%Function%%)
 (declare-const spec_f@0 %%Function%%)
 (declare-const mid@ Int)
 (declare-const left_vec@0 alloc!vec.Vec<usize./alloc!alloc.Global.>.)
 (declare-const i@0 Int)
 (declare-const left@ lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.)
 (declare-const right_len@ Int)
 (declare-const right_vec@0 alloc!vec.Vec<usize./alloc!alloc.Global.>.)
 (declare-const i$1@0 Int)
 (declare-const right@ lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.)
 (declare-const verus_tmp$2@0 vstd!seq.Seq<usize.>.)
 (declare-const left_input@0 vstd!seq.Seq<usize.>.)
 (declare-const verus_tmp$3@0 vstd!seq.Seq<usize.>.)
 (declare-const right_input@0 vstd!seq.Seq<usize.>.)
 (declare-const f1@ anonymous_closure%29498.)
 (declare-const f2@ anonymous_closure%29501.)
 (declare-const tmp%%$6@ tuple%2.)
 (declare-const left_result@ tuple%2.)
 (declare-const right_result@ tuple%2.)
 (declare-const l_prefixes@ lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.)
 (declare-const l_total@ Int)
 (declare-const r_prefixes@ lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.)
 (declare-const r_total@ Int)
 (declare-const verus_tmp$4@0 vstd!seq.Seq<usize.>.)
 (declare-const l_pref_view@0 vstd!seq.Seq<usize.>.)
 (declare-const verus_tmp$5@0 vstd!seq.Seq<usize.>.)
 (declare-const r_pref_view@0 vstd!seq.Seq<usize.>.)
 (declare-const l_len@ Int)
 (declare-const r_len@ Int)
 (declare-const verus_tmp$6@0 vstd!seq.Seq<usize.>.)
 (declare-const l_pv@0 vstd!seq.Seq<usize.>.)
 (declare-const verus_tmp$7@0 vstd!seq.Seq<usize.>.)
 (declare-const r_pv@0 vstd!seq.Seq<usize.>.)
 (declare-const lt@ Int)
 (declare-const copy_left@ anonymous_closure%29504.)
 (declare-const adjust_right@ anonymous_closure%29509.)
 (declare-const tmp%%$31@ tuple%2.)
 (declare-const left_part@ alloc!vec.Vec<usize./alloc!alloc.Global.>.)
 (declare-const right_part@ alloc!vec.Vec<usize./alloc!alloc.Global.>.)
 (declare-const result_vec@0 alloc!vec.Vec<usize./alloc!alloc.Global.>.)
 (declare-const i$12@0 Int)
 (declare-const total$1@ Int)
 (declare-const verus_tmp$8@0 vstd!seq.Seq<usize.>.)
 (declare-const result_view@0 vstd!seq.Seq<usize.>.)
 (declare-const result_prefixes@ lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.)
 (declare-const decrease%init0 Int)
 (assert
  fuel_defaults
 )
 (assert
  (has_type (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. a!) (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
    $ USIZE
 )))
 (assert
  (<= (%I (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_len.? $
     (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE) $ USIZE (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
      a!
    ))
   ) (- (uHi SZ) 1)
 ))
 (declare-const verus_tmp@1 vstd!seq.Seq<usize.>.)
 (declare-const input@1 vstd!seq.Seq<usize.>.)
 (declare-const verus_tmp$1@1 %%Function%%)
 (declare-const spec_f@1 %%Function%%)
 (declare-const left_vec@1 alloc!vec.Vec<usize./alloc!alloc.Global.>.)
 (declare-const i@1 Int)
 (declare-const right_vec@1 alloc!vec.Vec<usize./alloc!alloc.Global.>.)
 (declare-const i$1@1 Int)
 (declare-const verus_tmp$2@1 vstd!seq.Seq<usize.>.)
 (declare-const left_input@1 vstd!seq.Seq<usize.>.)
 (declare-const verus_tmp$3@1 vstd!seq.Seq<usize.>.)
 (declare-const right_input@1 vstd!seq.Seq<usize.>.)
 (declare-const verus_tmp$4@1 vstd!seq.Seq<usize.>.)
 (declare-const l_pref_view@1 vstd!seq.Seq<usize.>.)
 (declare-const verus_tmp$5@1 vstd!seq.Seq<usize.>.)
 (declare-const r_pref_view@1 vstd!seq.Seq<usize.>.)
 (declare-const verus_tmp$6@1 vstd!seq.Seq<usize.>.)
 (declare-const l_pv@1 vstd!seq.Seq<usize.>.)
 (declare-const verus_tmp$7@1 vstd!seq.Seq<usize.>.)
 (declare-const r_pv@1 vstd!seq.Seq<usize.>.)
 (declare-const v@1 alloc!vec.Vec<usize./alloc!alloc.Global.>.)
 (declare-const i$10@1 Int)
 (declare-const v$1@1 alloc!vec.Vec<usize./alloc!alloc.Global.>.)
 (declare-const i$11@1 Int)
 (declare-const result_vec@1 alloc!vec.Vec<usize./alloc!alloc.Global.>.)
 (declare-const i$12@1 Int)
 (declare-const verus_tmp$8@1 vstd!seq.Seq<usize.>.)
 (declare-const result_view@1 vstd!seq.Seq<usize.>.)
 (declare-const %%switch_label%%0 Bool)
 (declare-const %%switch_label%%1 Bool)
 (declare-const %%switch_label%%2 Bool)
 ;; postcondition not satisfied
 (declare-const %%location_label%%0 Bool)
 ;; precondition not satisfied
 (declare-const %%location_label%%1 Bool)
 ;; assertion failed
 (declare-const %%location_label%%2 Bool)
 ;; assertion failed
 (declare-const %%location_label%%3 Bool)
 ;; assertion failed
 (declare-const %%location_label%%4 Bool)
 ;; assertion failed
 (declare-const %%location_label%%5 Bool)
 ;; assertion failed
 (declare-const %%location_label%%6 Bool)
 ;; postcondition not satisfied
 (declare-const %%location_label%%7 Bool)
 ;; possible division by zero
 (declare-const %%location_label%%8 Bool)
 ;; invariant not satisfied before loop
 (declare-const %%location_label%%9 Bool)
 ;; invariant not satisfied before loop
 (declare-const %%location_label%%10 Bool)
 ;; invariant not satisfied before loop
 (declare-const %%location_label%%11 Bool)
 ;; invariant not satisfied before loop
 (declare-const %%location_label%%12 Bool)
 ;; invariant not satisfied before loop
 (declare-const %%location_label%%13 Bool)
 ;; possible arithmetic underflow/overflow
 (declare-const %%location_label%%14 Bool)
 ;; invariant not satisfied before loop
 (declare-const %%location_label%%15 Bool)
 ;; invariant not satisfied before loop
 (declare-const %%location_label%%16 Bool)
 ;; invariant not satisfied before loop
 (declare-const %%location_label%%17 Bool)
 ;; invariant not satisfied before loop
 (declare-const %%location_label%%18 Bool)
 ;; invariant not satisfied before loop
 (declare-const %%location_label%%19 Bool)
 ;; invariant not satisfied before loop
 (declare-const %%location_label%%20 Bool)
 ;; assertion failed
 (declare-const %%location_label%%21 Bool)
 ;; assertion failed
 (declare-const %%location_label%%22 Bool)
 ;; assertion failed
 (declare-const %%location_label%%23 Bool)
 ;; could not prove termination
 (declare-const %%location_label%%24 Bool)
 ;; precondition not satisfied
 (declare-const %%location_label%%25 Bool)
 ;; unable to prove post-condition of closure
 (declare-const %%location_label%%26 Bool)
 ;; could not prove termination
 (declare-const %%location_label%%27 Bool)
 ;; precondition not satisfied
 (declare-const %%location_label%%28 Bool)
 ;; unable to prove post-condition of closure
 (declare-const %%location_label%%29 Bool)
 ;; precondition not satisfied
 (declare-const %%location_label%%30 Bool)
 ;; invariant not satisfied before loop
 (declare-const %%location_label%%31 Bool)
 ;; invariant not satisfied before loop
 (declare-const %%location_label%%32 Bool)
 ;; invariant not satisfied before loop
 (declare-const %%location_label%%33 Bool)
 ;; invariant not satisfied before loop
 (declare-const %%location_label%%34 Bool)
 ;; invariant not satisfied before loop
 (declare-const %%location_label%%35 Bool)
 ;; invariant not satisfied before loop
 (declare-const %%location_label%%36 Bool)
 ;; unable to prove post-condition of closure
 (declare-const %%location_label%%37 Bool)
 ;; unable to prove post-condition of closure
 (declare-const %%location_label%%38 Bool)
 ;; invariant not satisfied before loop
 (declare-const %%location_label%%39 Bool)
 ;; invariant not satisfied before loop
 (declare-const %%location_label%%40 Bool)
 ;; invariant not satisfied before loop
 (declare-const %%location_label%%41 Bool)
 ;; invariant not satisfied before loop
 (declare-const %%location_label%%42 Bool)
 ;; invariant not satisfied before loop
 (declare-const %%location_label%%43 Bool)
 ;; invariant not satisfied before loop
 (declare-const %%location_label%%44 Bool)
 ;; unable to prove post-condition of closure
 (declare-const %%location_label%%45 Bool)
 ;; unable to prove post-condition of closure
 (declare-const %%location_label%%46 Bool)
 ;; precondition not satisfied
 (declare-const %%location_label%%47 Bool)
 ;; invariant not satisfied before loop
 (declare-const %%location_label%%48 Bool)
 ;; invariant not satisfied before loop
 (declare-const %%location_label%%49 Bool)
 ;; invariant not satisfied before loop
 (declare-const %%location_label%%50 Bool)
 ;; invariant not satisfied before loop
 (declare-const %%location_label%%51 Bool)
 ;; invariant not satisfied before loop
 (declare-const %%location_label%%52 Bool)
 ;; invariant not satisfied before loop
 (declare-const %%location_label%%53 Bool)
 ;; invariant not satisfied before loop
 (declare-const %%location_label%%54 Bool)
 ;; invariant not satisfied before loop
 (declare-const %%location_label%%55 Bool)
 ;; invariant not satisfied before loop
 (declare-const %%location_label%%56 Bool)
 ;; assertion failed
 (declare-const %%location_label%%57 Bool)
 ;; assertion failed
 (declare-const %%location_label%%58 Bool)
 ;; assertion failed
 (declare-const %%location_label%%59 Bool)
 ;; assertion failed
 (declare-const %%location_label%%60 Bool)
 ;; precondition not satisfied
 (declare-const %%location_label%%61 Bool)
 ;; precondition not satisfied
 (declare-const %%location_label%%62 Bool)
 ;; assertion failed
 (declare-const %%location_label%%63 Bool)
 ;; assertion failed
 (declare-const %%location_label%%64 Bool)
 ;; assertion failed
 (declare-const %%location_label%%65 Bool)
 ;; assertion failed
 (declare-const %%location_label%%66 Bool)
 ;; precondition not satisfied
 (declare-const %%location_label%%67 Bool)
 ;; assertion failed
 (declare-const %%location_label%%68 Bool)
 ;; assertion failed
 (declare-const %%location_label%%69 Bool)
 ;; precondition not satisfied
 (declare-const %%location_label%%70 Bool)
 ;; assertion failed
 (declare-const %%location_label%%71 Bool)
 ;; postcondition not satisfied
 (declare-const %%location_label%%72 Bool)
 (assert
  (not (=>
    (= decrease%init0 (%I (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_len.?
       $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE) $ USIZE (
        Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. a!
    ))))
    (=>
     (ens%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.length. $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
       $ USIZE
      ) $ USIZE (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. a!) tmp%1
     )
     (=>
      (= n@ (%I tmp%1))
      (=>
       (= verus_tmp@1 (%Poly%vstd!seq.Seq<usize.>. (vstd!seq.Seq.new.? $ USIZE (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_len.?
           $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE) $ USIZE (
            Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. a!
           )
          ) (Poly%fun%1. (mk_fun (%%lambda%%1 $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
              $ USIZE
             ) $ USIZE (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. a!)
       ))))))
       (=>
        (= verus_tmp_input@ verus_tmp@1)
        (=>
         (= input@1 verus_tmp_input@)
         (=>
          (= verus_tmp$1@1 (lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_sum_fn.? (I 0)))
          (=>
           (= verus_tmp_spec_f@ verus_tmp$1@1)
           (=>
            (= spec_f@1 verus_tmp_spec_f@)
            (or
             (and
              (=>
               (= n@ 0)
               (=>
                (ens%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerRedefinableTrait.empty. $
                 (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE) $ USIZE tmp%2
                )
                (=>
                 (= sums! (tuple%2./tuple%2 tmp%2 (I 0)))
                 (=>
                  %%location_label%%0
                  (lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_scan_post.? (vstd!seq.Seq.new.? $ USIZE (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_len.?
                     $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE) $ USIZE (
                      Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. a!
                     )
                    ) (Poly%fun%1. (mk_fun (%%lambda%%1 $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
                        $ USIZE
                       ) $ USIZE (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. a!)
                    )))
                   ) (Poly%fun%2. (lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_sum_fn.? (I 0))) (I 0) (vstd!seq.Seq.new.?
                    $ USIZE (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_len.?
                     $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE) $ USIZE (
                      tuple%2./tuple%2/0 (%Poly%tuple%2. (Poly%tuple%2. sums!))
                     )
                    ) (Poly%fun%1. (mk_fun (%%lambda%%1 $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
                        $ USIZE
                       ) $ USIZE (tuple%2./tuple%2/0 (%Poly%tuple%2. (Poly%tuple%2. sums!)))
                    )))
                   ) (tuple%2./tuple%2/1 (%Poly%tuple%2. (Poly%tuple%2. sums!)))
              )))))
              (=>
               (not (= n@ 0))
               %%switch_label%%2
             ))
             (and
              (not %%switch_label%%2)
              (or
               (and
                (=>
                 (= n@ 1)
                 (and
                  (=>
                   %%location_label%%1
                   (req%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.nth. $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
                     $ USIZE
                    ) $ USIZE (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. a!) (I 0)
                  ))
                  (=>
                   (ens%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.nth. $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
                     $ USIZE
                    ) $ USIZE (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. a!) (I 0)
                    tmp%3
                   )
                   (=>
                    (ens%core!num.impl&%11.wrapping_add. (%I tmp%3) 0 total@)
                    (=>
                     (fuel_bool fuel%vstd!seq_lib.impl&%0.fold_left.)
                     (=>
                      (= tmp%4 (= (vstd!seq.Seq.len.? $ USIZE (Poly%vstd!seq.Seq<usize.>. input@1)) 1))
                      (and
                       (=>
                        %%location_label%%2
                        tmp%4
                       )
                       (=>
                        tmp%4
                        (=>
                         (= tmp%5 (ext_eq false (TYPE%vstd!seq.Seq. $ USIZE) (vstd!seq_lib.impl&%0.drop_last.?
                            $ USIZE (Poly%vstd!seq.Seq<usize.>. input@1)
                           ) (vstd!seq.Seq.empty.? $ USIZE)
                         ))
                         (and
                          (=>
                           %%location_label%%3
                           tmp%5
                          )
                          (=>
                           tmp%5
                           (=>
                            (= tmp%6 (= (%I (vstd!seq_lib.impl&%0.fold_left.? $ USIZE $ USIZE (vstd!seq.Seq.empty.?
                                 $ USIZE
                                ) (I (uClip SZ 0)) (Poly%fun%2. spec_f@1)
                               )
                              ) (uClip SZ 0)
                            ))
                            (and
                             (=>
                              %%location_label%%4
                              tmp%6
                             )
                             (=>
                              tmp%6
                              (=>
                               (= tmp%7 (= (vstd!seq_lib.impl&%0.fold_left.? $ USIZE $ USIZE (Poly%vstd!seq.Seq<usize.>.
                                   input@1
                                  ) (I (uClip SZ 0)) (Poly%fun%2. spec_f@1)
                                 ) (%%apply%%1 spec_f@1 (I (uClip SZ 0)) (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_index.?
                                   $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE) $ USIZE (
                                    Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. a!
                                   ) (I 0)
                               ))))
                               (and
                                (=>
                                 %%location_label%%5
                                 tmp%7
                                )
                                (=>
                                 tmp%7
                                 (=>
                                  (= tmp%8 (ext_eq false (TYPE%vstd!seq.Seq. $ USIZE) (vstd!seq.Seq.subrange.? $ USIZE
                                     (Poly%vstd!seq.Seq<usize.>. input@1) (I 0) (I 0)
                                    ) (vstd!seq.Seq.empty.? $ USIZE)
                                  ))
                                  (and
                                   (=>
                                    %%location_label%%6
                                    tmp%8
                                   )
                                   (=>
                                    tmp%8
                                    (=>
                                     (ens%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerRedefinableTrait.singleton.
                                      $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE) $ USIZE (
                                       I 0
                                      ) tmp%9
                                     )
                                     (=>
                                      (= sums! (tuple%2./tuple%2 tmp%9 (I total@)))
                                      (=>
                                       %%location_label%%7
                                       (lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_scan_post.? (vstd!seq.Seq.new.? $ USIZE (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_len.?
                                          $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE) $ USIZE (
                                           Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. a!
                                          )
                                         ) (Poly%fun%1. (mk_fun (%%lambda%%1 $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
                                             $ USIZE
                                            ) $ USIZE (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. a!)
                                         )))
                                        ) (Poly%fun%2. (lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_sum_fn.? (I 0))) (I 0) (vstd!seq.Seq.new.?
                                         $ USIZE (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_len.?
                                          $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE) $ USIZE (
                                           tuple%2./tuple%2/0 (%Poly%tuple%2. (Poly%tuple%2. sums!))
                                          )
                                         ) (Poly%fun%1. (mk_fun (%%lambda%%1 $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
                                             $ USIZE
                                            ) $ USIZE (tuple%2./tuple%2/0 (%Poly%tuple%2. (Poly%tuple%2. sums!)))
                                         )))
                                        ) (tuple%2./tuple%2/1 (%Poly%tuple%2. (Poly%tuple%2. sums!)))
                ))))))))))))))))))))))))
                (=>
                 (not (= n@ 1))
                 %%switch_label%%1
               ))
               (and
                (not %%switch_label%%1)
                (and
                 (=>
                  %%location_label%%8
                  (not (= 2 0))
                 )
                 (=>
                  (not (= 2 0))
                  (=>
                   (= mid@ (uClip SZ (EucDiv n@ 2)))
                   (=>
                    (ens%alloc!vec.impl&%0.with_capacity. $ USIZE mid@ tmp%10)
                    (=>
                     (= left_vec@0 (%Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. tmp%10))
                     (=>
                      (= i@0 0)
                      (and
                       (=>
                        %%location_label%%9
                        (<= i@0 mid@)
                       )
                       (and
                        (=>
                         %%location_label%%10
                         (<= mid@ n@)
                        )
                        (and
                         (=>
                          %%location_label%%11
                          (= n@ (%I (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_len.?
                             $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE) $ USIZE (
                              Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. a!
                         )))))
                         (and
                          (=>
                           %%location_label%%12
                           (= (vstd!seq.Seq.len.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ USIZE
                               $ TYPE%alloc!alloc.Global.
                              ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. left_vec@0)
                             )
                            ) i@0
                          ))
                          (and
                           (=>
                            %%location_label%%13
                            (forall ((j$ Poly)) (!
                              (=>
                               (has_type j$ INT)
                               (=>
                                (let
                                 ((tmp%%$ 0))
                                 (let
                                  ((tmp%%$1 (%I j$)))
                                  (let
                                   ((tmp%%$2 i@0))
                                   (and
                                    (<= tmp%%$ tmp%%$1)
                                    (< tmp%%$1 tmp%%$2)
                                ))))
                                (= (vstd!seq.Seq.index.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ USIZE
                                    $ TYPE%alloc!alloc.Global.
                                   ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. left_vec@0)
                                  ) j$
                                 ) (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_index.? $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
                                   $ USIZE
                                  ) $ USIZE (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. a!) j$
                              ))))
                              :pattern ((vstd!seq.Seq.index.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec.
                                  $ USIZE $ TYPE%alloc!alloc.Global.
                                 ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. left_vec@0)
                                ) j$
                              ))
                              :qid user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_0
                              :skolemid skolem_user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_0
                           )))
                           (=>
                            (uInv SZ i@1)
                            (=>
                             (<= i@1 mid@)
                             (=>
                              (<= mid@ n@)
                              (=>
                               (= n@ (%I (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_len.?
                                  $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE) $ USIZE (
                                   Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. a!
                               ))))
                               (=>
                                (= (vstd!seq.Seq.len.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ USIZE
                                    $ TYPE%alloc!alloc.Global.
                                   ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. left_vec@1)
                                  )
                                 ) i@1
                                )
                                (=>
                                 (forall ((j$ Poly)) (!
                                   (=>
                                    (has_type j$ INT)
                                    (=>
                                     (let
                                      ((tmp%%$ 0))
                                      (let
                                       ((tmp%%$1 (%I j$)))
                                       (let
                                        ((tmp%%$2 i@1))
                                        (and
                                         (<= tmp%%$ tmp%%$1)
                                         (< tmp%%$1 tmp%%$2)
                                     ))))
                                     (= (vstd!seq.Seq.index.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ USIZE
                                         $ TYPE%alloc!alloc.Global.
                                        ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. left_vec@1)
                                       ) j$
                                      ) (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_index.? $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
                                        $ USIZE
                                       ) $ USIZE (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. a!) j$
                                   ))))
                                   :pattern ((vstd!seq.Seq.index.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec.
                                       $ USIZE $ TYPE%alloc!alloc.Global.
                                      ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. left_vec@1)
                                     ) j$
                                   ))
                                   :qid user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_0
                                   :skolemid skolem_user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_0
                                 ))
                                 (=>
                                  (not (< i@1 mid@))
                                  (=>
                                   (= left@ (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS./ArraySeqMtPerS (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>.
                                      left_vec@1
                                   )))
                                   (=>
                                    (has_resolved $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE)
                                     (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. left@)
                                    )
                                    (and
                                     (=>
                                      %%location_label%%14
                                      (uInv SZ (Sub n@ mid@))
                                     )
                                     (=>
                                      (uInv SZ (Sub n@ mid@))
                                      (=>
                                       (= right_len@ (uClip SZ (Sub n@ mid@)))
                                       (=>
                                        (ens%alloc!vec.impl&%0.with_capacity. $ USIZE right_len@ tmp%15)
                                        (=>
                                         (= right_vec@0 (%Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. tmp%15))
                                         (=>
                                          (= i$1@0 0)
                                          (and
                                           (=>
                                            %%location_label%%15
                                            (<= i$1@0 right_len@)
                                           )
                                           (and
                                            (=>
                                             %%location_label%%16
                                             (= right_len@ (Sub n@ mid@))
                                            )
                                            (and
                                             (=>
                                              %%location_label%%17
                                              (<= mid@ n@)
                                             )
                                             (and
                                              (=>
                                               %%location_label%%18
                                               (= n@ (%I (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_len.?
                                                  $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE) $ USIZE (
                                                   Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. a!
                                              )))))
                                              (and
                                               (=>
                                                %%location_label%%19
                                                (= (vstd!seq.Seq.len.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ USIZE
                                                    $ TYPE%alloc!alloc.Global.
                                                   ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. right_vec@0)
                                                  )
                                                 ) i$1@0
                                               ))
                                               (and
                                                (=>
                                                 %%location_label%%20
                                                 (forall ((j$ Poly)) (!
                                                   (=>
                                                    (has_type j$ INT)
                                                    (=>
                                                     (let
                                                      ((tmp%%$ 0))
                                                      (let
                                                       ((tmp%%$4 (%I j$)))
                                                       (let
                                                        ((tmp%%$5 i$1@0))
                                                        (and
                                                         (<= tmp%%$ tmp%%$4)
                                                         (< tmp%%$4 tmp%%$5)
                                                     ))))
                                                     (= (vstd!seq.Seq.index.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ USIZE
                                                         $ TYPE%alloc!alloc.Global.
                                                        ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. right_vec@0)
                                                       ) j$
                                                      ) (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_index.? $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
                                                        $ USIZE
                                                       ) $ USIZE (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. a!) (I (Add
                                                         mid@ (%I j$)
                                                   ))))))
                                                   :pattern ((vstd!seq.Seq.index.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec.
                                                       $ USIZE $ TYPE%alloc!alloc.Global.
                                                      ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. right_vec@0)
                                                     ) j$
                                                   ))
                                                   :qid user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_1
                                                   :skolemid skolem_user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_1
                                                )))
                                                (=>
                                                 (uInv SZ i$1@1)
                                                 (=>
                                                  (<= i$1@1 right_len@)
                                                  (=>
                                                   (= right_len@ (Sub n@ mid@))
                                                   (=>
                                                    (<= mid@ n@)
                                                    (=>
                                                     (= n@ (%I (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_len.?
                                                        $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE) $ USIZE (
                                                         Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. a!
                                                     ))))
                                                     (=>
                                                      (= (vstd!seq.Seq.len.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ USIZE
                                                          $ TYPE%alloc!alloc.Global.
                                                         ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. right_vec@1)
                                                        )
                                                       ) i$1@1
                                                      )
                                                      (=>
                                                       (forall ((j$ Poly)) (!
                                                         (=>
                                                          (has_type j$ INT)
                                                          (=>
                                                           (let
                                                            ((tmp%%$ 0))
                                                            (let
                                                             ((tmp%%$4 (%I j$)))
                                                             (let
                                                              ((tmp%%$5 i$1@1))
                                                              (and
                                                               (<= tmp%%$ tmp%%$4)
                                                               (< tmp%%$4 tmp%%$5)
                                                           ))))
                                                           (= (vstd!seq.Seq.index.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ USIZE
                                                               $ TYPE%alloc!alloc.Global.
                                                              ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. right_vec@1)
                                                             ) j$
                                                            ) (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_index.? $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
                                                              $ USIZE
                                                             ) $ USIZE (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. a!) (I (Add
                                                               mid@ (%I j$)
                                                         ))))))
                                                         :pattern ((vstd!seq.Seq.index.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec.
                                                             $ USIZE $ TYPE%alloc!alloc.Global.
                                                            ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. right_vec@1)
                                                           ) j$
                                                         ))
                                                         :qid user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_1
                                                         :skolemid skolem_user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_1
                                                       ))
                                                       (=>
                                                        (has_resolved $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE)
                                                         (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. left@)
                                                        )
                                                        (=>
                                                         (not (< i$1@1 right_len@))
                                                         (=>
                                                          (has_resolved $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE)
                                                           (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. left@)
                                                          )
                                                          (=>
                                                           (= right@ (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS./ArraySeqMtPerS (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>.
                                                              right_vec@1
                                                           )))
                                                           (=>
                                                            (has_resolved $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE)
                                                             (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. right@)
                                                            )
                                                            (=>
                                                             (= verus_tmp$2@1 (%Poly%vstd!seq.Seq<usize.>. (vstd!seq.Seq.new.? $ USIZE (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_len.?
                                                                 $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE) $ USIZE (
                                                                  Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. left@
                                                                 )
                                                                ) (Poly%fun%1. (mk_fun (%%lambda%%1 $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
                                                                    $ USIZE
                                                                   ) $ USIZE (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. left@)
                                                             ))))))
                                                             (=>
                                                              (= verus_tmp_left_input@ verus_tmp$2@1)
                                                              (=>
                                                               (= left_input@1 verus_tmp_left_input@)
                                                               (=>
                                                                (= verus_tmp$3@1 (%Poly%vstd!seq.Seq<usize.>. (vstd!seq.Seq.new.? $ USIZE (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_len.?
                                                                    $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE) $ USIZE (
                                                                     Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. right@
                                                                    )
                                                                   ) (Poly%fun%1. (mk_fun (%%lambda%%1 $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
                                                                       $ USIZE
                                                                      ) $ USIZE (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. right@)
                                                                ))))))
                                                                (=>
                                                                 (= verus_tmp_right_input@ verus_tmp$3@1)
                                                                 (=>
                                                                  (= right_input@1 verus_tmp_right_input@)
                                                                  (=>
                                                                   (= tmp%22 (ext_eq false (TYPE%vstd!seq.Seq. $ USIZE) (Poly%vstd!seq.Seq<usize.>. left_input@1)
                                                                     (vstd!seq.Seq.subrange.? $ USIZE (Poly%vstd!seq.Seq<usize.>. input@1) (I 0) (I mid@))
                                                                   ))
                                                                   (and
                                                                    (=>
                                                                     %%location_label%%21
                                                                     tmp%22
                                                                    )
                                                                    (=>
                                                                     tmp%22
                                                                     (=>
                                                                      (= tmp%23 (ext_eq false (TYPE%vstd!seq.Seq. $ USIZE) (Poly%vstd!seq.Seq<usize.>. right_input@1)
                                                                        (vstd!seq.Seq.subrange.? $ USIZE (Poly%vstd!seq.Seq<usize.>. input@1) (I mid@) (I n@))
                                                                      ))
                                                                      (and
                                                                       (=>
                                                                        %%location_label%%22
                                                                        tmp%23
                                                                       )
                                                                       (=>
                                                                        tmp%23
                                                                        (=>
                                                                         (= tmp%24 (ext_eq false (TYPE%vstd!seq.Seq. $ USIZE) (vstd!seq.Seq.add.? $ USIZE (Poly%vstd!seq.Seq<usize.>.
                                                                             left_input@1
                                                                            ) (Poly%vstd!seq.Seq<usize.>. right_input@1)
                                                                           ) (Poly%vstd!seq.Seq<usize.>. input@1)
                                                                         ))
                                                                         (and
                                                                          (=>
                                                                           %%location_label%%23
                                                                           tmp%24
                                                                          )
                                                                          (=>
                                                                           tmp%24
                                                                           (and
                                                                            (and
                                                                             (=>
                                                                              %%location_label%%24
                                                                              (check_decrease_height (let
                                                                                ((a!$0 left@))
                                                                                (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_len.? $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
                                                                                  $ USIZE
                                                                                 ) $ USIZE (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. a!$0)
                                                                                )
                                                                               ) (I decrease%init0) false
                                                                             ))
                                                                             (and
                                                                              (=>
                                                                               %%location_label%%25
                                                                               (req%lib!Chap26.ScanDCMtPer.ScanDCMtPer.prefix_sums_dc_inner. left@)
                                                                              )
                                                                              (=>
                                                                               (ens%lib!Chap26.ScanDCMtPer.ScanDCMtPer.prefix_sums_dc_inner. left@ tmp%25)
                                                                               (=>
                                                                                (= r~1222 tmp%25)
                                                                                (=>
                                                                                 %%location_label%%26
                                                                                 (lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_scan_post.? (Poly%vstd!seq.Seq<usize.>. left_input@1)
                                                                                  (Poly%fun%2. (lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_sum_fn.? (I 0))) (I 0) (vstd!seq.Seq.new.?
                                                                                   $ USIZE (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_len.?
                                                                                    $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE) $ USIZE (
                                                                                     tuple%2./tuple%2/0 (%Poly%tuple%2. (Poly%tuple%2. r~1222))
                                                                                    )
                                                                                   ) (Poly%fun%1. (mk_fun (%%lambda%%1 $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
                                                                                       $ USIZE
                                                                                      ) $ USIZE (tuple%2./tuple%2/0 (%Poly%tuple%2. (Poly%tuple%2. r~1222)))
                                                                                   )))
                                                                                  ) (tuple%2./tuple%2/1 (%Poly%tuple%2. (Poly%tuple%2. r~1222)))
                                                                            ))))))
                                                                            (=>
                                                                             (and
                                                                              (forall ((closure%$ Poly)) (!
                                                                                (=>
                                                                                 (has_type closure%$ TYPE%tuple%0.)
                                                                                 (closure_req TYPE%anonymous_closure%29498. $ TYPE%tuple%0. (Poly%anonymous_closure%29498.
                                                                                   tmp%%7
                                                                                  ) closure%$
                                                                                ))
                                                                                :pattern ((closure_req TYPE%anonymous_closure%29498. $ TYPE%tuple%0. (Poly%anonymous_closure%29498.
                                                                                   tmp%%7
                                                                                  ) closure%$
                                                                                ))
                                                                                :qid user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_2
                                                                                :skolemid skolem_user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_2
                                                                              ))
                                                                              (forall ((closure%$ Poly) (r$ Poly)) (!
                                                                                (=>
                                                                                 (and
                                                                                  (has_type closure%$ TYPE%tuple%0.)
                                                                                  (has_type r$ (TYPE%tuple%2. $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
                                                                                     $ USIZE
                                                                                    ) $ USIZE
                                                                                 )))
                                                                                 (=>
                                                                                  (closure_ens TYPE%anonymous_closure%29498. $ TYPE%tuple%0. (Poly%anonymous_closure%29498.
                                                                                    tmp%%7
                                                                                   ) closure%$ r$
                                                                                  )
                                                                                  (lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_scan_post.? (Poly%vstd!seq.Seq<usize.>. left_input@1)
                                                                                   (Poly%fun%2. (lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_sum_fn.? (I 0))) (I 0) (vstd!seq.Seq.new.?
                                                                                    $ USIZE (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_len.?
                                                                                     $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE) $ USIZE (
                                                                                      tuple%2./tuple%2/0 (%Poly%tuple%2. r$)
                                                                                     )
                                                                                    ) (Poly%fun%1. (mk_fun (%%lambda%%1 $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
                                                                                        $ USIZE
                                                                                       ) $ USIZE (tuple%2./tuple%2/0 (%Poly%tuple%2. r$))
                                                                                    )))
                                                                                   ) (tuple%2./tuple%2/1 (%Poly%tuple%2. r$))
                                                                                )))
                                                                                :pattern ((closure_ens TYPE%anonymous_closure%29498. $ TYPE%tuple%0. (Poly%anonymous_closure%29498.
                                                                                   tmp%%7
                                                                                  ) closure%$ r$
                                                                                ))
                                                                                :qid user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_3
                                                                                :skolemid skolem_user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_3
                                                                             )))
                                                                             (=>
                                                                              (= f1@ tmp%%7)
                                                                              (and
                                                                               (and
                                                                                (=>
                                                                                 %%location_label%%27
                                                                                 (check_decrease_height (let
                                                                                   ((a!$0 right@))
                                                                                   (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_len.? $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
                                                                                     $ USIZE
                                                                                    ) $ USIZE (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. a!$0)
                                                                                   )
                                                                                  ) (I decrease%init0) false
                                                                                ))
                                                                                (and
                                                                                 (=>
                                                                                  %%location_label%%28
                                                                                  (req%lib!Chap26.ScanDCMtPer.ScanDCMtPer.prefix_sums_dc_inner. right@)
                                                                                 )
                                                                                 (=>
                                                                                  (ens%lib!Chap26.ScanDCMtPer.ScanDCMtPer.prefix_sums_dc_inner. right@ tmp%26)
                                                                                  (=>
                                                                                   (= r~1325 tmp%26)
                                                                                   (=>
                                                                                    %%location_label%%29
                                                                                    (lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_scan_post.? (Poly%vstd!seq.Seq<usize.>. right_input@1)
                                                                                     (Poly%fun%2. (lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_sum_fn.? (I 0))) (I 0) (vstd!seq.Seq.new.?
                                                                                      $ USIZE (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_len.?
                                                                                       $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE) $ USIZE (
                                                                                        tuple%2./tuple%2/0 (%Poly%tuple%2. (Poly%tuple%2. r~1325))
                                                                                       )
                                                                                      ) (Poly%fun%1. (mk_fun (%%lambda%%1 $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
                                                                                          $ USIZE
                                                                                         ) $ USIZE (tuple%2./tuple%2/0 (%Poly%tuple%2. (Poly%tuple%2. r~1325)))
                                                                                      )))
                                                                                     ) (tuple%2./tuple%2/1 (%Poly%tuple%2. (Poly%tuple%2. r~1325)))
                                                                               ))))))
                                                                               (=>
                                                                                (and
                                                                                 (forall ((closure%$ Poly)) (!
                                                                                   (=>
                                                                                    (has_type closure%$ TYPE%tuple%0.)
                                                                                    (closure_req TYPE%anonymous_closure%29501. $ TYPE%tuple%0. (Poly%anonymous_closure%29501.
                                                                                      tmp%%8
                                                                                     ) closure%$
                                                                                   ))
                                                                                   :pattern ((closure_req TYPE%anonymous_closure%29501. $ TYPE%tuple%0. (Poly%anonymous_closure%29501.
                                                                                      tmp%%8
                                                                                     ) closure%$
                                                                                   ))
                                                                                   :qid user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_4
                                                                                   :skolemid skolem_user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_4
                                                                                 ))
                                                                                 (forall ((closure%$ Poly) (r$ Poly)) (!
                                                                                   (=>
                                                                                    (and
                                                                                     (has_type closure%$ TYPE%tuple%0.)
                                                                                     (has_type r$ (TYPE%tuple%2. $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
                                                                                        $ USIZE
                                                                                       ) $ USIZE
                                                                                    )))
                                                                                    (=>
                                                                                     (closure_ens TYPE%anonymous_closure%29501. $ TYPE%tuple%0. (Poly%anonymous_closure%29501.
                                                                                       tmp%%8
                                                                                      ) closure%$ r$
                                                                                     )
                                                                                     (lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_scan_post.? (Poly%vstd!seq.Seq<usize.>. right_input@1)
                                                                                      (Poly%fun%2. (lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_sum_fn.? (I 0))) (I 0) (vstd!seq.Seq.new.?
                                                                                       $ USIZE (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_len.?
                                                                                        $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE) $ USIZE (
                                                                                         tuple%2./tuple%2/0 (%Poly%tuple%2. r$)
                                                                                        )
                                                                                       ) (Poly%fun%1. (mk_fun (%%lambda%%1 $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
                                                                                           $ USIZE
                                                                                          ) $ USIZE (tuple%2./tuple%2/0 (%Poly%tuple%2. r$))
                                                                                       )))
                                                                                      ) (tuple%2./tuple%2/1 (%Poly%tuple%2. r$))
                                                                                   )))
                                                                                   :pattern ((closure_ens TYPE%anonymous_closure%29501. $ TYPE%tuple%0. (Poly%anonymous_closure%29501.
                                                                                      tmp%%8
                                                                                     ) closure%$ r$
                                                                                   ))
                                                                                   :qid user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_5
                                                                                   :skolemid skolem_user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_5
                                                                                )))
                                                                                (=>
                                                                                 (= f2@ tmp%%8)
                                                                                 (and
                                                                                  (=>
                                                                                   %%location_label%%30
                                                                                   (req%lib!Chap02.HFSchedulerMtEph.HFSchedulerMtEph.join. (DST $) (TYPE%tuple%2. $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
                                                                                      $ USIZE
                                                                                     ) $ USIZE
                                                                                    ) (DST $) (TYPE%tuple%2. $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
                                                                                      $ USIZE
                                                                                     ) $ USIZE
                                                                                    ) $ TYPE%anonymous_closure%29498. $ TYPE%anonymous_closure%29501. (Poly%anonymous_closure%29498.
                                                                                     f1@
                                                                                    ) (Poly%anonymous_closure%29501. f2@)
                                                                                  ))
                                                                                  (=>
                                                                                   (ens%lib!Chap02.HFSchedulerMtEph.HFSchedulerMtEph.join. (DST $) (TYPE%tuple%2. $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
                                                                                      $ USIZE
                                                                                     ) $ USIZE
                                                                                    ) (DST $) (TYPE%tuple%2. $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
                                                                                      $ USIZE
                                                                                     ) $ USIZE
                                                                                    ) $ TYPE%anonymous_closure%29498. $ TYPE%anonymous_closure%29501. (Poly%anonymous_closure%29498.
                                                                                     f1@
                                                                                    ) (Poly%anonymous_closure%29501. f2@) tmp%%$6@
                                                                                   )
                                                                                   (=>
                                                                                    (= left_result@ (%Poly%tuple%2. (tuple%2./tuple%2/0 (%Poly%tuple%2. (Poly%tuple%2. tmp%%$6@)))))
                                                                                    (=>
                                                                                     (= right_result@ (%Poly%tuple%2. (tuple%2./tuple%2/1 (%Poly%tuple%2. (Poly%tuple%2. tmp%%$6@)))))
                                                                                     (=>
                                                                                      (= l_prefixes@ (%Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. (tuple%2./tuple%2/0
                                                                                         (%Poly%tuple%2. (Poly%tuple%2. left_result@))
                                                                                      )))
                                                                                      (=>
                                                                                       (= l_total@ (%I (tuple%2./tuple%2/1 (%Poly%tuple%2. (Poly%tuple%2. left_result@)))))
                                                                                       (=>
                                                                                        (has_resolved $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE)
                                                                                         (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. l_prefixes@)
                                                                                        )
                                                                                        (=>
                                                                                         (= r_prefixes@ (%Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. (tuple%2./tuple%2/0
                                                                                            (%Poly%tuple%2. (Poly%tuple%2. right_result@))
                                                                                         )))
                                                                                         (=>
                                                                                          (= r_total@ (%I (tuple%2./tuple%2/1 (%Poly%tuple%2. (Poly%tuple%2. right_result@)))))
                                                                                          (=>
                                                                                           (has_resolved $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE)
                                                                                            (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. r_prefixes@)
                                                                                           )
                                                                                           (=>
                                                                                            (= verus_tmp$4@1 (%Poly%vstd!seq.Seq<usize.>. (vstd!seq.Seq.new.? $ USIZE (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_len.?
                                                                                                $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE) $ USIZE (
                                                                                                 Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. l_prefixes@
                                                                                                )
                                                                                               ) (Poly%fun%1. (mk_fun (%%lambda%%1 $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
                                                                                                   $ USIZE
                                                                                                  ) $ USIZE (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. l_prefixes@)
                                                                                            ))))))
                                                                                            (=>
                                                                                             (= verus_tmp_l_pref_view@ verus_tmp$4@1)
                                                                                             (=>
                                                                                              (= l_pref_view@1 verus_tmp_l_pref_view@)
                                                                                              (=>
                                                                                               (= verus_tmp$5@1 (%Poly%vstd!seq.Seq<usize.>. (vstd!seq.Seq.new.? $ USIZE (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_len.?
                                                                                                   $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE) $ USIZE (
                                                                                                    Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. r_prefixes@
                                                                                                   )
                                                                                                  ) (Poly%fun%1. (mk_fun (%%lambda%%1 $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
                                                                                                      $ USIZE
                                                                                                     ) $ USIZE (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. r_prefixes@)
                                                                                               ))))))
                                                                                               (=>
                                                                                                (= verus_tmp_r_pref_view@ verus_tmp$5@1)
                                                                                                (=>
                                                                                                 (= r_pref_view@1 verus_tmp_r_pref_view@)
                                                                                                 (=>
                                                                                                  (ens%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.length. $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
                                                                                                    $ USIZE
                                                                                                   ) $ USIZE (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. l_prefixes@)
                                                                                                   tmp%27
                                                                                                  )
                                                                                                  (=>
                                                                                                   (= l_len@ (%I tmp%27))
                                                                                                   (=>
                                                                                                    (ens%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.length. $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
                                                                                                      $ USIZE
                                                                                                     ) $ USIZE (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. r_prefixes@)
                                                                                                     tmp%28
                                                                                                    )
                                                                                                    (=>
                                                                                                     (= r_len@ (%I tmp%28))
                                                                                                     (=>
                                                                                                      (= verus_tmp$6@1 l_pref_view@1)
                                                                                                      (=>
                                                                                                       (= verus_tmp_l_pv@ verus_tmp$6@1)
                                                                                                       (=>
                                                                                                        (= l_pv@1 verus_tmp_l_pv@)
                                                                                                        (=>
                                                                                                         (= verus_tmp$7@1 r_pref_view@1)
                                                                                                         (=>
                                                                                                          (= verus_tmp_r_pv@ verus_tmp$7@1)
                                                                                                          (=>
                                                                                                           (= r_pv@1 verus_tmp_r_pv@)
                                                                                                           (=>
                                                                                                            (= lt@ l_total@)
                                                                                                            (and
                                                                                                             (=>
                                                                                                              (ens%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.length. $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
                                                                                                                $ USIZE
                                                                                                               ) $ USIZE (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. l_prefixes@)
                                                                                                               tmp%29
                                                                                                              )
                                                                                                              (=>
                                                                                                               (= ll@ (%I tmp%29))
                                                                                                               (=>
                                                                                                                (ens%alloc!vec.impl&%0.with_capacity. $ USIZE ll@ tmp%30)
                                                                                                                (=>
                                                                                                                 (= v@0 (%Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. tmp%30))
                                                                                                                 (=>
                                                                                                                  (= i$10@0 0)
                                                                                                                  (and
                                                                                                                   (=>
                                                                                                                    %%location_label%%31
                                                                                                                    (<= i$10@0 ll@)
                                                                                                                   )
                                                                                                                   (and
                                                                                                                    (=>
                                                                                                                     %%location_label%%32
                                                                                                                     (= ll@ (%I (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_len.?
                                                                                                                        $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE) $ USIZE (
                                                                                                                         Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. l_prefixes@
                                                                                                                    )))))
                                                                                                                    (and
                                                                                                                     (=>
                                                                                                                      %%location_label%%33
                                                                                                                      (= (vstd!seq.Seq.len.? $ USIZE (Poly%vstd!seq.Seq<usize.>. l_pv@1)) ll@)
                                                                                                                     )
                                                                                                                     (and
                                                                                                                      (=>
                                                                                                                       %%location_label%%34
                                                                                                                       (= (vstd!seq.Seq.len.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ USIZE
                                                                                                                           $ TYPE%alloc!alloc.Global.
                                                                                                                          ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. v@0)
                                                                                                                         )
                                                                                                                        ) i$10@0
                                                                                                                      ))
                                                                                                                      (and
                                                                                                                       (=>
                                                                                                                        %%location_label%%35
                                                                                                                        (forall ((j$ Poly)) (!
                                                                                                                          (=>
                                                                                                                           (has_type j$ INT)
                                                                                                                           (=>
                                                                                                                            (let
                                                                                                                             ((tmp%%$10 0))
                                                                                                                             (let
                                                                                                                              ((tmp%%$11 (%I j$)))
                                                                                                                              (let
                                                                                                                               ((tmp%%$12 ll@))
                                                                                                                               (and
                                                                                                                                (<= tmp%%$10 tmp%%$11)
                                                                                                                                (< tmp%%$11 tmp%%$12)
                                                                                                                            ))))
                                                                                                                            (= (vstd!seq.Seq.index.? $ USIZE (Poly%vstd!seq.Seq<usize.>. l_pv@1) j$) (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_index.?
                                                                                                                              $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE) $ USIZE (
                                                                                                                               Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. l_prefixes@
                                                                                                                              ) j$
                                                                                                                          ))))
                                                                                                                          :pattern ((vstd!seq.Seq.index.? $ USIZE (Poly%vstd!seq.Seq<usize.>. l_pv@1) j$))
                                                                                                                          :qid user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_6
                                                                                                                          :skolemid skolem_user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_6
                                                                                                                       )))
                                                                                                                       (and
                                                                                                                        (=>
                                                                                                                         %%location_label%%36
                                                                                                                         (forall ((j$ Poly)) (!
                                                                                                                           (=>
                                                                                                                            (has_type j$ INT)
                                                                                                                            (=>
                                                                                                                             (let
                                                                                                                              ((tmp%%$13 0))
                                                                                                                              (let
                                                                                                                               ((tmp%%$14 (%I j$)))
                                                                                                                               (let
                                                                                                                                ((tmp%%$15 i$10@0))
                                                                                                                                (and
                                                                                                                                 (<= tmp%%$13 tmp%%$14)
                                                                                                                                 (< tmp%%$14 tmp%%$15)
                                                                                                                             ))))
                                                                                                                             (= (vstd!seq.Seq.index.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ USIZE
                                                                                                                                 $ TYPE%alloc!alloc.Global.
                                                                                                                                ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. v@0)
                                                                                                                               ) j$
                                                                                                                              ) (vstd!seq.Seq.index.? $ USIZE (Poly%vstd!seq.Seq<usize.>. l_pv@1) j$)
                                                                                                                           )))
                                                                                                                           :pattern ((vstd!seq.Seq.index.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec.
                                                                                                                               $ USIZE $ TYPE%alloc!alloc.Global.
                                                                                                                              ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. v@0)
                                                                                                                             ) j$
                                                                                                                           ))
                                                                                                                           :qid user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_7
                                                                                                                           :skolemid skolem_user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_7
                                                                                                                        )))
                                                                                                                        (=>
                                                                                                                         (uInv SZ i$10@1)
                                                                                                                         (=>
                                                                                                                          (<= i$10@1 ll@)
                                                                                                                          (=>
                                                                                                                           (= ll@ (%I (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_len.?
                                                                                                                              $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE) $ USIZE (
                                                                                                                               Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. l_prefixes@
                                                                                                                           ))))
                                                                                                                           (=>
                                                                                                                            (= (vstd!seq.Seq.len.? $ USIZE (Poly%vstd!seq.Seq<usize.>. l_pv@1)) ll@)
                                                                                                                            (=>
                                                                                                                             (= (vstd!seq.Seq.len.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ USIZE
                                                                                                                                 $ TYPE%alloc!alloc.Global.
                                                                                                                                ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. v@1)
                                                                                                                               )
                                                                                                                              ) i$10@1
                                                                                                                             )
                                                                                                                             (=>
                                                                                                                              (forall ((j$ Poly)) (!
                                                                                                                                (=>
                                                                                                                                 (has_type j$ INT)
                                                                                                                                 (=>
                                                                                                                                  (let
                                                                                                                                   ((tmp%%$10 0))
                                                                                                                                   (let
                                                                                                                                    ((tmp%%$11 (%I j$)))
                                                                                                                                    (let
                                                                                                                                     ((tmp%%$12 ll@))
                                                                                                                                     (and
                                                                                                                                      (<= tmp%%$10 tmp%%$11)
                                                                                                                                      (< tmp%%$11 tmp%%$12)
                                                                                                                                  ))))
                                                                                                                                  (= (vstd!seq.Seq.index.? $ USIZE (Poly%vstd!seq.Seq<usize.>. l_pv@1) j$) (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_index.?
                                                                                                                                    $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE) $ USIZE (
                                                                                                                                     Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. l_prefixes@
                                                                                                                                    ) j$
                                                                                                                                ))))
                                                                                                                                :pattern ((vstd!seq.Seq.index.? $ USIZE (Poly%vstd!seq.Seq<usize.>. l_pv@1) j$))
                                                                                                                                :qid user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_6
                                                                                                                                :skolemid skolem_user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_6
                                                                                                                              ))
                                                                                                                              (=>
                                                                                                                               (forall ((j$ Poly)) (!
                                                                                                                                 (=>
                                                                                                                                  (has_type j$ INT)
                                                                                                                                  (=>
                                                                                                                                   (let
                                                                                                                                    ((tmp%%$13 0))
                                                                                                                                    (let
                                                                                                                                     ((tmp%%$14 (%I j$)))
                                                                                                                                     (let
                                                                                                                                      ((tmp%%$15 i$10@1))
                                                                                                                                      (and
                                                                                                                                       (<= tmp%%$13 tmp%%$14)
                                                                                                                                       (< tmp%%$14 tmp%%$15)
                                                                                                                                   ))))
                                                                                                                                   (= (vstd!seq.Seq.index.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ USIZE
                                                                                                                                       $ TYPE%alloc!alloc.Global.
                                                                                                                                      ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. v@1)
                                                                                                                                     ) j$
                                                                                                                                    ) (vstd!seq.Seq.index.? $ USIZE (Poly%vstd!seq.Seq<usize.>. l_pv@1) j$)
                                                                                                                                 )))
                                                                                                                                 :pattern ((vstd!seq.Seq.index.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec.
                                                                                                                                     $ USIZE $ TYPE%alloc!alloc.Global.
                                                                                                                                    ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. v@1)
                                                                                                                                   ) j$
                                                                                                                                 ))
                                                                                                                                 :qid user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_7
                                                                                                                                 :skolemid skolem_user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_7
                                                                                                                               ))
                                                                                                                               (=>
                                                                                                                                (not (< i$10@1 ll@))
                                                                                                                                (=>
                                                                                                                                 (= r~1633 v@1)
                                                                                                                                 (and
                                                                                                                                  (=>
                                                                                                                                   %%location_label%%37
                                                                                                                                   (= (vstd!seq.Seq.len.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ USIZE
                                                                                                                                       $ TYPE%alloc!alloc.Global.
                                                                                                                                      ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. r~1633)
                                                                                                                                     )
                                                                                                                                    ) (vstd!seq.Seq.len.? $ USIZE (Poly%vstd!seq.Seq<usize.>. l_pv@1))
                                                                                                                                  ))
                                                                                                                                  (=>
                                                                                                                                   %%location_label%%38
                                                                                                                                   (forall ((j$ Poly)) (!
                                                                                                                                     (=>
                                                                                                                                      (has_type j$ INT)
                                                                                                                                      (=>
                                                                                                                                       (let
                                                                                                                                        ((tmp%%$7 0))
                                                                                                                                        (let
                                                                                                                                         ((tmp%%$8 (%I j$)))
                                                                                                                                         (let
                                                                                                                                          ((tmp%%$9 (vstd!seq.Seq.len.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $
                                                                                                                                               USIZE $ TYPE%alloc!alloc.Global.
                                                                                                                                              ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. r~1633)
                                                                                                                                          ))))
                                                                                                                                          (and
                                                                                                                                           (<= tmp%%$7 tmp%%$8)
                                                                                                                                           (< tmp%%$8 tmp%%$9)
                                                                                                                                       ))))
                                                                                                                                       (= (vstd!seq.Seq.index.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ USIZE
                                                                                                                                           $ TYPE%alloc!alloc.Global.
                                                                                                                                          ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. r~1633)
                                                                                                                                         ) j$
                                                                                                                                        ) (vstd!seq.Seq.index.? $ USIZE (Poly%vstd!seq.Seq<usize.>. l_pv@1) j$)
                                                                                                                                     )))
                                                                                                                                     :pattern ((vstd!seq.Seq.index.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec.
                                                                                                                                         $ USIZE $ TYPE%alloc!alloc.Global.
                                                                                                                                        ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. r~1633)
                                                                                                                                       ) j$
                                                                                                                                     ))
                                                                                                                                     :qid user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_8
                                                                                                                                     :skolemid skolem_user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_8
                                                                                                             ))))))))))))))))))))))))
                                                                                                             (=>
                                                                                                              (and
                                                                                                               (forall ((closure%$ Poly)) (!
                                                                                                                 (=>
                                                                                                                  (has_type closure%$ TYPE%tuple%0.)
                                                                                                                  (closure_req TYPE%anonymous_closure%29504. $ TYPE%tuple%0. (Poly%anonymous_closure%29504.
                                                                                                                    tmp%%19
                                                                                                                   ) closure%$
                                                                                                                 ))
                                                                                                                 :pattern ((closure_req TYPE%anonymous_closure%29504. $ TYPE%tuple%0. (Poly%anonymous_closure%29504.
                                                                                                                    tmp%%19
                                                                                                                   ) closure%$
                                                                                                                 ))
                                                                                                                 :qid user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_9
                                                                                                                 :skolemid skolem_user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_9
                                                                                                               ))
                                                                                                               (forall ((closure%$ Poly) (r$ Poly)) (!
                                                                                                                 (=>
                                                                                                                  (and
                                                                                                                   (has_type closure%$ TYPE%tuple%0.)
                                                                                                                   (has_type r$ (TYPE%alloc!vec.Vec. $ USIZE $ TYPE%alloc!alloc.Global.))
                                                                                                                  )
                                                                                                                  (=>
                                                                                                                   (closure_ens TYPE%anonymous_closure%29504. $ TYPE%tuple%0. (Poly%anonymous_closure%29504.
                                                                                                                     tmp%%19
                                                                                                                    ) closure%$ r$
                                                                                                                   )
                                                                                                                   (and
                                                                                                                    (= (vstd!seq.Seq.len.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ USIZE
                                                                                                                        $ TYPE%alloc!alloc.Global.
                                                                                                                       ) r$
                                                                                                                      )
                                                                                                                     ) (vstd!seq.Seq.len.? $ USIZE (Poly%vstd!seq.Seq<usize.>. l_pv@1))
                                                                                                                    )
                                                                                                                    (forall ((j$ Poly)) (!
                                                                                                                      (=>
                                                                                                                       (has_type j$ INT)
                                                                                                                       (=>
                                                                                                                        (let
                                                                                                                         ((tmp%%$16 0))
                                                                                                                         (let
                                                                                                                          ((tmp%%$17 (%I j$)))
                                                                                                                          (let
                                                                                                                           ((tmp%%$18 (vstd!seq.Seq.len.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $
                                                                                                                                USIZE $ TYPE%alloc!alloc.Global.
                                                                                                                               ) r$
                                                                                                                           ))))
                                                                                                                           (and
                                                                                                                            (<= tmp%%$16 tmp%%$17)
                                                                                                                            (< tmp%%$17 tmp%%$18)
                                                                                                                        ))))
                                                                                                                        (= (vstd!seq.Seq.index.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ USIZE
                                                                                                                            $ TYPE%alloc!alloc.Global.
                                                                                                                           ) r$
                                                                                                                          ) j$
                                                                                                                         ) (vstd!seq.Seq.index.? $ USIZE (Poly%vstd!seq.Seq<usize.>. l_pv@1) j$)
                                                                                                                      )))
                                                                                                                      :pattern ((vstd!seq.Seq.index.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec.
                                                                                                                          $ USIZE $ TYPE%alloc!alloc.Global.
                                                                                                                         ) r$
                                                                                                                        ) j$
                                                                                                                      ))
                                                                                                                      :qid user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_10
                                                                                                                      :skolemid skolem_user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_10
                                                                                                                 )))))
                                                                                                                 :pattern ((closure_ens TYPE%anonymous_closure%29504. $ TYPE%tuple%0. (Poly%anonymous_closure%29504.
                                                                                                                    tmp%%19
                                                                                                                   ) closure%$ r$
                                                                                                                 ))
                                                                                                                 :qid user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_11
                                                                                                                 :skolemid skolem_user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_11
                                                                                                              )))
                                                                                                              (=>
                                                                                                               (= copy_left@ tmp%%19)
                                                                                                               (and
                                                                                                                (=>
                                                                                                                 (ens%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.length. $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
                                                                                                                   $ USIZE
                                                                                                                  ) $ USIZE (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. r_prefixes@)
                                                                                                                  tmp%35
                                                                                                                 )
                                                                                                                 (=>
                                                                                                                  (= rl@ (%I tmp%35))
                                                                                                                  (=>
                                                                                                                   (ens%alloc!vec.impl&%0.with_capacity. $ USIZE rl@ tmp%36)
                                                                                                                   (=>
                                                                                                                    (= v$1@0 (%Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. tmp%36))
                                                                                                                    (=>
                                                                                                                     (= i$11@0 0)
                                                                                                                     (and
                                                                                                                      (=>
                                                                                                                       %%location_label%%39
                                                                                                                       (<= i$11@0 rl@)
                                                                                                                      )
                                                                                                                      (and
                                                                                                                       (=>
                                                                                                                        %%location_label%%40
                                                                                                                        (= rl@ (%I (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_len.?
                                                                                                                           $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE) $ USIZE (
                                                                                                                            Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. r_prefixes@
                                                                                                                       )))))
                                                                                                                       (and
                                                                                                                        (=>
                                                                                                                         %%location_label%%41
                                                                                                                         (= (vstd!seq.Seq.len.? $ USIZE (Poly%vstd!seq.Seq<usize.>. r_pv@1)) rl@)
                                                                                                                        )
                                                                                                                        (and
                                                                                                                         (=>
                                                                                                                          %%location_label%%42
                                                                                                                          (= (vstd!seq.Seq.len.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ USIZE
                                                                                                                              $ TYPE%alloc!alloc.Global.
                                                                                                                             ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. v$1@0)
                                                                                                                            )
                                                                                                                           ) i$11@0
                                                                                                                         ))
                                                                                                                         (and
                                                                                                                          (=>
                                                                                                                           %%location_label%%43
                                                                                                                           (forall ((j$ Poly)) (!
                                                                                                                             (=>
                                                                                                                              (has_type j$ INT)
                                                                                                                              (=>
                                                                                                                               (let
                                                                                                                                ((tmp%%$22 0))
                                                                                                                                (let
                                                                                                                                 ((tmp%%$23 (%I j$)))
                                                                                                                                 (let
                                                                                                                                  ((tmp%%$24 rl@))
                                                                                                                                  (and
                                                                                                                                   (<= tmp%%$22 tmp%%$23)
                                                                                                                                   (< tmp%%$23 tmp%%$24)
                                                                                                                               ))))
                                                                                                                               (= (vstd!seq.Seq.index.? $ USIZE (Poly%vstd!seq.Seq<usize.>. r_pv@1) j$) (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_index.?
                                                                                                                                 $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE) $ USIZE (
                                                                                                                                  Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. r_prefixes@
                                                                                                                                 ) j$
                                                                                                                             ))))
                                                                                                                             :pattern ((vstd!seq.Seq.index.? $ USIZE (Poly%vstd!seq.Seq<usize.>. r_pv@1) j$))
                                                                                                                             :qid user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_12
                                                                                                                             :skolemid skolem_user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_12
                                                                                                                          )))
                                                                                                                          (and
                                                                                                                           (=>
                                                                                                                            %%location_label%%44
                                                                                                                            (forall ((j$ Poly)) (!
                                                                                                                              (=>
                                                                                                                               (has_type j$ INT)
                                                                                                                               (=>
                                                                                                                                (let
                                                                                                                                 ((tmp%%$25 0))
                                                                                                                                 (let
                                                                                                                                  ((tmp%%$26 (%I j$)))
                                                                                                                                  (let
                                                                                                                                   ((tmp%%$27 i$11@0))
                                                                                                                                   (and
                                                                                                                                    (<= tmp%%$25 tmp%%$26)
                                                                                                                                    (< tmp%%$26 tmp%%$27)
                                                                                                                                ))))
                                                                                                                                (= (%I (vstd!seq.Seq.index.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ USIZE
                                                                                                                                     $ TYPE%alloc!alloc.Global.
                                                                                                                                    ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. v$1@0)
                                                                                                                                   ) j$
                                                                                                                                  )
                                                                                                                                 ) (lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_wrapping_add.? (I lt@) (vstd!seq.Seq.index.?
                                                                                                                                   $ USIZE (Poly%vstd!seq.Seq<usize.>. r_pv@1) j$
                                                                                                                              )))))
                                                                                                                              :pattern ((vstd!seq.Seq.index.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec.
                                                                                                                                  $ USIZE $ TYPE%alloc!alloc.Global.
                                                                                                                                 ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. v$1@0)
                                                                                                                                ) j$
                                                                                                                              ))
                                                                                                                              :qid user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_13
                                                                                                                              :skolemid skolem_user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_13
                                                                                                                           )))
                                                                                                                           (=>
                                                                                                                            (uInv SZ i$11@1)
                                                                                                                            (=>
                                                                                                                             (<= i$11@1 rl@)
                                                                                                                             (=>
                                                                                                                              (= rl@ (%I (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_len.?
                                                                                                                                 $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE) $ USIZE (
                                                                                                                                  Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. r_prefixes@
                                                                                                                              ))))
                                                                                                                              (=>
                                                                                                                               (= (vstd!seq.Seq.len.? $ USIZE (Poly%vstd!seq.Seq<usize.>. r_pv@1)) rl@)
                                                                                                                               (=>
                                                                                                                                (= (vstd!seq.Seq.len.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ USIZE
                                                                                                                                    $ TYPE%alloc!alloc.Global.
                                                                                                                                   ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. v$1@1)
                                                                                                                                  )
                                                                                                                                 ) i$11@1
                                                                                                                                )
                                                                                                                                (=>
                                                                                                                                 (forall ((j$ Poly)) (!
                                                                                                                                   (=>
                                                                                                                                    (has_type j$ INT)
                                                                                                                                    (=>
                                                                                                                                     (let
                                                                                                                                      ((tmp%%$22 0))
                                                                                                                                      (let
                                                                                                                                       ((tmp%%$23 (%I j$)))
                                                                                                                                       (let
                                                                                                                                        ((tmp%%$24 rl@))
                                                                                                                                        (and
                                                                                                                                         (<= tmp%%$22 tmp%%$23)
                                                                                                                                         (< tmp%%$23 tmp%%$24)
                                                                                                                                     ))))
                                                                                                                                     (= (vstd!seq.Seq.index.? $ USIZE (Poly%vstd!seq.Seq<usize.>. r_pv@1) j$) (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_index.?
                                                                                                                                       $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE) $ USIZE (
                                                                                                                                        Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. r_prefixes@
                                                                                                                                       ) j$
                                                                                                                                   ))))
                                                                                                                                   :pattern ((vstd!seq.Seq.index.? $ USIZE (Poly%vstd!seq.Seq<usize.>. r_pv@1) j$))
                                                                                                                                   :qid user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_12
                                                                                                                                   :skolemid skolem_user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_12
                                                                                                                                 ))
                                                                                                                                 (=>
                                                                                                                                  (forall ((j$ Poly)) (!
                                                                                                                                    (=>
                                                                                                                                     (has_type j$ INT)
                                                                                                                                     (=>
                                                                                                                                      (let
                                                                                                                                       ((tmp%%$25 0))
                                                                                                                                       (let
                                                                                                                                        ((tmp%%$26 (%I j$)))
                                                                                                                                        (let
                                                                                                                                         ((tmp%%$27 i$11@1))
                                                                                                                                         (and
                                                                                                                                          (<= tmp%%$25 tmp%%$26)
                                                                                                                                          (< tmp%%$26 tmp%%$27)
                                                                                                                                      ))))
                                                                                                                                      (= (%I (vstd!seq.Seq.index.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ USIZE
                                                                                                                                           $ TYPE%alloc!alloc.Global.
                                                                                                                                          ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. v$1@1)
                                                                                                                                         ) j$
                                                                                                                                        )
                                                                                                                                       ) (lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_wrapping_add.? (I lt@) (vstd!seq.Seq.index.?
                                                                                                                                         $ USIZE (Poly%vstd!seq.Seq<usize.>. r_pv@1) j$
                                                                                                                                    )))))
                                                                                                                                    :pattern ((vstd!seq.Seq.index.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec.
                                                                                                                                        $ USIZE $ TYPE%alloc!alloc.Global.
                                                                                                                                       ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. v$1@1)
                                                                                                                                      ) j$
                                                                                                                                    ))
                                                                                                                                    :qid user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_13
                                                                                                                                    :skolemid skolem_user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_13
                                                                                                                                  ))
                                                                                                                                  (=>
                                                                                                                                   (not (< i$11@1 rl@))
                                                                                                                                   (=>
                                                                                                                                    (= r~2121 v$1@1)
                                                                                                                                    (and
                                                                                                                                     (=>
                                                                                                                                      %%location_label%%45
                                                                                                                                      (= (vstd!seq.Seq.len.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ USIZE
                                                                                                                                          $ TYPE%alloc!alloc.Global.
                                                                                                                                         ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. r~2121)
                                                                                                                                        )
                                                                                                                                       ) (vstd!seq.Seq.len.? $ USIZE (Poly%vstd!seq.Seq<usize.>. r_pv@1))
                                                                                                                                     ))
                                                                                                                                     (=>
                                                                                                                                      %%location_label%%46
                                                                                                                                      (forall ((j$ Poly)) (!
                                                                                                                                        (=>
                                                                                                                                         (has_type j$ INT)
                                                                                                                                         (=>
                                                                                                                                          (let
                                                                                                                                           ((tmp%%$19 0))
                                                                                                                                           (let
                                                                                                                                            ((tmp%%$20 (%I j$)))
                                                                                                                                            (let
                                                                                                                                             ((tmp%%$21 (vstd!seq.Seq.len.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $
                                                                                                                                                  USIZE $ TYPE%alloc!alloc.Global.
                                                                                                                                                 ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. r~2121)
                                                                                                                                             ))))
                                                                                                                                             (and
                                                                                                                                              (<= tmp%%$19 tmp%%$20)
                                                                                                                                              (< tmp%%$20 tmp%%$21)
                                                                                                                                          ))))
                                                                                                                                          (= (%I (vstd!seq.Seq.index.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ USIZE
                                                                                                                                               $ TYPE%alloc!alloc.Global.
                                                                                                                                              ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. r~2121)
                                                                                                                                             ) j$
                                                                                                                                            )
                                                                                                                                           ) (lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_wrapping_add.? (I l_total@) (vstd!seq.Seq.index.?
                                                                                                                                             $ USIZE (Poly%vstd!seq.Seq<usize.>. r_pv@1) j$
                                                                                                                                        )))))
                                                                                                                                        :pattern ((vstd!seq.Seq.index.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec.
                                                                                                                                            $ USIZE $ TYPE%alloc!alloc.Global.
                                                                                                                                           ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. r~2121)
                                                                                                                                          ) j$
                                                                                                                                        ))
                                                                                                                                        :qid user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_14
                                                                                                                                        :skolemid skolem_user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_14
                                                                                                                ))))))))))))))))))))))))
                                                                                                                (=>
                                                                                                                 (and
                                                                                                                  (forall ((closure%$ Poly)) (!
                                                                                                                    (=>
                                                                                                                     (has_type closure%$ TYPE%tuple%0.)
                                                                                                                     (closure_req TYPE%anonymous_closure%29509. $ TYPE%tuple%0. (Poly%anonymous_closure%29509.
                                                                                                                       tmp%%29
                                                                                                                      ) closure%$
                                                                                                                    ))
                                                                                                                    :pattern ((closure_req TYPE%anonymous_closure%29509. $ TYPE%tuple%0. (Poly%anonymous_closure%29509.
                                                                                                                       tmp%%29
                                                                                                                      ) closure%$
                                                                                                                    ))
                                                                                                                    :qid user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_15
                                                                                                                    :skolemid skolem_user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_15
                                                                                                                  ))
                                                                                                                  (forall ((closure%$ Poly) (r$ Poly)) (!
                                                                                                                    (=>
                                                                                                                     (and
                                                                                                                      (has_type closure%$ TYPE%tuple%0.)
                                                                                                                      (has_type r$ (TYPE%alloc!vec.Vec. $ USIZE $ TYPE%alloc!alloc.Global.))
                                                                                                                     )
                                                                                                                     (=>
                                                                                                                      (closure_ens TYPE%anonymous_closure%29509. $ TYPE%tuple%0. (Poly%anonymous_closure%29509.
                                                                                                                        tmp%%29
                                                                                                                       ) closure%$ r$
                                                                                                                      )
                                                                                                                      (and
                                                                                                                       (= (vstd!seq.Seq.len.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ USIZE
                                                                                                                           $ TYPE%alloc!alloc.Global.
                                                                                                                          ) r$
                                                                                                                         )
                                                                                                                        ) (vstd!seq.Seq.len.? $ USIZE (Poly%vstd!seq.Seq<usize.>. r_pv@1))
                                                                                                                       )
                                                                                                                       (forall ((j$ Poly)) (!
                                                                                                                         (=>
                                                                                                                          (has_type j$ INT)
                                                                                                                          (=>
                                                                                                                           (let
                                                                                                                            ((tmp%%$28 0))
                                                                                                                            (let
                                                                                                                             ((tmp%%$29 (%I j$)))
                                                                                                                             (let
                                                                                                                              ((tmp%%$30 (vstd!seq.Seq.len.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $
                                                                                                                                   USIZE $ TYPE%alloc!alloc.Global.
                                                                                                                                  ) r$
                                                                                                                              ))))
                                                                                                                              (and
                                                                                                                               (<= tmp%%$28 tmp%%$29)
                                                                                                                               (< tmp%%$29 tmp%%$30)
                                                                                                                           ))))
                                                                                                                           (= (%I (vstd!seq.Seq.index.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ USIZE
                                                                                                                                $ TYPE%alloc!alloc.Global.
                                                                                                                               ) r$
                                                                                                                              ) j$
                                                                                                                             )
                                                                                                                            ) (lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_wrapping_add.? (I l_total@) (vstd!seq.Seq.index.?
                                                                                                                              $ USIZE (Poly%vstd!seq.Seq<usize.>. r_pv@1) j$
                                                                                                                         )))))
                                                                                                                         :pattern ((vstd!seq.Seq.index.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec.
                                                                                                                             $ USIZE $ TYPE%alloc!alloc.Global.
                                                                                                                            ) r$
                                                                                                                           ) j$
                                                                                                                         ))
                                                                                                                         :qid user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_16
                                                                                                                         :skolemid skolem_user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_16
                                                                                                                    )))))
                                                                                                                    :pattern ((closure_ens TYPE%anonymous_closure%29509. $ TYPE%tuple%0. (Poly%anonymous_closure%29509.
                                                                                                                       tmp%%29
                                                                                                                      ) closure%$ r$
                                                                                                                    ))
                                                                                                                    :qid user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_17
                                                                                                                    :skolemid skolem_user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_17
                                                                                                                 )))
                                                                                                                 (=>
                                                                                                                  (= adjust_right@ tmp%%29)
                                                                                                                  (and
                                                                                                                   (=>
                                                                                                                    %%location_label%%47
                                                                                                                    (req%lib!Chap02.HFSchedulerMtEph.HFSchedulerMtEph.join. $ (TYPE%alloc!vec.Vec. $ USIZE
                                                                                                                      $ TYPE%alloc!alloc.Global.
                                                                                                                     ) $ (TYPE%alloc!vec.Vec. $ USIZE $ TYPE%alloc!alloc.Global.) $ TYPE%anonymous_closure%29504.
                                                                                                                     $ TYPE%anonymous_closure%29509. (Poly%anonymous_closure%29504. copy_left@) (Poly%anonymous_closure%29509.
                                                                                                                      adjust_right@
                                                                                                                   )))
                                                                                                                   (=>
                                                                                                                    (ens%lib!Chap02.HFSchedulerMtEph.HFSchedulerMtEph.join. $ (TYPE%alloc!vec.Vec. $ USIZE
                                                                                                                      $ TYPE%alloc!alloc.Global.
                                                                                                                     ) $ (TYPE%alloc!vec.Vec. $ USIZE $ TYPE%alloc!alloc.Global.) $ TYPE%anonymous_closure%29504.
                                                                                                                     $ TYPE%anonymous_closure%29509. (Poly%anonymous_closure%29504. copy_left@) (Poly%anonymous_closure%29509.
                                                                                                                      adjust_right@
                                                                                                                     ) tmp%%$31@
                                                                                                                    )
                                                                                                                    (=>
                                                                                                                     (= left_part@ (%Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. (tuple%2./tuple%2/0
                                                                                                                        (%Poly%tuple%2. (Poly%tuple%2. tmp%%$31@))
                                                                                                                     )))
                                                                                                                     (=>
                                                                                                                      (= right_part@ (%Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. (tuple%2./tuple%2/1
                                                                                                                         (%Poly%tuple%2. (Poly%tuple%2. tmp%%$31@))
                                                                                                                      )))
                                                                                                                      (=>
                                                                                                                       (has_resolved $ (TYPE%alloc!vec.Vec. $ USIZE $ TYPE%alloc!alloc.Global.) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>.
                                                                                                                         right_part@
                                                                                                                       ))
                                                                                                                       (=>
                                                                                                                        (= result_vec@0 left_part@)
                                                                                                                        (=>
                                                                                                                         (= i$12@0 0)
                                                                                                                         (and
                                                                                                                          (=>
                                                                                                                           %%location_label%%48
                                                                                                                           (<= i$12@0 r_len@)
                                                                                                                          )
                                                                                                                          (and
                                                                                                                           (=>
                                                                                                                            %%location_label%%49
                                                                                                                            (= r_len@ (vstd!seq.Seq.len.? $ USIZE (Poly%vstd!seq.Seq<usize.>. r_pref_view@1)))
                                                                                                                           )
                                                                                                                           (and
                                                                                                                            (=>
                                                                                                                             %%location_label%%50
                                                                                                                             (= l_len@ (vstd!seq.Seq.len.? $ USIZE (Poly%vstd!seq.Seq<usize.>. l_pref_view@1)))
                                                                                                                            )
                                                                                                                            (and
                                                                                                                             (=>
                                                                                                                              %%location_label%%51
                                                                                                                              (= l_len@ mid@)
                                                                                                                             )
                                                                                                                             (and
                                                                                                                              (=>
                                                                                                                               %%location_label%%52
                                                                                                                               (= (vstd!seq.Seq.len.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ USIZE
                                                                                                                                   $ TYPE%alloc!alloc.Global.
                                                                                                                                  ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. right_part@)
                                                                                                                                 )
                                                                                                                                ) r_len@
                                                                                                                              ))
                                                                                                                              (and
                                                                                                                               (=>
                                                                                                                                %%location_label%%53
                                                                                                                                (= (vstd!seq.Seq.len.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ USIZE
                                                                                                                                    $ TYPE%alloc!alloc.Global.
                                                                                                                                   ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. result_vec@0)
                                                                                                                                  )
                                                                                                                                 ) (Add l_len@ i$12@0)
                                                                                                                               ))
                                                                                                                               (and
                                                                                                                                (=>
                                                                                                                                 %%location_label%%54
                                                                                                                                 (forall ((j$ Poly)) (!
                                                                                                                                   (=>
                                                                                                                                    (has_type j$ INT)
                                                                                                                                    (=>
                                                                                                                                     (let
                                                                                                                                      ((tmp%%$32 0))
                                                                                                                                      (let
                                                                                                                                       ((tmp%%$33 (%I j$)))
                                                                                                                                       (let
                                                                                                                                        ((tmp%%$34 r_len@))
                                                                                                                                        (and
                                                                                                                                         (<= tmp%%$32 tmp%%$33)
                                                                                                                                         (< tmp%%$33 tmp%%$34)
                                                                                                                                     ))))
                                                                                                                                     (= (%I (vstd!seq.Seq.index.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ USIZE
                                                                                                                                          $ TYPE%alloc!alloc.Global.
                                                                                                                                         ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. right_part@)
                                                                                                                                        ) j$
                                                                                                                                       )
                                                                                                                                      ) (lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_wrapping_add.? (I l_total@) (vstd!seq.Seq.index.?
                                                                                                                                        $ USIZE (Poly%vstd!seq.Seq<usize.>. r_pref_view@1) j$
                                                                                                                                   )))))
                                                                                                                                   :pattern ((vstd!seq.Seq.index.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec.
                                                                                                                                       $ USIZE $ TYPE%alloc!alloc.Global.
                                                                                                                                      ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. right_part@)
                                                                                                                                     ) j$
                                                                                                                                   ))
                                                                                                                                   :qid user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_18
                                                                                                                                   :skolemid skolem_user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_18
                                                                                                                                )))
                                                                                                                                (and
                                                                                                                                 (=>
                                                                                                                                  %%location_label%%55
                                                                                                                                  (forall ((j$ Poly)) (!
                                                                                                                                    (=>
                                                                                                                                     (has_type j$ INT)
                                                                                                                                     (=>
                                                                                                                                      (let
                                                                                                                                       ((tmp%%$35 0))
                                                                                                                                       (let
                                                                                                                                        ((tmp%%$36 (%I j$)))
                                                                                                                                        (let
                                                                                                                                         ((tmp%%$37 l_len@))
                                                                                                                                         (and
                                                                                                                                          (<= tmp%%$35 tmp%%$36)
                                                                                                                                          (< tmp%%$36 tmp%%$37)
                                                                                                                                      ))))
                                                                                                                                      (= (vstd!seq.Seq.index.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ USIZE
                                                                                                                                          $ TYPE%alloc!alloc.Global.
                                                                                                                                         ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. result_vec@0)
                                                                                                                                        ) j$
                                                                                                                                       ) (vstd!seq.Seq.index.? $ USIZE (Poly%vstd!seq.Seq<usize.>. l_pref_view@1) j$)
                                                                                                                                    )))
                                                                                                                                    :pattern ((vstd!seq.Seq.index.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec.
                                                                                                                                        $ USIZE $ TYPE%alloc!alloc.Global.
                                                                                                                                       ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. result_vec@0)
                                                                                                                                      ) j$
                                                                                                                                    ))
                                                                                                                                    :qid user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_19
                                                                                                                                    :skolemid skolem_user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_19
                                                                                                                                 )))
                                                                                                                                 (and
                                                                                                                                  (=>
                                                                                                                                   %%location_label%%56
                                                                                                                                   (forall ((j$ Int)) (!
                                                                                                                                     (=>
                                                                                                                                      (let
                                                                                                                                       ((tmp%%$38 0))
                                                                                                                                       (let
                                                                                                                                        ((tmp%%$39 j$))
                                                                                                                                        (let
                                                                                                                                         ((tmp%%$40 i$12@0))
                                                                                                                                         (and
                                                                                                                                          (<= tmp%%$38 tmp%%$39)
                                                                                                                                          (< tmp%%$39 tmp%%$40)
                                                                                                                                      ))))
                                                                                                                                      (= (%I (vstd!seq.Seq.index.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ USIZE
                                                                                                                                           $ TYPE%alloc!alloc.Global.
                                                                                                                                          ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. result_vec@0)
                                                                                                                                         ) (I (Add l_len@ j$))
                                                                                                                                        )
                                                                                                                                       ) (lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_wrapping_add.? (I l_total@) (vstd!seq.Seq.index.?
                                                                                                                                         $ USIZE (Poly%vstd!seq.Seq<usize.>. r_pref_view@1) (I j$)
                                                                                                                                     ))))
                                                                                                                                     :pattern ((vstd!seq.Seq.index.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec.
                                                                                                                                         $ USIZE $ TYPE%alloc!alloc.Global.
                                                                                                                                        ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. result_vec@0)
                                                                                                                                       ) (I (Add l_len@ j$))
                                                                                                                                     ))
                                                                                                                                     :qid user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_20
                                                                                                                                     :skolemid skolem_user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_20
                                                                                                                                  )))
                                                                                                                                  (=>
                                                                                                                                   (uInv SZ i$12@1)
                                                                                                                                   (=>
                                                                                                                                    (<= i$12@1 r_len@)
                                                                                                                                    (=>
                                                                                                                                     (= r_len@ (vstd!seq.Seq.len.? $ USIZE (Poly%vstd!seq.Seq<usize.>. r_pref_view@1)))
                                                                                                                                     (=>
                                                                                                                                      (= l_len@ (vstd!seq.Seq.len.? $ USIZE (Poly%vstd!seq.Seq<usize.>. l_pref_view@1)))
                                                                                                                                      (=>
                                                                                                                                       (= l_len@ mid@)
                                                                                                                                       (=>
                                                                                                                                        (= (vstd!seq.Seq.len.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ USIZE
                                                                                                                                            $ TYPE%alloc!alloc.Global.
                                                                                                                                           ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. right_part@)
                                                                                                                                          )
                                                                                                                                         ) r_len@
                                                                                                                                        )
                                                                                                                                        (=>
                                                                                                                                         (= (vstd!seq.Seq.len.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ USIZE
                                                                                                                                             $ TYPE%alloc!alloc.Global.
                                                                                                                                            ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. result_vec@1)
                                                                                                                                           )
                                                                                                                                          ) (Add l_len@ i$12@1)
                                                                                                                                         )
                                                                                                                                         (=>
                                                                                                                                          (forall ((j$ Poly)) (!
                                                                                                                                            (=>
                                                                                                                                             (has_type j$ INT)
                                                                                                                                             (=>
                                                                                                                                              (let
                                                                                                                                               ((tmp%%$32 0))
                                                                                                                                               (let
                                                                                                                                                ((tmp%%$33 (%I j$)))
                                                                                                                                                (let
                                                                                                                                                 ((tmp%%$34 r_len@))
                                                                                                                                                 (and
                                                                                                                                                  (<= tmp%%$32 tmp%%$33)
                                                                                                                                                  (< tmp%%$33 tmp%%$34)
                                                                                                                                              ))))
                                                                                                                                              (= (%I (vstd!seq.Seq.index.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ USIZE
                                                                                                                                                   $ TYPE%alloc!alloc.Global.
                                                                                                                                                  ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. right_part@)
                                                                                                                                                 ) j$
                                                                                                                                                )
                                                                                                                                               ) (lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_wrapping_add.? (I l_total@) (vstd!seq.Seq.index.?
                                                                                                                                                 $ USIZE (Poly%vstd!seq.Seq<usize.>. r_pref_view@1) j$
                                                                                                                                            )))))
                                                                                                                                            :pattern ((vstd!seq.Seq.index.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec.
                                                                                                                                                $ USIZE $ TYPE%alloc!alloc.Global.
                                                                                                                                               ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. right_part@)
                                                                                                                                              ) j$
                                                                                                                                            ))
                                                                                                                                            :qid user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_18
                                                                                                                                            :skolemid skolem_user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_18
                                                                                                                                          ))
                                                                                                                                          (=>
                                                                                                                                           (forall ((j$ Poly)) (!
                                                                                                                                             (=>
                                                                                                                                              (has_type j$ INT)
                                                                                                                                              (=>
                                                                                                                                               (let
                                                                                                                                                ((tmp%%$35 0))
                                                                                                                                                (let
                                                                                                                                                 ((tmp%%$36 (%I j$)))
                                                                                                                                                 (let
                                                                                                                                                  ((tmp%%$37 l_len@))
                                                                                                                                                  (and
                                                                                                                                                   (<= tmp%%$35 tmp%%$36)
                                                                                                                                                   (< tmp%%$36 tmp%%$37)
                                                                                                                                               ))))
                                                                                                                                               (= (vstd!seq.Seq.index.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ USIZE
                                                                                                                                                   $ TYPE%alloc!alloc.Global.
                                                                                                                                                  ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. result_vec@1)
                                                                                                                                                 ) j$
                                                                                                                                                ) (vstd!seq.Seq.index.? $ USIZE (Poly%vstd!seq.Seq<usize.>. l_pref_view@1) j$)
                                                                                                                                             )))
                                                                                                                                             :pattern ((vstd!seq.Seq.index.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec.
                                                                                                                                                 $ USIZE $ TYPE%alloc!alloc.Global.
                                                                                                                                                ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. result_vec@1)
                                                                                                                                               ) j$
                                                                                                                                             ))
                                                                                                                                             :qid user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_19
                                                                                                                                             :skolemid skolem_user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_19
                                                                                                                                           ))
                                                                                                                                           (=>
                                                                                                                                            (forall ((j$ Int)) (!
                                                                                                                                              (=>
                                                                                                                                               (let
                                                                                                                                                ((tmp%%$38 0))
                                                                                                                                                (let
                                                                                                                                                 ((tmp%%$39 j$))
                                                                                                                                                 (let
                                                                                                                                                  ((tmp%%$40 i$12@1))
                                                                                                                                                  (and
                                                                                                                                                   (<= tmp%%$38 tmp%%$39)
                                                                                                                                                   (< tmp%%$39 tmp%%$40)
                                                                                                                                               ))))
                                                                                                                                               (= (%I (vstd!seq.Seq.index.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ USIZE
                                                                                                                                                    $ TYPE%alloc!alloc.Global.
                                                                                                                                                   ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. result_vec@1)
                                                                                                                                                  ) (I (Add l_len@ j$))
                                                                                                                                                 )
                                                                                                                                                ) (lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_wrapping_add.? (I l_total@) (vstd!seq.Seq.index.?
                                                                                                                                                  $ USIZE (Poly%vstd!seq.Seq<usize.>. r_pref_view@1) (I j$)
                                                                                                                                              ))))
                                                                                                                                              :pattern ((vstd!seq.Seq.index.? $ USIZE (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec.
                                                                                                                                                  $ USIZE $ TYPE%alloc!alloc.Global.
                                                                                                                                                 ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. result_vec@1)
                                                                                                                                                ) (I (Add l_len@ j$))
                                                                                                                                              ))
                                                                                                                                              :qid user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_20
                                                                                                                                              :skolemid skolem_user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_20
                                                                                                                                            ))
                                                                                                                                            (=>
                                                                                                                                             (has_resolved $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE)
                                                                                                                                              (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. left@)
                                                                                                                                             )
                                                                                                                                             (=>
                                                                                                                                              (has_resolved $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE)
                                                                                                                                               (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. right@)
                                                                                                                                              )
                                                                                                                                              (=>
                                                                                                                                               (has_resolved $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE)
                                                                                                                                                (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. l_prefixes@)
                                                                                                                                               )
                                                                                                                                               (=>
                                                                                                                                                (has_resolved $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE)
                                                                                                                                                 (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. r_prefixes@)
                                                                                                                                                )
                                                                                                                                                (=>
                                                                                                                                                 (has_resolved $ (TYPE%alloc!vec.Vec. $ USIZE $ TYPE%alloc!alloc.Global.) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>.
                                                                                                                                                   right_part@
                                                                                                                                                 ))
                                                                                                                                                 (=>
                                                                                                                                                  (not (< i$12@1 r_len@))
                                                                                                                                                  (=>
                                                                                                                                                   (has_resolved $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE)
                                                                                                                                                    (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. left@)
                                                                                                                                                   )
                                                                                                                                                   (=>
                                                                                                                                                    (has_resolved $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE)
                                                                                                                                                     (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. right@)
                                                                                                                                                    )
                                                                                                                                                    (=>
                                                                                                                                                     (has_resolved $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE)
                                                                                                                                                      (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. l_prefixes@)
                                                                                                                                                     )
                                                                                                                                                     (=>
                                                                                                                                                      (has_resolved $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE)
                                                                                                                                                       (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. r_prefixes@)
                                                                                                                                                      )
                                                                                                                                                      (=>
                                                                                                                                                       (has_resolved $ (TYPE%alloc!vec.Vec. $ USIZE $ TYPE%alloc!alloc.Global.) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>.
                                                                                                                                                         right_part@
                                                                                                                                                       ))
                                                                                                                                                       (=>
                                                                                                                                                        (ens%core!num.impl&%11.wrapping_add. l_total@ r_total@ total$1@)
                                                                                                                                                        (=>
                                                                                                                                                         (= verus_tmp$8@1 (%Poly%vstd!seq.Seq<usize.>. (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec.
                                                                                                                                                             $ USIZE $ TYPE%alloc!alloc.Global.
                                                                                                                                                            ) (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. result_vec@1)
                                                                                                                                                         )))
                                                                                                                                                         (=>
                                                                                                                                                          (= verus_tmp_result_view@ verus_tmp$8@1)
                                                                                                                                                          (=>
                                                                                                                                                           (= result_view@1 verus_tmp_result_view@)
                                                                                                                                                           (=>
                                                                                                                                                            (= result_prefixes@ (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS./ArraySeqMtPerS
                                                                                                                                                              (Poly%alloc!vec.Vec<usize./alloc!alloc.Global.>. result_vec@1)
                                                                                                                                                            ))
                                                                                                                                                            (=>
                                                                                                                                                             (= rp@ (%Poly%vstd!seq.Seq<usize.>. (vstd!seq.Seq.new.? $ USIZE (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_len.?
                                                                                                                                                                 $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE) $ USIZE (
                                                                                                                                                                  Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. result_prefixes@
                                                                                                                                                                 )
                                                                                                                                                                ) (Poly%fun%1. (mk_fun (%%lambda%%1 $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
                                                                                                                                                                    $ USIZE
                                                                                                                                                                   ) $ USIZE (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. result_prefixes@)
                                                                                                                                                             ))))))
                                                                                                                                                             (=>
                                                                                                                                                              (= tmp%46 (ext_eq false (TYPE%vstd!seq.Seq. $ USIZE) (Poly%vstd!seq.Seq<usize.>. rp@)
                                                                                                                                                                (Poly%vstd!seq.Seq<usize.>. result_view@1)
                                                                                                                                                              ))
                                                                                                                                                              (and
                                                                                                                                                               (=>
                                                                                                                                                                %%location_label%%57
                                                                                                                                                                tmp%46
                                                                                                                                                               )
                                                                                                                                                               (=>
                                                                                                                                                                tmp%46
                                                                                                                                                                (=>
                                                                                                                                                                 (= tmp%47 (= (vstd!seq.Seq.len.? $ USIZE (Poly%vstd!seq.Seq<usize.>. result_view@1))
                                                                                                                                                                   n@
                                                                                                                                                                 ))
                                                                                                                                                                 (and
                                                                                                                                                                  (=>
                                                                                                                                                                   %%location_label%%58
                                                                                                                                                                   tmp%47
                                                                                                                                                                  )
                                                                                                                                                                  (=>
                                                                                                                                                                   tmp%47
                                                                                                                                                                   (=>
                                                                                                                                                                    (= tmp%48 (ext_eq false (TYPE%vstd!seq.Seq. $ USIZE) (Poly%vstd!seq.Seq<usize.>. left_input@1)
                                                                                                                                                                      (vstd!seq.Seq.subrange.? $ USIZE (Poly%vstd!seq.Seq<usize.>. input@1) (I 0) (I mid@))
                                                                                                                                                                    ))
                                                                                                                                                                    (and
                                                                                                                                                                     (=>
                                                                                                                                                                      %%location_label%%59
                                                                                                                                                                      tmp%48
                                                                                                                                                                     )
                                                                                                                                                                     (=>
                                                                                                                                                                      tmp%48
                                                                                                                                                                      (=>
                                                                                                                                                                       (= tmp%49 (ext_eq false (TYPE%vstd!seq.Seq. $ USIZE) (Poly%vstd!seq.Seq<usize.>. right_input@1)
                                                                                                                                                                         (vstd!seq.Seq.subrange.? $ USIZE (Poly%vstd!seq.Seq<usize.>. input@1) (I mid@) (I n@))
                                                                                                                                                                       ))
                                                                                                                                                                       (and
                                                                                                                                                                        (=>
                                                                                                                                                                         %%location_label%%60
                                                                                                                                                                         tmp%49
                                                                                                                                                                        )
                                                                                                                                                                        (=>
                                                                                                                                                                         tmp%49
                                                                                                                                                                         (and
                                                                                                                                                                          (=>
                                                                                                                                                                           %%location_label%%61
                                                                                                                                                                           (req%vstd!seq_lib.impl&%0.lemma_fold_left_split. $ USIZE $ USIZE (Poly%vstd!seq.Seq<usize.>.
                                                                                                                                                                             input@1
                                                                                                                                                                            ) (I (uClip SZ 0)) spec_f@1 mid@
                                                                                                                                                                          ))
                                                                                                                                                                          (=>
                                                                                                                                                                           (ens%vstd!seq_lib.impl&%0.lemma_fold_left_split. $ USIZE $ USIZE (Poly%vstd!seq.Seq<usize.>.
                                                                                                                                                                             input@1
                                                                                                                                                                            ) (I (uClip SZ 0)) spec_f@1 mid@
                                                                                                                                                                           )
                                                                                                                                                                           (and
                                                                                                                                                                            (=>
                                                                                                                                                                             %%location_label%%62
                                                                                                                                                                             (req%lib!Chap26.ScanDCMtPer.ScanDCMtPer.lemma_fold_left_monoid. right_input@1 l_total@
                                                                                                                                                                              spec_f@1 (uClip SZ 0)
                                                                                                                                                                            ))
                                                                                                                                                                            (=>
                                                                                                                                                                             (ens%lib!Chap26.ScanDCMtPer.ScanDCMtPer.lemma_fold_left_monoid. right_input@1 l_total@
                                                                                                                                                                              spec_f@1 (uClip SZ 0)
                                                                                                                                                                             )
                                                                                                                                                                             (and
                                                                                                                                                                              (=>
                                                                                                                                                                               (has_type i$14@ INT)
                                                                                                                                                                               (=>
                                                                                                                                                                                (let
                                                                                                                                                                                 ((tmp%%$41 0))
                                                                                                                                                                                 (let
                                                                                                                                                                                  ((tmp%%$42 (%I i$14@)))
                                                                                                                                                                                  (let
                                                                                                                                                                                   ((tmp%%$43 n@))
                                                                                                                                                                                   (and
                                                                                                                                                                                    (<= tmp%%$41 tmp%%$42)
                                                                                                                                                                                    (< tmp%%$42 tmp%%$43)
                                                                                                                                                                                ))))
                                                                                                                                                                                (or
                                                                                                                                                                                 (and
                                                                                                                                                                                  (=>
                                                                                                                                                                                   (< (%I i$14@) mid@)
                                                                                                                                                                                   (=>
                                                                                                                                                                                    (= tmp%50 (= (vstd!seq.Seq.index.? $ USIZE (Poly%vstd!seq.Seq<usize.>. result_view@1)
                                                                                                                                                                                       i$14@
                                                                                                                                                                                      ) (vstd!seq.Seq.index.? $ USIZE (Poly%vstd!seq.Seq<usize.>. l_pref_view@1) i$14@)
                                                                                                                                                                                    ))
                                                                                                                                                                                    (and
                                                                                                                                                                                     (=>
                                                                                                                                                                                      %%location_label%%63
                                                                                                                                                                                      tmp%50
                                                                                                                                                                                     )
                                                                                                                                                                                     (=>
                                                                                                                                                                                      tmp%50
                                                                                                                                                                                      (=>
                                                                                                                                                                                       (= tmp%51 (ext_eq false (TYPE%vstd!seq.Seq. $ USIZE) (vstd!seq.Seq.subrange.? $ USIZE
                                                                                                                                                                                          (Poly%vstd!seq.Seq<usize.>. input@1) (I 0) i$14@
                                                                                                                                                                                         ) (vstd!seq.Seq.subrange.? $ USIZE (Poly%vstd!seq.Seq<usize.>. left_input@1) (I 0)
                                                                                                                                                                                          i$14@
                                                                                                                                                                                       )))
                                                                                                                                                                                       (and
                                                                                                                                                                                        (=>
                                                                                                                                                                                         %%location_label%%64
                                                                                                                                                                                         tmp%51
                                                                                                                                                                                        )
                                                                                                                                                                                        (=>
                                                                                                                                                                                         tmp%51
                                                                                                                                                                                         %%switch_label%%0
                                                                                                                                                                                  )))))))
                                                                                                                                                                                  (=>
                                                                                                                                                                                   (not (< (%I i$14@) mid@))
                                                                                                                                                                                   (=>
                                                                                                                                                                                    (= j@ (Sub (%I i$14@) mid@))
                                                                                                                                                                                    (=>
                                                                                                                                                                                     (= tmp%52 (= (%I i$14@) (Add l_len@ j@)))
                                                                                                                                                                                     (and
                                                                                                                                                                                      (=>
                                                                                                                                                                                       %%location_label%%65
                                                                                                                                                                                       tmp%52
                                                                                                                                                                                      )
                                                                                                                                                                                      (=>
                                                                                                                                                                                       tmp%52
                                                                                                                                                                                       (=>
                                                                                                                                                                                        (= tmp%53 (= (%I (vstd!seq.Seq.index.? $ USIZE (Poly%vstd!seq.Seq<usize.>. result_view@1)
                                                                                                                                                                                            (I (Add l_len@ j@))
                                                                                                                                                                                           )
                                                                                                                                                                                          ) (lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_wrapping_add.? (I l_total@) (vstd!seq.Seq.index.?
                                                                                                                                                                                            $ USIZE (Poly%vstd!seq.Seq<usize.>. r_pref_view@1) (I j@)
                                                                                                                                                                                        ))))
                                                                                                                                                                                        (and
                                                                                                                                                                                         (=>
                                                                                                                                                                                          %%location_label%%66
                                                                                                                                                                                          tmp%53
                                                                                                                                                                                         )
                                                                                                                                                                                         (=>
                                                                                                                                                                                          tmp%53
                                                                                                                                                                                          (=>
                                                                                                                                                                                           (= tmp%54 (%Poly%vstd!seq.Seq<usize.>. (vstd!seq.Seq.subrange.? $ USIZE (Poly%vstd!seq.Seq<usize.>.
                                                                                                                                                                                               right_input@1
                                                                                                                                                                                              ) (I 0) (I j@)
                                                                                                                                                                                           )))
                                                                                                                                                                                           (and
                                                                                                                                                                                            (=>
                                                                                                                                                                                             %%location_label%%67
                                                                                                                                                                                             (req%lib!Chap26.ScanDCMtPer.ScanDCMtPer.lemma_fold_left_monoid. tmp%54 l_total@ spec_f@1
                                                                                                                                                                                              (uClip SZ 0)
                                                                                                                                                                                            ))
                                                                                                                                                                                            (=>
                                                                                                                                                                                             (ens%lib!Chap26.ScanDCMtPer.ScanDCMtPer.lemma_fold_left_monoid. tmp%54 l_total@ spec_f@1
                                                                                                                                                                                              (uClip SZ 0)
                                                                                                                                                                                             )
                                                                                                                                                                                             (=>
                                                                                                                                                                                              (= tmp%55 (ext_eq false (TYPE%vstd!seq.Seq. $ USIZE) (vstd!seq.Seq.subrange.? $ USIZE
                                                                                                                                                                                                 (vstd!seq.Seq.subrange.? $ USIZE (Poly%vstd!seq.Seq<usize.>. input@1) (I 0) i$14@)
                                                                                                                                                                                                 (I 0) (I mid@)
                                                                                                                                                                                                ) (Poly%vstd!seq.Seq<usize.>. left_input@1)
                                                                                                                                                                                              ))
                                                                                                                                                                                              (and
                                                                                                                                                                                               (=>
                                                                                                                                                                                                %%location_label%%68
                                                                                                                                                                                                tmp%55
                                                                                                                                                                                               )
                                                                                                                                                                                               (=>
                                                                                                                                                                                                tmp%55
                                                                                                                                                                                                (=>
                                                                                                                                                                                                 (= tmp%56 (ext_eq false (TYPE%vstd!seq.Seq. $ USIZE) (vstd!seq.Seq.subrange.? $ USIZE
                                                                                                                                                                                                    (vstd!seq.Seq.subrange.? $ USIZE (Poly%vstd!seq.Seq<usize.>. input@1) (I 0) i$14@)
                                                                                                                                                                                                    (I mid@) i$14@
                                                                                                                                                                                                   ) (vstd!seq.Seq.subrange.? $ USIZE (Poly%vstd!seq.Seq<usize.>. right_input@1) (I 0)
                                                                                                                                                                                                    (I j@)
                                                                                                                                                                                                 )))
                                                                                                                                                                                                 (and
                                                                                                                                                                                                  (=>
                                                                                                                                                                                                   %%location_label%%69
                                                                                                                                                                                                   tmp%56
                                                                                                                                                                                                  )
                                                                                                                                                                                                  (=>
                                                                                                                                                                                                   tmp%56
                                                                                                                                                                                                   (=>
                                                                                                                                                                                                    (= tmp%57 (%Poly%vstd!seq.Seq<usize.>. (vstd!seq.Seq.subrange.? $ USIZE (Poly%vstd!seq.Seq<usize.>.
                                                                                                                                                                                                        input@1
                                                                                                                                                                                                       ) (I 0) i$14@
                                                                                                                                                                                                    )))
                                                                                                                                                                                                    (and
                                                                                                                                                                                                     (=>
                                                                                                                                                                                                      %%location_label%%70
                                                                                                                                                                                                      (req%vstd!seq_lib.impl&%0.lemma_fold_left_split. $ USIZE $ USIZE (Poly%vstd!seq.Seq<usize.>.
                                                                                                                                                                                                        tmp%57
                                                                                                                                                                                                       ) (I (uClip SZ 0)) spec_f@1 mid@
                                                                                                                                                                                                     ))
                                                                                                                                                                                                     (=>
                                                                                                                                                                                                      (ens%vstd!seq_lib.impl&%0.lemma_fold_left_split. $ USIZE $ USIZE (Poly%vstd!seq.Seq<usize.>.
                                                                                                                                                                                                        tmp%57
                                                                                                                                                                                                       ) (I (uClip SZ 0)) spec_f@1 mid@
                                                                                                                                                                                                      )
                                                                                                                                                                                                      %%switch_label%%0
                                                                                                                                                                                 )))))))))))))))))))))
                                                                                                                                                                                 (and
                                                                                                                                                                                  (not %%switch_label%%0)
                                                                                                                                                                                  (=>
                                                                                                                                                                                   %%location_label%%71
                                                                                                                                                                                   (= (%I (vstd!seq.Seq.index.? $ USIZE (Poly%vstd!seq.Seq<usize.>. result_view@1) i$14@))
                                                                                                                                                                                    (lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_scan_at.? (Poly%vstd!seq.Seq<usize.>. input@1)
                                                                                                                                                                                     (Poly%fun%2. spec_f@1) (I (uClip SZ 0)) i$14@
                                                                                                                                                                              )))))))
                                                                                                                                                                              (=>
                                                                                                                                                                               (forall ((i$15 Poly)) (!
                                                                                                                                                                                 (=>
                                                                                                                                                                                  (has_type i$15 INT)
                                                                                                                                                                                  (=>
                                                                                                                                                                                   (let
                                                                                                                                                                                    ((tmp%%$44 0))
                                                                                                                                                                                    (let
                                                                                                                                                                                     ((tmp%%$45 (%I i$15)))
                                                                                                                                                                                     (let
                                                                                                                                                                                      ((tmp%%$46 n@))
                                                                                                                                                                                      (and
                                                                                                                                                                                       (<= tmp%%$44 tmp%%$45)
                                                                                                                                                                                       (< tmp%%$45 tmp%%$46)
                                                                                                                                                                                   ))))
                                                                                                                                                                                   (= (%I (vstd!seq.Seq.index.? $ USIZE (Poly%vstd!seq.Seq<usize.>. result_view@1) i$15))
                                                                                                                                                                                    (lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_scan_at.? (Poly%vstd!seq.Seq<usize.>. input@1)
                                                                                                                                                                                     (Poly%fun%2. spec_f@1) (I (uClip SZ 0)) i$15
                                                                                                                                                                                 ))))
                                                                                                                                                                                 :pattern ((vstd!seq.Seq.index.? $ USIZE (Poly%vstd!seq.Seq<usize.>. result_view@1)
                                                                                                                                                                                   i$15
                                                                                                                                                                                 ))
                                                                                                                                                                                 :qid user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_21
                                                                                                                                                                                 :skolemid skolem_user_lib__Chap26__ScanDCMtPer__ScanDCMtPer__prefix_sums_dc_inner_21
                                                                                                                                                                               ))
                                                                                                                                                                               (=>
                                                                                                                                                                                (= sums! (tuple%2./tuple%2 (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
                                                                                                                                                                                   result_prefixes@
                                                                                                                                                                                  ) (I total$1@)
                                                                                                                                                                                ))
                                                                                                                                                                                (=>
                                                                                                                                                                                 %%location_label%%72
                                                                                                                                                                                 (lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_scan_post.? (vstd!seq.Seq.new.? $ USIZE (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_len.?
                                                                                                                                                                                    $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE) $ USIZE (
                                                                                                                                                                                     Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. a!
                                                                                                                                                                                    )
                                                                                                                                                                                   ) (Poly%fun%1. (mk_fun (%%lambda%%1 $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
                                                                                                                                                                                       $ USIZE
                                                                                                                                                                                      ) $ USIZE (Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. a!)
                                                                                                                                                                                   )))
                                                                                                                                                                                  ) (Poly%fun%2. (lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_sum_fn.? (I 0))) (I 0) (vstd!seq.Seq.new.?
                                                                                                                                                                                   $ USIZE (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_len.?
                                                                                                                                                                                    $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE) $ USIZE (
                                                                                                                                                                                     tuple%2./tuple%2/0 (%Poly%tuple%2. (Poly%tuple%2. sums!))
                                                                                                                                                                                    )
                                                                                                                                                                                   ) (Poly%fun%1. (mk_fun (%%lambda%%1 $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
                                                                                                                                                                                       $ USIZE
                                                                                                                                                                                      ) $ USIZE (tuple%2./tuple%2/0 (%Poly%tuple%2. (Poly%tuple%2. sums!)))
                                                                                                                                                                                   )))
                                                                                                                                                                                  ) (tuple%2./tuple%2/1 (%Poly%tuple%2. (Poly%tuple%2. sums!)))
 )))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
 (get-info :all-statistics)
 (get-info :version)
 (set-option :rlimit 30000000)
 (check-sat)
 (set-option :rlimit 0)
 (get-info :all-statistics)
(pop)

;; Function-Def lib::Chap18::ArraySeqMtPer::ArraySeqMtPer::ArraySeqMtPerS::prefix_sums_dc_parallel
;; src/Chap26/ScanDCMtPer.rs:360:9: 360:103 (#0)
(push)
 (get-info :all-statistics)
 (declare-const %return! Poly)
 (declare-const a! Poly)
 (declare-const tmp%1 tuple%2.)
 (assert
  fuel_defaults
 )
 (assert
  (has_type a! (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE))
 )
 (assert
  (<= (%I (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_len.? $
     (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE) $ USIZE a!
    )
   ) (- (uHi SZ) 1)
 ))
 ;; precondition not satisfied
 (declare-const %%location_label%%0 Bool)
 ;; postcondition not satisfied
 (declare-const %%location_label%%1 Bool)
 (assert
  (not (and
    (=>
     %%location_label%%0
     (req%lib!Chap26.ScanDCMtPer.ScanDCMtPer.prefix_sums_dc_inner. (%Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
       a!
    )))
    (=>
     (ens%lib!Chap26.ScanDCMtPer.ScanDCMtPer.prefix_sums_dc_inner. (%Poly%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
       a!
      ) tmp%1
     )
     (=>
      (= %return! (Poly%tuple%2. tmp%1))
      (=>
       %%location_label%%1
       (lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_scan_post.? (vstd!seq.Seq.new.? $ USIZE (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_len.?
          $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE) $ USIZE a!
         ) (Poly%fun%1. (mk_fun (%%lambda%%1 $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
             $ USIZE
            ) $ USIZE a!
         )))
        ) (Poly%fun%2. (lib!Chap26.ScanDCMtPer.ScanDCMtPer.spec_sum_fn.? (I 0))) (I 0) (vstd!seq.Seq.new.?
         $ USIZE (lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerBaseTrait.spec_len.?
          $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS. $ USIZE) $ USIZE (
           tuple%2./tuple%2/0 (%Poly%tuple%2. %return!)
          )
         ) (Poly%fun%1. (mk_fun (%%lambda%%1 $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
             $ USIZE
            ) $ USIZE (tuple%2./tuple%2/0 (%Poly%tuple%2. %return!))
         )))
        ) (tuple%2./tuple%2/1 (%Poly%tuple%2. %return!))
 )))))))
 (get-info :all-statistics)
 (get-info :version)
 (set-option :rlimit 30000000)
 (check-sat)
 (set-option :rlimit 0)
 (get-info :all-statistics)
(pop)

;; Trait-Impl-Axiom
(assert
 (tr_bound%lib!Chap26.ScanDCMtPer.ScanDCMtPer.ScanDCMtTrait. $ (TYPE%lib!Chap18.ArraySeqMtPer.ArraySeqMtPer.ArraySeqMtPerS.
   $ USIZE
)))

;; Trait-Impl-Axiom
(assert
 (tr_bound%core!ops.function.FnOnce. $ TYPE%anonymous_closure%29498. $ TYPE%tuple%0.)
)

;; Trait-Impl-Axiom
(assert
 (tr_bound%core!ops.function.FnOnce. $ TYPE%anonymous_closure%29501. $ TYPE%tuple%0.)
)

;; Trait-Impl-Axiom
(assert
 (tr_bound%core!ops.function.FnOnce. $ TYPE%anonymous_closure%29504. $ TYPE%tuple%0.)
)

;; Trait-Impl-Axiom
(assert
 (tr_bound%core!ops.function.FnOnce. $ TYPE%anonymous_closure%29509. $ TYPE%tuple%0.)
)
