(set-option :auto_config false)
(set-option :smt.mbqi false)
(set-option :smt.case_split 3)
(set-option :smt.qi.eager_threshold 100.0)
(set-option :smt.delay_units true)
(set-option :smt.arith.solver 2)
(set-option :smt.arith.nl false)
(set-option :pi.enabled false)
(set-option :rewriter.sort_disjunctions false)

;; Prelude

;; AIR prelude
(declare-sort %%Function%% 0)

(declare-sort FuelId 0)
(declare-sort Fuel 0)
(declare-const zero Fuel)
(declare-fun succ (Fuel) Fuel)
(declare-fun fuel_bool (FuelId) Bool)
(declare-fun fuel_bool_default (FuelId) Bool)
(declare-const fuel_defaults Bool)
(assert
 (=>
  fuel_defaults
  (forall ((id FuelId)) (!
    (= (fuel_bool id) (fuel_bool_default id))
    :pattern ((fuel_bool id))
    :qid prelude_fuel_defaults
    :skolemid skolem_prelude_fuel_defaults
))))
(declare-datatypes ((fndef 0)) (((fndef_singleton))))
(declare-sort Poly 0)
(declare-sort Height 0)
(declare-fun I (Int) Poly)
(declare-fun B (Bool) Poly)
(declare-fun R (Real) Poly)
(declare-fun F (fndef) Poly)
(declare-fun %I (Poly) Int)
(declare-fun %B (Poly) Bool)
(declare-fun %R (Poly) Real)
(declare-fun %F (Poly) fndef)
(declare-sort Type 0)
(declare-const BOOL Type)
(declare-const INT Type)
(declare-const NAT Type)
(declare-const REAL Type)
(declare-const CHAR Type)
(declare-const USIZE Type)
(declare-const ISIZE Type)
(declare-const TYPE%tuple%0. Type)
(declare-fun UINT (Int) Type)
(declare-fun SINT (Int) Type)
(declare-fun FLOAT (Int) Type)
(declare-fun CONST_INT (Int) Type)
(declare-fun CONST_BOOL (Bool) Type)
(declare-sort Dcr 0)
(declare-const $ Dcr)
(declare-const $slice Dcr)
(declare-const $dyn Dcr)
(declare-fun DST (Dcr) Dcr)
(declare-fun REF (Dcr) Dcr)
(declare-fun BOX (Dcr Type Dcr) Dcr)
(declare-fun RC (Dcr Type Dcr) Dcr)
(declare-fun ARC (Dcr Type Dcr) Dcr)
(declare-fun GHOST (Dcr) Dcr)
(declare-fun TRACKED (Dcr) Dcr)
(declare-fun NEVER (Dcr) Dcr)
(declare-fun CONST_PTR (Dcr) Dcr)
(declare-fun ARRAY (Dcr Type Dcr Type) Type)
(declare-fun MUTREF (Dcr Type) Type)
(declare-fun SLICE (Dcr Type) Type)
(declare-const STRSLICE Type)
(declare-const ALLOCATOR_GLOBAL Type)
(declare-fun PTR (Dcr Type) Type)
(declare-fun has_type (Poly Type) Bool)
(declare-fun sized (Dcr) Bool)
(declare-fun as_type (Poly Type) Poly)
(declare-fun mk_fun (%%Function%%) %%Function%%)
(declare-fun const_int (Type) Int)
(declare-fun const_bool (Type) Bool)
(declare-fun mut_ref_current% (Poly) Poly)
(declare-fun mut_ref_future% (Poly) Poly)
(declare-fun mut_ref_update_current% (Poly Poly) Poly)
(assert
 (forall ((m Poly) (arg Poly)) (!
   (= (mut_ref_current% (mut_ref_update_current% m arg)) arg)
   :pattern ((mut_ref_update_current% m arg))
   :qid prelude_mut_ref_update_current_current
   :skolemid skolem_prelude_mut_ref_update_current_current
)))
(assert
 (forall ((m Poly) (arg Poly)) (!
   (= (mut_ref_future% (mut_ref_update_current% m arg)) (mut_ref_future% m))
   :pattern ((mut_ref_update_current% m arg))
   :qid prelude_mut_ref_update_current_future
   :skolemid skolem_prelude_mut_ref_update_current_future
)))
(assert
 (forall ((m Poly) (d Dcr) (t Type)) (!
   (=>
    (has_type m (MUTREF d t))
    (has_type (mut_ref_current% m) t)
   )
   :pattern ((has_type m (MUTREF d t)) (mut_ref_current% m))
   :qid prelude_mut_ref_current_has_type
   :skolemid skolem_prelude_mut_ref_current_has_type
)))
(assert
 (forall ((m Poly) (d Dcr) (t Type)) (!
   (=>
    (has_type m (MUTREF d t))
    (has_type (mut_ref_future% m) t)
   )
   :pattern ((has_type m (MUTREF d t)) (mut_ref_future% m))
   :qid prelude_mut_ref_future_has_type
   :skolemid skolem_prelude_mut_ref_future_has_type
)))
(assert
 (forall ((m Poly) (d Dcr) (t Type) (arg Poly)) (!
   (=>
    (and
     (has_type m (MUTREF d t))
     (has_type arg t)
    )
    (has_type (mut_ref_update_current% m arg) (MUTREF d t))
   )
   :pattern ((has_type m (MUTREF d t)) (mut_ref_update_current% m arg))
   :qid prelude_mut_ref_update_has_type
   :skolemid skolem_prelude_mut_ref_update_has_type
)))
(assert
 (forall ((d Dcr)) (!
   (=>
    (sized d)
    (sized (DST d))
   )
   :pattern ((sized (DST d)))
   :qid prelude_sized_decorate_struct_inherit
   :skolemid skolem_prelude_sized_decorate_struct_inherit
)))
(assert
 (forall ((d Dcr)) (!
   (sized (REF d))
   :pattern ((sized (REF d)))
   :qid prelude_sized_decorate_ref
   :skolemid skolem_prelude_sized_decorate_ref
)))
(assert
 (forall ((d Dcr) (t Type) (d2 Dcr)) (!
   (sized (BOX d t d2))
   :pattern ((sized (BOX d t d2)))
   :qid prelude_sized_decorate_box
   :skolemid skolem_prelude_sized_decorate_box
)))
(assert
 (forall ((d Dcr) (t Type) (d2 Dcr)) (!
   (sized (RC d t d2))
   :pattern ((sized (RC d t d2)))
   :qid prelude_sized_decorate_rc
   :skolemid skolem_prelude_sized_decorate_rc
)))
(assert
 (forall ((d Dcr) (t Type) (d2 Dcr)) (!
   (sized (ARC d t d2))
   :pattern ((sized (ARC d t d2)))
   :qid prelude_sized_decorate_arc
   :skolemid skolem_prelude_sized_decorate_arc
)))
(assert
 (forall ((d Dcr)) (!
   (sized (GHOST d))
   :pattern ((sized (GHOST d)))
   :qid prelude_sized_decorate_ghost
   :skolemid skolem_prelude_sized_decorate_ghost
)))
(assert
 (forall ((d Dcr)) (!
   (sized (TRACKED d))
   :pattern ((sized (TRACKED d)))
   :qid prelude_sized_decorate_tracked
   :skolemid skolem_prelude_sized_decorate_tracked
)))
(assert
 (forall ((d Dcr)) (!
   (sized (NEVER d))
   :pattern ((sized (NEVER d)))
   :qid prelude_sized_decorate_never
   :skolemid skolem_prelude_sized_decorate_never
)))
(assert
 (forall ((d Dcr)) (!
   (sized (CONST_PTR d))
   :pattern ((sized (CONST_PTR d)))
   :qid prelude_sized_decorate_const_ptr
   :skolemid skolem_prelude_sized_decorate_const_ptr
)))
(assert
 (sized $)
)
(assert
 (forall ((i Int)) (!
   (= i (const_int (CONST_INT i)))
   :pattern ((CONST_INT i))
   :qid prelude_type_id_const_int
   :skolemid skolem_prelude_type_id_const_int
)))
(assert
 (forall ((b Bool)) (!
   (= b (const_bool (CONST_BOOL b)))
   :pattern ((CONST_BOOL b))
   :qid prelude_type_id_const_bool
   :skolemid skolem_prelude_type_id_const_bool
)))
(assert
 (forall ((b Bool)) (!
   (has_type (B b) BOOL)
   :pattern ((has_type (B b) BOOL))
   :qid prelude_has_type_bool
   :skolemid skolem_prelude_has_type_bool
)))
(assert
 (forall ((r Real)) (!
   (has_type (R r) REAL)
   :pattern ((has_type (R r) REAL))
   :qid prelude_has_type_real
   :skolemid skolem_prelude_has_type_real
)))
(assert
 (forall ((x Poly) (t Type)) (!
   (and
    (has_type (as_type x t) t)
    (=>
     (has_type x t)
     (= x (as_type x t))
   ))
   :pattern ((as_type x t))
   :qid prelude_as_type
   :skolemid skolem_prelude_as_type
)))
(assert
 (forall ((x %%Function%%)) (!
   (= (mk_fun x) x)
   :pattern ((mk_fun x))
   :qid prelude_mk_fun
   :skolemid skolem_prelude_mk_fun
)))
(assert
 (forall ((x Bool)) (!
   (= x (%B (B x)))
   :pattern ((B x))
   :qid prelude_unbox_box_bool
   :skolemid skolem_prelude_unbox_box_bool
)))
(assert
 (forall ((x Int)) (!
   (= x (%I (I x)))
   :pattern ((I x))
   :qid prelude_unbox_box_int
   :skolemid skolem_prelude_unbox_box_int
)))
(assert
 (forall ((x Real)) (!
   (= x (%R (R x)))
   :pattern ((R x))
   :qid prelude_unbox_box_real
   :skolemid skolem_prelude_unbox_box_real
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x BOOL)
    (= x (B (%B x)))
   )
   :pattern ((has_type x BOOL))
   :qid prelude_box_unbox_bool
   :skolemid skolem_prelude_box_unbox_bool
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x INT)
    (= x (I (%I x)))
   )
   :pattern ((has_type x INT))
   :qid prelude_box_unbox_int
   :skolemid skolem_prelude_box_unbox_int
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x NAT)
    (= x (I (%I x)))
   )
   :pattern ((has_type x NAT))
   :qid prelude_box_unbox_nat
   :skolemid skolem_prelude_box_unbox_nat
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x USIZE)
    (= x (I (%I x)))
   )
   :pattern ((has_type x USIZE))
   :qid prelude_box_unbox_usize
   :skolemid skolem_prelude_box_unbox_usize
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x ISIZE)
    (= x (I (%I x)))
   )
   :pattern ((has_type x ISIZE))
   :qid prelude_box_unbox_isize
   :skolemid skolem_prelude_box_unbox_isize
)))
(assert
 (forall ((bits Int) (x Poly)) (!
   (=>
    (has_type x (UINT bits))
    (= x (I (%I x)))
   )
   :pattern ((has_type x (UINT bits)))
   :qid prelude_box_unbox_uint
   :skolemid skolem_prelude_box_unbox_uint
)))
(assert
 (forall ((bits Int) (x Poly)) (!
   (=>
    (has_type x (SINT bits))
    (= x (I (%I x)))
   )
   :pattern ((has_type x (SINT bits)))
   :qid prelude_box_unbox_sint
   :skolemid skolem_prelude_box_unbox_sint
)))
(assert
 (forall ((bits Int) (x Poly)) (!
   (=>
    (has_type x (FLOAT bits))
    (= x (I (%I x)))
   )
   :pattern ((has_type x (FLOAT bits)))
   :qid prelude_box_unbox_float
   :skolemid skolem_prelude_box_unbox_float
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x CHAR)
    (= x (I (%I x)))
   )
   :pattern ((has_type x CHAR))
   :qid prelude_box_unbox_char
   :skolemid skolem_prelude_box_unbox_char
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x REAL)
    (= x (R (%R x)))
   )
   :pattern ((has_type x REAL))
   :qid prelude_box_unbox_real
   :skolemid skolem_prelude_box_unbox_real
)))
(declare-fun ext_eq (Bool Type Poly Poly) Bool)
(assert
 (forall ((deep Bool) (t Type) (x Poly) (y Poly)) (!
   (= (= x y) (ext_eq deep t x y))
   :pattern ((ext_eq deep t x y))
   :qid prelude_ext_eq
   :skolemid skolem_prelude_ext_eq
)))
(declare-const SZ Int)
(assert
 (or
  (= SZ 32)
  (= SZ 64)
))
(declare-fun uHi (Int) Int)
(declare-fun iLo (Int) Int)
(declare-fun iHi (Int) Int)
(assert
 (= (uHi 8) 256)
)
(assert
 (= (uHi 16) 65536)
)
(assert
 (= (uHi 32) 4294967296)
)
(assert
 (= (uHi 64) 18446744073709551616)
)
(assert
 (= (uHi 128) (+ 1 340282366920938463463374607431768211455))
)
(assert
 (= (iLo 8) (- 128))
)
(assert
 (= (iLo 16) (- 32768))
)
(assert
 (= (iLo 32) (- 2147483648))
)
(assert
 (= (iLo 64) (- 9223372036854775808))
)
(assert
 (= (iLo 128) (- 170141183460469231731687303715884105728))
)
(assert
 (= (iHi 8) 128)
)
(assert
 (= (iHi 16) 32768)
)
(assert
 (= (iHi 32) 2147483648)
)
(assert
 (= (iHi 64) 9223372036854775808)
)
(assert
 (= (iHi 128) 170141183460469231731687303715884105728)
)
(declare-fun nClip (Int) Int)
(declare-fun uClip (Int Int) Int)
(declare-fun iClip (Int Int) Int)
(declare-fun charClip (Int) Int)
(assert
 (forall ((i Int)) (!
   (and
    (<= 0 (nClip i))
    (=>
     (<= 0 i)
     (= i (nClip i))
   ))
   :pattern ((nClip i))
   :qid prelude_nat_clip
   :skolemid skolem_prelude_nat_clip
)))
(assert
 (forall ((bits Int) (i Int)) (!
   (and
    (<= 0 (uClip bits i))
    (< (uClip bits i) (uHi bits))
    (=>
     (and
      (<= 0 i)
      (< i (uHi bits))
     )
     (= i (uClip bits i))
   ))
   :pattern ((uClip bits i))
   :qid prelude_u_clip
   :skolemid skolem_prelude_u_clip
)))
(assert
 (forall ((bits Int) (i Int)) (!
   (and
    (<= (iLo bits) (iClip bits i))
    (< (iClip bits i) (iHi bits))
    (=>
     (and
      (<= (iLo bits) i)
      (< i (iHi bits))
     )
     (= i (iClip bits i))
   ))
   :pattern ((iClip bits i))
   :qid prelude_i_clip
   :skolemid skolem_prelude_i_clip
)))
(assert
 (forall ((i Int)) (!
   (and
    (or
     (and
      (<= 0 (charClip i))
      (<= (charClip i) 55295)
     )
     (and
      (<= 57344 (charClip i))
      (<= (charClip i) 1114111)
    ))
    (=>
     (or
      (and
       (<= 0 i)
       (<= i 55295)
      )
      (and
       (<= 57344 i)
       (<= i 1114111)
     ))
     (= i (charClip i))
   ))
   :pattern ((charClip i))
   :qid prelude_char_clip
   :skolemid skolem_prelude_char_clip
)))
(declare-fun uInv (Int Int) Bool)
(declare-fun iInv (Int Int) Bool)
(declare-fun charInv (Int) Bool)
(assert
 (forall ((bits Int) (i Int)) (!
   (= (uInv bits i) (and
     (<= 0 i)
     (< i (uHi bits))
   ))
   :pattern ((uInv bits i))
   :qid prelude_u_inv
   :skolemid skolem_prelude_u_inv
)))
(assert
 (forall ((bits Int) (i Int)) (!
   (= (iInv bits i) (and
     (<= (iLo bits) i)
     (< i (iHi bits))
   ))
   :pattern ((iInv bits i))
   :qid prelude_i_inv
   :skolemid skolem_prelude_i_inv
)))
(assert
 (forall ((i Int)) (!
   (= (charInv i) (or
     (and
      (<= 0 i)
      (<= i 55295)
     )
     (and
      (<= 57344 i)
      (<= i 1114111)
   )))
   :pattern ((charInv i))
   :qid prelude_char_inv
   :skolemid skolem_prelude_char_inv
)))
(assert
 (forall ((x Int)) (!
   (has_type (I x) INT)
   :pattern ((has_type (I x) INT))
   :qid prelude_has_type_int
   :skolemid skolem_prelude_has_type_int
)))
(assert
 (forall ((x Int)) (!
   (=>
    (<= 0 x)
    (has_type (I x) NAT)
   )
   :pattern ((has_type (I x) NAT))
   :qid prelude_has_type_nat
   :skolemid skolem_prelude_has_type_nat
)))
(assert
 (forall ((x Int)) (!
   (=>
    (uInv SZ x)
    (has_type (I x) USIZE)
   )
   :pattern ((has_type (I x) USIZE))
   :qid prelude_has_type_usize
   :skolemid skolem_prelude_has_type_usize
)))
(assert
 (forall ((x Int)) (!
   (=>
    (iInv SZ x)
    (has_type (I x) ISIZE)
   )
   :pattern ((has_type (I x) ISIZE))
   :qid prelude_has_type_isize
   :skolemid skolem_prelude_has_type_isize
)))
(assert
 (forall ((bits Int) (x Int)) (!
   (=>
    (uInv bits x)
    (has_type (I x) (UINT bits))
   )
   :pattern ((has_type (I x) (UINT bits)))
   :qid prelude_has_type_uint
   :skolemid skolem_prelude_has_type_uint
)))
(assert
 (forall ((bits Int) (x Int)) (!
   (=>
    (iInv bits x)
    (has_type (I x) (SINT bits))
   )
   :pattern ((has_type (I x) (SINT bits)))
   :qid prelude_has_type_sint
   :skolemid skolem_prelude_has_type_sint
)))
(assert
 (forall ((bits Int) (x Int)) (!
   (=>
    (uInv bits x)
    (has_type (I x) (FLOAT bits))
   )
   :pattern ((has_type (I x) (FLOAT bits)))
   :qid prelude_has_type_float
   :skolemid skolem_prelude_has_type_float
)))
(assert
 (forall ((x Int)) (!
   (=>
    (charInv x)
    (has_type (I x) CHAR)
   )
   :pattern ((has_type (I x) CHAR))
   :qid prelude_has_type_char
   :skolemid skolem_prelude_has_type_char
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x NAT)
    (<= 0 (%I x))
   )
   :pattern ((has_type x NAT))
   :qid prelude_unbox_int
   :skolemid skolem_prelude_unbox_int
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x USIZE)
    (uInv SZ (%I x))
   )
   :pattern ((has_type x USIZE))
   :qid prelude_unbox_usize
   :skolemid skolem_prelude_unbox_usize
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x CHAR)
    (charInv (%I x))
   )
   :pattern ((has_type x CHAR))
   :qid prelude_unbox_char
   :skolemid skolem_prelude_unbox_char
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x ISIZE)
    (iInv SZ (%I x))
   )
   :pattern ((has_type x ISIZE))
   :qid prelude_unbox_isize
   :skolemid skolem_prelude_unbox_isize
)))
(assert
 (forall ((bits Int) (x Poly)) (!
   (=>
    (has_type x (UINT bits))
    (uInv bits (%I x))
   )
   :pattern ((has_type x (UINT bits)))
   :qid prelude_unbox_uint
   :skolemid skolem_prelude_unbox_uint
)))
(assert
 (forall ((bits Int) (x Poly)) (!
   (=>
    (has_type x (SINT bits))
    (iInv bits (%I x))
   )
   :pattern ((has_type x (SINT bits)))
   :qid prelude_unbox_sint
   :skolemid skolem_prelude_unbox_sint
)))
(assert
 (forall ((bits Int) (x Poly)) (!
   (=>
    (has_type x (FLOAT bits))
    (uInv bits (%I x))
   )
   :pattern ((has_type x (FLOAT bits)))
   :qid prelude_unbox_float
   :skolemid skolem_prelude_unbox_float
)))
(declare-fun Add (Int Int) Int)
(declare-fun Sub (Int Int) Int)
(declare-fun Mul (Int Int) Int)
(declare-fun EucDiv (Int Int) Int)
(declare-fun EucMod (Int Int) Int)
(declare-fun RAdd (Real Real) Real)
(declare-fun RSub (Real Real) Real)
(declare-fun RMul (Real Real) Real)
(declare-fun RDiv (Real Real) Real)
(assert
 (forall ((x Int) (y Int)) (!
   (= (Add x y) (+ x y))
   :pattern ((Add x y))
   :qid prelude_add
   :skolemid skolem_prelude_add
)))
(assert
 (forall ((x Int) (y Int)) (!
   (= (Sub x y) (- x y))
   :pattern ((Sub x y))
   :qid prelude_sub
   :skolemid skolem_prelude_sub
)))
(assert
 (forall ((x Int) (y Int)) (!
   (= (Mul x y) (* x y))
   :pattern ((Mul x y))
   :qid prelude_mul
   :skolemid skolem_prelude_mul
)))
(assert
 (forall ((x Int) (y Int)) (!
   (= (EucDiv x y) (div x y))
   :pattern ((EucDiv x y))
   :qid prelude_eucdiv
   :skolemid skolem_prelude_eucdiv
)))
(assert
 (forall ((x Int) (y Int)) (!
   (= (EucMod x y) (mod x y))
   :pattern ((EucMod x y))
   :qid prelude_eucmod
   :skolemid skolem_prelude_eucmod
)))
(assert
 (forall ((x Real) (y Real)) (!
   (= (RAdd x y) (+ x y))
   :pattern ((RAdd x y))
   :qid prelude_radd
   :skolemid skolem_prelude_radd
)))
(assert
 (forall ((x Real) (y Real)) (!
   (= (RSub x y) (- x y))
   :pattern ((RSub x y))
   :qid prelude_rsub
   :skolemid skolem_prelude_rsub
)))
(assert
 (forall ((x Real) (y Real)) (!
   (= (RMul x y) (* x y))
   :pattern ((RMul x y))
   :qid prelude_rmul
   :skolemid skolem_prelude_rmul
)))
(assert
 (forall ((x Real) (y Real)) (!
   (= (RDiv x y) (/ x y))
   :pattern ((RDiv x y))
   :qid prelude_rdiv
   :skolemid skolem_prelude_rdiv
)))
(assert
 (forall ((x Int) (y Int)) (!
   (=>
    (and
     (<= 0 x)
     (<= 0 y)
    )
    (<= 0 (Mul x y))
   )
   :pattern ((Mul x y))
   :qid prelude_mul_nats
   :skolemid skolem_prelude_mul_nats
)))
(assert
 (forall ((x Int) (y Int)) (!
   (=>
    (and
     (<= 0 x)
     (< 0 y)
    )
    (and
     (<= 0 (EucDiv x y))
     (<= (EucDiv x y) x)
   ))
   :pattern ((EucDiv x y))
   :qid prelude_div_unsigned_in_bounds
   :skolemid skolem_prelude_div_unsigned_in_bounds
)))
(assert
 (forall ((x Int) (y Int)) (!
   (=>
    (and
     (<= 0 x)
     (< 0 y)
    )
    (and
     (<= 0 (EucMod x y))
     (< (EucMod x y) y)
   ))
   :pattern ((EucMod x y))
   :qid prelude_mod_unsigned_in_bounds
   :skolemid skolem_prelude_mod_unsigned_in_bounds
)))
(declare-fun bitxor (Poly Poly) Int)
(declare-fun bitand (Poly Poly) Int)
(declare-fun bitor (Poly Poly) Int)
(declare-fun bitshr (Poly Poly) Int)
(declare-fun bitshl (Poly Poly) Int)
(declare-fun bitnot (Poly) Int)
(assert
 (forall ((x Poly) (y Poly) (bits Int)) (!
   (=>
    (and
     (uInv bits (%I x))
     (uInv bits (%I y))
    )
    (uInv bits (bitxor x y))
   )
   :pattern ((uClip bits (bitxor x y)))
   :qid prelude_bit_xor_u_inv
   :skolemid skolem_prelude_bit_xor_u_inv
)))
(assert
 (forall ((x Poly) (y Poly) (bits Int)) (!
   (=>
    (and
     (iInv bits (%I x))
     (iInv bits (%I y))
    )
    (iInv bits (bitxor x y))
   )
   :pattern ((iClip bits (bitxor x y)))
   :qid prelude_bit_xor_i_inv
   :skolemid skolem_prelude_bit_xor_i_inv
)))
(assert
 (forall ((x Poly) (y Poly) (bits Int)) (!
   (=>
    (and
     (uInv bits (%I x))
     (uInv bits (%I y))
    )
    (uInv bits (bitor x y))
   )
   :pattern ((uClip bits (bitor x y)))
   :qid prelude_bit_or_u_inv
   :skolemid skolem_prelude_bit_or_u_inv
)))
(assert
 (forall ((x Poly) (y Poly) (bits Int)) (!
   (=>
    (and
     (iInv bits (%I x))
     (iInv bits (%I y))
    )
    (iInv bits (bitor x y))
   )
   :pattern ((iClip bits (bitor x y)))
   :qid prelude_bit_or_i_inv
   :skolemid skolem_prelude_bit_or_i_inv
)))
(assert
 (forall ((x Poly) (y Poly) (bits Int)) (!
   (=>
    (and
     (uInv bits (%I x))
     (uInv bits (%I y))
    )
    (uInv bits (bitand x y))
   )
   :pattern ((uClip bits (bitand x y)))
   :qid prelude_bit_and_u_inv
   :skolemid skolem_prelude_bit_and_u_inv
)))
(assert
 (forall ((x Poly) (y Poly) (bits Int)) (!
   (=>
    (and
     (iInv bits (%I x))
     (iInv bits (%I y))
    )
    (iInv bits (bitand x y))
   )
   :pattern ((iClip bits (bitand x y)))
   :qid prelude_bit_and_i_inv
   :skolemid skolem_prelude_bit_and_i_inv
)))
(assert
 (forall ((x Poly) (y Poly) (bits Int)) (!
   (=>
    (and
     (uInv bits (%I x))
     (<= 0 (%I y))
    )
    (uInv bits (bitshr x y))
   )
   :pattern ((uClip bits (bitshr x y)))
   :qid prelude_bit_shr_u_inv
   :skolemid skolem_prelude_bit_shr_u_inv
)))
(assert
 (forall ((x Poly) (y Poly) (bits Int)) (!
   (=>
    (and
     (iInv bits (%I x))
     (<= 0 (%I y))
    )
    (iInv bits (bitshr x y))
   )
   :pattern ((iClip bits (bitshr x y)))
   :qid prelude_bit_shr_i_inv
   :skolemid skolem_prelude_bit_shr_i_inv
)))
(declare-fun singular_mod (Int Int) Int)
(assert
 (forall ((x Int) (y Int)) (!
   (=>
    (not (= y 0))
    (= (EucMod x y) (singular_mod x y))
   )
   :pattern ((singular_mod x y))
   :qid prelude_singularmod
   :skolemid skolem_prelude_singularmod
)))
(declare-fun has_resolved (Dcr Type Poly) Bool)
(declare-fun closure_req (Type Dcr Type Poly Poly) Bool)
(declare-fun closure_ens (Type Dcr Type Poly Poly Poly) Bool)
(declare-fun default_ens (Type Dcr Type Poly Poly Poly) Bool)
(declare-fun height (Poly) Height)
(declare-fun height_lt (Height Height) Bool)
(declare-fun fun_from_recursive_field (Poly) Poly)
(declare-fun check_decrease_height (Poly Poly Bool) Bool)
(assert
 (forall ((cur Poly) (prev Poly) (otherwise Bool)) (!
   (= (check_decrease_height cur prev otherwise) (or
     (height_lt (height cur) (height prev))
     (and
      (= (height cur) (height prev))
      otherwise
   )))
   :pattern ((check_decrease_height cur prev otherwise))
   :qid prelude_check_decrease_height
   :skolemid skolem_prelude_check_decrease_height
)))
(assert
 (forall ((cur Int) (prev Int)) (!
   (= (height_lt (height (I cur)) (height (I prev))) (and
     (<= 0 cur)
     (< cur prev)
   ))
   :pattern ((height_lt (height (I cur)) (height (I prev))))
   :qid prelude_check_decrease_int_height
   :skolemid skolem_prelude_check_decrease_int_height
)))
(assert
 (forall ((x Height) (y Height)) (!
   (= (height_lt x y) (and
     ((_ partial-order 0) x y)
     (not (= x y))
   ))
   :pattern ((height_lt x y))
   :qid prelude_height_lt
   :skolemid skolem_prelude_height_lt
)))

;; MODULE 'module Chap35::OrderStatSelectMtEph::OrderStatSelectMtEph'
;; src/Chap35/OrderStatSelectMtEph.rs:493:5: 495:27 (#0)

;; query spun off because: spinoff_all

;; Fuel
(declare-const fuel%vstd!std_specs.num.usize_specs_tmp.impl&%0.eq_spec. FuelId)
(declare-const fuel%vstd!std_specs.array.impl&%0.eq_spec. FuelId)
(declare-const fuel%vstd!std_specs.array.impl&%1.eq_spec. FuelId)
(declare-const fuel%vstd!std_specs.array.impl&%2.eq_spec. FuelId)
(declare-const fuel%vstd!std_specs.array.impl&%3.eq_spec. FuelId)
(declare-const fuel%vstd!std_specs.array.impl&%4.eq_spec. FuelId)
(declare-const fuel%vstd!std_specs.cmp.impl&%2.eq_spec. FuelId)
(declare-const fuel%vstd!std_specs.cmp.impl&%3.eq_spec. FuelId)
(declare-const fuel%vstd!std_specs.cmp.impl&%9.eq_spec. FuelId)
(declare-const fuel%vstd!std_specs.cmp.impl&%12.eq_spec. FuelId)
(declare-const fuel%vstd!std_specs.cmp.impl&%15.eq_spec. FuelId)
(declare-const fuel%vstd!std_specs.option.impl&%0.arrow_0. FuelId)
(declare-const fuel%vstd!std_specs.option.is_some. FuelId)
(declare-const fuel%vstd!std_specs.option.is_none. FuelId)
(declare-const fuel%vstd!std_specs.option.spec_unwrap. FuelId)
(declare-const fuel%vstd!std_specs.option.impl&%1.eq_spec. FuelId)
(declare-const fuel%vstd!std_specs.slice.impl&%9.eq_spec. FuelId)
(declare-const fuel%vstd!std_specs.vec.impl&%0.spec_index. FuelId)
(declare-const fuel%vstd!std_specs.vec.axiom_spec_len. FuelId)
(declare-const fuel%vstd!std_specs.vec.vec_clone_trigger. FuelId)
(declare-const fuel%vstd!std_specs.vec.vec_clone_deep_view_proof. FuelId)
(declare-const fuel%vstd!std_specs.vec.axiom_vec_index_decreases. FuelId)
(declare-const fuel%vstd!std_specs.vec.impl&%2.eq_spec. FuelId)
(declare-const fuel%vstd!std_specs.vec.axiom_vec_has_resolved. FuelId)
(declare-const fuel%vstd!std_specs.vec.axiom_vec_decreases_to_view. FuelId)
(declare-const fuel%vstd!array.array_view. FuelId)
(declare-const fuel%vstd!array.impl&%0.view. FuelId)
(declare-const fuel%vstd!array.impl&%1.deep_view. FuelId)
(declare-const fuel%vstd!array.impl&%2.spec_index. FuelId)
(declare-const fuel%vstd!array.lemma_array_index. FuelId)
(declare-const fuel%vstd!array.array_len_matches_n. FuelId)
(declare-const fuel%vstd!array.axiom_array_ext_equal. FuelId)
(declare-const fuel%vstd!array.axiom_array_has_resolved. FuelId)
(declare-const fuel%vstd!array.axiom_array_decreases_to_seq. FuelId)
(declare-const fuel%vstd!array.lemma_array_index_decreases. FuelId)
(declare-const fuel%vstd!function.axiom_fn_mut_call_requires. FuelId)
(declare-const fuel%vstd!function.axiom_fn_mut_call_ensures. FuelId)
(declare-const fuel%vstd!multiset.impl&%0.insert. FuelId)
(declare-const fuel%vstd!multiset.axiom_multiset_singleton. FuelId)
(declare-const fuel%vstd!multiset.axiom_multiset_singleton_different. FuelId)
(declare-const fuel%vstd!multiset.axiom_multiset_add. FuelId)
(declare-const fuel%vstd!multiset.axiom_multiset_ext_equal. FuelId)
(declare-const fuel%vstd!multiset.axiom_multiset_ext_equal_deep. FuelId)
(declare-const fuel%vstd!multiset.axiom_len_singleton. FuelId)
(declare-const fuel%vstd!multiset.axiom_len_add. FuelId)
(declare-const fuel%vstd!multiset.axiom_count_le_len. FuelId)
(declare-const fuel%vstd!pervasive.impl&%0.requires. FuelId)
(declare-const fuel%vstd!pervasive.impl&%0.ensures. FuelId)
(declare-const fuel%vstd!pervasive.strictly_cloned. FuelId)
(declare-const fuel%vstd!pervasive.cloned. FuelId)
(declare-const fuel%vstd!raw_ptr.impl&%3.view. FuelId)
(declare-const fuel%vstd!raw_ptr.ptrs_mut_eq. FuelId)
(declare-const fuel%vstd!raw_ptr.ptrs_mut_eq_sized. FuelId)
(declare-const fuel%vstd!relations.reflexive. FuelId)
(declare-const fuel%vstd!relations.antisymmetric. FuelId)
(declare-const fuel%vstd!relations.strongly_connected. FuelId)
(declare-const fuel%vstd!relations.transitive. FuelId)
(declare-const fuel%vstd!relations.total_ordering. FuelId)
(declare-const fuel%vstd!relations.sorted_by. FuelId)
(declare-const fuel%vstd!seq.impl&%2.spec_index. FuelId)
(declare-const fuel%vstd!seq.impl&%2.take. FuelId)
(declare-const fuel%vstd!seq.impl&%2.skip. FuelId)
(declare-const fuel%vstd!seq.impl&%2.spec_add. FuelId)
(declare-const fuel%vstd!seq.lemma_seq_index_decreases. FuelId)
(declare-const fuel%vstd!seq.lemma_seq_subrange_decreases. FuelId)
(declare-const fuel%vstd!seq.lemma_seq_empty. FuelId)
(declare-const fuel%vstd!seq.lemma_seq_new_len. FuelId)
(declare-const fuel%vstd!seq.lemma_seq_new_index. FuelId)
(declare-const fuel%vstd!seq.lemma_seq_push_len. FuelId)
(declare-const fuel%vstd!seq.lemma_seq_push_index_same. FuelId)
(declare-const fuel%vstd!seq.lemma_seq_push_index_different. FuelId)
(declare-const fuel%vstd!seq.lemma_seq_ext_equal. FuelId)
(declare-const fuel%vstd!seq.lemma_seq_ext_equal_deep. FuelId)
(declare-const fuel%vstd!seq.lemma_seq_subrange_len. FuelId)
(declare-const fuel%vstd!seq.lemma_seq_subrange_index. FuelId)
(declare-const fuel%vstd!seq.lemma_seq_two_subranges_index. FuelId)
(declare-const fuel%vstd!seq.lemma_seq_add_len. FuelId)
(declare-const fuel%vstd!seq.lemma_seq_add_index1. FuelId)
(declare-const fuel%vstd!seq.lemma_seq_add_index2. FuelId)
(declare-const fuel%vstd!seq_lib.impl&%0.map. FuelId)
(declare-const fuel%vstd!seq_lib.impl&%0.add_empty_left. FuelId)
(declare-const fuel%vstd!seq_lib.impl&%0.add_empty_right. FuelId)
(declare-const fuel%vstd!seq_lib.impl&%0.push_distributes_over_add. FuelId)
(declare-const fuel%vstd!seq_lib.impl&%0.contains. FuelId)
(declare-const fuel%vstd!seq_lib.impl&%0.drop_last. FuelId)
(declare-const fuel%vstd!seq_lib.to_multiset_build. FuelId)
(declare-const fuel%vstd!seq_lib.to_multiset_len. FuelId)
(declare-const fuel%vstd!seq_lib.to_multiset_contains. FuelId)
(declare-const fuel%vstd!seq_lib.lemma_multiset_commutative. FuelId)
(declare-const fuel%vstd!seq_lib.lemma_seq_contains. FuelId)
(declare-const fuel%vstd!seq_lib.lemma_seq_empty_contains_nothing. FuelId)
(declare-const fuel%vstd!seq_lib.lemma_seq_empty_equality. FuelId)
(declare-const fuel%vstd!seq_lib.lemma_seq_concat_contains_all_elements. FuelId)
(declare-const fuel%vstd!seq_lib.lemma_seq_contains_after_push. FuelId)
(declare-const fuel%vstd!seq_lib.lemma_seq_subrange_elements. FuelId)
(declare-const fuel%vstd!seq_lib.lemma_seq_take_len. FuelId)
(declare-const fuel%vstd!seq_lib.lemma_seq_take_contains. FuelId)
(declare-const fuel%vstd!seq_lib.lemma_seq_take_index. FuelId)
(declare-const fuel%vstd!seq_lib.lemma_seq_skip_len. FuelId)
(declare-const fuel%vstd!seq_lib.lemma_seq_skip_contains. FuelId)
(declare-const fuel%vstd!seq_lib.lemma_seq_skip_index. FuelId)
(declare-const fuel%vstd!seq_lib.lemma_seq_skip_index2. FuelId)
(declare-const fuel%vstd!seq_lib.lemma_seq_append_take_skip. FuelId)
(declare-const fuel%vstd!seq_lib.lemma_seq_skip_build_commut. FuelId)
(declare-const fuel%vstd!seq_lib.lemma_seq_skip_nothing. FuelId)
(declare-const fuel%vstd!seq_lib.lemma_seq_take_nothing. FuelId)
(declare-const fuel%vstd!slice.impl&%1.deep_view. FuelId)
(declare-const fuel%vstd!slice.impl&%2.spec_index. FuelId)
(declare-const fuel%vstd!slice.axiom_spec_len. FuelId)
(declare-const fuel%vstd!slice.len%returns_clause_autospec. FuelId)
(declare-const fuel%vstd!slice.axiom_slice_ext_equal. FuelId)
(declare-const fuel%vstd!slice.axiom_slice_has_resolved. FuelId)
(declare-const fuel%vstd!slice.axiom_slice_decreases_to_seq. FuelId)
(declare-const fuel%vstd!slice.lemma_slice_index_decreases. FuelId)
(declare-const fuel%vstd!view.impl&%0.view. FuelId)
(declare-const fuel%vstd!view.impl&%1.deep_view. FuelId)
(declare-const fuel%vstd!view.impl&%2.view. FuelId)
(declare-const fuel%vstd!view.impl&%3.deep_view. FuelId)
(declare-const fuel%vstd!view.impl&%4.view. FuelId)
(declare-const fuel%vstd!view.impl&%5.deep_view. FuelId)
(declare-const fuel%vstd!view.impl&%6.view. FuelId)
(declare-const fuel%vstd!view.impl&%7.deep_view. FuelId)
(declare-const fuel%vstd!view.impl&%9.deep_view. FuelId)
(declare-const fuel%vstd!view.impl&%14.view. FuelId)
(declare-const fuel%vstd!view.impl&%15.deep_view. FuelId)
(declare-const fuel%vstd!view.impl&%16.view. FuelId)
(declare-const fuel%vstd!view.impl&%17.deep_view. FuelId)
(declare-const fuel%vstd!view.impl&%18.view. FuelId)
(declare-const fuel%vstd!view.impl&%19.deep_view. FuelId)
(declare-const fuel%vstd!view.impl&%30.view. FuelId)
(declare-const fuel%vstd!view.impl&%31.deep_view. FuelId)
(declare-const fuel%vstd!view.impl&%46.view. FuelId)
(declare-const fuel%vstd!view.impl&%47.deep_view. FuelId)
(declare-const fuel%vstd!view.impl&%48.view. FuelId)
(declare-const fuel%vstd!view.impl&%49.deep_view. FuelId)
(declare-const fuel%vstd!view.impl&%50.view. FuelId)
(declare-const fuel%vstd!view.impl&%51.deep_view. FuelId)
(declare-const fuel%lib!vstdplus.total_order.total_order.impl&%5.le. FuelId)
(declare-const fuel%lib!vstdplus.feq.feq.obeys_feq_clone. FuelId)
(declare-const fuel%lib!vstdplus.feq.feq.axiom_cloned_implies_eq. FuelId)
(declare-const fuel%lib!vstdplus.feq.feq.axiom_cloned_implies_eq_owned. FuelId)
(declare-const fuel%lib!vstdplus.feq.feq.axiom_strictly_cloned_implies_eq. FuelId)
(declare-const fuel%lib!vstdplus.feq.feq.axiom_strictly_cloned_implies_eq_owned. FuelId)
(declare-const fuel%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.impl&%2.view. FuelId)
(declare-const fuel%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.impl&%3.spec_len. FuelId)
(declare-const fuel%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.impl&%3.spec_index. FuelId)
(declare-const fuel%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.impl&%7.eq_spec. FuelId)
(declare-const fuel%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.impl&%2.view.
 FuelId
)
(declare-const fuel%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.impl&%3.spec_arrayseqmtephslice_wf.
 FuelId
)
(declare-const fuel%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.impl&%3.spec_len.
 FuelId
)
(declare-const fuel%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.impl&%3.spec_index.
 FuelId
)
(declare-const fuel%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.impl&%5.eq_spec.
 FuelId
)
(declare-const fuel%lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.spec_leq.
 FuelId
)
(declare-const fuel%lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.spec_kth.
 FuelId
)
(declare-const fuel%lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.spec_const_seq.
 FuelId
)
(declare-const fuel%lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.spec_slice_elements.
 FuelId
)
(declare-const fuel%vstd!array.group_array_axioms. FuelId)
(declare-const fuel%vstd!function.group_function_axioms. FuelId)
(declare-const fuel%vstd!imap.group_imap_lemmas. FuelId)
(declare-const fuel%vstd!iset.group_iset_lemmas. FuelId)
(declare-const fuel%vstd!laws_cmp.group_laws_cmp. FuelId)
(declare-const fuel%vstd!laws_eq.bool_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.u8_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.i8_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.u16_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.i16_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.u32_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.i32_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.u64_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.i64_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.u128_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.i128_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.usize_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.isize_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_1_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_2_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_3_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_4_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_5_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_6_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_7_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_8_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_9_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_10_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_11_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_12_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.group_laws_eq. FuelId)
(declare-const fuel%vstd!layout.group_align_properties. FuelId)
(declare-const fuel%vstd!layout.group_layout_axioms. FuelId)
(declare-const fuel%vstd!map.group_map_lemmas. FuelId)
(declare-const fuel%vstd!multiset.group_multiset_axioms. FuelId)
(declare-const fuel%vstd!mut_ref.group_mut_ref_axioms. FuelId)
(declare-const fuel%vstd!raw_ptr.group_raw_ptr_axioms. FuelId)
(declare-const fuel%vstd!seq.group_seq_axioms. FuelId)
(declare-const fuel%vstd!seq.group_seq_lemmas. FuelId)
(declare-const fuel%vstd!seq_lib.group_filter_ensures. FuelId)
(declare-const fuel%vstd!seq_lib.group_seq_lib_default. FuelId)
(declare-const fuel%vstd!seq_lib.group_to_multiset_ensures. FuelId)
(declare-const fuel%vstd!seq_lib.group_seq_properties. FuelId)
(declare-const fuel%vstd!set.group_set_lemmas. FuelId)
(declare-const fuel%vstd!set_lib.group_set_lib_default. FuelId)
(declare-const fuel%vstd!slice.group_slice_axioms. FuelId)
(declare-const fuel%vstd!string.group_string_axioms. FuelId)
(declare-const fuel%vstd!std_specs.bits.group_bits_axioms. FuelId)
(declare-const fuel%vstd!std_specs.control_flow.group_control_flow_axioms. FuelId)
(declare-const fuel%vstd!std_specs.fmt.group_fmt_axioms. FuelId)
(declare-const fuel%vstd!std_specs.iter.group_iter_axioms. FuelId)
(declare-const fuel%vstd!std_specs.manually_drop.group_manually_drop_axioms. FuelId)
(declare-const fuel%vstd!std_specs.btree.group_btree_axioms. FuelId)
(declare-const fuel%vstd!std_specs.hash.group_hash_axioms. FuelId)
(declare-const fuel%vstd!std_specs.range.group_range_axioms. FuelId)
(declare-const fuel%vstd!std_specs.vec.group_vec_axioms. FuelId)
(declare-const fuel%vstd!std_specs.vecdeque.group_vec_dequeue_axioms. FuelId)
(declare-const fuel%vstd!std_specs.nonzero.group_nonzero_axioms. FuelId)
(declare-const fuel%vstd!group_vstd_default. FuelId)
(declare-const fuel%lib!vstdplus.feq.feq.group_feq_axioms. FuelId)
(assert
 (distinct fuel%vstd!std_specs.num.usize_specs_tmp.impl&%0.eq_spec. fuel%vstd!std_specs.array.impl&%0.eq_spec.
  fuel%vstd!std_specs.array.impl&%1.eq_spec. fuel%vstd!std_specs.array.impl&%2.eq_spec.
  fuel%vstd!std_specs.array.impl&%3.eq_spec. fuel%vstd!std_specs.array.impl&%4.eq_spec.
  fuel%vstd!std_specs.cmp.impl&%2.eq_spec. fuel%vstd!std_specs.cmp.impl&%3.eq_spec.
  fuel%vstd!std_specs.cmp.impl&%9.eq_spec. fuel%vstd!std_specs.cmp.impl&%12.eq_spec.
  fuel%vstd!std_specs.cmp.impl&%15.eq_spec. fuel%vstd!std_specs.option.impl&%0.arrow_0.
  fuel%vstd!std_specs.option.is_some. fuel%vstd!std_specs.option.is_none. fuel%vstd!std_specs.option.spec_unwrap.
  fuel%vstd!std_specs.option.impl&%1.eq_spec. fuel%vstd!std_specs.slice.impl&%9.eq_spec.
  fuel%vstd!std_specs.vec.impl&%0.spec_index. fuel%vstd!std_specs.vec.axiom_spec_len.
  fuel%vstd!std_specs.vec.vec_clone_trigger. fuel%vstd!std_specs.vec.vec_clone_deep_view_proof.
  fuel%vstd!std_specs.vec.axiom_vec_index_decreases. fuel%vstd!std_specs.vec.impl&%2.eq_spec.
  fuel%vstd!std_specs.vec.axiom_vec_has_resolved. fuel%vstd!std_specs.vec.axiom_vec_decreases_to_view.
  fuel%vstd!array.array_view. fuel%vstd!array.impl&%0.view. fuel%vstd!array.impl&%1.deep_view.
  fuel%vstd!array.impl&%2.spec_index. fuel%vstd!array.lemma_array_index. fuel%vstd!array.array_len_matches_n.
  fuel%vstd!array.axiom_array_ext_equal. fuel%vstd!array.axiom_array_has_resolved.
  fuel%vstd!array.axiom_array_decreases_to_seq. fuel%vstd!array.lemma_array_index_decreases.
  fuel%vstd!function.axiom_fn_mut_call_requires. fuel%vstd!function.axiom_fn_mut_call_ensures.
  fuel%vstd!multiset.impl&%0.insert. fuel%vstd!multiset.axiom_multiset_singleton. fuel%vstd!multiset.axiom_multiset_singleton_different.
  fuel%vstd!multiset.axiom_multiset_add. fuel%vstd!multiset.axiom_multiset_ext_equal.
  fuel%vstd!multiset.axiom_multiset_ext_equal_deep. fuel%vstd!multiset.axiom_len_singleton.
  fuel%vstd!multiset.axiom_len_add. fuel%vstd!multiset.axiom_count_le_len. fuel%vstd!pervasive.impl&%0.requires.
  fuel%vstd!pervasive.impl&%0.ensures. fuel%vstd!pervasive.strictly_cloned. fuel%vstd!pervasive.cloned.
  fuel%vstd!raw_ptr.impl&%3.view. fuel%vstd!raw_ptr.ptrs_mut_eq. fuel%vstd!raw_ptr.ptrs_mut_eq_sized.
  fuel%vstd!relations.reflexive. fuel%vstd!relations.antisymmetric. fuel%vstd!relations.strongly_connected.
  fuel%vstd!relations.transitive. fuel%vstd!relations.total_ordering. fuel%vstd!relations.sorted_by.
  fuel%vstd!seq.impl&%2.spec_index. fuel%vstd!seq.impl&%2.take. fuel%vstd!seq.impl&%2.skip.
  fuel%vstd!seq.impl&%2.spec_add. fuel%vstd!seq.lemma_seq_index_decreases. fuel%vstd!seq.lemma_seq_subrange_decreases.
  fuel%vstd!seq.lemma_seq_empty. fuel%vstd!seq.lemma_seq_new_len. fuel%vstd!seq.lemma_seq_new_index.
  fuel%vstd!seq.lemma_seq_push_len. fuel%vstd!seq.lemma_seq_push_index_same. fuel%vstd!seq.lemma_seq_push_index_different.
  fuel%vstd!seq.lemma_seq_ext_equal. fuel%vstd!seq.lemma_seq_ext_equal_deep. fuel%vstd!seq.lemma_seq_subrange_len.
  fuel%vstd!seq.lemma_seq_subrange_index. fuel%vstd!seq.lemma_seq_two_subranges_index.
  fuel%vstd!seq.lemma_seq_add_len. fuel%vstd!seq.lemma_seq_add_index1. fuel%vstd!seq.lemma_seq_add_index2.
  fuel%vstd!seq_lib.impl&%0.map. fuel%vstd!seq_lib.impl&%0.add_empty_left. fuel%vstd!seq_lib.impl&%0.add_empty_right.
  fuel%vstd!seq_lib.impl&%0.push_distributes_over_add. fuel%vstd!seq_lib.impl&%0.contains.
  fuel%vstd!seq_lib.impl&%0.drop_last. fuel%vstd!seq_lib.to_multiset_build. fuel%vstd!seq_lib.to_multiset_len.
  fuel%vstd!seq_lib.to_multiset_contains. fuel%vstd!seq_lib.lemma_multiset_commutative.
  fuel%vstd!seq_lib.lemma_seq_contains. fuel%vstd!seq_lib.lemma_seq_empty_contains_nothing.
  fuel%vstd!seq_lib.lemma_seq_empty_equality. fuel%vstd!seq_lib.lemma_seq_concat_contains_all_elements.
  fuel%vstd!seq_lib.lemma_seq_contains_after_push. fuel%vstd!seq_lib.lemma_seq_subrange_elements.
  fuel%vstd!seq_lib.lemma_seq_take_len. fuel%vstd!seq_lib.lemma_seq_take_contains.
  fuel%vstd!seq_lib.lemma_seq_take_index. fuel%vstd!seq_lib.lemma_seq_skip_len. fuel%vstd!seq_lib.lemma_seq_skip_contains.
  fuel%vstd!seq_lib.lemma_seq_skip_index. fuel%vstd!seq_lib.lemma_seq_skip_index2.
  fuel%vstd!seq_lib.lemma_seq_append_take_skip. fuel%vstd!seq_lib.lemma_seq_skip_build_commut.
  fuel%vstd!seq_lib.lemma_seq_skip_nothing. fuel%vstd!seq_lib.lemma_seq_take_nothing.
  fuel%vstd!slice.impl&%1.deep_view. fuel%vstd!slice.impl&%2.spec_index. fuel%vstd!slice.axiom_spec_len.
  fuel%vstd!slice.len%returns_clause_autospec. fuel%vstd!slice.axiom_slice_ext_equal.
  fuel%vstd!slice.axiom_slice_has_resolved. fuel%vstd!slice.axiom_slice_decreases_to_seq.
  fuel%vstd!slice.lemma_slice_index_decreases. fuel%vstd!view.impl&%0.view. fuel%vstd!view.impl&%1.deep_view.
  fuel%vstd!view.impl&%2.view. fuel%vstd!view.impl&%3.deep_view. fuel%vstd!view.impl&%4.view.
  fuel%vstd!view.impl&%5.deep_view. fuel%vstd!view.impl&%6.view. fuel%vstd!view.impl&%7.deep_view.
  fuel%vstd!view.impl&%9.deep_view. fuel%vstd!view.impl&%14.view. fuel%vstd!view.impl&%15.deep_view.
  fuel%vstd!view.impl&%16.view. fuel%vstd!view.impl&%17.deep_view. fuel%vstd!view.impl&%18.view.
  fuel%vstd!view.impl&%19.deep_view. fuel%vstd!view.impl&%30.view. fuel%vstd!view.impl&%31.deep_view.
  fuel%vstd!view.impl&%46.view. fuel%vstd!view.impl&%47.deep_view. fuel%vstd!view.impl&%48.view.
  fuel%vstd!view.impl&%49.deep_view. fuel%vstd!view.impl&%50.view. fuel%vstd!view.impl&%51.deep_view.
  fuel%lib!vstdplus.total_order.total_order.impl&%5.le. fuel%lib!vstdplus.feq.feq.obeys_feq_clone.
  fuel%lib!vstdplus.feq.feq.axiom_cloned_implies_eq. fuel%lib!vstdplus.feq.feq.axiom_cloned_implies_eq_owned.
  fuel%lib!vstdplus.feq.feq.axiom_strictly_cloned_implies_eq. fuel%lib!vstdplus.feq.feq.axiom_strictly_cloned_implies_eq_owned.
  fuel%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.impl&%2.view. fuel%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.impl&%3.spec_len.
  fuel%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.impl&%3.spec_index. fuel%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.impl&%7.eq_spec.
  fuel%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.impl&%2.view. fuel%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.impl&%3.spec_arrayseqmtephslice_wf.
  fuel%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.impl&%3.spec_len. fuel%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.impl&%3.spec_index.
  fuel%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.impl&%5.eq_spec. fuel%lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.spec_leq.
  fuel%lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.spec_kth. fuel%lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.spec_const_seq.
  fuel%lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.spec_slice_elements. fuel%vstd!array.group_array_axioms.
  fuel%vstd!function.group_function_axioms. fuel%vstd!imap.group_imap_lemmas. fuel%vstd!iset.group_iset_lemmas.
  fuel%vstd!laws_cmp.group_laws_cmp. fuel%vstd!laws_eq.bool_laws.group_laws_eq. fuel%vstd!laws_eq.u8_laws.group_laws_eq.
  fuel%vstd!laws_eq.i8_laws.group_laws_eq. fuel%vstd!laws_eq.u16_laws.group_laws_eq.
  fuel%vstd!laws_eq.i16_laws.group_laws_eq. fuel%vstd!laws_eq.u32_laws.group_laws_eq.
  fuel%vstd!laws_eq.i32_laws.group_laws_eq. fuel%vstd!laws_eq.u64_laws.group_laws_eq.
  fuel%vstd!laws_eq.i64_laws.group_laws_eq. fuel%vstd!laws_eq.u128_laws.group_laws_eq.
  fuel%vstd!laws_eq.i128_laws.group_laws_eq. fuel%vstd!laws_eq.usize_laws.group_laws_eq.
  fuel%vstd!laws_eq.isize_laws.group_laws_eq. fuel%vstd!laws_eq.tuple_1_laws.group_laws_eq.
  fuel%vstd!laws_eq.tuple_2_laws.group_laws_eq. fuel%vstd!laws_eq.tuple_3_laws.group_laws_eq.
  fuel%vstd!laws_eq.tuple_4_laws.group_laws_eq. fuel%vstd!laws_eq.tuple_5_laws.group_laws_eq.
  fuel%vstd!laws_eq.tuple_6_laws.group_laws_eq. fuel%vstd!laws_eq.tuple_7_laws.group_laws_eq.
  fuel%vstd!laws_eq.tuple_8_laws.group_laws_eq. fuel%vstd!laws_eq.tuple_9_laws.group_laws_eq.
  fuel%vstd!laws_eq.tuple_10_laws.group_laws_eq. fuel%vstd!laws_eq.tuple_11_laws.group_laws_eq.
  fuel%vstd!laws_eq.tuple_12_laws.group_laws_eq. fuel%vstd!laws_eq.group_laws_eq. fuel%vstd!layout.group_align_properties.
  fuel%vstd!layout.group_layout_axioms. fuel%vstd!map.group_map_lemmas. fuel%vstd!multiset.group_multiset_axioms.
  fuel%vstd!mut_ref.group_mut_ref_axioms. fuel%vstd!raw_ptr.group_raw_ptr_axioms. fuel%vstd!seq.group_seq_axioms.
  fuel%vstd!seq.group_seq_lemmas. fuel%vstd!seq_lib.group_filter_ensures. fuel%vstd!seq_lib.group_seq_lib_default.
  fuel%vstd!seq_lib.group_to_multiset_ensures. fuel%vstd!seq_lib.group_seq_properties.
  fuel%vstd!set.group_set_lemmas. fuel%vstd!set_lib.group_set_lib_default. fuel%vstd!slice.group_slice_axioms.
  fuel%vstd!string.group_string_axioms. fuel%vstd!std_specs.bits.group_bits_axioms.
  fuel%vstd!std_specs.control_flow.group_control_flow_axioms. fuel%vstd!std_specs.fmt.group_fmt_axioms.
  fuel%vstd!std_specs.iter.group_iter_axioms. fuel%vstd!std_specs.manually_drop.group_manually_drop_axioms.
  fuel%vstd!std_specs.btree.group_btree_axioms. fuel%vstd!std_specs.hash.group_hash_axioms.
  fuel%vstd!std_specs.range.group_range_axioms. fuel%vstd!std_specs.vec.group_vec_axioms.
  fuel%vstd!std_specs.vecdeque.group_vec_dequeue_axioms. fuel%vstd!std_specs.nonzero.group_nonzero_axioms.
  fuel%vstd!group_vstd_default. fuel%lib!vstdplus.feq.feq.group_feq_axioms.
))
(assert
 (=>
  (fuel_bool_default fuel%vstd!array.group_array_axioms.)
  (and
   (fuel_bool_default fuel%vstd!array.array_len_matches_n.)
   (fuel_bool_default fuel%vstd!array.lemma_array_index.)
   (fuel_bool_default fuel%vstd!array.axiom_array_ext_equal.)
   (fuel_bool_default fuel%vstd!array.axiom_array_has_resolved.)
   (fuel_bool_default fuel%vstd!array.axiom_array_decreases_to_seq.)
   (fuel_bool_default fuel%vstd!array.lemma_array_index_decreases.)
)))
(assert
 (=>
  (fuel_bool_default fuel%vstd!function.group_function_axioms.)
  (and
   (fuel_bool_default fuel%vstd!function.axiom_fn_mut_call_requires.)
   (fuel_bool_default fuel%vstd!function.axiom_fn_mut_call_ensures.)
)))
(assert
 (=>
  (fuel_bool_default fuel%vstd!laws_eq.group_laws_eq.)
  (and
   (fuel_bool_default fuel%vstd!laws_eq.bool_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.u8_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.i8_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.u16_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.i16_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.u32_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.i32_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.u64_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.i64_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.u128_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.i128_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.usize_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.isize_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_1_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_2_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_3_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_4_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_5_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_6_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_7_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_8_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_9_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_10_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_11_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_12_laws.group_laws_eq.)
)))
(assert
 (=>
  (fuel_bool_default fuel%vstd!layout.group_layout_axioms.)
  (fuel_bool_default fuel%vstd!layout.group_align_properties.)
))
(assert
 (=>
  (fuel_bool_default fuel%vstd!multiset.group_multiset_axioms.)
  (and
   (fuel_bool_default fuel%vstd!multiset.axiom_multiset_singleton.)
   (fuel_bool_default fuel%vstd!multiset.axiom_multiset_singleton_different.)
   (fuel_bool_default fuel%vstd!multiset.axiom_multiset_add.)
   (fuel_bool_default fuel%vstd!multiset.axiom_multiset_ext_equal.)
   (fuel_bool_default fuel%vstd!multiset.axiom_multiset_ext_equal_deep.)
   (fuel_bool_default fuel%vstd!multiset.axiom_len_singleton.)
   (fuel_bool_default fuel%vstd!multiset.axiom_len_add.)
   (fuel_bool_default fuel%vstd!multiset.axiom_count_le_len.)
)))
(assert
 (=>
  (fuel_bool_default fuel%vstd!raw_ptr.group_raw_ptr_axioms.)
  (and
   (fuel_bool_default fuel%vstd!raw_ptr.ptrs_mut_eq.)
   (fuel_bool_default fuel%vstd!raw_ptr.ptrs_mut_eq_sized.)
)))
(assert
 (=>
  (fuel_bool_default fuel%vstd!seq.group_seq_axioms.)
  (and
   (fuel_bool_default fuel%vstd!seq.lemma_seq_index_decreases.)
   (fuel_bool_default fuel%vstd!seq.lemma_seq_subrange_decreases.)
   (fuel_bool_default fuel%vstd!seq.lemma_seq_empty.)
   (fuel_bool_default fuel%vstd!seq.lemma_seq_new_len.)
   (fuel_bool_default fuel%vstd!seq.lemma_seq_new_index.)
   (fuel_bool_default fuel%vstd!seq.lemma_seq_push_len.)
   (fuel_bool_default fuel%vstd!seq.lemma_seq_push_index_same.)
   (fuel_bool_default fuel%vstd!seq.lemma_seq_push_index_different.)
   (fuel_bool_default fuel%vstd!seq.lemma_seq_ext_equal.)
   (fuel_bool_default fuel%vstd!seq.lemma_seq_ext_equal_deep.)
   (fuel_bool_default fuel%vstd!seq.lemma_seq_subrange_len.)
   (fuel_bool_default fuel%vstd!seq.lemma_seq_subrange_index.)
   (fuel_bool_default fuel%vstd!seq.lemma_seq_two_subranges_index.)
   (fuel_bool_default fuel%vstd!seq.lemma_seq_add_len.)
   (fuel_bool_default fuel%vstd!seq.lemma_seq_add_index1.)
   (fuel_bool_default fuel%vstd!seq.lemma_seq_add_index2.)
)))
(assert
 (=>
  (fuel_bool_default fuel%vstd!seq.group_seq_lemmas.)
  (and
   (fuel_bool_default fuel%vstd!seq.lemma_seq_index_decreases.)
   (fuel_bool_default fuel%vstd!seq.lemma_seq_subrange_decreases.)
   (fuel_bool_default fuel%vstd!seq.lemma_seq_empty.)
   (fuel_bool_default fuel%vstd!seq.lemma_seq_new_len.)
   (fuel_bool_default fuel%vstd!seq.lemma_seq_new_index.)
   (fuel_bool_default fuel%vstd!seq.lemma_seq_push_len.)
   (fuel_bool_default fuel%vstd!seq.lemma_seq_push_index_same.)
   (fuel_bool_default fuel%vstd!seq.lemma_seq_push_index_different.)
   (fuel_bool_default fuel%vstd!seq.lemma_seq_ext_equal.)
   (fuel_bool_default fuel%vstd!seq.lemma_seq_ext_equal_deep.)
   (fuel_bool_default fuel%vstd!seq.lemma_seq_subrange_len.)
   (fuel_bool_default fuel%vstd!seq.lemma_seq_subrange_index.)
   (fuel_bool_default fuel%vstd!seq.lemma_seq_two_subranges_index.)
   (fuel_bool_default fuel%vstd!seq.lemma_seq_add_len.)
   (fuel_bool_default fuel%vstd!seq.lemma_seq_add_index1.)
   (fuel_bool_default fuel%vstd!seq.lemma_seq_add_index2.)
)))
(assert
 (=>
  (fuel_bool_default fuel%vstd!seq_lib.group_seq_lib_default.)
  (and
   (fuel_bool_default fuel%vstd!seq_lib.group_filter_ensures.)
   (fuel_bool_default fuel%vstd!seq_lib.impl&%0.add_empty_left.)
   (fuel_bool_default fuel%vstd!seq_lib.impl&%0.add_empty_right.)
   (fuel_bool_default fuel%vstd!seq_lib.impl&%0.push_distributes_over_add.)
)))
(assert
 (=>
  (fuel_bool_default fuel%vstd!seq_lib.group_to_multiset_ensures.)
  (and
   (fuel_bool_default fuel%vstd!seq_lib.to_multiset_build.)
   (fuel_bool_default fuel%vstd!seq_lib.to_multiset_len.)
   (fuel_bool_default fuel%vstd!seq_lib.to_multiset_contains.)
)))
(assert
 (=>
  (fuel_bool_default fuel%vstd!seq_lib.group_seq_properties.)
  (and
   (fuel_bool_default fuel%vstd!seq_lib.lemma_seq_contains.)
   (fuel_bool_default fuel%vstd!seq_lib.lemma_seq_empty_contains_nothing.)
   (fuel_bool_default fuel%vstd!seq_lib.lemma_seq_empty_equality.)
   (fuel_bool_default fuel%vstd!seq_lib.lemma_seq_concat_contains_all_elements.)
   (fuel_bool_default fuel%vstd!seq_lib.lemma_seq_contains_after_push.)
   (fuel_bool_default fuel%vstd!seq_lib.lemma_seq_subrange_elements.)
   (fuel_bool_default fuel%vstd!seq_lib.lemma_seq_take_len.)
   (fuel_bool_default fuel%vstd!seq_lib.lemma_seq_take_contains.)
   (fuel_bool_default fuel%vstd!seq_lib.lemma_seq_take_index.)
   (fuel_bool_default fuel%vstd!seq_lib.lemma_seq_skip_len.)
   (fuel_bool_default fuel%vstd!seq_lib.lemma_seq_skip_contains.)
   (fuel_bool_default fuel%vstd!seq_lib.lemma_seq_skip_index.)
   (fuel_bool_default fuel%vstd!seq_lib.lemma_seq_skip_index2.)
   (fuel_bool_default fuel%vstd!seq_lib.lemma_seq_append_take_skip.)
   (fuel_bool_default fuel%vstd!seq_lib.lemma_seq_skip_build_commut.)
   (fuel_bool_default fuel%vstd!seq_lib.lemma_seq_skip_nothing.)
   (fuel_bool_default fuel%vstd!seq_lib.lemma_seq_take_nothing.)
   (fuel_bool_default fuel%vstd!seq_lib.group_to_multiset_ensures.)
)))
(assert
 (=>
  (fuel_bool_default fuel%vstd!slice.group_slice_axioms.)
  (and
   (fuel_bool_default fuel%vstd!slice.axiom_spec_len.)
   (fuel_bool_default fuel%vstd!slice.axiom_slice_ext_equal.)
   (fuel_bool_default fuel%vstd!slice.axiom_slice_has_resolved.)
   (fuel_bool_default fuel%vstd!slice.axiom_slice_decreases_to_seq.)
   (fuel_bool_default fuel%vstd!slice.lemma_slice_index_decreases.)
)))
(assert
 (=>
  (fuel_bool_default fuel%vstd!std_specs.vec.group_vec_axioms.)
  (and
   (fuel_bool_default fuel%vstd!std_specs.vec.axiom_spec_len.)
   (fuel_bool_default fuel%vstd!std_specs.vec.axiom_vec_index_decreases.)
   (fuel_bool_default fuel%vstd!std_specs.vec.vec_clone_deep_view_proof.)
   (fuel_bool_default fuel%vstd!std_specs.vec.axiom_vec_has_resolved.)
   (fuel_bool_default fuel%vstd!std_specs.vec.axiom_vec_decreases_to_view.)
)))
(assert
 (fuel_bool_default fuel%vstd!group_vstd_default.)
)
(assert
 (=>
  (fuel_bool_default fuel%vstd!group_vstd_default.)
  (and
   (fuel_bool_default fuel%vstd!seq.group_seq_lemmas.)
   (fuel_bool_default fuel%vstd!seq_lib.group_seq_lib_default.)
   (fuel_bool_default fuel%vstd!map.group_map_lemmas.)
   (fuel_bool_default fuel%vstd!set.group_set_lemmas.)
   (fuel_bool_default fuel%vstd!imap.group_imap_lemmas.)
   (fuel_bool_default fuel%vstd!iset.group_iset_lemmas.)
   (fuel_bool_default fuel%vstd!set_lib.group_set_lib_default.)
   (fuel_bool_default fuel%vstd!multiset.group_multiset_axioms.)
   (fuel_bool_default fuel%vstd!function.group_function_axioms.)
   (fuel_bool_default fuel%vstd!laws_eq.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_cmp.group_laws_cmp.)
   (fuel_bool_default fuel%vstd!slice.group_slice_axioms.)
   (fuel_bool_default fuel%vstd!array.group_array_axioms.)
   (fuel_bool_default fuel%vstd!string.group_string_axioms.)
   (fuel_bool_default fuel%vstd!raw_ptr.group_raw_ptr_axioms.)
   (fuel_bool_default fuel%vstd!layout.group_layout_axioms.)
   (fuel_bool_default fuel%vstd!mut_ref.group_mut_ref_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.range.group_range_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.bits.group_bits_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.control_flow.group_control_flow_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.fmt.group_fmt_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.manually_drop.group_manually_drop_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.iter.group_iter_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.vec.group_vec_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.vecdeque.group_vec_dequeue_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.hash.group_hash_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.btree.group_btree_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.nonzero.group_nonzero_axioms.)
)))
(assert
 (=>
  (fuel_bool_default fuel%lib!vstdplus.feq.feq.group_feq_axioms.)
  (and
   (fuel_bool_default fuel%lib!vstdplus.feq.feq.axiom_cloned_implies_eq.)
   (fuel_bool_default fuel%lib!vstdplus.feq.feq.axiom_cloned_implies_eq_owned.)
   (fuel_bool_default fuel%lib!vstdplus.feq.feq.axiom_strictly_cloned_implies_eq.)
   (fuel_bool_default fuel%lib!vstdplus.feq.feq.axiom_strictly_cloned_implies_eq_owned.)
)))
(assert
 (and
  (fuel_bool_default fuel%vstd!std_specs.vec.group_vec_axioms.)
  (fuel_bool_default fuel%vstd!seq.group_seq_axioms.)
  (fuel_bool_default fuel%vstd!seq_lib.group_to_multiset_ensures.)
  (fuel_bool_default fuel%vstd!multiset.group_multiset_axioms.)
  (fuel_bool_default fuel%lib!vstdplus.feq.feq.group_feq_axioms.)
  (fuel_bool_default fuel%vstd!seq_lib.group_seq_properties.)
))

;; Trait-Decls
(declare-fun tr_bound%vstd!array.ArrayAdditionalSpecFns. (Dcr Type Dcr Type) Bool)
(declare-fun tr_bound%vstd!pervasive.FnWithRequiresEnsures. (Dcr Type Dcr Type Dcr
  Type
 ) Bool
)
(declare-fun tr_bound%vstd!slice.SliceAdditionalSpecFns. (Dcr Type Dcr Type) Bool)
(declare-fun tr_bound%vstd!view.View. (Dcr Type) Bool)
(declare-fun tr_bound%vstd!view.DeepView. (Dcr Type) Bool)
(declare-fun tr_bound%core!clone.Clone. (Dcr Type) Bool)
(declare-fun tr_bound%core!marker.Copy. (Dcr Type) Bool)
(declare-fun tr_bound%core!cmp.PartialEq. (Dcr Type Dcr Type) Bool)
(declare-fun tr_bound%core!cmp.Eq. (Dcr Type) Bool)
(declare-fun tr_bound%vstd!std_specs.cmp.PartialEqSpec. (Dcr Type Dcr Type) Bool)
(declare-fun tr_bound%core!marker.Tuple. (Dcr Type) Bool)
(declare-fun tr_bound%core!ops.function.FnOnce. (Dcr Type Dcr Type) Bool)
(declare-fun tr_bound%core!ops.function.FnMut. (Dcr Type Dcr Type) Bool)
(declare-fun tr_bound%core!ops.function.Fn. (Dcr Type Dcr Type) Bool)
(declare-fun tr_bound%core!alloc.Allocator. (Dcr Type) Bool)
(declare-fun tr_bound%core!fmt.Debug. (Dcr Type) Bool)
(declare-fun tr_bound%core!fmt.Display. (Dcr Type) Bool)
(declare-fun tr_bound%vstd!std_specs.option.OptionAdditionalFns. (Dcr Type Dcr Type)
 Bool
)
(declare-fun tr_bound%vstd!std_specs.vec.VecAdditionalSpecFns. (Dcr Type Dcr Type)
 Bool
)
(declare-fun tr_bound%lib!Types.Types.StT. (Dcr Type) Bool)
(declare-fun tr_bound%lib!Concurrency.Concurrency.StTInMtT. (Dcr Type) Bool)
(declare-fun tr_bound%lib!vstdplus.total_order.total_order.TotalOrder. (Dcr Type)
 Bool
)
(declare-fun tr_bound%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphTrait. (
  Dcr Type Dcr Type
 ) Bool
)
(declare-fun tr_bound%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceTrait.
 (Dcr Type Dcr Type) Bool
)
(declare-fun tr_bound%lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.OrderStatSelectMtEphTrait.
 (Dcr Type Dcr Type) Bool
)

;; Associated-Type-Decls
(declare-fun proj%%vstd!view.View./V (Dcr Type) Dcr)
(declare-fun proj%vstd!view.View./V (Dcr Type) Type)
(declare-fun proj%%vstd!view.DeepView./V (Dcr Type) Dcr)
(declare-fun proj%vstd!view.DeepView./V (Dcr Type) Type)
(declare-fun proj%%core!ops.function.FnOnce./Output (Dcr Type Dcr Type) Dcr)
(declare-fun proj%core!ops.function.FnOnce./Output (Dcr Type Dcr Type) Type)

;; Datatypes
(declare-fun pointee_metadata% (Dcr) Type)
(declare-fun pointee_metadata%% (Dcr) Dcr)
(assert
 (forall ((d Dcr)) (!
   (=>
    (sized d)
    (= (pointee_metadata% d) TYPE%tuple%0.)
   )
   :pattern ((pointee_metadata% d))
   :qid prelude_project_pointee_metadata_sized
   :skolemid skolem_prelude_project_pointee_metadata_sized
)))
(assert
 (forall ((d Dcr)) (!
   (=>
    (sized d)
    (= (pointee_metadata%% d) $)
   )
   :pattern ((pointee_metadata%% d))
   :qid prelude_project_pointee_metadata_decoration_sized
   :skolemid skolem_prelude_project_pointee_metadata_decoration_sized
)))
(assert
 (= (pointee_metadata% $slice) USIZE)
)
(assert
 (= (pointee_metadata%% $slice) $)
)
(assert
 (forall ((d Dcr)) (!
   (= (pointee_metadata% (DST d)) (pointee_metadata% d))
   :pattern ((pointee_metadata% (DST d)))
   :qid prelude_project_pointee_metadata_decorate_struct_inherit
   :skolemid skolem_prelude_project_pointee_metadata_decorate_struct_inherit
)))
(assert
 (forall ((d Dcr)) (!
   (= (pointee_metadata%% (DST d)) (pointee_metadata%% d))
   :pattern ((pointee_metadata%% (DST d)))
   :qid prelude_project_pointee_metadata_decoration_decorate_struct_inherit
   :skolemid skolem_prelude_project_pointee_metadata_decoration_decorate_struct_inherit
)))
(declare-sort alloc!alloc.Global. 0)
(declare-sort vstd!raw_ptr.Provenance. 0)
(declare-datatypes ((core!cmp.Ordering. 0) (core!option.Option. 0) (vstd!raw_ptr.PtrData.
   0
  ) (lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS. 0) (lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS.
   0
  ) (tuple%0. 0) (tuple%1. 0) (tuple%2. 0) (tuple%3. 0)
 ) (((core!cmp.Ordering./Less) (core!cmp.Ordering./Equal) (core!cmp.Ordering./Greater))
  ((core!option.Option./None) (core!option.Option./Some (core!option.Option./Some/?0 Poly)))
  ((vstd!raw_ptr.PtrData./PtrData (vstd!raw_ptr.PtrData./PtrData/?addr Int) (vstd!raw_ptr.PtrData./PtrData/?provenance
     vstd!raw_ptr.Provenance.
    ) (vstd!raw_ptr.PtrData./PtrData/?metadata Poly)
   )
  ) ((lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS./ArraySeqMtEphS (lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS./ArraySeqMtEphS/?seq
     Poly
   ))
  ) ((lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS./ArraySeqMtEphSliceS
    (lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS./ArraySeqMtEphSliceS/?data
     Poly
    ) (lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS./ArraySeqMtEphSliceS/?start
     Int
    ) (lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS./ArraySeqMtEphSliceS/?len
     Int
   ))
  ) ((tuple%0./tuple%0)) ((tuple%1./tuple%1 (tuple%1./tuple%1/?0 Poly))) ((tuple%2./tuple%2
    (tuple%2./tuple%2/?0 Poly) (tuple%2./tuple%2/?1 Poly)
   )
  ) ((tuple%3./tuple%3 (tuple%3./tuple%3/?0 Poly) (tuple%3./tuple%3/?1 Poly) (tuple%3./tuple%3/?2
     Poly
)))))
(declare-fun core!option.Option./Some/0 (Dcr Type core!option.Option.) Poly)
(declare-fun vstd!raw_ptr.PtrData./PtrData/addr (vstd!raw_ptr.PtrData.) Int)
(declare-fun vstd!raw_ptr.PtrData./PtrData/provenance (vstd!raw_ptr.PtrData.) vstd!raw_ptr.Provenance.)
(declare-fun vstd!raw_ptr.PtrData./PtrData/metadata (vstd!raw_ptr.PtrData.) Poly)
(declare-fun lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS./ArraySeqMtEphS/seq
 (lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS.) Poly
)
(declare-fun lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS./ArraySeqMtEphSliceS/data
 (lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS.) Poly
)
(declare-fun lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS./ArraySeqMtEphSliceS/start
 (lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS.) Int
)
(declare-fun lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS./ArraySeqMtEphSliceS/len
 (lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS.) Int
)
(declare-fun tuple%1./tuple%1/0 (tuple%1.) Poly)
(declare-fun tuple%2./tuple%2/0 (tuple%2.) Poly)
(declare-fun tuple%2./tuple%2/1 (tuple%2.) Poly)
(declare-fun tuple%3./tuple%3/0 (tuple%3.) Poly)
(declare-fun tuple%3./tuple%3/1 (tuple%3.) Poly)
(declare-fun tuple%3./tuple%3/2 (tuple%3.) Poly)
(declare-fun TYPE%fun%1. (Dcr Type Dcr Type) Type)
(declare-fun TYPE%fun%2. (Dcr Type Dcr Type Dcr Type) Type)
(declare-const TYPE%alloc!alloc.Global. Type)
(declare-const TYPE%core!cmp.Ordering. Type)
(declare-fun TYPE%core!option.Option. (Dcr Type) Type)
(declare-fun TYPE%alloc!vec.Vec. (Dcr Type Dcr Type) Type)
(declare-fun TYPE%vstd!multiset.Multiset. (Dcr Type) Type)
(declare-const TYPE%vstd!raw_ptr.Provenance. Type)
(declare-fun TYPE%vstd!raw_ptr.PtrData. (Dcr Type) Type)
(declare-fun TYPE%vstd!seq.Seq. (Dcr Type) Type)
(declare-fun TYPE%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS. (Dcr Type)
 Type
)
(declare-fun TYPE%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS.
 (Dcr Type) Type
)
(declare-fun TYPE%tuple%1. (Dcr Type) Type)
(declare-fun TYPE%tuple%2. (Dcr Type Dcr Type) Type)
(declare-fun TYPE%tuple%3. (Dcr Type Dcr Type Dcr Type) Type)
(declare-fun TYPE%anonymous_closure%697. (Dcr Type) Type)
(declare-fun TYPE%anonymous_closure%702. (Dcr Type) Type)
(declare-fun FNDEF%core!clone.Clone.clone. (Dcr Type) Type)
(declare-fun Poly%fun%1. (%%Function%%) Poly)
(declare-fun %Poly%fun%1. (Poly) %%Function%%)
(declare-fun Poly%fun%2. (%%Function%%) Poly)
(declare-fun %Poly%fun%2. (Poly) %%Function%%)
(declare-fun Poly%array%. (%%Function%%) Poly)
(declare-fun %Poly%array%. (Poly) %%Function%%)
(declare-fun Poly%alloc!alloc.Global. (alloc!alloc.Global.) Poly)
(declare-fun %Poly%alloc!alloc.Global. (Poly) alloc!alloc.Global.)
(declare-fun Poly%vstd!raw_ptr.Provenance. (vstd!raw_ptr.Provenance.) Poly)
(declare-fun %Poly%vstd!raw_ptr.Provenance. (Poly) vstd!raw_ptr.Provenance.)
(declare-fun Poly%core!cmp.Ordering. (core!cmp.Ordering.) Poly)
(declare-fun %Poly%core!cmp.Ordering. (Poly) core!cmp.Ordering.)
(declare-fun Poly%core!option.Option. (core!option.Option.) Poly)
(declare-fun %Poly%core!option.Option. (Poly) core!option.Option.)
(declare-fun Poly%vstd!raw_ptr.PtrData. (vstd!raw_ptr.PtrData.) Poly)
(declare-fun %Poly%vstd!raw_ptr.PtrData. (Poly) vstd!raw_ptr.PtrData.)
(declare-fun Poly%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS. (lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS.)
 Poly
)
(declare-fun %Poly%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS. (Poly) lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS.)
(declare-fun Poly%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS.
 (lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS.) Poly
)
(declare-fun %Poly%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS.
 (Poly) lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS.
)
(declare-fun Poly%tuple%0. (tuple%0.) Poly)
(declare-fun %Poly%tuple%0. (Poly) tuple%0.)
(declare-fun Poly%tuple%1. (tuple%1.) Poly)
(declare-fun %Poly%tuple%1. (Poly) tuple%1.)
(declare-fun Poly%tuple%2. (tuple%2.) Poly)
(declare-fun %Poly%tuple%2. (Poly) tuple%2.)
(declare-fun Poly%tuple%3. (tuple%3.) Poly)
(declare-fun %Poly%tuple%3. (Poly) tuple%3.)
(assert
 (forall ((x %%Function%%)) (!
   (= x (%Poly%fun%1. (Poly%fun%1. x)))
   :pattern ((Poly%fun%1. x))
   :qid internal_crate__fun__1_box_axiom_definition
   :skolemid skolem_internal_crate__fun__1_box_axiom_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%fun%1. T%0&. T%0& T%1&. T%1&))
    (= x (Poly%fun%1. (%Poly%fun%1. x)))
   )
   :pattern ((has_type x (TYPE%fun%1. T%0&. T%0& T%1&. T%1&)))
   :qid internal_crate__fun__1_unbox_axiom_definition
   :skolemid skolem_internal_crate__fun__1_unbox_axiom_definition
)))
(declare-fun %%apply%%0 (%%Function%% Poly) Poly)
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (x %%Function%%)) (!
   (=>
    (forall ((T%0 Poly)) (!
      (=>
       (has_type T%0 T%0&)
       (has_type (%%apply%%0 x T%0) T%1&)
      )
      :pattern ((has_type (%%apply%%0 x T%0) T%1&))
      :qid internal_crate__fun__1_constructor_inner_definition
      :skolemid skolem_internal_crate__fun__1_constructor_inner_definition
    ))
    (has_type (Poly%fun%1. (mk_fun x)) (TYPE%fun%1. T%0&. T%0& T%1&. T%1&))
   )
   :pattern ((has_type (Poly%fun%1. (mk_fun x)) (TYPE%fun%1. T%0&. T%0& T%1&. T%1&)))
   :qid internal_crate__fun__1_constructor_definition
   :skolemid skolem_internal_crate__fun__1_constructor_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (T%0 Poly) (x %%Function%%))
  (!
   (=>
    (and
     (has_type (Poly%fun%1. x) (TYPE%fun%1. T%0&. T%0& T%1&. T%1&))
     (has_type T%0 T%0&)
    )
    (has_type (%%apply%%0 x T%0) T%1&)
   )
   :pattern ((%%apply%%0 x T%0) (has_type (Poly%fun%1. x) (TYPE%fun%1. T%0&. T%0& T%1&.
      T%1&
   )))
   :qid internal_crate__fun__1_apply_definition
   :skolemid skolem_internal_crate__fun__1_apply_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (T%0 Poly) (x %%Function%%))
  (!
   (=>
    (and
     (has_type (Poly%fun%1. x) (TYPE%fun%1. T%0&. T%0& T%1&. T%1&))
     (has_type T%0 T%0&)
    )
    (height_lt (height (%%apply%%0 x T%0)) (height (fun_from_recursive_field (Poly%fun%1.
        (mk_fun x)
   )))))
   :pattern ((height (%%apply%%0 x T%0)) (has_type (Poly%fun%1. x) (TYPE%fun%1. T%0&. T%0&
      T%1&. T%1&
   )))
   :qid internal_crate__fun__1_height_apply_definition
   :skolemid skolem_internal_crate__fun__1_height_apply_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (deep Bool) (x Poly) (y Poly))
  (!
   (=>
    (and
     (has_type x (TYPE%fun%1. T%0&. T%0& T%1&. T%1&))
     (has_type y (TYPE%fun%1. T%0&. T%0& T%1&. T%1&))
     (forall ((T%0 Poly)) (!
       (=>
        (has_type T%0 T%0&)
        (ext_eq deep T%1& (%%apply%%0 (%Poly%fun%1. x) T%0) (%%apply%%0 (%Poly%fun%1. y) T%0))
       )
       :pattern ((ext_eq deep T%1& (%%apply%%0 (%Poly%fun%1. x) T%0) (%%apply%%0 (%Poly%fun%1.
           y
          ) T%0
       )))
       :qid internal_crate__fun__1_inner_ext_equal_definition
       :skolemid skolem_internal_crate__fun__1_inner_ext_equal_definition
    )))
    (ext_eq deep (TYPE%fun%1. T%0&. T%0& T%1&. T%1&) x y)
   )
   :pattern ((ext_eq deep (TYPE%fun%1. T%0&. T%0& T%1&. T%1&) x y))
   :qid internal_crate__fun__1_ext_equal_definition
   :skolemid skolem_internal_crate__fun__1_ext_equal_definition
)))
(assert
 (forall ((x %%Function%%)) (!
   (= x (%Poly%fun%2. (Poly%fun%2. x)))
   :pattern ((Poly%fun%2. x))
   :qid internal_crate__fun__2_box_axiom_definition
   :skolemid skolem_internal_crate__fun__2_box_axiom_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (T%2&. Dcr) (T%2& Type) (x
    Poly
   )
  ) (!
   (=>
    (has_type x (TYPE%fun%2. T%0&. T%0& T%1&. T%1& T%2&. T%2&))
    (= x (Poly%fun%2. (%Poly%fun%2. x)))
   )
   :pattern ((has_type x (TYPE%fun%2. T%0&. T%0& T%1&. T%1& T%2&. T%2&)))
   :qid internal_crate__fun__2_unbox_axiom_definition
   :skolemid skolem_internal_crate__fun__2_unbox_axiom_definition
)))
(declare-fun %%apply%%1 (%%Function%% Poly Poly) Poly)
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (T%2&. Dcr) (T%2& Type) (x
    %%Function%%
   )
  ) (!
   (=>
    (forall ((T%0 Poly) (T%1 Poly)) (!
      (=>
       (and
        (has_type T%0 T%0&)
        (has_type T%1 T%1&)
       )
       (has_type (%%apply%%1 x T%0 T%1) T%2&)
      )
      :pattern ((has_type (%%apply%%1 x T%0 T%1) T%2&))
      :qid internal_crate__fun__2_constructor_inner_definition
      :skolemid skolem_internal_crate__fun__2_constructor_inner_definition
    ))
    (has_type (Poly%fun%2. (mk_fun x)) (TYPE%fun%2. T%0&. T%0& T%1&. T%1& T%2&. T%2&))
   )
   :pattern ((has_type (Poly%fun%2. (mk_fun x)) (TYPE%fun%2. T%0&. T%0& T%1&. T%1& T%2&.
      T%2&
   )))
   :qid internal_crate__fun__2_constructor_definition
   :skolemid skolem_internal_crate__fun__2_constructor_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (T%2&. Dcr) (T%2& Type) (T%0
    Poly
   ) (T%1 Poly) (x %%Function%%)
  ) (!
   (=>
    (and
     (has_type (Poly%fun%2. x) (TYPE%fun%2. T%0&. T%0& T%1&. T%1& T%2&. T%2&))
     (has_type T%0 T%0&)
     (has_type T%1 T%1&)
    )
    (has_type (%%apply%%1 x T%0 T%1) T%2&)
   )
   :pattern ((%%apply%%1 x T%0 T%1) (has_type (Poly%fun%2. x) (TYPE%fun%2. T%0&. T%0& T%1&.
      T%1& T%2&. T%2&
   )))
   :qid internal_crate__fun__2_apply_definition
   :skolemid skolem_internal_crate__fun__2_apply_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (T%2&. Dcr) (T%2& Type) (T%0
    Poly
   ) (T%1 Poly) (x %%Function%%)
  ) (!
   (=>
    (and
     (has_type (Poly%fun%2. x) (TYPE%fun%2. T%0&. T%0& T%1&. T%1& T%2&. T%2&))
     (has_type T%0 T%0&)
     (has_type T%1 T%1&)
    )
    (height_lt (height (%%apply%%1 x T%0 T%1)) (height (fun_from_recursive_field (Poly%fun%2.
        (mk_fun x)
   )))))
   :pattern ((height (%%apply%%1 x T%0 T%1)) (has_type (Poly%fun%2. x) (TYPE%fun%2. T%0&.
      T%0& T%1&. T%1& T%2&. T%2&
   )))
   :qid internal_crate__fun__2_height_apply_definition
   :skolemid skolem_internal_crate__fun__2_height_apply_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (T%2&. Dcr) (T%2& Type) (deep
    Bool
   ) (x Poly) (y Poly)
  ) (!
   (=>
    (and
     (has_type x (TYPE%fun%2. T%0&. T%0& T%1&. T%1& T%2&. T%2&))
     (has_type y (TYPE%fun%2. T%0&. T%0& T%1&. T%1& T%2&. T%2&))
     (forall ((T%0 Poly) (T%1 Poly)) (!
       (=>
        (and
         (has_type T%0 T%0&)
         (has_type T%1 T%1&)
        )
        (ext_eq deep T%2& (%%apply%%1 (%Poly%fun%2. x) T%0 T%1) (%%apply%%1 (%Poly%fun%2. y)
          T%0 T%1
       )))
       :pattern ((ext_eq deep T%2& (%%apply%%1 (%Poly%fun%2. x) T%0 T%1) (%%apply%%1 (%Poly%fun%2.
           y
          ) T%0 T%1
       )))
       :qid internal_crate__fun__2_inner_ext_equal_definition
       :skolemid skolem_internal_crate__fun__2_inner_ext_equal_definition
    )))
    (ext_eq deep (TYPE%fun%2. T%0&. T%0& T%1&. T%1& T%2&. T%2&) x y)
   )
   :pattern ((ext_eq deep (TYPE%fun%2. T%0&. T%0& T%1&. T%1& T%2&. T%2&) x y))
   :qid internal_crate__fun__2_ext_equal_definition
   :skolemid skolem_internal_crate__fun__2_ext_equal_definition
)))
(assert
 (forall ((x %%Function%%)) (!
   (= x (%Poly%array%. (Poly%array%. x)))
   :pattern ((Poly%array%. x))
   :qid internal_crate__array___box_axiom_definition
   :skolemid skolem_internal_crate__array___box_axiom_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type) (x Poly)) (!
   (=>
    (has_type x (ARRAY T&. T& N&. N&))
    (= x (Poly%array%. (%Poly%array%. x)))
   )
   :pattern ((has_type x (ARRAY T&. T& N&. N&)))
   :qid internal_crate__array___unbox_axiom_definition
   :skolemid skolem_internal_crate__array___unbox_axiom_definition
)))
(assert
 (forall ((x alloc!alloc.Global.)) (!
   (= x (%Poly%alloc!alloc.Global. (Poly%alloc!alloc.Global. x)))
   :pattern ((Poly%alloc!alloc.Global. x))
   :qid internal_alloc__alloc__Global_box_axiom_definition
   :skolemid skolem_internal_alloc__alloc__Global_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%alloc!alloc.Global.)
    (= x (Poly%alloc!alloc.Global. (%Poly%alloc!alloc.Global. x)))
   )
   :pattern ((has_type x TYPE%alloc!alloc.Global.))
   :qid internal_alloc__alloc__Global_unbox_axiom_definition
   :skolemid skolem_internal_alloc__alloc__Global_unbox_axiom_definition
)))
(assert
 (forall ((x alloc!alloc.Global.)) (!
   (has_type (Poly%alloc!alloc.Global. x) TYPE%alloc!alloc.Global.)
   :pattern ((has_type (Poly%alloc!alloc.Global. x) TYPE%alloc!alloc.Global.))
   :qid internal_alloc__alloc__Global_has_type_always_definition
   :skolemid skolem_internal_alloc__alloc__Global_has_type_always_definition
)))
(assert
 (forall ((x vstd!raw_ptr.Provenance.)) (!
   (= x (%Poly%vstd!raw_ptr.Provenance. (Poly%vstd!raw_ptr.Provenance. x)))
   :pattern ((Poly%vstd!raw_ptr.Provenance. x))
   :qid internal_vstd__raw_ptr__Provenance_box_axiom_definition
   :skolemid skolem_internal_vstd__raw_ptr__Provenance_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%vstd!raw_ptr.Provenance.)
    (= x (Poly%vstd!raw_ptr.Provenance. (%Poly%vstd!raw_ptr.Provenance. x)))
   )
   :pattern ((has_type x TYPE%vstd!raw_ptr.Provenance.))
   :qid internal_vstd__raw_ptr__Provenance_unbox_axiom_definition
   :skolemid skolem_internal_vstd__raw_ptr__Provenance_unbox_axiom_definition
)))
(assert
 (forall ((x vstd!raw_ptr.Provenance.)) (!
   (has_type (Poly%vstd!raw_ptr.Provenance. x) TYPE%vstd!raw_ptr.Provenance.)
   :pattern ((has_type (Poly%vstd!raw_ptr.Provenance. x) TYPE%vstd!raw_ptr.Provenance.))
   :qid internal_vstd__raw_ptr__Provenance_has_type_always_definition
   :skolemid skolem_internal_vstd__raw_ptr__Provenance_has_type_always_definition
)))
(assert
 (forall ((x core!cmp.Ordering.)) (!
   (= x (%Poly%core!cmp.Ordering. (Poly%core!cmp.Ordering. x)))
   :pattern ((Poly%core!cmp.Ordering. x))
   :qid internal_core__cmp__Ordering_box_axiom_definition
   :skolemid skolem_internal_core__cmp__Ordering_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%core!cmp.Ordering.)
    (= x (Poly%core!cmp.Ordering. (%Poly%core!cmp.Ordering. x)))
   )
   :pattern ((has_type x TYPE%core!cmp.Ordering.))
   :qid internal_core__cmp__Ordering_unbox_axiom_definition
   :skolemid skolem_internal_core__cmp__Ordering_unbox_axiom_definition
)))
(assert
 (forall ((x core!cmp.Ordering.)) (!
   (has_type (Poly%core!cmp.Ordering. x) TYPE%core!cmp.Ordering.)
   :pattern ((has_type (Poly%core!cmp.Ordering. x) TYPE%core!cmp.Ordering.))
   :qid internal_core__cmp__Ordering_has_type_always_definition
   :skolemid skolem_internal_core__cmp__Ordering_has_type_always_definition
)))
(assert
 (forall ((x core!option.Option.)) (!
   (= x (%Poly%core!option.Option. (Poly%core!option.Option. x)))
   :pattern ((Poly%core!option.Option. x))
   :qid internal_core__option__Option_box_axiom_definition
   :skolemid skolem_internal_core__option__Option_box_axiom_definition
)))
(assert
 (forall ((V&. Dcr) (V& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%core!option.Option. V&. V&))
    (= x (Poly%core!option.Option. (%Poly%core!option.Option. x)))
   )
   :pattern ((has_type x (TYPE%core!option.Option. V&. V&)))
   :qid internal_core__option__Option_unbox_axiom_definition
   :skolemid skolem_internal_core__option__Option_unbox_axiom_definition
)))
(assert
 (forall ((V&. Dcr) (V& Type)) (!
   (has_type (Poly%core!option.Option. core!option.Option./None) (TYPE%core!option.Option.
     V&. V&
   ))
   :pattern ((has_type (Poly%core!option.Option. core!option.Option./None) (TYPE%core!option.Option.
      V&. V&
   )))
   :qid internal_core!option.Option./None_constructor_definition
   :skolemid skolem_internal_core!option.Option./None_constructor_definition
)))
(assert
 (forall ((V&. Dcr) (V& Type) (_0! Poly)) (!
   (=>
    (has_type _0! V&)
    (has_type (Poly%core!option.Option. (core!option.Option./Some _0!)) (TYPE%core!option.Option.
      V&. V&
   )))
   :pattern ((has_type (Poly%core!option.Option. (core!option.Option./Some _0!)) (TYPE%core!option.Option.
      V&. V&
   )))
   :qid internal_core!option.Option./Some_constructor_definition
   :skolemid skolem_internal_core!option.Option./Some_constructor_definition
)))
(assert
 (forall ((V&. Dcr) (V& Type) (x core!option.Option.)) (!
   (=>
    (is-core!option.Option./Some x)
    (= (core!option.Option./Some/0 V&. V& x) (core!option.Option./Some/?0 x))
   )
   :pattern ((core!option.Option./Some/0 V&. V& x))
   :qid internal_core!option.Option./Some/0_accessor_definition
   :skolemid skolem_internal_core!option.Option./Some/0_accessor_definition
)))
(assert
 (forall ((V&. Dcr) (V& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%core!option.Option. V&. V&))
    (has_type (core!option.Option./Some/0 V&. V& (%Poly%core!option.Option. x)) V&)
   )
   :pattern ((core!option.Option./Some/0 V&. V& (%Poly%core!option.Option. x)) (has_type
     x (TYPE%core!option.Option. V&. V&)
   ))
   :qid internal_core!option.Option./Some/0_invariant_definition
   :skolemid skolem_internal_core!option.Option./Some/0_invariant_definition
)))
(assert
 (forall ((V&. Dcr) (V& Type) (x core!option.Option.)) (!
   (=>
    (is-core!option.Option./Some x)
    (height_lt (height (core!option.Option./Some/0 V&. V& x)) (height (Poly%core!option.Option.
       x
   ))))
   :pattern ((height (core!option.Option./Some/0 V&. V& x)))
   :qid prelude_datatype_height_core!option.Option./Some/0
   :skolemid skolem_prelude_datatype_height_core!option.Option./Some/0
)))
(assert
 (forall ((V&. Dcr) (V& Type) (deep Bool) (x Poly) (y Poly)) (!
   (=>
    (and
     (has_type x (TYPE%core!option.Option. V&. V&))
     (has_type y (TYPE%core!option.Option. V&. V&))
     (is-core!option.Option./None (%Poly%core!option.Option. x))
     (is-core!option.Option./None (%Poly%core!option.Option. y))
    )
    (ext_eq deep (TYPE%core!option.Option. V&. V&) x y)
   )
   :pattern ((ext_eq deep (TYPE%core!option.Option. V&. V&) x y))
   :qid internal_core!option.Option./None_ext_equal_definition
   :skolemid skolem_internal_core!option.Option./None_ext_equal_definition
)))
(assert
 (forall ((V&. Dcr) (V& Type) (deep Bool) (x Poly) (y Poly)) (!
   (=>
    (and
     (has_type x (TYPE%core!option.Option. V&. V&))
     (has_type y (TYPE%core!option.Option. V&. V&))
     (is-core!option.Option./Some (%Poly%core!option.Option. x))
     (is-core!option.Option./Some (%Poly%core!option.Option. y))
     (ext_eq deep V& (core!option.Option./Some/0 V&. V& (%Poly%core!option.Option. x))
      (core!option.Option./Some/0 V&. V& (%Poly%core!option.Option. y))
    ))
    (ext_eq deep (TYPE%core!option.Option. V&. V&) x y)
   )
   :pattern ((ext_eq deep (TYPE%core!option.Option. V&. V&) x y))
   :qid internal_core!option.Option./Some_ext_equal_definition
   :skolemid skolem_internal_core!option.Option./Some_ext_equal_definition
)))
(assert
 (forall ((x vstd!raw_ptr.PtrData.)) (!
   (= x (%Poly%vstd!raw_ptr.PtrData. (Poly%vstd!raw_ptr.PtrData. x)))
   :pattern ((Poly%vstd!raw_ptr.PtrData. x))
   :qid internal_vstd__raw_ptr__PtrData_box_axiom_definition
   :skolemid skolem_internal_vstd__raw_ptr__PtrData_box_axiom_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%vstd!raw_ptr.PtrData. T&. T&))
    (= x (Poly%vstd!raw_ptr.PtrData. (%Poly%vstd!raw_ptr.PtrData. x)))
   )
   :pattern ((has_type x (TYPE%vstd!raw_ptr.PtrData. T&. T&)))
   :qid internal_vstd__raw_ptr__PtrData_unbox_axiom_definition
   :skolemid skolem_internal_vstd__raw_ptr__PtrData_unbox_axiom_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (_addr! Int) (_provenance! vstd!raw_ptr.Provenance.) (
    _metadata! Poly
   )
  ) (!
   (=>
    (and
     (uInv SZ _addr!)
     (has_type _metadata! (pointee_metadata% T&.))
    )
    (has_type (Poly%vstd!raw_ptr.PtrData. (vstd!raw_ptr.PtrData./PtrData _addr! _provenance!
       _metadata!
      )
     ) (TYPE%vstd!raw_ptr.PtrData. T&. T&)
   ))
   :pattern ((has_type (Poly%vstd!raw_ptr.PtrData. (vstd!raw_ptr.PtrData./PtrData _addr!
       _provenance! _metadata!
      )
     ) (TYPE%vstd!raw_ptr.PtrData. T&. T&)
   ))
   :qid internal_vstd!raw_ptr.PtrData./PtrData_constructor_definition
   :skolemid skolem_internal_vstd!raw_ptr.PtrData./PtrData_constructor_definition
)))
(assert
 (forall ((x vstd!raw_ptr.PtrData.)) (!
   (= (vstd!raw_ptr.PtrData./PtrData/addr x) (vstd!raw_ptr.PtrData./PtrData/?addr x))
   :pattern ((vstd!raw_ptr.PtrData./PtrData/addr x))
   :qid internal_vstd!raw_ptr.PtrData./PtrData/addr_accessor_definition
   :skolemid skolem_internal_vstd!raw_ptr.PtrData./PtrData/addr_accessor_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%vstd!raw_ptr.PtrData. T&. T&))
    (uInv SZ (vstd!raw_ptr.PtrData./PtrData/addr (%Poly%vstd!raw_ptr.PtrData. x)))
   )
   :pattern ((vstd!raw_ptr.PtrData./PtrData/addr (%Poly%vstd!raw_ptr.PtrData. x)) (has_type
     x (TYPE%vstd!raw_ptr.PtrData. T&. T&)
   ))
   :qid internal_vstd!raw_ptr.PtrData./PtrData/addr_invariant_definition
   :skolemid skolem_internal_vstd!raw_ptr.PtrData./PtrData/addr_invariant_definition
)))
(assert
 (forall ((x vstd!raw_ptr.PtrData.)) (!
   (= (vstd!raw_ptr.PtrData./PtrData/provenance x) (vstd!raw_ptr.PtrData./PtrData/?provenance
     x
   ))
   :pattern ((vstd!raw_ptr.PtrData./PtrData/provenance x))
   :qid internal_vstd!raw_ptr.PtrData./PtrData/provenance_accessor_definition
   :skolemid skolem_internal_vstd!raw_ptr.PtrData./PtrData/provenance_accessor_definition
)))
(assert
 (forall ((x vstd!raw_ptr.PtrData.)) (!
   (= (vstd!raw_ptr.PtrData./PtrData/metadata x) (vstd!raw_ptr.PtrData./PtrData/?metadata
     x
   ))
   :pattern ((vstd!raw_ptr.PtrData./PtrData/metadata x))
   :qid internal_vstd!raw_ptr.PtrData./PtrData/metadata_accessor_definition
   :skolemid skolem_internal_vstd!raw_ptr.PtrData./PtrData/metadata_accessor_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%vstd!raw_ptr.PtrData. T&. T&))
    (has_type (vstd!raw_ptr.PtrData./PtrData/metadata (%Poly%vstd!raw_ptr.PtrData. x))
     (pointee_metadata% T&.)
   ))
   :pattern ((vstd!raw_ptr.PtrData./PtrData/metadata (%Poly%vstd!raw_ptr.PtrData. x))
    (has_type x (TYPE%vstd!raw_ptr.PtrData. T&. T&))
   )
   :qid internal_vstd!raw_ptr.PtrData./PtrData/metadata_invariant_definition
   :skolemid skolem_internal_vstd!raw_ptr.PtrData./PtrData/metadata_invariant_definition
)))
(assert
 (forall ((x lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS.)) (!
   (= x (%Poly%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS. (Poly%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS.
      x
   )))
   :pattern ((Poly%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS. x))
   :qid internal_lib__Chap19__ArraySeqMtEph__ArraySeqMtEph__ArraySeqMtEphS_box_axiom_definition
   :skolemid skolem_internal_lib__Chap19__ArraySeqMtEph__ArraySeqMtEph__ArraySeqMtEphS_box_axiom_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS. T&. T&))
    (= x (Poly%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS. (%Poly%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS.
       x
   ))))
   :pattern ((has_type x (TYPE%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS. T&.
      T&
   )))
   :qid internal_lib__Chap19__ArraySeqMtEph__ArraySeqMtEph__ArraySeqMtEphS_unbox_axiom_definition
   :skolemid skolem_internal_lib__Chap19__ArraySeqMtEph__ArraySeqMtEph__ArraySeqMtEphS_unbox_axiom_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (_seq! Poly)) (!
   (=>
    (has_type _seq! (TYPE%alloc!vec.Vec. T&. T& $ TYPE%alloc!alloc.Global.))
    (has_type (Poly%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS. (lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS./ArraySeqMtEphS
       _seq!
      )
     ) (TYPE%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS. T&. T&)
   ))
   :pattern ((has_type (Poly%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS. (lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS./ArraySeqMtEphS
       _seq!
      )
     ) (TYPE%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS. T&. T&)
   ))
   :qid internal_lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS./ArraySeqMtEphS_constructor_definition
   :skolemid skolem_internal_lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS./ArraySeqMtEphS_constructor_definition
)))
(assert
 (forall ((x lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS.)) (!
   (= (lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS./ArraySeqMtEphS/seq x) (
     lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS./ArraySeqMtEphS/?seq x
   ))
   :pattern ((lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS./ArraySeqMtEphS/seq
     x
   ))
   :qid internal_lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS./ArraySeqMtEphS/seq_accessor_definition
   :skolemid skolem_internal_lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS./ArraySeqMtEphS/seq_accessor_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS. T&. T&))
    (has_type (lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS./ArraySeqMtEphS/seq
      (%Poly%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS. x)
     ) (TYPE%alloc!vec.Vec. T&. T& $ TYPE%alloc!alloc.Global.)
   ))
   :pattern ((lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS./ArraySeqMtEphS/seq
     (%Poly%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS. x)
    ) (has_type x (TYPE%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS. T&. T&))
   )
   :qid internal_lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS./ArraySeqMtEphS/seq_invariant_definition
   :skolemid skolem_internal_lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS./ArraySeqMtEphS/seq_invariant_definition
)))
(assert
 (forall ((x lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS.)) (!
   (=>
    (is-lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS./ArraySeqMtEphS x)
    (height_lt (height (lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS./ArraySeqMtEphS/seq
       x
      )
     ) (height (Poly%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS. x))
   ))
   :pattern ((height (lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS./ArraySeqMtEphS/seq
      x
   )))
   :qid prelude_datatype_height_lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS./ArraySeqMtEphS/seq
   :skolemid skolem_prelude_datatype_height_lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS./ArraySeqMtEphS/seq
)))
(assert
 (forall ((x lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS.))
  (!
   (= x (%Poly%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS. (
      Poly%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS. x
   )))
   :pattern ((Poly%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS.
     x
   ))
   :qid internal_lib__Chap19__ArraySeqMtEphSlice__ArraySeqMtEphSlice__ArraySeqMtEphSliceS_box_axiom_definition
   :skolemid skolem_internal_lib__Chap19__ArraySeqMtEphSlice__ArraySeqMtEphSlice__ArraySeqMtEphSliceS_box_axiom_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS.
      T&. T&
    ))
    (= x (Poly%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS. (%Poly%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS.
       x
   ))))
   :pattern ((has_type x (TYPE%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS.
      T&. T&
   )))
   :qid internal_lib__Chap19__ArraySeqMtEphSlice__ArraySeqMtEphSlice__ArraySeqMtEphSliceS_unbox_axiom_definition
   :skolemid skolem_internal_lib__Chap19__ArraySeqMtEphSlice__ArraySeqMtEphSlice__ArraySeqMtEphSliceS_unbox_axiom_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (_data! Poly) (_start! Int) (_len! Int)) (!
   (=>
    (and
     (has_type _data! (TYPE%alloc!vec.Vec. T&. T& $ TYPE%alloc!alloc.Global.))
     (uInv SZ _start!)
     (uInv SZ _len!)
    )
    (has_type (Poly%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS.
      (lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS./ArraySeqMtEphSliceS
       _data! _start! _len!
      )
     ) (TYPE%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS. T&.
      T&
   )))
   :pattern ((has_type (Poly%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS.
      (lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS./ArraySeqMtEphSliceS
       _data! _start! _len!
      )
     ) (TYPE%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS. T&.
      T&
   )))
   :qid internal_lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS./ArraySeqMtEphSliceS_constructor_definition
   :skolemid skolem_internal_lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS./ArraySeqMtEphSliceS_constructor_definition
)))
(assert
 (forall ((x lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS.))
  (!
   (= (lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS./ArraySeqMtEphSliceS/data
     x
    ) (lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS./ArraySeqMtEphSliceS/?data
     x
   ))
   :pattern ((lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS./ArraySeqMtEphSliceS/data
     x
   ))
   :qid internal_lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS./ArraySeqMtEphSliceS/data_accessor_definition
   :skolemid skolem_internal_lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS./ArraySeqMtEphSliceS/data_accessor_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS.
      T&. T&
    ))
    (has_type (lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS./ArraySeqMtEphSliceS/data
      (%Poly%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS. x)
     ) (TYPE%alloc!vec.Vec. T&. T& $ TYPE%alloc!alloc.Global.)
   ))
   :pattern ((lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS./ArraySeqMtEphSliceS/data
     (%Poly%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS. x)
    ) (has_type x (TYPE%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS.
      T&. T&
   )))
   :qid internal_lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS./ArraySeqMtEphSliceS/data_invariant_definition
   :skolemid skolem_internal_lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS./ArraySeqMtEphSliceS/data_invariant_definition
)))
(assert
 (forall ((x lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS.))
  (!
   (= (lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS./ArraySeqMtEphSliceS/start
     x
    ) (lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS./ArraySeqMtEphSliceS/?start
     x
   ))
   :pattern ((lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS./ArraySeqMtEphSliceS/start
     x
   ))
   :qid internal_lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS./ArraySeqMtEphSliceS/start_accessor_definition
   :skolemid skolem_internal_lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS./ArraySeqMtEphSliceS/start_accessor_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS.
      T&. T&
    ))
    (uInv SZ (lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS./ArraySeqMtEphSliceS/start
      (%Poly%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS. x)
   )))
   :pattern ((lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS./ArraySeqMtEphSliceS/start
     (%Poly%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS. x)
    ) (has_type x (TYPE%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS.
      T&. T&
   )))
   :qid internal_lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS./ArraySeqMtEphSliceS/start_invariant_definition
   :skolemid skolem_internal_lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS./ArraySeqMtEphSliceS/start_invariant_definition
)))
(assert
 (forall ((x lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS.))
  (!
   (= (lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS./ArraySeqMtEphSliceS/len
     x
    ) (lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS./ArraySeqMtEphSliceS/?len
     x
   ))
   :pattern ((lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS./ArraySeqMtEphSliceS/len
     x
   ))
   :qid internal_lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS./ArraySeqMtEphSliceS/len_accessor_definition
   :skolemid skolem_internal_lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS./ArraySeqMtEphSliceS/len_accessor_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS.
      T&. T&
    ))
    (uInv SZ (lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS./ArraySeqMtEphSliceS/len
      (%Poly%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS. x)
   )))
   :pattern ((lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS./ArraySeqMtEphSliceS/len
     (%Poly%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS. x)
    ) (has_type x (TYPE%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS.
      T&. T&
   )))
   :qid internal_lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS./ArraySeqMtEphSliceS/len_invariant_definition
   :skolemid skolem_internal_lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS./ArraySeqMtEphSliceS/len_invariant_definition
)))
(assert
 (forall ((x lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS.))
  (!
   (=>
    (is-lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS./ArraySeqMtEphSliceS
     x
    )
    (height_lt (height (lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS./ArraySeqMtEphSliceS/data
       x
      )
     ) (height (Poly%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS.
       x
   ))))
   :pattern ((height (lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS./ArraySeqMtEphSliceS/data
      x
   )))
   :qid prelude_datatype_height_lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS./ArraySeqMtEphSliceS/data
   :skolemid skolem_prelude_datatype_height_lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS./ArraySeqMtEphSliceS/data
)))
(assert
 (forall ((x tuple%0.)) (!
   (= x (%Poly%tuple%0. (Poly%tuple%0. x)))
   :pattern ((Poly%tuple%0. x))
   :qid internal_crate__tuple__0_box_axiom_definition
   :skolemid skolem_internal_crate__tuple__0_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%tuple%0.)
    (= x (Poly%tuple%0. (%Poly%tuple%0. x)))
   )
   :pattern ((has_type x TYPE%tuple%0.))
   :qid internal_crate__tuple__0_unbox_axiom_definition
   :skolemid skolem_internal_crate__tuple__0_unbox_axiom_definition
)))
(assert
 (forall ((x tuple%0.)) (!
   (has_type (Poly%tuple%0. x) TYPE%tuple%0.)
   :pattern ((has_type (Poly%tuple%0. x) TYPE%tuple%0.))
   :qid internal_crate__tuple__0_has_type_always_definition
   :skolemid skolem_internal_crate__tuple__0_has_type_always_definition
)))
(assert
 (forall ((x tuple%1.)) (!
   (= x (%Poly%tuple%1. (Poly%tuple%1. x)))
   :pattern ((Poly%tuple%1. x))
   :qid internal_crate__tuple__1_box_axiom_definition
   :skolemid skolem_internal_crate__tuple__1_box_axiom_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%tuple%1. T%0&. T%0&))
    (= x (Poly%tuple%1. (%Poly%tuple%1. x)))
   )
   :pattern ((has_type x (TYPE%tuple%1. T%0&. T%0&)))
   :qid internal_crate__tuple__1_unbox_axiom_definition
   :skolemid skolem_internal_crate__tuple__1_unbox_axiom_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (_0! Poly)) (!
   (=>
    (has_type _0! T%0&)
    (has_type (Poly%tuple%1. (tuple%1./tuple%1 _0!)) (TYPE%tuple%1. T%0&. T%0&))
   )
   :pattern ((has_type (Poly%tuple%1. (tuple%1./tuple%1 _0!)) (TYPE%tuple%1. T%0&. T%0&)))
   :qid internal_tuple__1./tuple__1_constructor_definition
   :skolemid skolem_internal_tuple__1./tuple__1_constructor_definition
)))
(assert
 (forall ((x tuple%1.)) (!
   (= (tuple%1./tuple%1/0 x) (tuple%1./tuple%1/?0 x))
   :pattern ((tuple%1./tuple%1/0 x))
   :qid internal_tuple__1./tuple__1/0_accessor_definition
   :skolemid skolem_internal_tuple__1./tuple__1/0_accessor_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%tuple%1. T%0&. T%0&))
    (has_type (tuple%1./tuple%1/0 (%Poly%tuple%1. x)) T%0&)
   )
   :pattern ((tuple%1./tuple%1/0 (%Poly%tuple%1. x)) (has_type x (TYPE%tuple%1. T%0&. T%0&)))
   :qid internal_tuple__1./tuple__1/0_invariant_definition
   :skolemid skolem_internal_tuple__1./tuple__1/0_invariant_definition
)))
(assert
 (forall ((x tuple%1.)) (!
   (=>
    (is-tuple%1./tuple%1 x)
    (height_lt (height (tuple%1./tuple%1/0 x)) (height (Poly%tuple%1. x)))
   )
   :pattern ((height (tuple%1./tuple%1/0 x)))
   :qid prelude_datatype_height_tuple%1./tuple%1/0
   :skolemid skolem_prelude_datatype_height_tuple%1./tuple%1/0
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (deep Bool) (x Poly) (y Poly)) (!
   (=>
    (and
     (has_type x (TYPE%tuple%1. T%0&. T%0&))
     (has_type y (TYPE%tuple%1. T%0&. T%0&))
     (ext_eq deep T%0& (tuple%1./tuple%1/0 (%Poly%tuple%1. x)) (tuple%1./tuple%1/0 (%Poly%tuple%1.
        y
    ))))
    (ext_eq deep (TYPE%tuple%1. T%0&. T%0&) x y)
   )
   :pattern ((ext_eq deep (TYPE%tuple%1. T%0&. T%0&) x y))
   :qid internal_tuple__1./tuple__1_ext_equal_definition
   :skolemid skolem_internal_tuple__1./tuple__1_ext_equal_definition
)))
(assert
 (forall ((x tuple%2.)) (!
   (= x (%Poly%tuple%2. (Poly%tuple%2. x)))
   :pattern ((Poly%tuple%2. x))
   :qid internal_crate__tuple__2_box_axiom_definition
   :skolemid skolem_internal_crate__tuple__2_box_axiom_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%tuple%2. T%0&. T%0& T%1&. T%1&))
    (= x (Poly%tuple%2. (%Poly%tuple%2. x)))
   )
   :pattern ((has_type x (TYPE%tuple%2. T%0&. T%0& T%1&. T%1&)))
   :qid internal_crate__tuple__2_unbox_axiom_definition
   :skolemid skolem_internal_crate__tuple__2_unbox_axiom_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (_0! Poly) (_1! Poly)) (!
   (=>
    (and
     (has_type _0! T%0&)
     (has_type _1! T%1&)
    )
    (has_type (Poly%tuple%2. (tuple%2./tuple%2 _0! _1!)) (TYPE%tuple%2. T%0&. T%0& T%1&.
      T%1&
   )))
   :pattern ((has_type (Poly%tuple%2. (tuple%2./tuple%2 _0! _1!)) (TYPE%tuple%2. T%0&.
      T%0& T%1&. T%1&
   )))
   :qid internal_tuple__2./tuple__2_constructor_definition
   :skolemid skolem_internal_tuple__2./tuple__2_constructor_definition
)))
(assert
 (forall ((x tuple%2.)) (!
   (= (tuple%2./tuple%2/0 x) (tuple%2./tuple%2/?0 x))
   :pattern ((tuple%2./tuple%2/0 x))
   :qid internal_tuple__2./tuple__2/0_accessor_definition
   :skolemid skolem_internal_tuple__2./tuple__2/0_accessor_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%tuple%2. T%0&. T%0& T%1&. T%1&))
    (has_type (tuple%2./tuple%2/0 (%Poly%tuple%2. x)) T%0&)
   )
   :pattern ((tuple%2./tuple%2/0 (%Poly%tuple%2. x)) (has_type x (TYPE%tuple%2. T%0&. T%0&
      T%1&. T%1&
   )))
   :qid internal_tuple__2./tuple__2/0_invariant_definition
   :skolemid skolem_internal_tuple__2./tuple__2/0_invariant_definition
)))
(assert
 (forall ((x tuple%2.)) (!
   (= (tuple%2./tuple%2/1 x) (tuple%2./tuple%2/?1 x))
   :pattern ((tuple%2./tuple%2/1 x))
   :qid internal_tuple__2./tuple__2/1_accessor_definition
   :skolemid skolem_internal_tuple__2./tuple__2/1_accessor_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%tuple%2. T%0&. T%0& T%1&. T%1&))
    (has_type (tuple%2./tuple%2/1 (%Poly%tuple%2. x)) T%1&)
   )
   :pattern ((tuple%2./tuple%2/1 (%Poly%tuple%2. x)) (has_type x (TYPE%tuple%2. T%0&. T%0&
      T%1&. T%1&
   )))
   :qid internal_tuple__2./tuple__2/1_invariant_definition
   :skolemid skolem_internal_tuple__2./tuple__2/1_invariant_definition
)))
(assert
 (forall ((x tuple%2.)) (!
   (=>
    (is-tuple%2./tuple%2 x)
    (height_lt (height (tuple%2./tuple%2/0 x)) (height (Poly%tuple%2. x)))
   )
   :pattern ((height (tuple%2./tuple%2/0 x)))
   :qid prelude_datatype_height_tuple%2./tuple%2/0
   :skolemid skolem_prelude_datatype_height_tuple%2./tuple%2/0
)))
(assert
 (forall ((x tuple%2.)) (!
   (=>
    (is-tuple%2./tuple%2 x)
    (height_lt (height (tuple%2./tuple%2/1 x)) (height (Poly%tuple%2. x)))
   )
   :pattern ((height (tuple%2./tuple%2/1 x)))
   :qid prelude_datatype_height_tuple%2./tuple%2/1
   :skolemid skolem_prelude_datatype_height_tuple%2./tuple%2/1
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (deep Bool) (x Poly) (y Poly))
  (!
   (=>
    (and
     (has_type x (TYPE%tuple%2. T%0&. T%0& T%1&. T%1&))
     (has_type y (TYPE%tuple%2. T%0&. T%0& T%1&. T%1&))
     (ext_eq deep T%0& (tuple%2./tuple%2/0 (%Poly%tuple%2. x)) (tuple%2./tuple%2/0 (%Poly%tuple%2.
        y
     )))
     (ext_eq deep T%1& (tuple%2./tuple%2/1 (%Poly%tuple%2. x)) (tuple%2./tuple%2/1 (%Poly%tuple%2.
        y
    ))))
    (ext_eq deep (TYPE%tuple%2. T%0&. T%0& T%1&. T%1&) x y)
   )
   :pattern ((ext_eq deep (TYPE%tuple%2. T%0&. T%0& T%1&. T%1&) x y))
   :qid internal_tuple__2./tuple__2_ext_equal_definition
   :skolemid skolem_internal_tuple__2./tuple__2_ext_equal_definition
)))
(assert
 (forall ((x tuple%3.)) (!
   (= x (%Poly%tuple%3. (Poly%tuple%3. x)))
   :pattern ((Poly%tuple%3. x))
   :qid internal_crate__tuple__3_box_axiom_definition
   :skolemid skolem_internal_crate__tuple__3_box_axiom_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (T%2&. Dcr) (T%2& Type) (x
    Poly
   )
  ) (!
   (=>
    (has_type x (TYPE%tuple%3. T%0&. T%0& T%1&. T%1& T%2&. T%2&))
    (= x (Poly%tuple%3. (%Poly%tuple%3. x)))
   )
   :pattern ((has_type x (TYPE%tuple%3. T%0&. T%0& T%1&. T%1& T%2&. T%2&)))
   :qid internal_crate__tuple__3_unbox_axiom_definition
   :skolemid skolem_internal_crate__tuple__3_unbox_axiom_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (T%2&. Dcr) (T%2& Type) (_0!
    Poly
   ) (_1! Poly) (_2! Poly)
  ) (!
   (=>
    (and
     (has_type _0! T%0&)
     (has_type _1! T%1&)
     (has_type _2! T%2&)
    )
    (has_type (Poly%tuple%3. (tuple%3./tuple%3 _0! _1! _2!)) (TYPE%tuple%3. T%0&. T%0&
      T%1&. T%1& T%2&. T%2&
   )))
   :pattern ((has_type (Poly%tuple%3. (tuple%3./tuple%3 _0! _1! _2!)) (TYPE%tuple%3. T%0&.
      T%0& T%1&. T%1& T%2&. T%2&
   )))
   :qid internal_tuple__3./tuple__3_constructor_definition
   :skolemid skolem_internal_tuple__3./tuple__3_constructor_definition
)))
(assert
 (forall ((x tuple%3.)) (!
   (= (tuple%3./tuple%3/0 x) (tuple%3./tuple%3/?0 x))
   :pattern ((tuple%3./tuple%3/0 x))
   :qid internal_tuple__3./tuple__3/0_accessor_definition
   :skolemid skolem_internal_tuple__3./tuple__3/0_accessor_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (T%2&. Dcr) (T%2& Type) (x
    Poly
   )
  ) (!
   (=>
    (has_type x (TYPE%tuple%3. T%0&. T%0& T%1&. T%1& T%2&. T%2&))
    (has_type (tuple%3./tuple%3/0 (%Poly%tuple%3. x)) T%0&)
   )
   :pattern ((tuple%3./tuple%3/0 (%Poly%tuple%3. x)) (has_type x (TYPE%tuple%3. T%0&. T%0&
      T%1&. T%1& T%2&. T%2&
   )))
   :qid internal_tuple__3./tuple__3/0_invariant_definition
   :skolemid skolem_internal_tuple__3./tuple__3/0_invariant_definition
)))
(assert
 (forall ((x tuple%3.)) (!
   (= (tuple%3./tuple%3/1 x) (tuple%3./tuple%3/?1 x))
   :pattern ((tuple%3./tuple%3/1 x))
   :qid internal_tuple__3./tuple__3/1_accessor_definition
   :skolemid skolem_internal_tuple__3./tuple__3/1_accessor_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (T%2&. Dcr) (T%2& Type) (x
    Poly
   )
  ) (!
   (=>
    (has_type x (TYPE%tuple%3. T%0&. T%0& T%1&. T%1& T%2&. T%2&))
    (has_type (tuple%3./tuple%3/1 (%Poly%tuple%3. x)) T%1&)
   )
   :pattern ((tuple%3./tuple%3/1 (%Poly%tuple%3. x)) (has_type x (TYPE%tuple%3. T%0&. T%0&
      T%1&. T%1& T%2&. T%2&
   )))
   :qid internal_tuple__3./tuple__3/1_invariant_definition
   :skolemid skolem_internal_tuple__3./tuple__3/1_invariant_definition
)))
(assert
 (forall ((x tuple%3.)) (!
   (= (tuple%3./tuple%3/2 x) (tuple%3./tuple%3/?2 x))
   :pattern ((tuple%3./tuple%3/2 x))
   :qid internal_tuple__3./tuple__3/2_accessor_definition
   :skolemid skolem_internal_tuple__3./tuple__3/2_accessor_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (T%2&. Dcr) (T%2& Type) (x
    Poly
   )
  ) (!
   (=>
    (has_type x (TYPE%tuple%3. T%0&. T%0& T%1&. T%1& T%2&. T%2&))
    (has_type (tuple%3./tuple%3/2 (%Poly%tuple%3. x)) T%2&)
   )
   :pattern ((tuple%3./tuple%3/2 (%Poly%tuple%3. x)) (has_type x (TYPE%tuple%3. T%0&. T%0&
      T%1&. T%1& T%2&. T%2&
   )))
   :qid internal_tuple__3./tuple__3/2_invariant_definition
   :skolemid skolem_internal_tuple__3./tuple__3/2_invariant_definition
)))
(assert
 (forall ((x tuple%3.)) (!
   (=>
    (is-tuple%3./tuple%3 x)
    (height_lt (height (tuple%3./tuple%3/0 x)) (height (Poly%tuple%3. x)))
   )
   :pattern ((height (tuple%3./tuple%3/0 x)))
   :qid prelude_datatype_height_tuple%3./tuple%3/0
   :skolemid skolem_prelude_datatype_height_tuple%3./tuple%3/0
)))
(assert
 (forall ((x tuple%3.)) (!
   (=>
    (is-tuple%3./tuple%3 x)
    (height_lt (height (tuple%3./tuple%3/1 x)) (height (Poly%tuple%3. x)))
   )
   :pattern ((height (tuple%3./tuple%3/1 x)))
   :qid prelude_datatype_height_tuple%3./tuple%3/1
   :skolemid skolem_prelude_datatype_height_tuple%3./tuple%3/1
)))
(assert
 (forall ((x tuple%3.)) (!
   (=>
    (is-tuple%3./tuple%3 x)
    (height_lt (height (tuple%3./tuple%3/2 x)) (height (Poly%tuple%3. x)))
   )
   :pattern ((height (tuple%3./tuple%3/2 x)))
   :qid prelude_datatype_height_tuple%3./tuple%3/2
   :skolemid skolem_prelude_datatype_height_tuple%3./tuple%3/2
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (T%2&. Dcr) (T%2& Type) (deep
    Bool
   ) (x Poly) (y Poly)
  ) (!
   (=>
    (and
     (has_type x (TYPE%tuple%3. T%0&. T%0& T%1&. T%1& T%2&. T%2&))
     (has_type y (TYPE%tuple%3. T%0&. T%0& T%1&. T%1& T%2&. T%2&))
     (ext_eq deep T%0& (tuple%3./tuple%3/0 (%Poly%tuple%3. x)) (tuple%3./tuple%3/0 (%Poly%tuple%3.
        y
     )))
     (ext_eq deep T%1& (tuple%3./tuple%3/1 (%Poly%tuple%3. x)) (tuple%3./tuple%3/1 (%Poly%tuple%3.
        y
     )))
     (ext_eq deep T%2& (tuple%3./tuple%3/2 (%Poly%tuple%3. x)) (tuple%3./tuple%3/2 (%Poly%tuple%3.
        y
    ))))
    (ext_eq deep (TYPE%tuple%3. T%0&. T%0& T%1&. T%1& T%2&. T%2&) x y)
   )
   :pattern ((ext_eq deep (TYPE%tuple%3. T%0&. T%0& T%1&. T%1& T%2&. T%2&) x y))
   :qid internal_tuple__3./tuple__3_ext_equal_definition
   :skolemid skolem_internal_tuple__3./tuple__3_ext_equal_definition
)))
(declare-fun array_new (Dcr Type Int %%Function%%) Poly)
(declare-fun array_index (Dcr Type Dcr Type %%Function%% Poly) Poly)
(assert
 (forall ((Tdcr Dcr) (T Type) (N Int) (Fn %%Function%%)) (!
   (= (array_new Tdcr T N Fn) (Poly%array%. Fn))
   :pattern ((array_new Tdcr T N Fn))
   :qid prelude_array_new
   :skolemid skolem_prelude_array_new
)))
(declare-fun %%apply%%2 (%%Function%% Int) Poly)
(assert
 (forall ((Tdcr Dcr) (T Type) (N Int) (Fn %%Function%%)) (!
   (=>
    (forall ((i Int)) (!
      (=>
       (and
        (<= 0 i)
        (< i N)
       )
       (has_type (%%apply%%2 Fn i) T)
      )
      :pattern ((has_type (%%apply%%2 Fn i) T))
      :qid prelude_has_type_array_elts
      :skolemid skolem_prelude_has_type_array_elts
    ))
    (has_type (array_new Tdcr T N Fn) (ARRAY Tdcr T $ (CONST_INT N)))
   )
   :pattern ((array_new Tdcr T N Fn))
   :qid prelude_has_type_array_new
   :skolemid skolem_prelude_has_type_array_new
)))
(assert
 (forall ((Tdcr Dcr) (T Type) (Nd Dcr) (Ndcr Dcr) (N Type) (Fn %%Function%%) (i Poly))
  (!
   (=>
    (and
     (has_type (Poly%array%. Fn) (ARRAY Tdcr T Ndcr N))
     (has_type i INT)
    )
    (has_type (array_index Tdcr T Nd N Fn i) T)
   )
   :pattern ((array_index Tdcr T Nd N Fn i) (has_type (Poly%array%. Fn) (ARRAY Tdcr T Ndcr
      N
   )))
   :qid prelude_has_type_array_index
   :skolemid skolem_prelude_has_type_array_index
)))
(assert
 (!
  (forall ((Tdcr Dcr) (T Type) (N Int) (Fn %%Function%%) (i Int)) (!
    (= (array_index Tdcr T $ (CONST_INT N) Fn (I i)) (%%apply%%2 Fn i))
    :pattern ((array_new Tdcr T N Fn) (%%apply%%2 Fn i))
    :qid prelude_array_index_trigger
    :skolemid skolem_prelude_array_index_trigger
  ))
  :named
  prelude_axiom_array_index
))
(assert
 (forall ((d Dcr) (t Type) (x Poly)) (!
   (=>
    (and
     (has_type x (MUTREF d t))
     (has_resolved $ (MUTREF d t) x)
    )
    (= (mut_ref_current% x) (mut_ref_future% x))
   )
   :pattern ((has_resolved $ (MUTREF d t) x))
   :qid prelude_resolved_mut_ref
   :skolemid skolem_prelude_resolved_mut_ref
)))
(assert
 (forall ((T&. Dcr) (T& Type) (x$ Poly)) (!
   (=>
    (has_type x$ (TYPE%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS. T&. T&))
    (=>
     (has_resolved $ (TYPE%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS. T&. T&)
      x$
     )
     (has_resolved $ (TYPE%alloc!vec.Vec. T&. T& $ TYPE%alloc!alloc.Global.) (lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS./ArraySeqMtEphS/seq
       (%Poly%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS. x$)
   ))))
   :pattern ((has_resolved $ (TYPE%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS.
      T&. T&
     ) x$
    ) (lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS./ArraySeqMtEphS/seq (%Poly%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS.
      x$
   )))
   :qid user_no_function_0
   :skolemid skolem_user_no_function_0
)))
(assert
 (forall ((T&. Dcr) (T& Type) (x$ Poly)) (!
   (=>
    (has_type x$ (TYPE%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS.
      T&. T&
    ))
    (=>
     (has_resolved $ (TYPE%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS.
       T&. T&
      ) x$
     )
     (has_resolved (ARC $ TYPE%alloc!alloc.Global. $) (TYPE%alloc!vec.Vec. T&. T& $ TYPE%alloc!alloc.Global.)
      (lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS./ArraySeqMtEphSliceS/data
       (%Poly%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS. x$)
   ))))
   :pattern ((has_resolved $ (TYPE%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS.
      T&. T&
     ) x$
    ) (lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS./ArraySeqMtEphSliceS/data
     (%Poly%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS. x$)
   ))
   :qid user_no_function_1
   :skolemid skolem_user_no_function_1
)))
(assert
 (forall ((T&. Dcr) (T& Type) (x$ Poly)) (!
   (=>
    (has_type x$ (TYPE%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS.
      T&. T&
    ))
    (=>
     (has_resolved $ (TYPE%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS.
       T&. T&
      ) x$
     )
     (has_resolved $ USIZE (I (lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS./ArraySeqMtEphSliceS/start
        (%Poly%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS. x$)
   )))))
   :pattern ((has_resolved $ (TYPE%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS.
      T&. T&
     ) x$
    ) (lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS./ArraySeqMtEphSliceS/start
     (%Poly%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS. x$)
   ))
   :qid user_no_function_2
   :skolemid skolem_user_no_function_2
)))
(assert
 (forall ((T&. Dcr) (T& Type) (x$ Poly)) (!
   (=>
    (has_type x$ (TYPE%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS.
      T&. T&
    ))
    (=>
     (has_resolved $ (TYPE%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS.
       T&. T&
      ) x$
     )
     (has_resolved $ USIZE (I (lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS./ArraySeqMtEphSliceS/len
        (%Poly%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS. x$)
   )))))
   :pattern ((has_resolved $ (TYPE%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS.
      T&. T&
     ) x$
    ) (lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS./ArraySeqMtEphSliceS/len
     (%Poly%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS. x$)
   ))
   :qid user_no_function_3
   :skolemid skolem_user_no_function_3
)))
(assert
 (forall ((x fndef) (Self%&. Dcr) (Self%& Type)) (!
   (has_type (F x) (FNDEF%core!clone.Clone.clone. Self%&. Self%&))
   :pattern ((has_type (F x) (FNDEF%core!clone.Clone.clone. Self%&. Self%&)))
   :qid prelude_has_type_fndef_FNDEF%core!clone.Clone.clone.
   :skolemid skolem_prelude_has_type_fndef_FNDEF%core!clone.Clone.clone.
)))

;; Trait-Bounds
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (T&. Dcr) (T& Type)) (!
   (=>
    (tr_bound%vstd!array.ArrayAdditionalSpecFns. Self%&. Self%& T&. T&)
    (and
     (tr_bound%vstd!view.View. Self%&. Self%&)
     (and
      (= $ (proj%%vstd!view.View./V Self%&. Self%&))
      (= (TYPE%vstd!seq.Seq. T&. T&) (proj%vstd!view.View./V Self%&. Self%&))
     )
     (sized T&.)
   ))
   :pattern ((tr_bound%vstd!array.ArrayAdditionalSpecFns. Self%&. Self%& T&. T&))
   :qid internal_vstd__array__ArrayAdditionalSpecFns_trait_type_bounds_definition
   :skolemid skolem_internal_vstd__array__ArrayAdditionalSpecFns_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (Args&. Dcr) (Args& Type) (Output&. Dcr) (Output&
    Type
   )
  ) (!
   (=>
    (tr_bound%vstd!pervasive.FnWithRequiresEnsures. Self%&. Self%& Args&. Args& Output&.
     Output&
    )
    (and
     (sized Self%&.)
     (sized Args&.)
     (sized Output&.)
   ))
   :pattern ((tr_bound%vstd!pervasive.FnWithRequiresEnsures. Self%&. Self%& Args&. Args&
     Output&. Output&
   ))
   :qid internal_vstd__pervasive__FnWithRequiresEnsures_trait_type_bounds_definition
   :skolemid skolem_internal_vstd__pervasive__FnWithRequiresEnsures_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (T&. Dcr) (T& Type)) (!
   (=>
    (tr_bound%vstd!slice.SliceAdditionalSpecFns. Self%&. Self%& T&. T&)
    (and
     (tr_bound%vstd!view.View. Self%&. Self%&)
     (and
      (= $ (proj%%vstd!view.View./V Self%&. Self%&))
      (= (TYPE%vstd!seq.Seq. T&. T&) (proj%vstd!view.View./V Self%&. Self%&))
     )
     (sized T&.)
   ))
   :pattern ((tr_bound%vstd!slice.SliceAdditionalSpecFns. Self%&. Self%& T&. T&))
   :qid internal_vstd__slice__SliceAdditionalSpecFns_trait_type_bounds_definition
   :skolemid skolem_internal_vstd__slice__SliceAdditionalSpecFns_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type)) (!
   (=>
    (tr_bound%vstd!view.View. Self%&. Self%&)
    (sized (proj%%vstd!view.View./V Self%&. Self%&))
   )
   :pattern ((tr_bound%vstd!view.View. Self%&. Self%&))
   :qid internal_vstd__view__View_trait_type_bounds_definition
   :skolemid skolem_internal_vstd__view__View_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type)) (!
   (=>
    (tr_bound%vstd!view.DeepView. Self%&. Self%&)
    (sized (proj%%vstd!view.DeepView./V Self%&. Self%&))
   )
   :pattern ((tr_bound%vstd!view.DeepView. Self%&. Self%&))
   :qid internal_vstd__view__DeepView_trait_type_bounds_definition
   :skolemid skolem_internal_vstd__view__DeepView_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type)) (!
   (=>
    (tr_bound%core!clone.Clone. Self%&. Self%&)
    (sized Self%&.)
   )
   :pattern ((tr_bound%core!clone.Clone. Self%&. Self%&))
   :qid internal_core__clone__Clone_trait_type_bounds_definition
   :skolemid skolem_internal_core__clone__Clone_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type)) (!
   (=>
    (tr_bound%core!marker.Copy. Self%&. Self%&)
    (tr_bound%core!clone.Clone. Self%&. Self%&)
   )
   :pattern ((tr_bound%core!marker.Copy. Self%&. Self%&))
   :qid internal_core__marker__Copy_trait_type_bounds_definition
   :skolemid skolem_internal_core__marker__Copy_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (Rhs&. Dcr) (Rhs& Type)) (!
   true
   :pattern ((tr_bound%core!cmp.PartialEq. Self%&. Self%& Rhs&. Rhs&))
   :qid internal_core__cmp__PartialEq_trait_type_bounds_definition
   :skolemid skolem_internal_core__cmp__PartialEq_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type)) (!
   (=>
    (tr_bound%core!cmp.Eq. Self%&. Self%&)
    (tr_bound%core!cmp.PartialEq. Self%&. Self%& Self%&. Self%&)
   )
   :pattern ((tr_bound%core!cmp.Eq. Self%&. Self%&))
   :qid internal_core__cmp__Eq_trait_type_bounds_definition
   :skolemid skolem_internal_core__cmp__Eq_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (Rhs&. Dcr) (Rhs& Type)) (!
   (=>
    (tr_bound%vstd!std_specs.cmp.PartialEqSpec. Self%&. Self%& Rhs&. Rhs&)
    (tr_bound%core!cmp.PartialEq. Self%&. Self%& Rhs&. Rhs&)
   )
   :pattern ((tr_bound%vstd!std_specs.cmp.PartialEqSpec. Self%&. Self%& Rhs&. Rhs&))
   :qid internal_vstd__std_specs__cmp__PartialEqSpec_trait_type_bounds_definition
   :skolemid skolem_internal_vstd__std_specs__cmp__PartialEqSpec_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type)) (!
   true
   :pattern ((tr_bound%core!marker.Tuple. Self%&. Self%&))
   :qid internal_core__marker__Tuple_trait_type_bounds_definition
   :skolemid skolem_internal_core__marker__Tuple_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (Args&. Dcr) (Args& Type)) (!
   (=>
    (tr_bound%core!ops.function.FnOnce. Self%&. Self%& Args&. Args&)
    (and
     (sized Args&.)
     (tr_bound%core!marker.Tuple. Args&. Args&)
     (sized (proj%%core!ops.function.FnOnce./Output Self%&. Self%& Args&. Args&))
   ))
   :pattern ((tr_bound%core!ops.function.FnOnce. Self%&. Self%& Args&. Args&))
   :qid internal_core__ops__function__FnOnce_trait_type_bounds_definition
   :skolemid skolem_internal_core__ops__function__FnOnce_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (Args&. Dcr) (Args& Type)) (!
   (=>
    (tr_bound%core!ops.function.FnMut. Self%&. Self%& Args&. Args&)
    (and
     (tr_bound%core!ops.function.FnOnce. Self%&. Self%& Args&. Args&)
     (sized Args&.)
     (tr_bound%core!marker.Tuple. Args&. Args&)
   ))
   :pattern ((tr_bound%core!ops.function.FnMut. Self%&. Self%& Args&. Args&))
   :qid internal_core__ops__function__FnMut_trait_type_bounds_definition
   :skolemid skolem_internal_core__ops__function__FnMut_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (Args&. Dcr) (Args& Type)) (!
   (=>
    (tr_bound%core!ops.function.Fn. Self%&. Self%& Args&. Args&)
    (and
     (tr_bound%core!ops.function.FnMut. Self%&. Self%& Args&. Args&)
     (sized Args&.)
     (tr_bound%core!marker.Tuple. Args&. Args&)
   ))
   :pattern ((tr_bound%core!ops.function.Fn. Self%&. Self%& Args&. Args&))
   :qid internal_core__ops__function__Fn_trait_type_bounds_definition
   :skolemid skolem_internal_core__ops__function__Fn_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type)) (!
   true
   :pattern ((tr_bound%core!alloc.Allocator. Self%&. Self%&))
   :qid internal_core__alloc__Allocator_trait_type_bounds_definition
   :skolemid skolem_internal_core__alloc__Allocator_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type)) (!
   true
   :pattern ((tr_bound%core!fmt.Debug. Self%&. Self%&))
   :qid internal_core__fmt__Debug_trait_type_bounds_definition
   :skolemid skolem_internal_core__fmt__Debug_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type)) (!
   true
   :pattern ((tr_bound%core!fmt.Display. Self%&. Self%&))
   :qid internal_core__fmt__Display_trait_type_bounds_definition
   :skolemid skolem_internal_core__fmt__Display_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (T&. Dcr) (T& Type)) (!
   (=>
    (tr_bound%vstd!std_specs.option.OptionAdditionalFns. Self%&. Self%& T&. T&)
    (and
     (sized Self%&.)
     (sized T&.)
   ))
   :pattern ((tr_bound%vstd!std_specs.option.OptionAdditionalFns. Self%&. Self%& T&. T&))
   :qid internal_vstd__std_specs__option__OptionAdditionalFns_trait_type_bounds_definition
   :skolemid skolem_internal_vstd__std_specs__option__OptionAdditionalFns_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (T&. Dcr) (T& Type)) (!
   (=>
    (tr_bound%vstd!std_specs.vec.VecAdditionalSpecFns. Self%&. Self%& T&. T&)
    (and
     (tr_bound%vstd!view.View. Self%&. Self%&)
     (and
      (= $ (proj%%vstd!view.View./V Self%&. Self%&))
      (= (TYPE%vstd!seq.Seq. T&. T&) (proj%vstd!view.View./V Self%&. Self%&))
     )
     (sized T&.)
   ))
   :pattern ((tr_bound%vstd!std_specs.vec.VecAdditionalSpecFns. Self%&. Self%& T&. T&))
   :qid internal_vstd__std_specs__vec__VecAdditionalSpecFns_trait_type_bounds_definition
   :skolemid skolem_internal_vstd__std_specs__vec__VecAdditionalSpecFns_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type)) (!
   (=>
    (tr_bound%lib!Types.Types.StT. Self%&. Self%&)
    (and
     (sized Self%&.)
     (tr_bound%core!cmp.Eq. Self%&. Self%&)
     (tr_bound%core!cmp.PartialEq. Self%&. Self%& Self%&. Self%&)
     (tr_bound%core!clone.Clone. Self%&. Self%&)
     (tr_bound%core!fmt.Display. Self%&. Self%&)
     (tr_bound%core!fmt.Debug. Self%&. Self%&)
     (tr_bound%vstd!view.View. Self%&. Self%&)
   ))
   :pattern ((tr_bound%lib!Types.Types.StT. Self%&. Self%&))
   :qid internal_lib__Types__Types__StT_trait_type_bounds_definition
   :skolemid skolem_internal_lib__Types__Types__StT_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type)) (!
   (=>
    (tr_bound%lib!Concurrency.Concurrency.StTInMtT. Self%&. Self%&)
    (tr_bound%lib!Types.Types.StT. Self%&. Self%&)
   )
   :pattern ((tr_bound%lib!Concurrency.Concurrency.StTInMtT. Self%&. Self%&))
   :qid internal_lib__Concurrency__Concurrency__StTInMtT_trait_type_bounds_definition
   :skolemid skolem_internal_lib__Concurrency__Concurrency__StTInMtT_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type)) (!
   (=>
    (tr_bound%lib!vstdplus.total_order.total_order.TotalOrder. Self%&. Self%&)
    (sized Self%&.)
   )
   :pattern ((tr_bound%lib!vstdplus.total_order.total_order.TotalOrder. Self%&. Self%&))
   :qid internal_lib__vstdplus__total_order__total_order__TotalOrder_trait_type_bounds_definition
   :skolemid skolem_internal_lib__vstdplus__total_order__total_order__TotalOrder_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (T&. Dcr) (T& Type)) (!
   (=>
    (tr_bound%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphTrait. Self%&. Self%&
     T&. T&
    )
    (and
     (sized Self%&.)
     (sized T&.)
   ))
   :pattern ((tr_bound%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphTrait. Self%&.
     Self%& T&. T&
   ))
   :qid internal_lib__Chap19__ArraySeqMtEph__ArraySeqMtEph__ArraySeqMtEphTrait_trait_type_bounds_definition
   :skolemid skolem_internal_lib__Chap19__ArraySeqMtEph__ArraySeqMtEph__ArraySeqMtEphTrait_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (T&. Dcr) (T& Type)) (!
   (=>
    (tr_bound%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceTrait.
     Self%&. Self%& T&. T&
    )
    (and
     (sized Self%&.)
     (sized T&.)
     (tr_bound%lib!Concurrency.Concurrency.StTInMtT. T&. T&)
   ))
   :pattern ((tr_bound%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceTrait.
     Self%&. Self%& T&. T&
   ))
   :qid internal_lib__Chap19__ArraySeqMtEphSlice__ArraySeqMtEphSlice__ArraySeqMtEphSliceTrait_trait_type_bounds_definition
   :skolemid skolem_internal_lib__Chap19__ArraySeqMtEphSlice__ArraySeqMtEphSlice__ArraySeqMtEphSliceTrait_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (T&. Dcr) (T& Type)) (!
   (=>
    (tr_bound%lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.OrderStatSelectMtEphTrait.
     Self%&. Self%& T&. T&
    )
    (and
     (sized T&.)
     (tr_bound%lib!Concurrency.Concurrency.StTInMtT. T&. T&)
     (tr_bound%lib!vstdplus.total_order.total_order.TotalOrder. T&. T&)
   ))
   :pattern ((tr_bound%lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.OrderStatSelectMtEphTrait.
     Self%&. Self%& T&. T&
   ))
   :qid internal_lib__Chap35__OrderStatSelectMtEph__OrderStatSelectMtEph__OrderStatSelectMtEphTrait_trait_type_bounds_definition
   :skolemid skolem_internal_lib__Chap35__OrderStatSelectMtEph__OrderStatSelectMtEph__OrderStatSelectMtEphTrait_trait_type_bounds_definition
)))

;; Associated-Type-Impls
(assert
 (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type)) (!
   (=>
    (and
     (sized T&.)
     (uInv SZ (const_int N&))
    )
    (= (proj%%vstd!view.View./V $ (ARRAY T&. T& N&. N&)) $)
   )
   :pattern ((proj%%vstd!view.View./V $ (ARRAY T&. T& N&. N&)))
   :qid internal_proj____vstd!view.View./V_vstd__array__impl&__0_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____vstd!view.View./V_vstd__array__impl&__0_assoc_type_impl_true_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type)) (!
   (=>
    (and
     (sized T&.)
     (uInv SZ (const_int N&))
    )
    (= (proj%vstd!view.View./V $ (ARRAY T&. T& N&. N&)) (TYPE%vstd!seq.Seq. T&. T&))
   )
   :pattern ((proj%vstd!view.View./V $ (ARRAY T&. T& N&. N&)))
   :qid internal_proj__vstd!view.View./V_vstd__array__impl&__0_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__vstd!view.View./V_vstd__array__impl&__0_assoc_type_impl_false_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type)) (!
   (=>
    (and
     (sized T&.)
     (uInv SZ (const_int N&))
     (tr_bound%vstd!view.DeepView. T&. T&)
    )
    (= (proj%%vstd!view.DeepView./V $ (ARRAY T&. T& N&. N&)) $)
   )
   :pattern ((proj%%vstd!view.DeepView./V $ (ARRAY T&. T& N&. N&)))
   :qid internal_proj____vstd!view.DeepView./V_vstd__array__impl&__1_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____vstd!view.DeepView./V_vstd__array__impl&__1_assoc_type_impl_true_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type)) (!
   (=>
    (and
     (sized T&.)
     (uInv SZ (const_int N&))
     (tr_bound%vstd!view.DeepView. T&. T&)
    )
    (= (proj%vstd!view.DeepView./V $ (ARRAY T&. T& N&. N&)) (TYPE%vstd!seq.Seq. (proj%%vstd!view.DeepView./V
       T&. T&
      ) (proj%vstd!view.DeepView./V T&. T&)
   )))
   :pattern ((proj%vstd!view.DeepView./V $ (ARRAY T&. T& N&. N&)))
   :qid internal_proj__vstd!view.DeepView./V_vstd__array__impl&__1_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__vstd!view.DeepView./V_vstd__array__impl&__1_assoc_type_impl_false_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (= (proj%%vstd!view.View./V $ (PTR T&. T&)) $)
   :pattern ((proj%%vstd!view.View./V $ (PTR T&. T&)))
   :qid internal_proj____vstd!view.View./V_vstd__raw_ptr__impl&__2_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____vstd!view.View./V_vstd__raw_ptr__impl&__2_assoc_type_impl_true_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (= (proj%vstd!view.View./V $ (PTR T&. T&)) (TYPE%vstd!raw_ptr.PtrData. T&. T&))
   :pattern ((proj%vstd!view.View./V $ (PTR T&. T&)))
   :qid internal_proj__vstd!view.View./V_vstd__raw_ptr__impl&__2_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__vstd!view.View./V_vstd__raw_ptr__impl&__2_assoc_type_impl_false_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (= (proj%%vstd!view.View./V (CONST_PTR $) (PTR T&. T&)) $)
   :pattern ((proj%%vstd!view.View./V (CONST_PTR $) (PTR T&. T&)))
   :qid internal_proj____vstd!view.View./V_vstd__raw_ptr__impl&__3_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____vstd!view.View./V_vstd__raw_ptr__impl&__3_assoc_type_impl_true_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (= (proj%vstd!view.View./V (CONST_PTR $) (PTR T&. T&)) (TYPE%vstd!raw_ptr.PtrData.
     T&. T&
   ))
   :pattern ((proj%vstd!view.View./V (CONST_PTR $) (PTR T&. T&)))
   :qid internal_proj__vstd!view.View./V_vstd__raw_ptr__impl&__3_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__vstd!view.View./V_vstd__raw_ptr__impl&__3_assoc_type_impl_false_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (sized T&.)
    (= (proj%%vstd!view.View./V $slice (SLICE T&. T&)) $)
   )
   :pattern ((proj%%vstd!view.View./V $slice (SLICE T&. T&)))
   :qid internal_proj____vstd!view.View./V_vstd__slice__impl&__0_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____vstd!view.View./V_vstd__slice__impl&__0_assoc_type_impl_true_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (sized T&.)
    (= (proj%vstd!view.View./V $slice (SLICE T&. T&)) (TYPE%vstd!seq.Seq. T&. T&))
   )
   :pattern ((proj%vstd!view.View./V $slice (SLICE T&. T&)))
   :qid internal_proj__vstd!view.View./V_vstd__slice__impl&__0_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__vstd!view.View./V_vstd__slice__impl&__0_assoc_type_impl_false_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (and
     (sized T&.)
     (tr_bound%vstd!view.DeepView. T&. T&)
    )
    (= (proj%%vstd!view.DeepView./V $slice (SLICE T&. T&)) $)
   )
   :pattern ((proj%%vstd!view.DeepView./V $slice (SLICE T&. T&)))
   :qid internal_proj____vstd!view.DeepView./V_vstd__slice__impl&__1_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____vstd!view.DeepView./V_vstd__slice__impl&__1_assoc_type_impl_true_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (and
     (sized T&.)
     (tr_bound%vstd!view.DeepView. T&. T&)
    )
    (= (proj%vstd!view.DeepView./V $slice (SLICE T&. T&)) (TYPE%vstd!seq.Seq. (proj%%vstd!view.DeepView./V
       T&. T&
      ) (proj%vstd!view.DeepView./V T&. T&)
   )))
   :pattern ((proj%vstd!view.DeepView./V $slice (SLICE T&. T&)))
   :qid internal_proj__vstd!view.DeepView./V_vstd__slice__impl&__1_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__vstd!view.DeepView./V_vstd__slice__impl&__1_assoc_type_impl_false_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (tr_bound%vstd!view.View. A&. A&)
    (= (proj%%vstd!view.View./V (REF A&.) A&) (proj%%vstd!view.View./V A&. A&))
   )
   :pattern ((proj%%vstd!view.View./V (REF A&.) A&))
   :qid internal_proj____vstd!view.View./V_vstd__view__impl&__0_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____vstd!view.View./V_vstd__view__impl&__0_assoc_type_impl_true_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (tr_bound%vstd!view.View. A&. A&)
    (= (proj%vstd!view.View./V (REF A&.) A&) (proj%vstd!view.View./V A&. A&))
   )
   :pattern ((proj%vstd!view.View./V (REF A&.) A&))
   :qid internal_proj__vstd!view.View./V_vstd__view__impl&__0_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__vstd!view.View./V_vstd__view__impl&__0_assoc_type_impl_false_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (tr_bound%vstd!view.DeepView. A&. A&)
    (= (proj%%vstd!view.DeepView./V (REF A&.) A&) (proj%%vstd!view.DeepView./V A&. A&))
   )
   :pattern ((proj%%vstd!view.DeepView./V (REF A&.) A&))
   :qid internal_proj____vstd!view.DeepView./V_vstd__view__impl&__1_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____vstd!view.DeepView./V_vstd__view__impl&__1_assoc_type_impl_true_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (tr_bound%vstd!view.DeepView. A&. A&)
    (= (proj%vstd!view.DeepView./V (REF A&.) A&) (proj%vstd!view.DeepView./V A&. A&))
   )
   :pattern ((proj%vstd!view.DeepView./V (REF A&.) A&))
   :qid internal_proj__vstd!view.DeepView./V_vstd__view__impl&__1_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__vstd!view.DeepView./V_vstd__view__impl&__1_assoc_type_impl_false_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (tr_bound%vstd!view.View. A&. A&)
    (= (proj%%vstd!view.View./V (BOX $ TYPE%alloc!alloc.Global. A&.) A&) (proj%%vstd!view.View./V
      A&. A&
   )))
   :pattern ((proj%%vstd!view.View./V (BOX $ TYPE%alloc!alloc.Global. A&.) A&))
   :qid internal_proj____vstd!view.View./V_vstd__view__impl&__2_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____vstd!view.View./V_vstd__view__impl&__2_assoc_type_impl_true_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (tr_bound%vstd!view.View. A&. A&)
    (= (proj%vstd!view.View./V (BOX $ TYPE%alloc!alloc.Global. A&.) A&) (proj%vstd!view.View./V
      A&. A&
   )))
   :pattern ((proj%vstd!view.View./V (BOX $ TYPE%alloc!alloc.Global. A&.) A&))
   :qid internal_proj__vstd!view.View./V_vstd__view__impl&__2_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__vstd!view.View./V_vstd__view__impl&__2_assoc_type_impl_false_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (tr_bound%vstd!view.DeepView. A&. A&)
    (= (proj%%vstd!view.DeepView./V (BOX $ TYPE%alloc!alloc.Global. A&.) A&) (proj%%vstd!view.DeepView./V
      A&. A&
   )))
   :pattern ((proj%%vstd!view.DeepView./V (BOX $ TYPE%alloc!alloc.Global. A&.) A&))
   :qid internal_proj____vstd!view.DeepView./V_vstd__view__impl&__3_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____vstd!view.DeepView./V_vstd__view__impl&__3_assoc_type_impl_true_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (tr_bound%vstd!view.DeepView. A&. A&)
    (= (proj%vstd!view.DeepView./V (BOX $ TYPE%alloc!alloc.Global. A&.) A&) (proj%vstd!view.DeepView./V
      A&. A&
   )))
   :pattern ((proj%vstd!view.DeepView./V (BOX $ TYPE%alloc!alloc.Global. A&.) A&))
   :qid internal_proj__vstd!view.DeepView./V_vstd__view__impl&__3_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__vstd!view.DeepView./V_vstd__view__impl&__3_assoc_type_impl_false_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%vstd!view.View. A&. A&)
    )
    (= (proj%%vstd!view.View./V (RC $ TYPE%alloc!alloc.Global. A&.) A&) (proj%%vstd!view.View./V
      A&. A&
   )))
   :pattern ((proj%%vstd!view.View./V (RC $ TYPE%alloc!alloc.Global. A&.) A&))
   :qid internal_proj____vstd!view.View./V_vstd__view__impl&__4_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____vstd!view.View./V_vstd__view__impl&__4_assoc_type_impl_true_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%vstd!view.View. A&. A&)
    )
    (= (proj%vstd!view.View./V (RC $ TYPE%alloc!alloc.Global. A&.) A&) (proj%vstd!view.View./V
      A&. A&
   )))
   :pattern ((proj%vstd!view.View./V (RC $ TYPE%alloc!alloc.Global. A&.) A&))
   :qid internal_proj__vstd!view.View./V_vstd__view__impl&__4_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__vstd!view.View./V_vstd__view__impl&__4_assoc_type_impl_false_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%vstd!view.DeepView. A&. A&)
    )
    (= (proj%%vstd!view.DeepView./V (RC $ TYPE%alloc!alloc.Global. A&.) A&) (proj%%vstd!view.DeepView./V
      A&. A&
   )))
   :pattern ((proj%%vstd!view.DeepView./V (RC $ TYPE%alloc!alloc.Global. A&.) A&))
   :qid internal_proj____vstd!view.DeepView./V_vstd__view__impl&__5_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____vstd!view.DeepView./V_vstd__view__impl&__5_assoc_type_impl_true_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%vstd!view.DeepView. A&. A&)
    )
    (= (proj%vstd!view.DeepView./V (RC $ TYPE%alloc!alloc.Global. A&.) A&) (proj%vstd!view.DeepView./V
      A&. A&
   )))
   :pattern ((proj%vstd!view.DeepView./V (RC $ TYPE%alloc!alloc.Global. A&.) A&))
   :qid internal_proj__vstd!view.DeepView./V_vstd__view__impl&__5_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__vstd!view.DeepView./V_vstd__view__impl&__5_assoc_type_impl_false_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%vstd!view.View. A&. A&)
    )
    (= (proj%%vstd!view.View./V (ARC $ TYPE%alloc!alloc.Global. A&.) A&) (proj%%vstd!view.View./V
      A&. A&
   )))
   :pattern ((proj%%vstd!view.View./V (ARC $ TYPE%alloc!alloc.Global. A&.) A&))
   :qid internal_proj____vstd!view.View./V_vstd__view__impl&__6_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____vstd!view.View./V_vstd__view__impl&__6_assoc_type_impl_true_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%vstd!view.View. A&. A&)
    )
    (= (proj%vstd!view.View./V (ARC $ TYPE%alloc!alloc.Global. A&.) A&) (proj%vstd!view.View./V
      A&. A&
   )))
   :pattern ((proj%vstd!view.View./V (ARC $ TYPE%alloc!alloc.Global. A&.) A&))
   :qid internal_proj__vstd!view.View./V_vstd__view__impl&__6_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__vstd!view.View./V_vstd__view__impl&__6_assoc_type_impl_false_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%vstd!view.DeepView. A&. A&)
    )
    (= (proj%%vstd!view.DeepView./V (ARC $ TYPE%alloc!alloc.Global. A&.) A&) (proj%%vstd!view.DeepView./V
      A&. A&
   )))
   :pattern ((proj%%vstd!view.DeepView./V (ARC $ TYPE%alloc!alloc.Global. A&.) A&))
   :qid internal_proj____vstd!view.DeepView./V_vstd__view__impl&__7_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____vstd!view.DeepView./V_vstd__view__impl&__7_assoc_type_impl_true_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%vstd!view.DeepView. A&. A&)
    )
    (= (proj%vstd!view.DeepView./V (ARC $ TYPE%alloc!alloc.Global. A&.) A&) (proj%vstd!view.DeepView./V
      A&. A&
   )))
   :pattern ((proj%vstd!view.DeepView./V (ARC $ TYPE%alloc!alloc.Global. A&.) A&))
   :qid internal_proj__vstd!view.DeepView./V_vstd__view__impl&__7_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__vstd!view.DeepView./V_vstd__view__impl&__7_assoc_type_impl_false_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized T&.)
     (sized A&.)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (= (proj%%vstd!view.View./V $ (TYPE%alloc!vec.Vec. T&. T& A&. A&)) $)
   )
   :pattern ((proj%%vstd!view.View./V $ (TYPE%alloc!vec.Vec. T&. T& A&. A&)))
   :qid internal_proj____vstd!view.View./V_vstd__view__impl&__8_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____vstd!view.View./V_vstd__view__impl&__8_assoc_type_impl_true_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized T&.)
     (sized A&.)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (= (proj%vstd!view.View./V $ (TYPE%alloc!vec.Vec. T&. T& A&. A&)) (TYPE%vstd!seq.Seq.
      T&. T&
   )))
   :pattern ((proj%vstd!view.View./V $ (TYPE%alloc!vec.Vec. T&. T& A&. A&)))
   :qid internal_proj__vstd!view.View./V_vstd__view__impl&__8_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__vstd!view.View./V_vstd__view__impl&__8_assoc_type_impl_false_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized T&.)
     (sized A&.)
     (tr_bound%vstd!view.DeepView. T&. T&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (= (proj%%vstd!view.DeepView./V $ (TYPE%alloc!vec.Vec. T&. T& A&. A&)) $)
   )
   :pattern ((proj%%vstd!view.DeepView./V $ (TYPE%alloc!vec.Vec. T&. T& A&. A&)))
   :qid internal_proj____vstd!view.DeepView./V_vstd__view__impl&__9_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____vstd!view.DeepView./V_vstd__view__impl&__9_assoc_type_impl_true_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized T&.)
     (sized A&.)
     (tr_bound%vstd!view.DeepView. T&. T&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (= (proj%vstd!view.DeepView./V $ (TYPE%alloc!vec.Vec. T&. T& A&. A&)) (TYPE%vstd!seq.Seq.
      (proj%%vstd!view.DeepView./V T&. T&) (proj%vstd!view.DeepView./V T&. T&)
   )))
   :pattern ((proj%vstd!view.DeepView./V $ (TYPE%alloc!vec.Vec. T&. T& A&. A&)))
   :qid internal_proj__vstd!view.DeepView./V_vstd__view__impl&__9_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__vstd!view.DeepView./V_vstd__view__impl&__9_assoc_type_impl_false_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (sized T&.)
    (= (proj%%vstd!view.View./V $ (TYPE%core!option.Option. T&. T&)) $)
   )
   :pattern ((proj%%vstd!view.View./V $ (TYPE%core!option.Option. T&. T&)))
   :qid internal_proj____vstd!view.View./V_vstd__view__impl&__14_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____vstd!view.View./V_vstd__view__impl&__14_assoc_type_impl_true_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (sized T&.)
    (= (proj%vstd!view.View./V $ (TYPE%core!option.Option. T&. T&)) (TYPE%core!option.Option.
      T&. T&
   )))
   :pattern ((proj%vstd!view.View./V $ (TYPE%core!option.Option. T&. T&)))
   :qid internal_proj__vstd!view.View./V_vstd__view__impl&__14_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__vstd!view.View./V_vstd__view__impl&__14_assoc_type_impl_false_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (and
     (sized T&.)
     (tr_bound%vstd!view.DeepView. T&. T&)
    )
    (= (proj%%vstd!view.DeepView./V $ (TYPE%core!option.Option. T&. T&)) $)
   )
   :pattern ((proj%%vstd!view.DeepView./V $ (TYPE%core!option.Option. T&. T&)))
   :qid internal_proj____vstd!view.DeepView./V_vstd__view__impl&__15_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____vstd!view.DeepView./V_vstd__view__impl&__15_assoc_type_impl_true_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (and
     (sized T&.)
     (tr_bound%vstd!view.DeepView. T&. T&)
    )
    (= (proj%vstd!view.DeepView./V $ (TYPE%core!option.Option. T&. T&)) (TYPE%core!option.Option.
      (proj%%vstd!view.DeepView./V T&. T&) (proj%vstd!view.DeepView./V T&. T&)
   )))
   :pattern ((proj%vstd!view.DeepView./V $ (TYPE%core!option.Option. T&. T&)))
   :qid internal_proj__vstd!view.DeepView./V_vstd__view__impl&__15_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__vstd!view.DeepView./V_vstd__view__impl&__15_assoc_type_impl_false_definition
)))
(assert
 (= (proj%%vstd!view.View./V $ TYPE%tuple%0.) $)
)
(assert
 (= (proj%vstd!view.View./V $ TYPE%tuple%0.) TYPE%tuple%0.)
)
(assert
 (= (proj%%vstd!view.DeepView./V $ TYPE%tuple%0.) $)
)
(assert
 (= (proj%vstd!view.DeepView./V $ TYPE%tuple%0.) TYPE%tuple%0.)
)
(assert
 (= (proj%%vstd!view.View./V $ BOOL) $)
)
(assert
 (= (proj%vstd!view.View./V $ BOOL) BOOL)
)
(assert
 (= (proj%%vstd!view.DeepView./V $ BOOL) $)
)
(assert
 (= (proj%vstd!view.DeepView./V $ BOOL) BOOL)
)
(assert
 (= (proj%%vstd!view.View./V $ USIZE) $)
)
(assert
 (= (proj%vstd!view.View./V $ USIZE) USIZE)
)
(assert
 (= (proj%%vstd!view.DeepView./V $ USIZE) $)
)
(assert
 (= (proj%vstd!view.DeepView./V $ USIZE) USIZE)
)
(assert
 (forall ((A0&. Dcr) (A0& Type)) (!
   (=>
    (and
     (sized A0&.)
     (tr_bound%vstd!view.View. A0&. A0&)
    )
    (= (proj%%vstd!view.View./V (DST A0&.) (TYPE%tuple%1. A0&. A0&)) (DST (proj%%vstd!view.View./V
       A0&. A0&
   ))))
   :pattern ((proj%%vstd!view.View./V (DST A0&.) (TYPE%tuple%1. A0&. A0&)))
   :qid internal_proj____vstd!view.View./V_vstd__view__impl&__46_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____vstd!view.View./V_vstd__view__impl&__46_assoc_type_impl_true_definition
)))
(assert
 (forall ((A0&. Dcr) (A0& Type)) (!
   (=>
    (and
     (sized A0&.)
     (tr_bound%vstd!view.View. A0&. A0&)
    )
    (= (proj%vstd!view.View./V (DST A0&.) (TYPE%tuple%1. A0&. A0&)) (TYPE%tuple%1. (proj%%vstd!view.View./V
       A0&. A0&
      ) (proj%vstd!view.View./V A0&. A0&)
   )))
   :pattern ((proj%vstd!view.View./V (DST A0&.) (TYPE%tuple%1. A0&. A0&)))
   :qid internal_proj__vstd!view.View./V_vstd__view__impl&__46_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__vstd!view.View./V_vstd__view__impl&__46_assoc_type_impl_false_definition
)))
(assert
 (forall ((A0&. Dcr) (A0& Type)) (!
   (=>
    (and
     (sized A0&.)
     (tr_bound%vstd!view.DeepView. A0&. A0&)
    )
    (= (proj%%vstd!view.DeepView./V (DST A0&.) (TYPE%tuple%1. A0&. A0&)) (DST (proj%%vstd!view.DeepView./V
       A0&. A0&
   ))))
   :pattern ((proj%%vstd!view.DeepView./V (DST A0&.) (TYPE%tuple%1. A0&. A0&)))
   :qid internal_proj____vstd!view.DeepView./V_vstd__view__impl&__47_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____vstd!view.DeepView./V_vstd__view__impl&__47_assoc_type_impl_true_definition
)))
(assert
 (forall ((A0&. Dcr) (A0& Type)) (!
   (=>
    (and
     (sized A0&.)
     (tr_bound%vstd!view.DeepView. A0&. A0&)
    )
    (= (proj%vstd!view.DeepView./V (DST A0&.) (TYPE%tuple%1. A0&. A0&)) (TYPE%tuple%1.
      (proj%%vstd!view.DeepView./V A0&. A0&) (proj%vstd!view.DeepView./V A0&. A0&)
   )))
   :pattern ((proj%vstd!view.DeepView./V (DST A0&.) (TYPE%tuple%1. A0&. A0&)))
   :qid internal_proj__vstd!view.DeepView./V_vstd__view__impl&__47_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__vstd!view.DeepView./V_vstd__view__impl&__47_assoc_type_impl_false_definition
)))
(assert
 (forall ((A0&. Dcr) (A0& Type) (A1&. Dcr) (A1& Type)) (!
   (=>
    (and
     (sized A0&.)
     (sized A1&.)
     (tr_bound%vstd!view.View. A0&. A0&)
     (tr_bound%vstd!view.View. A1&. A1&)
    )
    (= (proj%%vstd!view.View./V (DST A1&.) (TYPE%tuple%2. A0&. A0& A1&. A1&)) (DST (proj%%vstd!view.View./V
       A1&. A1&
   ))))
   :pattern ((proj%%vstd!view.View./V (DST A1&.) (TYPE%tuple%2. A0&. A0& A1&. A1&)))
   :qid internal_proj____vstd!view.View./V_vstd__view__impl&__48_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____vstd!view.View./V_vstd__view__impl&__48_assoc_type_impl_true_definition
)))
(assert
 (forall ((A0&. Dcr) (A0& Type) (A1&. Dcr) (A1& Type)) (!
   (=>
    (and
     (sized A0&.)
     (sized A1&.)
     (tr_bound%vstd!view.View. A0&. A0&)
     (tr_bound%vstd!view.View. A1&. A1&)
    )
    (= (proj%vstd!view.View./V (DST A1&.) (TYPE%tuple%2. A0&. A0& A1&. A1&)) (TYPE%tuple%2.
      (proj%%vstd!view.View./V A0&. A0&) (proj%vstd!view.View./V A0&. A0&) (proj%%vstd!view.View./V
       A1&. A1&
      ) (proj%vstd!view.View./V A1&. A1&)
   )))
   :pattern ((proj%vstd!view.View./V (DST A1&.) (TYPE%tuple%2. A0&. A0& A1&. A1&)))
   :qid internal_proj__vstd!view.View./V_vstd__view__impl&__48_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__vstd!view.View./V_vstd__view__impl&__48_assoc_type_impl_false_definition
)))
(assert
 (forall ((A0&. Dcr) (A0& Type) (A1&. Dcr) (A1& Type)) (!
   (=>
    (and
     (sized A0&.)
     (sized A1&.)
     (tr_bound%vstd!view.DeepView. A0&. A0&)
     (tr_bound%vstd!view.DeepView. A1&. A1&)
    )
    (= (proj%%vstd!view.DeepView./V (DST A1&.) (TYPE%tuple%2. A0&. A0& A1&. A1&)) (DST
      (proj%%vstd!view.DeepView./V A1&. A1&)
   )))
   :pattern ((proj%%vstd!view.DeepView./V (DST A1&.) (TYPE%tuple%2. A0&. A0& A1&. A1&)))
   :qid internal_proj____vstd!view.DeepView./V_vstd__view__impl&__49_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____vstd!view.DeepView./V_vstd__view__impl&__49_assoc_type_impl_true_definition
)))
(assert
 (forall ((A0&. Dcr) (A0& Type) (A1&. Dcr) (A1& Type)) (!
   (=>
    (and
     (sized A0&.)
     (sized A1&.)
     (tr_bound%vstd!view.DeepView. A0&. A0&)
     (tr_bound%vstd!view.DeepView. A1&. A1&)
    )
    (= (proj%vstd!view.DeepView./V (DST A1&.) (TYPE%tuple%2. A0&. A0& A1&. A1&)) (TYPE%tuple%2.
      (proj%%vstd!view.DeepView./V A0&. A0&) (proj%vstd!view.DeepView./V A0&. A0&) (proj%%vstd!view.DeepView./V
       A1&. A1&
      ) (proj%vstd!view.DeepView./V A1&. A1&)
   )))
   :pattern ((proj%vstd!view.DeepView./V (DST A1&.) (TYPE%tuple%2. A0&. A0& A1&. A1&)))
   :qid internal_proj__vstd!view.DeepView./V_vstd__view__impl&__49_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__vstd!view.DeepView./V_vstd__view__impl&__49_assoc_type_impl_false_definition
)))
(assert
 (forall ((A0&. Dcr) (A0& Type) (A1&. Dcr) (A1& Type) (A2&. Dcr) (A2& Type)) (!
   (=>
    (and
     (sized A0&.)
     (sized A1&.)
     (sized A2&.)
     (tr_bound%vstd!view.View. A0&. A0&)
     (tr_bound%vstd!view.View. A1&. A1&)
     (tr_bound%vstd!view.View. A2&. A2&)
    )
    (= (proj%%vstd!view.View./V (DST A2&.) (TYPE%tuple%3. A0&. A0& A1&. A1& A2&. A2&))
     (DST (proj%%vstd!view.View./V A2&. A2&))
   ))
   :pattern ((proj%%vstd!view.View./V (DST A2&.) (TYPE%tuple%3. A0&. A0& A1&. A1& A2&.
      A2&
   )))
   :qid internal_proj____vstd!view.View./V_vstd__view__impl&__50_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____vstd!view.View./V_vstd__view__impl&__50_assoc_type_impl_true_definition
)))
(assert
 (forall ((A0&. Dcr) (A0& Type) (A1&. Dcr) (A1& Type) (A2&. Dcr) (A2& Type)) (!
   (=>
    (and
     (sized A0&.)
     (sized A1&.)
     (sized A2&.)
     (tr_bound%vstd!view.View. A0&. A0&)
     (tr_bound%vstd!view.View. A1&. A1&)
     (tr_bound%vstd!view.View. A2&. A2&)
    )
    (= (proj%vstd!view.View./V (DST A2&.) (TYPE%tuple%3. A0&. A0& A1&. A1& A2&. A2&))
     (TYPE%tuple%3. (proj%%vstd!view.View./V A0&. A0&) (proj%vstd!view.View./V A0&. A0&)
      (proj%%vstd!view.View./V A1&. A1&) (proj%vstd!view.View./V A1&. A1&) (proj%%vstd!view.View./V
       A2&. A2&
      ) (proj%vstd!view.View./V A2&. A2&)
   )))
   :pattern ((proj%vstd!view.View./V (DST A2&.) (TYPE%tuple%3. A0&. A0& A1&. A1& A2&. A2&)))
   :qid internal_proj__vstd!view.View./V_vstd__view__impl&__50_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__vstd!view.View./V_vstd__view__impl&__50_assoc_type_impl_false_definition
)))
(assert
 (forall ((A0&. Dcr) (A0& Type) (A1&. Dcr) (A1& Type) (A2&. Dcr) (A2& Type)) (!
   (=>
    (and
     (sized A0&.)
     (sized A1&.)
     (sized A2&.)
     (tr_bound%vstd!view.DeepView. A0&. A0&)
     (tr_bound%vstd!view.DeepView. A1&. A1&)
     (tr_bound%vstd!view.DeepView. A2&. A2&)
    )
    (= (proj%%vstd!view.DeepView./V (DST A2&.) (TYPE%tuple%3. A0&. A0& A1&. A1& A2&. A2&))
     (DST (proj%%vstd!view.DeepView./V A2&. A2&))
   ))
   :pattern ((proj%%vstd!view.DeepView./V (DST A2&.) (TYPE%tuple%3. A0&. A0& A1&. A1& A2&.
      A2&
   )))
   :qid internal_proj____vstd!view.DeepView./V_vstd__view__impl&__51_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____vstd!view.DeepView./V_vstd__view__impl&__51_assoc_type_impl_true_definition
)))
(assert
 (forall ((A0&. Dcr) (A0& Type) (A1&. Dcr) (A1& Type) (A2&. Dcr) (A2& Type)) (!
   (=>
    (and
     (sized A0&.)
     (sized A1&.)
     (sized A2&.)
     (tr_bound%vstd!view.DeepView. A0&. A0&)
     (tr_bound%vstd!view.DeepView. A1&. A1&)
     (tr_bound%vstd!view.DeepView. A2&. A2&)
    )
    (= (proj%vstd!view.DeepView./V (DST A2&.) (TYPE%tuple%3. A0&. A0& A1&. A1& A2&. A2&))
     (TYPE%tuple%3. (proj%%vstd!view.DeepView./V A0&. A0&) (proj%vstd!view.DeepView./V A0&.
       A0&
      ) (proj%%vstd!view.DeepView./V A1&. A1&) (proj%vstd!view.DeepView./V A1&. A1&) (proj%%vstd!view.DeepView./V
       A2&. A2&
      ) (proj%vstd!view.DeepView./V A2&. A2&)
   )))
   :pattern ((proj%vstd!view.DeepView./V (DST A2&.) (TYPE%tuple%3. A0&. A0& A1&. A1& A2&.
      A2&
   )))
   :qid internal_proj__vstd!view.DeepView./V_vstd__view__impl&__51_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__vstd!view.DeepView./V_vstd__view__impl&__51_assoc_type_impl_false_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.Fn. F&. F& A&. A&)
    )
    (= (proj%%core!ops.function.FnOnce./Output (REF F&.) F& A&. A&) (proj%%core!ops.function.FnOnce./Output
      F&. F& A&. A&
   )))
   :pattern ((proj%%core!ops.function.FnOnce./Output (REF F&.) F& A&. A&))
   :qid internal_proj____core!ops.function.FnOnce./Output_core__ops__function__impls__impl&__2_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____core!ops.function.FnOnce./Output_core__ops__function__impls__impl&__2_assoc_type_impl_true_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.Fn. F&. F& A&. A&)
    )
    (= (proj%core!ops.function.FnOnce./Output (REF F&.) F& A&. A&) (proj%core!ops.function.FnOnce./Output
      F&. F& A&. A&
   )))
   :pattern ((proj%core!ops.function.FnOnce./Output (REF F&.) F& A&. A&))
   :qid internal_proj__core!ops.function.FnOnce./Output_core__ops__function__impls__impl&__2_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__core!ops.function.FnOnce./Output_core__ops__function__impls__impl&__2_assoc_type_impl_false_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.FnMut. F&. F& A&. A&)
    )
    (= (proj%%core!ops.function.FnOnce./Output $ (MUTREF F&. F&) A&. A&) (proj%%core!ops.function.FnOnce./Output
      F&. F& A&. A&
   )))
   :pattern ((proj%%core!ops.function.FnOnce./Output $ (MUTREF F&. F&) A&. A&))
   :qid internal_proj____core!ops.function.FnOnce./Output_core__ops__function__impls__impl&__4_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____core!ops.function.FnOnce./Output_core__ops__function__impls__impl&__4_assoc_type_impl_true_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.FnMut. F&. F& A&. A&)
    )
    (= (proj%core!ops.function.FnOnce./Output $ (MUTREF F&. F&) A&. A&) (proj%core!ops.function.FnOnce./Output
      F&. F& A&. A&
   )))
   :pattern ((proj%core!ops.function.FnOnce./Output $ (MUTREF F&. F&) A&. A&))
   :qid internal_proj__core!ops.function.FnOnce./Output_core__ops__function__impls__impl&__4_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__core!ops.function.FnOnce./Output_core__ops__function__impls__impl&__4_assoc_type_impl_false_definition
)))
(assert
 (forall ((Args&. Dcr) (Args& Type) (F&. Dcr) (F& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized Args&.)
     (sized A&.)
     (tr_bound%core!marker.Tuple. Args&. Args&)
     (tr_bound%core!ops.function.FnOnce. F&. F& Args&. Args&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (= (proj%%core!ops.function.FnOnce./Output (BOX A&. A& F&.) F& Args&. Args&) (proj%%core!ops.function.FnOnce./Output
      F&. F& Args&. Args&
   )))
   :pattern ((proj%%core!ops.function.FnOnce./Output (BOX A&. A& F&.) F& Args&. Args&))
   :qid internal_proj____core!ops.function.FnOnce./Output_alloc__boxed__impl&__31_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____core!ops.function.FnOnce./Output_alloc__boxed__impl&__31_assoc_type_impl_true_definition
)))
(assert
 (forall ((Args&. Dcr) (Args& Type) (F&. Dcr) (F& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized Args&.)
     (sized A&.)
     (tr_bound%core!marker.Tuple. Args&. Args&)
     (tr_bound%core!ops.function.FnOnce. F&. F& Args&. Args&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (= (proj%core!ops.function.FnOnce./Output (BOX A&. A& F&.) F& Args&. Args&) (proj%core!ops.function.FnOnce./Output
      F&. F& Args&. Args&
   )))
   :pattern ((proj%core!ops.function.FnOnce./Output (BOX A&. A& F&.) F& Args&. Args&))
   :qid internal_proj__core!ops.function.FnOnce./Output_alloc__boxed__impl&__31_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__core!ops.function.FnOnce./Output_alloc__boxed__impl&__31_assoc_type_impl_false_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (and
     (sized T&.)
     (tr_bound%vstd!view.View. T&. T&)
    )
    (= (proj%%vstd!view.View./V $ (TYPE%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS.
       T&. T&
      )
     ) $
   ))
   :pattern ((proj%%vstd!view.View./V $ (TYPE%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS.
      T&. T&
   )))
   :qid internal_proj____vstd!view.View./V_lib__Chap19__ArraySeqMtEph__ArraySeqMtEph__impl&__2_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____vstd!view.View./V_lib__Chap19__ArraySeqMtEph__ArraySeqMtEph__impl&__2_assoc_type_impl_true_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (and
     (sized T&.)
     (tr_bound%vstd!view.View. T&. T&)
    )
    (= (proj%vstd!view.View./V $ (TYPE%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS.
       T&. T&
      )
     ) (TYPE%vstd!seq.Seq. (proj%%vstd!view.View./V T&. T&) (proj%vstd!view.View./V T&.
       T&
   ))))
   :pattern ((proj%vstd!view.View./V $ (TYPE%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS.
      T&. T&
   )))
   :qid internal_proj__vstd!view.View./V_lib__Chap19__ArraySeqMtEph__ArraySeqMtEph__impl&__2_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__vstd!view.View./V_lib__Chap19__ArraySeqMtEph__ArraySeqMtEph__impl&__2_assoc_type_impl_false_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (and
     (sized T&.)
     (tr_bound%vstd!view.View. T&. T&)
    )
    (= (proj%%vstd!view.View./V $ (TYPE%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS.
       T&. T&
      )
     ) $
   ))
   :pattern ((proj%%vstd!view.View./V $ (TYPE%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS.
      T&. T&
   )))
   :qid internal_proj____vstd!view.View./V_lib__Chap19__ArraySeqMtEphSlice__ArraySeqMtEphSlice__impl&__2_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____vstd!view.View./V_lib__Chap19__ArraySeqMtEphSlice__ArraySeqMtEphSlice__impl&__2_assoc_type_impl_true_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (and
     (sized T&.)
     (tr_bound%vstd!view.View. T&. T&)
    )
    (= (proj%vstd!view.View./V $ (TYPE%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS.
       T&. T&
      )
     ) (TYPE%vstd!seq.Seq. (proj%%vstd!view.View./V T&. T&) (proj%vstd!view.View./V T&.
       T&
   ))))
   :pattern ((proj%vstd!view.View./V $ (TYPE%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS.
      T&. T&
   )))
   :qid internal_proj__vstd!view.View./V_lib__Chap19__ArraySeqMtEphSlice__ArraySeqMtEphSlice__impl&__2_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__vstd!view.View./V_lib__Chap19__ArraySeqMtEphSlice__ArraySeqMtEphSlice__impl&__2_assoc_type_impl_false_definition
)))
(assert
 (= (proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $ USIZE)
   (DST (REF $)) (TYPE%tuple%1. (REF $) USIZE)
  ) $
))
(assert
 (= (proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $ USIZE)
   (DST (REF $)) (TYPE%tuple%1. (REF $) USIZE)
  ) USIZE
))
(assert
 (forall ((Self%&. Dcr) (Self%& Type)) (!
   (=>
    (and
     (sized Self%&.)
     (tr_bound%core!clone.Clone. Self%&. Self%&)
    )
    (= (proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. Self%&.
       Self%&
      ) (DST (REF Self%&.)) (TYPE%tuple%1. (REF Self%&.) Self%&)
     ) Self%&.
   ))
   :pattern ((proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. Self%&.
      Self%&
     ) (DST (REF Self%&.)) (TYPE%tuple%1. (REF Self%&.) Self%&)
   ))
   :qid internal_proj____core!ops.function.FnOnce./Output_core__clone__Clone__clone__impl_fndef&__FnOnce_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____core!ops.function.FnOnce./Output_core__clone__Clone__clone__impl_fndef&__FnOnce_assoc_type_impl_true_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type)) (!
   (=>
    (and
     (sized Self%&.)
     (tr_bound%core!clone.Clone. Self%&. Self%&)
    )
    (= (proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. Self%&. Self%&)
      (DST (REF Self%&.)) (TYPE%tuple%1. (REF Self%&.) Self%&)
     ) Self%&
   ))
   :pattern ((proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. Self%&.
      Self%&
     ) (DST (REF Self%&.)) (TYPE%tuple%1. (REF Self%&.) Self%&)
   ))
   :qid internal_proj__core!ops.function.FnOnce./Output_core__clone__Clone__clone__impl_fndef&__FnOnce_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__core!ops.function.FnOnce./Output_core__clone__Clone__clone__impl_fndef&__FnOnce_assoc_type_impl_false_definition
)))
(assert
 (= (proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $ BOOL)
   (DST (REF $)) (TYPE%tuple%1. (REF $) BOOL)
  ) $
))
(assert
 (= (proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $ BOOL)
   (DST (REF $)) (TYPE%tuple%1. (REF $) BOOL)
  ) BOOL
))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (= (proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. (REF T&.)
      T&
     ) (DST (REF (REF T&.))) (TYPE%tuple%1. (REF (REF T&.)) T&)
    ) (REF T&.)
   )
   :pattern ((proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. (
       REF T&.
      ) T&
     ) (DST (REF (REF T&.))) (TYPE%tuple%1. (REF (REF T&.)) T&)
   ))
   :qid internal_proj____core!ops.function.FnOnce./Output_core__clone__impls__impl&__6__clone__impl_fndef&__FnOnce_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____core!ops.function.FnOnce./Output_core__clone__impls__impl&__6__clone__impl_fndef&__FnOnce_assoc_type_impl_true_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (= (proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. (REF T&.)
      T&
     ) (DST (REF (REF T&.))) (TYPE%tuple%1. (REF (REF T&.)) T&)
    ) T&
   )
   :pattern ((proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. (REF
       T&.
      ) T&
     ) (DST (REF (REF T&.))) (TYPE%tuple%1. (REF (REF T&.)) T&)
   ))
   :qid internal_proj__core!ops.function.FnOnce./Output_core__clone__impls__impl&__6__clone__impl_fndef&__FnOnce_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__core!ops.function.FnOnce./Output_core__clone__impls__impl&__6__clone__impl_fndef&__FnOnce_assoc_type_impl_false_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type)) (!
   (=>
    (and
     (sized T&.)
     (uInv SZ (const_int N&))
     (tr_bound%core!clone.Clone. T&. T&)
    )
    (= (proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $ (ARRAY
        T&. T& N&. N&
       )
      ) (DST (REF $)) (TYPE%tuple%1. (REF $) (ARRAY T&. T& N&. N&))
     ) $
   ))
   :pattern ((proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $
      (ARRAY T&. T& N&. N&)
     ) (DST (REF $)) (TYPE%tuple%1. (REF $) (ARRAY T&. T& N&. N&))
   ))
   :qid internal_proj____core!ops.function.FnOnce./Output_core__array__impl&__20__clone__impl_fndef&__FnOnce_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____core!ops.function.FnOnce./Output_core__array__impl&__20__clone__impl_fndef&__FnOnce_assoc_type_impl_true_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type)) (!
   (=>
    (and
     (sized T&.)
     (uInv SZ (const_int N&))
     (tr_bound%core!clone.Clone. T&. T&)
    )
    (= (proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $ (ARRAY T&.
        T& N&. N&
       )
      ) (DST (REF $)) (TYPE%tuple%1. (REF $) (ARRAY T&. T& N&. N&))
     ) (ARRAY T&. T& N&. N&)
   ))
   :pattern ((proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $
      (ARRAY T&. T& N&. N&)
     ) (DST (REF $)) (TYPE%tuple%1. (REF $) (ARRAY T&. T& N&. N&))
   ))
   :qid internal_proj__core!ops.function.FnOnce./Output_core__array__impl&__20__clone__impl_fndef&__FnOnce_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__core!ops.function.FnOnce./Output_core__array__impl&__20__clone__impl_fndef&__FnOnce_assoc_type_impl_false_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (and
     (sized T&.)
     (tr_bound%core!marker.Copy. T&. T&)
    )
    (= (proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. (TRACKED
        T&.
       ) T&
      ) (DST (REF (TRACKED T&.))) (TYPE%tuple%1. (REF (TRACKED T&.)) T&)
     ) (TRACKED T&.)
   ))
   :pattern ((proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. (
       TRACKED T&.
      ) T&
     ) (DST (REF (TRACKED T&.))) (TYPE%tuple%1. (REF (TRACKED T&.)) T&)
   ))
   :qid internal_proj____core!ops.function.FnOnce./Output_verus_builtin__impl&__9__clone__impl_fndef&__FnOnce_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____core!ops.function.FnOnce./Output_verus_builtin__impl&__9__clone__impl_fndef&__FnOnce_assoc_type_impl_true_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (and
     (sized T&.)
     (tr_bound%core!marker.Copy. T&. T&)
    )
    (= (proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. (TRACKED T&.)
       T&
      ) (DST (REF (TRACKED T&.))) (TYPE%tuple%1. (REF (TRACKED T&.)) T&)
     ) T&
   ))
   :pattern ((proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. (TRACKED
       T&.
      ) T&
     ) (DST (REF (TRACKED T&.))) (TYPE%tuple%1. (REF (TRACKED T&.)) T&)
   ))
   :qid internal_proj__core!ops.function.FnOnce./Output_verus_builtin__impl&__9__clone__impl_fndef&__FnOnce_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__core!ops.function.FnOnce./Output_verus_builtin__impl&__9__clone__impl_fndef&__FnOnce_assoc_type_impl_false_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (sized T&.)
    (= (proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. (GHOST T&.)
       T&
      ) (DST (REF (GHOST T&.))) (TYPE%tuple%1. (REF (GHOST T&.)) T&)
     ) (GHOST T&.)
   ))
   :pattern ((proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. (
       GHOST T&.
      ) T&
     ) (DST (REF (GHOST T&.))) (TYPE%tuple%1. (REF (GHOST T&.)) T&)
   ))
   :qid internal_proj____core!ops.function.FnOnce./Output_verus_builtin__impl&__7__clone__impl_fndef&__FnOnce_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____core!ops.function.FnOnce./Output_verus_builtin__impl&__7__clone__impl_fndef&__FnOnce_assoc_type_impl_true_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (sized T&.)
    (= (proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. (GHOST T&.)
       T&
      ) (DST (REF (GHOST T&.))) (TYPE%tuple%1. (REF (GHOST T&.)) T&)
     ) T&
   ))
   :pattern ((proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. (GHOST
       T&.
      ) T&
     ) (DST (REF (GHOST T&.))) (TYPE%tuple%1. (REF (GHOST T&.)) T&)
   ))
   :qid internal_proj__core!ops.function.FnOnce./Output_verus_builtin__impl&__7__clone__impl_fndef&__FnOnce_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__core!ops.function.FnOnce./Output_verus_builtin__impl&__7__clone__impl_fndef&__FnOnce_assoc_type_impl_false_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (and
     (sized T&.)
     (tr_bound%core!clone.Clone. T&. T&)
    )
    (= (proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $ (TYPE%core!option.Option.
        T&. T&
       )
      ) (DST (REF $)) (TYPE%tuple%1. (REF $) (TYPE%core!option.Option. T&. T&))
     ) $
   ))
   :pattern ((proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $
      (TYPE%core!option.Option. T&. T&)
     ) (DST (REF $)) (TYPE%tuple%1. (REF $) (TYPE%core!option.Option. T&. T&))
   ))
   :qid internal_proj____core!ops.function.FnOnce./Output_core__option__impl&__6__clone__impl_fndef&__FnOnce_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____core!ops.function.FnOnce./Output_core__option__impl&__6__clone__impl_fndef&__FnOnce_assoc_type_impl_true_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (and
     (sized T&.)
     (tr_bound%core!clone.Clone. T&. T&)
    )
    (= (proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $ (TYPE%core!option.Option.
        T&. T&
       )
      ) (DST (REF $)) (TYPE%tuple%1. (REF $) (TYPE%core!option.Option. T&. T&))
     ) (TYPE%core!option.Option. T&. T&)
   ))
   :pattern ((proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $
      (TYPE%core!option.Option. T&. T&)
     ) (DST (REF $)) (TYPE%tuple%1. (REF $) (TYPE%core!option.Option. T&. T&))
   ))
   :qid internal_proj__core!ops.function.FnOnce./Output_core__option__impl&__6__clone__impl_fndef&__FnOnce_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__core!ops.function.FnOnce./Output_core__option__impl&__6__clone__impl_fndef&__FnOnce_assoc_type_impl_false_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized T&.)
     (sized A&.)
     (tr_bound%core!clone.Clone. T&. T&)
     (tr_bound%core!alloc.Allocator. A&. A&)
     (tr_bound%core!clone.Clone. A&. A&)
    )
    (= (proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $ (TYPE%alloc!vec.Vec.
        T&. T& A&. A&
       )
      ) (DST (REF $)) (TYPE%tuple%1. (REF $) (TYPE%alloc!vec.Vec. T&. T& A&. A&))
     ) $
   ))
   :pattern ((proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $
      (TYPE%alloc!vec.Vec. T&. T& A&. A&)
     ) (DST (REF $)) (TYPE%tuple%1. (REF $) (TYPE%alloc!vec.Vec. T&. T& A&. A&))
   ))
   :qid internal_proj____core!ops.function.FnOnce./Output_alloc__vec__impl&__12__clone__impl_fndef&__FnOnce_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____core!ops.function.FnOnce./Output_alloc__vec__impl&__12__clone__impl_fndef&__FnOnce_assoc_type_impl_true_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized T&.)
     (sized A&.)
     (tr_bound%core!clone.Clone. T&. T&)
     (tr_bound%core!alloc.Allocator. A&. A&)
     (tr_bound%core!clone.Clone. A&. A&)
    )
    (= (proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $ (TYPE%alloc!vec.Vec.
        T&. T& A&. A&
       )
      ) (DST (REF $)) (TYPE%tuple%1. (REF $) (TYPE%alloc!vec.Vec. T&. T& A&. A&))
     ) (TYPE%alloc!vec.Vec. T&. T& A&. A&)
   ))
   :pattern ((proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $
      (TYPE%alloc!vec.Vec. T&. T& A&. A&)
     ) (DST (REF $)) (TYPE%tuple%1. (REF $) (TYPE%alloc!vec.Vec. T&. T& A&. A&))
   ))
   :qid internal_proj__core!ops.function.FnOnce./Output_alloc__vec__impl&__12__clone__impl_fndef&__FnOnce_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__core!ops.function.FnOnce./Output_alloc__vec__impl&__12__clone__impl_fndef&__FnOnce_assoc_type_impl_false_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized T&.)
     (sized A&.)
     (tr_bound%core!clone.Clone. T&. T&)
     (tr_bound%core!alloc.Allocator. A&. A&)
     (tr_bound%core!clone.Clone. A&. A&)
    )
    (= (proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. (BOX A&.
        A& T&.
       ) T&
      ) (DST (REF (BOX A&. A& T&.))) (TYPE%tuple%1. (REF (BOX A&. A& T&.)) T&)
     ) (BOX A&. A& T&.)
   ))
   :pattern ((proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. (
       BOX A&. A& T&.
      ) T&
     ) (DST (REF (BOX A&. A& T&.))) (TYPE%tuple%1. (REF (BOX A&. A& T&.)) T&)
   ))
   :qid internal_proj____core!ops.function.FnOnce./Output_alloc__boxed__impl&__15__clone__impl_fndef&__FnOnce_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____core!ops.function.FnOnce./Output_alloc__boxed__impl&__15__clone__impl_fndef&__FnOnce_assoc_type_impl_true_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized T&.)
     (sized A&.)
     (tr_bound%core!clone.Clone. T&. T&)
     (tr_bound%core!alloc.Allocator. A&. A&)
     (tr_bound%core!clone.Clone. A&. A&)
    )
    (= (proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. (BOX A&. A&
        T&.
       ) T&
      ) (DST (REF (BOX A&. A& T&.))) (TYPE%tuple%1. (REF (BOX A&. A& T&.)) T&)
     ) T&
   ))
   :pattern ((proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. (BOX
       A&. A& T&.
      ) T&
     ) (DST (REF (BOX A&. A& T&.))) (TYPE%tuple%1. (REF (BOX A&. A& T&.)) T&)
   ))
   :qid internal_proj__core!ops.function.FnOnce./Output_alloc__boxed__impl&__15__clone__impl_fndef&__FnOnce_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__core!ops.function.FnOnce./Output_alloc__boxed__impl&__15__clone__impl_fndef&__FnOnce_assoc_type_impl_false_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!alloc.Allocator. A&. A&)
     (tr_bound%core!clone.Clone. A&. A&)
    )
    (= (proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. (ARC A&.
        A& T&.
       ) T&
      ) (DST (REF (ARC A&. A& T&.))) (TYPE%tuple%1. (REF (ARC A&. A& T&.)) T&)
     ) (ARC A&. A& T&.)
   ))
   :pattern ((proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. (
       ARC A&. A& T&.
      ) T&
     ) (DST (REF (ARC A&. A& T&.))) (TYPE%tuple%1. (REF (ARC A&. A& T&.)) T&)
   ))
   :qid internal_proj____core!ops.function.FnOnce./Output_alloc__sync__impl&__32__clone__impl_fndef&__FnOnce_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____core!ops.function.FnOnce./Output_alloc__sync__impl&__32__clone__impl_fndef&__FnOnce_assoc_type_impl_true_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!alloc.Allocator. A&. A&)
     (tr_bound%core!clone.Clone. A&. A&)
    )
    (= (proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. (ARC A&. A&
        T&.
       ) T&
      ) (DST (REF (ARC A&. A& T&.))) (TYPE%tuple%1. (REF (ARC A&. A& T&.)) T&)
     ) T&
   ))
   :pattern ((proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. (ARC
       A&. A& T&.
      ) T&
     ) (DST (REF (ARC A&. A& T&.))) (TYPE%tuple%1. (REF (ARC A&. A& T&.)) T&)
   ))
   :qid internal_proj__core!ops.function.FnOnce./Output_alloc__sync__impl&__32__clone__impl_fndef&__FnOnce_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__core!ops.function.FnOnce./Output_alloc__sync__impl&__32__clone__impl_fndef&__FnOnce_assoc_type_impl_false_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (and
     (sized T&.)
     (tr_bound%core!clone.Clone. T&. T&)
    )
    (= (proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $ (TYPE%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS.
        T&. T&
       )
      ) (DST (REF $)) (TYPE%tuple%1. (REF $) (TYPE%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS.
        T&. T&
      ))
     ) $
   ))
   :pattern ((proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $
      (TYPE%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS. T&. T&)
     ) (DST (REF $)) (TYPE%tuple%1. (REF $) (TYPE%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS.
       T&. T&
   ))))
   :qid internal_proj____core!ops.function.FnOnce./Output_lib__Chap19__ArraySeqMtEph__ArraySeqMtEph__impl&__8__clone__impl_fndef&__FnOnce_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____core!ops.function.FnOnce./Output_lib__Chap19__ArraySeqMtEph__ArraySeqMtEph__impl&__8__clone__impl_fndef&__FnOnce_assoc_type_impl_true_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (and
     (sized T&.)
     (tr_bound%core!clone.Clone. T&. T&)
    )
    (= (proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $ (TYPE%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS.
        T&. T&
       )
      ) (DST (REF $)) (TYPE%tuple%1. (REF $) (TYPE%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS.
        T&. T&
      ))
     ) (TYPE%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS. T&. T&)
   ))
   :pattern ((proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $
      (TYPE%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS. T&. T&)
     ) (DST (REF $)) (TYPE%tuple%1. (REF $) (TYPE%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS.
       T&. T&
   ))))
   :qid internal_proj__core!ops.function.FnOnce./Output_lib__Chap19__ArraySeqMtEph__ArraySeqMtEph__impl&__8__clone__impl_fndef&__FnOnce_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__core!ops.function.FnOnce./Output_lib__Chap19__ArraySeqMtEph__ArraySeqMtEph__impl&__8__clone__impl_fndef&__FnOnce_assoc_type_impl_false_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (and
     (sized T&.)
     (tr_bound%core!clone.Clone. T&. T&)
    )
    (= (proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $ (TYPE%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS.
        T&. T&
       )
      ) (DST (REF $)) (TYPE%tuple%1. (REF $) (TYPE%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS.
        T&. T&
      ))
     ) $
   ))
   :pattern ((proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $
      (TYPE%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS. T&. T&)
     ) (DST (REF $)) (TYPE%tuple%1. (REF $) (TYPE%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS.
       T&. T&
   ))))
   :qid internal_proj____core!ops.function.FnOnce./Output_lib__Chap19__ArraySeqMtEphSlice__ArraySeqMtEphSlice__impl&__6__clone__impl_fndef&__FnOnce_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____core!ops.function.FnOnce./Output_lib__Chap19__ArraySeqMtEphSlice__ArraySeqMtEphSlice__impl&__6__clone__impl_fndef&__FnOnce_assoc_type_impl_true_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (and
     (sized T&.)
     (tr_bound%core!clone.Clone. T&. T&)
    )
    (= (proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $ (TYPE%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS.
        T&. T&
       )
      ) (DST (REF $)) (TYPE%tuple%1. (REF $) (TYPE%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS.
        T&. T&
      ))
     ) (TYPE%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS. T&.
      T&
   )))
   :pattern ((proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $
      (TYPE%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS. T&. T&)
     ) (DST (REF $)) (TYPE%tuple%1. (REF $) (TYPE%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS.
       T&. T&
   ))))
   :qid internal_proj__core!ops.function.FnOnce./Output_lib__Chap19__ArraySeqMtEphSlice__ArraySeqMtEphSlice__impl&__6__clone__impl_fndef&__FnOnce_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__core!ops.function.FnOnce./Output_lib__Chap19__ArraySeqMtEphSlice__ArraySeqMtEphSlice__impl&__6__clone__impl_fndef&__FnOnce_assoc_type_impl_false_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (and
     (sized T&.)
     (tr_bound%lib!Concurrency.Concurrency.StTInMtT. T&. T&)
     (tr_bound%lib!vstdplus.total_order.total_order.TotalOrder. T&. T&)
     (tr_bound%core!marker.Copy. T&. T&)
    )
    (= (proj%%core!ops.function.FnOnce./Output $ (TYPE%anonymous_closure%697. T&. T&) $
      TYPE%tuple%0.
     ) (DST $)
   ))
   :pattern ((proj%%core!ops.function.FnOnce./Output $ (TYPE%anonymous_closure%697. T&.
      T&
     ) $ TYPE%tuple%0.
   ))
   :qid internal_proj____core!ops.function.FnOnce./Output_crate__impl_closure&__FnOnce697_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____core!ops.function.FnOnce./Output_crate__impl_closure&__FnOnce697_assoc_type_impl_true_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (and
     (sized T&.)
     (tr_bound%lib!Concurrency.Concurrency.StTInMtT. T&. T&)
     (tr_bound%lib!vstdplus.total_order.total_order.TotalOrder. T&. T&)
     (tr_bound%core!marker.Copy. T&. T&)
    )
    (= (proj%core!ops.function.FnOnce./Output $ (TYPE%anonymous_closure%697. T&. T&) $
      TYPE%tuple%0.
     ) (TYPE%tuple%3. $ (TYPE%alloc!vec.Vec. T&. T& $ TYPE%alloc!alloc.Global.) $ (TYPE%alloc!vec.Vec.
       T&. T& $ TYPE%alloc!alloc.Global.
      ) $ (TYPE%alloc!vec.Vec. T&. T& $ TYPE%alloc!alloc.Global.)
   )))
   :pattern ((proj%core!ops.function.FnOnce./Output $ (TYPE%anonymous_closure%697. T&.
      T&
     ) $ TYPE%tuple%0.
   ))
   :qid internal_proj__core!ops.function.FnOnce./Output_crate__impl_closure&__FnOnce697_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__core!ops.function.FnOnce./Output_crate__impl_closure&__FnOnce697_assoc_type_impl_false_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (and
     (sized T&.)
     (tr_bound%lib!Concurrency.Concurrency.StTInMtT. T&. T&)
     (tr_bound%lib!vstdplus.total_order.total_order.TotalOrder. T&. T&)
     (tr_bound%core!marker.Copy. T&. T&)
    )
    (= (proj%%core!ops.function.FnOnce./Output $ (TYPE%anonymous_closure%702. T&. T&) $
      TYPE%tuple%0.
     ) (DST $)
   ))
   :pattern ((proj%%core!ops.function.FnOnce./Output $ (TYPE%anonymous_closure%702. T&.
      T&
     ) $ TYPE%tuple%0.
   ))
   :qid internal_proj____core!ops.function.FnOnce./Output_crate__impl_closure&__FnOnce702_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____core!ops.function.FnOnce./Output_crate__impl_closure&__FnOnce702_assoc_type_impl_true_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (and
     (sized T&.)
     (tr_bound%lib!Concurrency.Concurrency.StTInMtT. T&. T&)
     (tr_bound%lib!vstdplus.total_order.total_order.TotalOrder. T&. T&)
     (tr_bound%core!marker.Copy. T&. T&)
    )
    (= (proj%core!ops.function.FnOnce./Output $ (TYPE%anonymous_closure%702. T&. T&) $
      TYPE%tuple%0.
     ) (TYPE%tuple%3. $ (TYPE%alloc!vec.Vec. T&. T& $ TYPE%alloc!alloc.Global.) $ (TYPE%alloc!vec.Vec.
       T&. T& $ TYPE%alloc!alloc.Global.
      ) $ (TYPE%alloc!vec.Vec. T&. T& $ TYPE%alloc!alloc.Global.)
   )))
   :pattern ((proj%core!ops.function.FnOnce./Output $ (TYPE%anonymous_closure%702. T&.
      T&
     ) $ TYPE%tuple%0.
   ))
   :qid internal_proj__core!ops.function.FnOnce./Output_crate__impl_closure&__FnOnce702_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__core!ops.function.FnOnce./Output_crate__impl_closure&__FnOnce702_assoc_type_impl_false_definition
)))

;; Function-Decl vstd::seq::Seq::len
(declare-fun vstd!seq.Seq.len.? (Dcr Type Poly) Int)

;; Function-Decl vstd::seq::Seq::index
(declare-fun vstd!seq.Seq.index.? (Dcr Type Poly Poly) Poly)

;; Function-Decl vstd::seq::impl&%2::spec_index
(declare-fun vstd!seq.impl&%2.spec_index.? (Dcr Type Poly Poly) Poly)

;; Function-Decl vstd::seq::Seq::subrange
(declare-fun vstd!seq.Seq.subrange.? (Dcr Type Poly Poly Poly) Poly)

;; Function-Decl vstd::seq::Seq::empty
(declare-fun vstd!seq.Seq.empty.? (Dcr Type) Poly)

;; Function-Decl vstd::seq::Seq::new
(declare-fun vstd!seq.Seq.new.? (Dcr Type Poly Poly) Poly)

;; Function-Decl vstd::seq::Seq::push
(declare-fun vstd!seq.Seq.push.? (Dcr Type Poly Poly) Poly)

;; Function-Decl vstd::seq::Seq::add
(declare-fun vstd!seq.Seq.add.? (Dcr Type Poly Poly) Poly)

;; Function-Decl vstd::seq_lib::impl&%0::contains
(declare-fun vstd!seq_lib.impl&%0.contains.? (Dcr Type Poly Poly) Bool)

;; Function-Decl vstd::seq::impl&%2::spec_add
(declare-fun vstd!seq.impl&%2.spec_add.? (Dcr Type Poly Poly) Poly)

;; Function-Decl vstd::seq_lib::impl&%0::drop_last
(declare-fun vstd!seq_lib.impl&%0.drop_last.? (Dcr Type Poly) Poly)

;; Function-Decl vstd::multiset::impl&%0::count
(declare-fun vstd!multiset.impl&%0.count.? (Dcr Type Poly Poly) Int)

;; Function-Decl vstd::multiset::impl&%0::singleton
(declare-fun vstd!multiset.impl&%0.singleton.? (Dcr Type Poly) Poly)

;; Function-Decl vstd::multiset::impl&%0::add
(declare-fun vstd!multiset.impl&%0.add.? (Dcr Type Poly Poly) Poly)

;; Function-Decl vstd::multiset::impl&%0::len
(declare-fun vstd!multiset.impl&%0.len.? (Dcr Type Poly) Int)

;; Function-Decl vstd::std_specs::cmp::PartialEqSpec::eq_spec
(declare-fun vstd!std_specs.cmp.PartialEqSpec.eq_spec.? (Dcr Type Dcr Type Poly Poly)
 Poly
)
(declare-fun vstd!std_specs.cmp.PartialEqSpec.eq_spec%default%.? (Dcr Type Dcr Type
  Poly Poly
 ) Poly
)

;; Function-Decl vstd::view::View::view
(declare-fun vstd!view.View.view.? (Dcr Type Poly) Poly)
(declare-fun vstd!view.View.view%default%.? (Dcr Type Poly) Poly)

;; Function-Decl vstd::view::DeepView::deep_view
(declare-fun vstd!view.DeepView.deep_view.? (Dcr Type Poly) Poly)
(declare-fun vstd!view.DeepView.deep_view%default%.? (Dcr Type Poly) Poly)

;; Function-Decl vstd::slice::spec_slice_len
(declare-fun vstd!slice.spec_slice_len.? (Dcr Type Poly) Int)

;; Function-Decl vstd::slice::len%returns_clause_autospec
(declare-fun vstd!slice.len%returns_clause_autospec.? (Dcr Type Poly) Int)

;; Function-Decl vstd::slice::SliceAdditionalSpecFns::spec_index
(declare-fun vstd!slice.SliceAdditionalSpecFns.spec_index.? (Dcr Type Dcr Type Poly
  Poly
 ) Poly
)
(declare-fun vstd!slice.SliceAdditionalSpecFns.spec_index%default%.? (Dcr Type Dcr
  Type Poly Poly
 ) Poly
)

;; Function-Decl vstd::array::array_view
(declare-fun vstd!array.array_view.? (Dcr Type Dcr Type Poly) Poly)

;; Function-Decl vstd::array::ArrayAdditionalSpecFns::spec_index
(declare-fun vstd!array.ArrayAdditionalSpecFns.spec_index.? (Dcr Type Dcr Type Poly
  Poly
 ) Poly
)
(declare-fun vstd!array.ArrayAdditionalSpecFns.spec_index%default%.? (Dcr Type Dcr
  Type Poly Poly
 ) Poly
)

;; Function-Decl vstd::raw_ptr::view_reverse_for_eq
(declare-fun vstd!raw_ptr.view_reverse_for_eq.? (Dcr Type Poly) Poly)

;; Function-Decl vstd::raw_ptr::view_reverse_for_eq_sized
(declare-fun vstd!raw_ptr.view_reverse_for_eq_sized.? (Dcr Type Poly Poly) Poly)

;; Function-Decl vstd::std_specs::vec::spec_vec_len
(declare-fun vstd!std_specs.vec.spec_vec_len.? (Dcr Type Dcr Type Poly) Int)

;; Function-Decl vstd::std_specs::vec::VecAdditionalSpecFns::spec_index
(declare-fun vstd!std_specs.vec.VecAdditionalSpecFns.spec_index.? (Dcr Type Dcr Type
  Poly Poly
 ) Poly
)
(declare-fun vstd!std_specs.vec.VecAdditionalSpecFns.spec_index%default%.? (Dcr Type
  Dcr Type Poly Poly
 ) Poly
)

;; Function-Decl vstd::std_specs::vec::vec_clone_trigger
(declare-fun vstd!std_specs.vec.vec_clone_trigger.? (Dcr Type Dcr Type Poly Poly)
 Bool
)

;; Function-Decl vstd::std_specs::option::OptionAdditionalFns::arrow_0
(declare-fun vstd!std_specs.option.OptionAdditionalFns.arrow_0.? (Dcr Type Dcr Type
  Poly
 ) Poly
)
(declare-fun vstd!std_specs.option.OptionAdditionalFns.arrow_0%default%.? (Dcr Type
  Dcr Type Poly
 ) Poly
)

;; Function-Decl lib::vstdplus::total_order::total_order::TotalOrder::le
(declare-fun lib!vstdplus.total_order.total_order.TotalOrder.le.? (Dcr Type Poly Poly)
 Poly
)
(declare-fun lib!vstdplus.total_order.total_order.TotalOrder.le%default%.? (Dcr Type
  Poly Poly
 ) Poly
)

;; Function-Decl vstd::pervasive::strictly_cloned
(declare-fun vstd!pervasive.strictly_cloned.? (Dcr Type Poly Poly) Bool)

;; Function-Decl vstd::pervasive::cloned
(declare-fun vstd!pervasive.cloned.? (Dcr Type Poly Poly) Bool)

;; Function-Decl vstd::seq::impl&%2::take
(declare-fun vstd!seq.impl&%2.take.? (Dcr Type Poly Poly) Poly)

;; Function-Decl vstd::seq::impl&%2::skip
(declare-fun vstd!seq.impl&%2.skip.? (Dcr Type Poly Poly) Poly)

;; Function-Decl vstd::seq_lib::impl&%0::to_multiset
(declare-fun vstd!seq_lib.impl&%0.to_multiset.? (Dcr Type Poly) Poly)

;; Function-Decl vstd::multiset::impl&%0::insert
(declare-fun vstd!multiset.impl&%0.insert.? (Dcr Type Poly Poly) Poly)

;; Function-Decl lib::vstdplus::feq::feq::obeys_feq_clone
(declare-fun lib!vstdplus.feq.feq.obeys_feq_clone.? (Dcr Type) Bool)

;; Function-Decl vstd::pervasive::FnWithRequiresEnsures::requires
(declare-fun vstd!pervasive.FnWithRequiresEnsures.requires.? (Dcr Type Dcr Type Dcr
  Type Poly Poly
 ) Poly
)
(declare-fun vstd!pervasive.FnWithRequiresEnsures.requires%default%.? (Dcr Type Dcr
  Type Dcr Type Poly Poly
 ) Poly
)

;; Function-Decl vstd::pervasive::FnWithRequiresEnsures::ensures
(declare-fun vstd!pervasive.FnWithRequiresEnsures.ensures.? (Dcr Type Dcr Type Dcr
  Type Poly Poly Poly
 ) Poly
)
(declare-fun vstd!pervasive.FnWithRequiresEnsures.ensures%default%.? (Dcr Type Dcr
  Type Dcr Type Poly Poly Poly
 ) Poly
)

;; Function-Decl lib::Chap19::ArraySeqMtEphSlice::ArraySeqMtEphSlice::ArraySeqMtEphSliceTrait::spec_arrayseqmtephslice_wf
(declare-fun lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceTrait.spec_arrayseqmtephslice_wf.?
 (Dcr Type Dcr Type Poly) Poly
)
(declare-fun lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceTrait.spec_arrayseqmtephslice_wf%default%.?
 (Dcr Type Dcr Type Poly) Poly
)

;; Function-Decl lib::Chap19::ArraySeqMtEphSlice::ArraySeqMtEphSlice::ArraySeqMtEphSliceTrait::spec_len
(declare-fun lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceTrait.spec_len.?
 (Dcr Type Dcr Type Poly) Poly
)
(declare-fun lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceTrait.spec_len%default%.?
 (Dcr Type Dcr Type Poly) Poly
)

;; Function-Decl lib::Chap19::ArraySeqMtEphSlice::ArraySeqMtEphSlice::ArraySeqMtEphSliceTrait::spec_index
(declare-fun lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceTrait.spec_index.?
 (Dcr Type Dcr Type Poly Poly) Poly
)
(declare-fun lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceTrait.spec_index%default%.?
 (Dcr Type Dcr Type Poly Poly) Poly
)

;; Function-Decl vstd::relations::reflexive
(declare-fun vstd!relations.reflexive.? (Dcr Type Poly) Bool)

;; Function-Decl vstd::relations::antisymmetric
(declare-fun vstd!relations.antisymmetric.? (Dcr Type Poly) Bool)

;; Function-Decl vstd::relations::transitive
(declare-fun vstd!relations.transitive.? (Dcr Type Poly) Bool)

;; Function-Decl vstd::relations::strongly_connected
(declare-fun vstd!relations.strongly_connected.? (Dcr Type Poly) Bool)

;; Function-Decl vstd::relations::total_ordering
(declare-fun vstd!relations.total_ordering.? (Dcr Type Poly) Bool)

;; Function-Decl vstd::seq_lib::impl&%0::sort_by
(declare-fun vstd!seq_lib.impl&%0.sort_by.? (Dcr Type Poly Poly) Poly)

;; Function-Decl lib::Chap19::ArraySeqMtEph::ArraySeqMtEph::ArraySeqMtEphTrait::spec_len
(declare-fun lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphTrait.spec_len.?
 (Dcr Type Dcr Type Poly) Poly
)
(declare-fun lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphTrait.spec_len%default%.?
 (Dcr Type Dcr Type Poly) Poly
)

;; Function-Decl lib::Chap19::ArraySeqMtEph::ArraySeqMtEph::ArraySeqMtEphTrait::spec_index
(declare-fun lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphTrait.spec_index.?
 (Dcr Type Dcr Type Poly Poly) Poly
)
(declare-fun lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphTrait.spec_index%default%.?
 (Dcr Type Dcr Type Poly Poly) Poly
)

;; Function-Decl lib::Chap35::OrderStatSelectMtEph::OrderStatSelectMtEph::spec_leq
(declare-fun lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.spec_leq.? (Dcr Type)
 %%Function%%
)

;; Function-Decl lib::Chap35::OrderStatSelectMtEph::OrderStatSelectMtEph::spec_kth
(declare-fun lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.spec_kth.? (Dcr Type
  Poly Poly
 ) Poly
)

;; Function-Decl vstd::std_specs::option::is_some
(declare-fun vstd!std_specs.option.is_some.? (Dcr Type Poly) Bool)

;; Function-Decl vstd::std_specs::option::is_none
(declare-fun vstd!std_specs.option.is_none.? (Dcr Type Poly) Bool)

;; Function-Decl vstd::std_specs::option::spec_unwrap
(declare-fun vstd!std_specs.option.spec_unwrap.? (Dcr Type Poly) Poly)

;; Function-Decl vstd::relations::sorted_by
(declare-fun vstd!relations.sorted_by.? (Dcr Type Poly Poly) Bool)

;; Function-Decl vstd::seq_lib::impl&%0::map
(declare-fun vstd!seq_lib.impl&%0.map.? (Dcr Type Dcr Type Poly Poly) Poly)

;; Function-Decl lib::Chap35::OrderStatSelectMtEph::OrderStatSelectMtEph::spec_const_seq
(declare-fun lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.spec_const_seq.?
 (Dcr Type Poly Poly) Poly
)

;; Function-Decl lib::Chap35::OrderStatSelectMtEph::OrderStatSelectMtEph::spec_slice_elements
(declare-fun lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.spec_slice_elements.?
 (Dcr Type Poly) Poly
)

;; Function-Axioms vstd::seq::Seq::len
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly)) (!
   (=>
    (has_type self! (TYPE%vstd!seq.Seq. A&. A&))
    (<= 0 (vstd!seq.Seq.len.? A&. A& self!))
   )
   :pattern ((vstd!seq.Seq.len.? A&. A& self!))
   :qid internal_vstd!seq.Seq.len.?_pre_post_definition
   :skolemid skolem_internal_vstd!seq.Seq.len.?_pre_post_definition
)))

;; Function-Specs vstd::seq::Seq::index
(declare-fun req%vstd!seq.Seq.index. (Dcr Type Poly Poly) Bool)
(declare-const %%global_location_label%%0 Bool)
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly) (i! Poly)) (!
   (= (req%vstd!seq.Seq.index. A&. A& self! i!) (=>
     %%global_location_label%%0
     (let
      ((tmp%%$ 0))
      (let
       ((tmp%%$1 (%I i!)))
       (let
        ((tmp%%$2 (vstd!seq.Seq.len.? A&. A& self!)))
        (and
         (<= tmp%%$ tmp%%$1)
         (< tmp%%$1 tmp%%$2)
   ))))))
   :pattern ((req%vstd!seq.Seq.index. A&. A& self! i!))
   :qid internal_req__vstd!seq.Seq.index._definition
   :skolemid skolem_internal_req__vstd!seq.Seq.index._definition
)))

;; Function-Axioms vstd::seq::Seq::index
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly) (i! Poly)) (!
   (=>
    (and
     (has_type self! (TYPE%vstd!seq.Seq. A&. A&))
     (has_type i! INT)
    )
    (has_type (vstd!seq.Seq.index.? A&. A& self! i!) A&)
   )
   :pattern ((vstd!seq.Seq.index.? A&. A& self! i!))
   :qid internal_vstd!seq.Seq.index.?_pre_post_definition
   :skolemid skolem_internal_vstd!seq.Seq.index.?_pre_post_definition
)))

;; Function-Specs vstd::seq::impl&%2::spec_index
(declare-fun req%vstd!seq.impl&%2.spec_index. (Dcr Type Poly Poly) Bool)
(declare-const %%global_location_label%%1 Bool)
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly) (i! Poly)) (!
   (= (req%vstd!seq.impl&%2.spec_index. A&. A& self! i!) (=>
     %%global_location_label%%1
     (let
      ((tmp%%$ 0))
      (let
       ((tmp%%$1 (%I i!)))
       (let
        ((tmp%%$2 (vstd!seq.Seq.len.? A&. A& self!)))
        (and
         (<= tmp%%$ tmp%%$1)
         (< tmp%%$1 tmp%%$2)
   ))))))
   :pattern ((req%vstd!seq.impl&%2.spec_index. A&. A& self! i!))
   :qid internal_req__vstd!seq.impl&__2.spec_index._definition
   :skolemid skolem_internal_req__vstd!seq.impl&__2.spec_index._definition
)))

;; Function-Axioms vstd::seq::impl&%2::spec_index
(assert
 (fuel_bool_default fuel%vstd!seq.impl&%2.spec_index.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!seq.impl&%2.spec_index.)
  (forall ((A&. Dcr) (A& Type) (self! Poly) (i! Poly)) (!
    (= (vstd!seq.impl&%2.spec_index.? A&. A& self! i!) (vstd!seq.Seq.index.? A&. A& self!
      i!
    ))
    :pattern ((vstd!seq.impl&%2.spec_index.? A&. A& self! i!))
    :qid internal_vstd!seq.impl&__2.spec_index.?_definition
    :skolemid skolem_internal_vstd!seq.impl&__2.spec_index.?_definition
))))
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly) (i! Poly)) (!
   (=>
    (and
     (has_type self! (TYPE%vstd!seq.Seq. A&. A&))
     (has_type i! INT)
    )
    (has_type (vstd!seq.impl&%2.spec_index.? A&. A& self! i!) A&)
   )
   :pattern ((vstd!seq.impl&%2.spec_index.? A&. A& self! i!))
   :qid internal_vstd!seq.impl&__2.spec_index.?_pre_post_definition
   :skolemid skolem_internal_vstd!seq.impl&__2.spec_index.?_pre_post_definition
)))

;; Broadcast vstd::seq::lemma_seq_index_decreases
(assert
 (=>
  (fuel_bool fuel%vstd!seq.lemma_seq_index_decreases.)
  (forall ((A&. Dcr) (A& Type) (s! Poly) (i! Poly)) (!
    (=>
     (and
      (has_type s! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type i! INT)
     )
     (=>
      (and
       (sized A&.)
       (let
        ((tmp%%$ 0))
        (let
         ((tmp%%$1 (%I i!)))
         (let
          ((tmp%%$2 (vstd!seq.Seq.len.? A&. A& s!)))
          (and
           (<= tmp%%$ tmp%%$1)
           (< tmp%%$1 tmp%%$2)
      )))))
      (height_lt (height (vstd!seq.Seq.index.? A&. A& s! i!)) (height s!))
    ))
    :pattern ((height (vstd!seq.Seq.index.? A&. A& s! i!)))
    :qid user_vstd__seq__lemma_seq_index_decreases_0
    :skolemid skolem_user_vstd__seq__lemma_seq_index_decreases_0
))))

;; Function-Specs vstd::seq::Seq::subrange
(declare-fun req%vstd!seq.Seq.subrange. (Dcr Type Poly Poly Poly) Bool)
(declare-const %%global_location_label%%2 Bool)
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly) (start_inclusive! Poly) (end_exclusive! Poly))
  (!
   (= (req%vstd!seq.Seq.subrange. A&. A& self! start_inclusive! end_exclusive!) (=>
     %%global_location_label%%2
     (let
      ((tmp%%$ 0))
      (let
       ((tmp%%$1 (%I start_inclusive!)))
       (let
        ((tmp%%$2 (%I end_exclusive!)))
        (let
         ((tmp%%$3 (vstd!seq.Seq.len.? A&. A& self!)))
         (and
          (and
           (<= tmp%%$ tmp%%$1)
           (<= tmp%%$1 tmp%%$2)
          )
          (<= tmp%%$2 tmp%%$3)
   )))))))
   :pattern ((req%vstd!seq.Seq.subrange. A&. A& self! start_inclusive! end_exclusive!))
   :qid internal_req__vstd!seq.Seq.subrange._definition
   :skolemid skolem_internal_req__vstd!seq.Seq.subrange._definition
)))

;; Function-Axioms vstd::seq::Seq::subrange
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly) (start_inclusive! Poly) (end_exclusive! Poly))
  (!
   (=>
    (and
     (has_type self! (TYPE%vstd!seq.Seq. A&. A&))
     (has_type start_inclusive! INT)
     (has_type end_exclusive! INT)
    )
    (has_type (vstd!seq.Seq.subrange.? A&. A& self! start_inclusive! end_exclusive!) (
      TYPE%vstd!seq.Seq. A&. A&
   )))
   :pattern ((vstd!seq.Seq.subrange.? A&. A& self! start_inclusive! end_exclusive!))
   :qid internal_vstd!seq.Seq.subrange.?_pre_post_definition
   :skolemid skolem_internal_vstd!seq.Seq.subrange.?_pre_post_definition
)))

;; Broadcast vstd::seq::lemma_seq_subrange_decreases
(assert
 (=>
  (fuel_bool fuel%vstd!seq.lemma_seq_subrange_decreases.)
  (forall ((A&. Dcr) (A& Type) (s! Poly) (i! Poly) (j! Poly)) (!
    (=>
     (and
      (has_type s! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type i! INT)
      (has_type j! INT)
     )
     (=>
      (and
       (and
        (sized A&.)
        (let
         ((tmp%%$ 0))
         (let
          ((tmp%%$1 (%I i!)))
          (let
           ((tmp%%$2 (%I j!)))
           (let
            ((tmp%%$3 (vstd!seq.Seq.len.? A&. A& s!)))
            (and
             (and
              (<= tmp%%$ tmp%%$1)
              (<= tmp%%$1 tmp%%$2)
             )
             (<= tmp%%$2 tmp%%$3)
       ))))))
       (< (vstd!seq.Seq.len.? A&. A& (vstd!seq.Seq.subrange.? A&. A& s! i! j!)) (vstd!seq.Seq.len.?
         A&. A& s!
      )))
      (height_lt (height (vstd!seq.Seq.subrange.? A&. A& s! i! j!)) (height s!))
    ))
    :pattern ((height (vstd!seq.Seq.subrange.? A&. A& s! i! j!)))
    :qid user_vstd__seq__lemma_seq_subrange_decreases_0
    :skolemid skolem_user_vstd__seq__lemma_seq_subrange_decreases_0
))))

;; Function-Axioms vstd::seq::Seq::empty
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (has_type (vstd!seq.Seq.empty.? A&. A&) (TYPE%vstd!seq.Seq. A&. A&))
   :pattern ((vstd!seq.Seq.empty.? A&. A&))
   :qid internal_vstd!seq.Seq.empty.?_pre_post_definition
   :skolemid skolem_internal_vstd!seq.Seq.empty.?_pre_post_definition
)))

;; Broadcast vstd::seq::lemma_seq_empty
(assert
 (=>
  (fuel_bool fuel%vstd!seq.lemma_seq_empty.)
  (forall ((A&. Dcr) (A& Type)) (!
    (=>
     (sized A&.)
     (= (vstd!seq.Seq.len.? A&. A& (vstd!seq.Seq.empty.? A&. A&)) 0)
    )
    :pattern ((vstd!seq.Seq.len.? A&. A& (vstd!seq.Seq.empty.? A&. A&)))
    :qid user_vstd__seq__lemma_seq_empty_0
    :skolemid skolem_user_vstd__seq__lemma_seq_empty_0
))))

;; Function-Axioms vstd::seq::Seq::new
(assert
 (forall ((A&. Dcr) (A& Type) (len! Poly) (f! Poly)) (!
   (=>
    (and
     (has_type len! NAT)
     (has_type f! (TYPE%fun%1. $ INT A&. A&))
    )
    (has_type (vstd!seq.Seq.new.? A&. A& len! f!) (TYPE%vstd!seq.Seq. A&. A&))
   )
   :pattern ((vstd!seq.Seq.new.? A&. A& len! f!))
   :qid internal_vstd!seq.Seq.new.?_pre_post_definition
   :skolemid skolem_internal_vstd!seq.Seq.new.?_pre_post_definition
)))

;; Broadcast vstd::seq::lemma_seq_new_len
(assert
 (=>
  (fuel_bool fuel%vstd!seq.lemma_seq_new_len.)
  (forall ((A&. Dcr) (A& Type) (len! Poly) (f! Poly)) (!
    (=>
     (and
      (has_type len! NAT)
      (has_type f! (TYPE%fun%1. $ INT A&. A&))
     )
     (=>
      (sized A&.)
      (= (vstd!seq.Seq.len.? A&. A& (vstd!seq.Seq.new.? A&. A& len! f!)) (%I len!))
    ))
    :pattern ((vstd!seq.Seq.len.? A&. A& (vstd!seq.Seq.new.? A&. A& len! f!)))
    :qid user_vstd__seq__lemma_seq_new_len_0
    :skolemid skolem_user_vstd__seq__lemma_seq_new_len_0
))))

;; Broadcast vstd::seq::lemma_seq_new_index
(assert
 (=>
  (fuel_bool fuel%vstd!seq.lemma_seq_new_index.)
  (forall ((A&. Dcr) (A& Type) (len! Poly) (f! Poly) (i! Poly)) (!
    (=>
     (and
      (has_type len! NAT)
      (has_type f! (TYPE%fun%1. $ INT A&. A&))
      (has_type i! INT)
     )
     (=>
      (and
       (sized A&.)
       (let
        ((tmp%%$ 0))
        (let
         ((tmp%%$1 (%I i!)))
         (let
          ((tmp%%$2 (%I len!)))
          (and
           (<= tmp%%$ tmp%%$1)
           (< tmp%%$1 tmp%%$2)
      )))))
      (= (vstd!seq.Seq.index.? A&. A& (vstd!seq.Seq.new.? A&. A& len! f!) i!) (%%apply%%0
        (%Poly%fun%1. f!) i!
    ))))
    :pattern ((vstd!seq.Seq.index.? A&. A& (vstd!seq.Seq.new.? A&. A& len! f!) i!))
    :qid user_vstd__seq__lemma_seq_new_index_0
    :skolemid skolem_user_vstd__seq__lemma_seq_new_index_0
))))

;; Function-Axioms vstd::seq::Seq::push
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly) (a! Poly)) (!
   (=>
    (and
     (has_type self! (TYPE%vstd!seq.Seq. A&. A&))
     (has_type a! A&)
    )
    (has_type (vstd!seq.Seq.push.? A&. A& self! a!) (TYPE%vstd!seq.Seq. A&. A&))
   )
   :pattern ((vstd!seq.Seq.push.? A&. A& self! a!))
   :qid internal_vstd!seq.Seq.push.?_pre_post_definition
   :skolemid skolem_internal_vstd!seq.Seq.push.?_pre_post_definition
)))

;; Broadcast vstd::seq::lemma_seq_push_len
(assert
 (=>
  (fuel_bool fuel%vstd!seq.lemma_seq_push_len.)
  (forall ((A&. Dcr) (A& Type) (s! Poly) (a! Poly)) (!
    (=>
     (and
      (has_type s! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type a! A&)
     )
     (=>
      (sized A&.)
      (= (vstd!seq.Seq.len.? A&. A& (vstd!seq.Seq.push.? A&. A& s! a!)) (nClip (Add (vstd!seq.Seq.len.?
          A&. A& s!
         ) 1
    )))))
    :pattern ((vstd!seq.Seq.len.? A&. A& (vstd!seq.Seq.push.? A&. A& s! a!)))
    :qid user_vstd__seq__lemma_seq_push_len_0
    :skolemid skolem_user_vstd__seq__lemma_seq_push_len_0
))))

;; Broadcast vstd::seq::lemma_seq_push_index_same
(assert
 (=>
  (fuel_bool fuel%vstd!seq.lemma_seq_push_index_same.)
  (forall ((A&. Dcr) (A& Type) (s! Poly) (a! Poly) (i! Poly)) (!
    (=>
     (and
      (has_type s! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type a! A&)
      (has_type i! INT)
     )
     (=>
      (and
       (sized A&.)
       (= (%I i!) (vstd!seq.Seq.len.? A&. A& s!))
      )
      (= (vstd!seq.Seq.index.? A&. A& (vstd!seq.Seq.push.? A&. A& s! a!) i!) a!)
    ))
    :pattern ((vstd!seq.Seq.index.? A&. A& (vstd!seq.Seq.push.? A&. A& s! a!) i!))
    :qid user_vstd__seq__lemma_seq_push_index_same_0
    :skolemid skolem_user_vstd__seq__lemma_seq_push_index_same_0
))))

;; Broadcast vstd::seq::lemma_seq_push_index_different
(assert
 (=>
  (fuel_bool fuel%vstd!seq.lemma_seq_push_index_different.)
  (forall ((A&. Dcr) (A& Type) (s! Poly) (a! Poly) (i! Poly)) (!
    (=>
     (and
      (has_type s! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type a! A&)
      (has_type i! INT)
     )
     (=>
      (and
       (sized A&.)
       (< (%I i!) (vstd!seq.Seq.len.? A&. A& s!))
      )
      (= (vstd!seq.Seq.index.? A&. A& (vstd!seq.Seq.push.? A&. A& s! a!) i!) (vstd!seq.Seq.index.?
        A&. A& s! i!
    ))))
    :pattern ((vstd!seq.Seq.index.? A&. A& (vstd!seq.Seq.push.? A&. A& s! a!) i!))
    :qid user_vstd__seq__lemma_seq_push_index_different_0
    :skolemid skolem_user_vstd__seq__lemma_seq_push_index_different_0
))))

;; Broadcast vstd::seq::lemma_seq_ext_equal
(assert
 (=>
  (fuel_bool fuel%vstd!seq.lemma_seq_ext_equal.)
  (forall ((A&. Dcr) (A& Type) (s1! Poly) (s2! Poly)) (!
    (=>
     (and
      (has_type s1! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type s2! (TYPE%vstd!seq.Seq. A&. A&))
     )
     (=>
      (sized A&.)
      (= (ext_eq false (TYPE%vstd!seq.Seq. A&. A&) s1! s2!) (and
        (= (vstd!seq.Seq.len.? A&. A& s1!) (vstd!seq.Seq.len.? A&. A& s2!))
        (forall ((i$ Poly)) (!
          (=>
           (has_type i$ INT)
           (=>
            (let
             ((tmp%%$ 0))
             (let
              ((tmp%%$1 (%I i$)))
              (let
               ((tmp%%$2 (vstd!seq.Seq.len.? A&. A& s1!)))
               (and
                (<= tmp%%$ tmp%%$1)
                (< tmp%%$1 tmp%%$2)
            ))))
            (= (vstd!seq.Seq.index.? A&. A& s1! i$) (vstd!seq.Seq.index.? A&. A& s2! i$))
          ))
          :pattern ((vstd!seq.Seq.index.? A&. A& s1! i$))
          :pattern ((vstd!seq.Seq.index.? A&. A& s2! i$))
          :qid user_vstd__seq__lemma_seq_ext_equal_0
          :skolemid skolem_user_vstd__seq__lemma_seq_ext_equal_0
    ))))))
    :pattern ((ext_eq false (TYPE%vstd!seq.Seq. A&. A&) s1! s2!))
    :qid user_vstd__seq__lemma_seq_ext_equal_1
    :skolemid skolem_user_vstd__seq__lemma_seq_ext_equal_1
))))

;; Broadcast vstd::seq::lemma_seq_ext_equal_deep
(assert
 (=>
  (fuel_bool fuel%vstd!seq.lemma_seq_ext_equal_deep.)
  (forall ((A&. Dcr) (A& Type) (s1! Poly) (s2! Poly)) (!
    (=>
     (and
      (has_type s1! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type s2! (TYPE%vstd!seq.Seq. A&. A&))
     )
     (=>
      (sized A&.)
      (= (ext_eq true (TYPE%vstd!seq.Seq. A&. A&) s1! s2!) (and
        (= (vstd!seq.Seq.len.? A&. A& s1!) (vstd!seq.Seq.len.? A&. A& s2!))
        (forall ((i$ Poly)) (!
          (=>
           (has_type i$ INT)
           (=>
            (let
             ((tmp%%$ 0))
             (let
              ((tmp%%$1 (%I i$)))
              (let
               ((tmp%%$2 (vstd!seq.Seq.len.? A&. A& s1!)))
               (and
                (<= tmp%%$ tmp%%$1)
                (< tmp%%$1 tmp%%$2)
            ))))
            (ext_eq true A& (vstd!seq.Seq.index.? A&. A& s1! i$) (vstd!seq.Seq.index.? A&. A& s2!
              i$
          ))))
          :pattern ((vstd!seq.Seq.index.? A&. A& s1! i$))
          :pattern ((vstd!seq.Seq.index.? A&. A& s2! i$))
          :qid user_vstd__seq__lemma_seq_ext_equal_deep_0
          :skolemid skolem_user_vstd__seq__lemma_seq_ext_equal_deep_0
    ))))))
    :pattern ((ext_eq true (TYPE%vstd!seq.Seq. A&. A&) s1! s2!))
    :qid user_vstd__seq__lemma_seq_ext_equal_deep_1
    :skolemid skolem_user_vstd__seq__lemma_seq_ext_equal_deep_1
))))

;; Broadcast vstd::seq::lemma_seq_subrange_len
(assert
 (=>
  (fuel_bool fuel%vstd!seq.lemma_seq_subrange_len.)
  (forall ((A&. Dcr) (A& Type) (s! Poly) (j! Poly) (k! Poly)) (!
    (=>
     (and
      (has_type s! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type j! INT)
      (has_type k! INT)
     )
     (=>
      (and
       (sized A&.)
       (let
        ((tmp%%$ 0))
        (let
         ((tmp%%$1 (%I j!)))
         (let
          ((tmp%%$2 (%I k!)))
          (let
           ((tmp%%$3 (vstd!seq.Seq.len.? A&. A& s!)))
           (and
            (and
             (<= tmp%%$ tmp%%$1)
             (<= tmp%%$1 tmp%%$2)
            )
            (<= tmp%%$2 tmp%%$3)
      ))))))
      (= (vstd!seq.Seq.len.? A&. A& (vstd!seq.Seq.subrange.? A&. A& s! j! k!)) (Sub (%I k!)
        (%I j!)
    ))))
    :pattern ((vstd!seq.Seq.len.? A&. A& (vstd!seq.Seq.subrange.? A&. A& s! j! k!)))
    :qid user_vstd__seq__lemma_seq_subrange_len_0
    :skolemid skolem_user_vstd__seq__lemma_seq_subrange_len_0
))))

;; Broadcast vstd::seq::lemma_seq_subrange_index
(assert
 (=>
  (fuel_bool fuel%vstd!seq.lemma_seq_subrange_index.)
  (forall ((A&. Dcr) (A& Type) (s! Poly) (j! Poly) (k! Poly) (i! Poly)) (!
    (=>
     (and
      (has_type s! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type j! INT)
      (has_type k! INT)
      (has_type i! INT)
     )
     (=>
      (and
       (and
        (sized A&.)
        (let
         ((tmp%%$ 0))
         (let
          ((tmp%%$1 (%I j!)))
          (let
           ((tmp%%$2 (%I k!)))
           (let
            ((tmp%%$3 (vstd!seq.Seq.len.? A&. A& s!)))
            (and
             (and
              (<= tmp%%$ tmp%%$1)
              (<= tmp%%$1 tmp%%$2)
             )
             (<= tmp%%$2 tmp%%$3)
       ))))))
       (let
        ((tmp%%$ 0))
        (let
         ((tmp%%$5 (%I i!)))
         (let
          ((tmp%%$6 (Sub (%I k!) (%I j!))))
          (and
           (<= tmp%%$ tmp%%$5)
           (< tmp%%$5 tmp%%$6)
      )))))
      (= (vstd!seq.Seq.index.? A&. A& (vstd!seq.Seq.subrange.? A&. A& s! j! k!) i!) (vstd!seq.Seq.index.?
        A&. A& s! (I (Add (%I i!) (%I j!)))
    ))))
    :pattern ((vstd!seq.Seq.index.? A&. A& (vstd!seq.Seq.subrange.? A&. A& s! j! k!) i!))
    :qid user_vstd__seq__lemma_seq_subrange_index_0
    :skolemid skolem_user_vstd__seq__lemma_seq_subrange_index_0
))))

;; Broadcast vstd::seq::lemma_seq_two_subranges_index
(assert
 (=>
  (fuel_bool fuel%vstd!seq.lemma_seq_two_subranges_index.)
  (forall ((A&. Dcr) (A& Type) (s! Poly) (j! Poly) (k1! Poly) (k2! Poly) (i! Poly))
   (!
    (=>
     (and
      (has_type s! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type j! INT)
      (has_type k1! INT)
      (has_type k2! INT)
      (has_type i! INT)
     )
     (=>
      (and
       (and
        (and
         (and
          (sized A&.)
          (let
           ((tmp%%$ 0))
           (let
            ((tmp%%$1 (%I j!)))
            (let
             ((tmp%%$2 (%I k1!)))
             (let
              ((tmp%%$3 (vstd!seq.Seq.len.? A&. A& s!)))
              (and
               (and
                (<= tmp%%$ tmp%%$1)
                (<= tmp%%$1 tmp%%$2)
               )
               (<= tmp%%$2 tmp%%$3)
         ))))))
         (let
          ((tmp%%$ 0))
          (let
           ((tmp%%$5 (%I j!)))
           (let
            ((tmp%%$6 (%I k2!)))
            (let
             ((tmp%%$7 (vstd!seq.Seq.len.? A&. A& s!)))
             (and
              (and
               (<= tmp%%$ tmp%%$5)
               (<= tmp%%$5 tmp%%$6)
              )
              (<= tmp%%$6 tmp%%$7)
        ))))))
        (let
         ((tmp%%$ 0))
         (let
          ((tmp%%$9 (%I i!)))
          (let
           ((tmp%%$10 (Sub (%I k1!) (%I j!))))
           (and
            (<= tmp%%$ tmp%%$9)
            (< tmp%%$9 tmp%%$10)
       )))))
       (let
        ((tmp%%$ 0))
        (let
         ((tmp%%$12 (%I i!)))
         (let
          ((tmp%%$13 (Sub (%I k2!) (%I j!))))
          (and
           (<= tmp%%$ tmp%%$12)
           (< tmp%%$12 tmp%%$13)
      )))))
      (= (vstd!seq.Seq.index.? A&. A& (vstd!seq.Seq.subrange.? A&. A& s! j! k1!) i!) (vstd!seq.Seq.index.?
        A&. A& (vstd!seq.Seq.subrange.? A&. A& s! j! k2!) i!
    ))))
    :pattern ((vstd!seq.Seq.index.? A&. A& (vstd!seq.Seq.subrange.? A&. A& s! j! k1!) i!)
     (vstd!seq.Seq.subrange.? A&. A& s! j! k2!)
    )
    :qid user_vstd__seq__lemma_seq_two_subranges_index_0
    :skolemid skolem_user_vstd__seq__lemma_seq_two_subranges_index_0
))))

;; Function-Axioms vstd::seq::Seq::add
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly) (rhs! Poly)) (!
   (=>
    (and
     (has_type self! (TYPE%vstd!seq.Seq. A&. A&))
     (has_type rhs! (TYPE%vstd!seq.Seq. A&. A&))
    )
    (has_type (vstd!seq.Seq.add.? A&. A& self! rhs!) (TYPE%vstd!seq.Seq. A&. A&))
   )
   :pattern ((vstd!seq.Seq.add.? A&. A& self! rhs!))
   :qid internal_vstd!seq.Seq.add.?_pre_post_definition
   :skolemid skolem_internal_vstd!seq.Seq.add.?_pre_post_definition
)))

;; Broadcast vstd::seq::lemma_seq_add_len
(assert
 (=>
  (fuel_bool fuel%vstd!seq.lemma_seq_add_len.)
  (forall ((A&. Dcr) (A& Type) (s1! Poly) (s2! Poly)) (!
    (=>
     (and
      (has_type s1! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type s2! (TYPE%vstd!seq.Seq. A&. A&))
     )
     (=>
      (sized A&.)
      (= (vstd!seq.Seq.len.? A&. A& (vstd!seq.Seq.add.? A&. A& s1! s2!)) (nClip (Add (vstd!seq.Seq.len.?
          A&. A& s1!
         ) (vstd!seq.Seq.len.? A&. A& s2!)
    )))))
    :pattern ((vstd!seq.Seq.len.? A&. A& (vstd!seq.Seq.add.? A&. A& s1! s2!)))
    :qid user_vstd__seq__lemma_seq_add_len_0
    :skolemid skolem_user_vstd__seq__lemma_seq_add_len_0
))))

;; Broadcast vstd::seq::lemma_seq_add_index1
(assert
 (=>
  (fuel_bool fuel%vstd!seq.lemma_seq_add_index1.)
  (forall ((A&. Dcr) (A& Type) (s1! Poly) (s2! Poly) (i! Poly)) (!
    (=>
     (and
      (has_type s1! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type s2! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type i! INT)
     )
     (=>
      (and
       (sized A&.)
       (< (%I i!) (vstd!seq.Seq.len.? A&. A& s1!))
      )
      (= (vstd!seq.Seq.index.? A&. A& (vstd!seq.Seq.add.? A&. A& s1! s2!) i!) (vstd!seq.Seq.index.?
        A&. A& s1! i!
    ))))
    :pattern ((vstd!seq.Seq.index.? A&. A& (vstd!seq.Seq.add.? A&. A& s1! s2!) i!))
    :qid user_vstd__seq__lemma_seq_add_index1_0
    :skolemid skolem_user_vstd__seq__lemma_seq_add_index1_0
))))

;; Broadcast vstd::seq::lemma_seq_add_index2
(assert
 (=>
  (fuel_bool fuel%vstd!seq.lemma_seq_add_index2.)
  (forall ((A&. Dcr) (A& Type) (s1! Poly) (s2! Poly) (i! Poly)) (!
    (=>
     (and
      (has_type s1! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type s2! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type i! INT)
     )
     (=>
      (and
       (sized A&.)
       (let
        ((tmp%%$ (vstd!seq.Seq.len.? A&. A& s1!)))
        (let
         ((tmp%%$1 (%I i!)))
         (let
          ((tmp%%$2 (nClip (Add (vstd!seq.Seq.len.? A&. A& s1!) (vstd!seq.Seq.len.? A&. A& s2!)))))
          (and
           (<= tmp%%$ tmp%%$1)
           (< tmp%%$1 tmp%%$2)
      )))))
      (= (vstd!seq.Seq.index.? A&. A& (vstd!seq.Seq.add.? A&. A& s1! s2!) i!) (vstd!seq.Seq.index.?
        A&. A& s2! (I (Sub (%I i!) (vstd!seq.Seq.len.? A&. A& s1!)))
    ))))
    :pattern ((vstd!seq.Seq.index.? A&. A& (vstd!seq.Seq.add.? A&. A& s1! s2!) i!))
    :qid user_vstd__seq__lemma_seq_add_index2_0
    :skolemid skolem_user_vstd__seq__lemma_seq_add_index2_0
))))

;; Function-Axioms vstd::seq_lib::impl&%0::contains
(assert
 (fuel_bool_default fuel%vstd!seq_lib.impl&%0.contains.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!seq_lib.impl&%0.contains.)
  (forall ((A&. Dcr) (A& Type) (self! Poly) (needle! Poly)) (!
    (= (vstd!seq_lib.impl&%0.contains.? A&. A& self! needle!) (exists ((i$ Poly)) (!
       (and
        (has_type i$ INT)
        (and
         (let
          ((tmp%%$ 0))
          (let
           ((tmp%%$1 (%I i$)))
           (let
            ((tmp%%$2 (vstd!seq.Seq.len.? A&. A& self!)))
            (and
             (<= tmp%%$ tmp%%$1)
             (< tmp%%$1 tmp%%$2)
         ))))
         (= (vstd!seq.Seq.index.? A&. A& self! i$) needle!)
       ))
       :pattern ((vstd!seq.Seq.index.? A&. A& self! i$))
       :qid user_vstd__seq_lib__impl&%0__contains_0
       :skolemid skolem_user_vstd__seq_lib__impl&%0__contains_0
    )))
    :pattern ((vstd!seq_lib.impl&%0.contains.? A&. A& self! needle!))
    :qid internal_vstd!seq_lib.impl&__0.contains.?_definition
    :skolemid skolem_internal_vstd!seq_lib.impl&__0.contains.?_definition
))))

;; Function-Axioms vstd::seq::impl&%2::spec_add
(assert
 (fuel_bool_default fuel%vstd!seq.impl&%2.spec_add.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!seq.impl&%2.spec_add.)
  (forall ((A&. Dcr) (A& Type) (self! Poly) (rhs! Poly)) (!
    (= (vstd!seq.impl&%2.spec_add.? A&. A& self! rhs!) (vstd!seq.Seq.add.? A&. A& self!
      rhs!
    ))
    :pattern ((vstd!seq.impl&%2.spec_add.? A&. A& self! rhs!))
    :qid internal_vstd!seq.impl&__2.spec_add.?_definition
    :skolemid skolem_internal_vstd!seq.impl&__2.spec_add.?_definition
))))
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly) (rhs! Poly)) (!
   (=>
    (and
     (has_type self! (TYPE%vstd!seq.Seq. A&. A&))
     (has_type rhs! (TYPE%vstd!seq.Seq. A&. A&))
    )
    (has_type (vstd!seq.impl&%2.spec_add.? A&. A& self! rhs!) (TYPE%vstd!seq.Seq. A&. A&))
   )
   :pattern ((vstd!seq.impl&%2.spec_add.? A&. A& self! rhs!))
   :qid internal_vstd!seq.impl&__2.spec_add.?_pre_post_definition
   :skolemid skolem_internal_vstd!seq.impl&__2.spec_add.?_pre_post_definition
)))

;; Broadcast vstd::seq_lib::impl&%0::add_empty_left
(assert
 (=>
  (fuel_bool fuel%vstd!seq_lib.impl&%0.add_empty_left.)
  (forall ((A&. Dcr) (A& Type) (a! Poly) (b! Poly)) (!
    (=>
     (and
      (has_type a! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type b! (TYPE%vstd!seq.Seq. A&. A&))
     )
     (=>
      (and
       (sized A&.)
       (= (vstd!seq.Seq.len.? A&. A& a!) 0)
      )
      (= (vstd!seq.Seq.add.? A&. A& a! b!) b!)
    ))
    :pattern ((vstd!seq.Seq.add.? A&. A& a! b!))
    :qid user_vstd__seq_lib__impl&%0__add_empty_left_0
    :skolemid skolem_user_vstd__seq_lib__impl&%0__add_empty_left_0
))))

;; Broadcast vstd::seq_lib::impl&%0::add_empty_right
(assert
 (=>
  (fuel_bool fuel%vstd!seq_lib.impl&%0.add_empty_right.)
  (forall ((A&. Dcr) (A& Type) (a! Poly) (b! Poly)) (!
    (=>
     (and
      (has_type a! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type b! (TYPE%vstd!seq.Seq. A&. A&))
     )
     (=>
      (and
       (sized A&.)
       (= (vstd!seq.Seq.len.? A&. A& b!) 0)
      )
      (= (vstd!seq.Seq.add.? A&. A& a! b!) a!)
    ))
    :pattern ((vstd!seq.Seq.add.? A&. A& a! b!))
    :qid user_vstd__seq_lib__impl&%0__add_empty_right_0
    :skolemid skolem_user_vstd__seq_lib__impl&%0__add_empty_right_0
))))

;; Broadcast vstd::seq_lib::impl&%0::push_distributes_over_add
(assert
 (=>
  (fuel_bool fuel%vstd!seq_lib.impl&%0.push_distributes_over_add.)
  (forall ((A&. Dcr) (A& Type) (a! Poly) (b! Poly) (elt! Poly)) (!
    (=>
     (and
      (has_type a! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type b! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type elt! A&)
     )
     (=>
      (sized A&.)
      (= (vstd!seq.Seq.push.? A&. A& (vstd!seq.Seq.add.? A&. A& a! b!) elt!) (vstd!seq.Seq.add.?
        A&. A& a! (vstd!seq.Seq.push.? A&. A& b! elt!)
    ))))
    :pattern ((vstd!seq.Seq.push.? A&. A& (vstd!seq.Seq.add.? A&. A& a! b!) elt!))
    :qid user_vstd__seq_lib__impl&%0__push_distributes_over_add_0
    :skolemid skolem_user_vstd__seq_lib__impl&%0__push_distributes_over_add_0
))))

;; Function-Specs vstd::seq_lib::impl&%0::drop_last
(declare-fun req%vstd!seq_lib.impl&%0.drop_last. (Dcr Type Poly) Bool)
(declare-const %%global_location_label%%3 Bool)
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly)) (!
   (= (req%vstd!seq_lib.impl&%0.drop_last. A&. A& self!) (=>
     %%global_location_label%%3
     (>= (vstd!seq.Seq.len.? A&. A& self!) 1)
   ))
   :pattern ((req%vstd!seq_lib.impl&%0.drop_last. A&. A& self!))
   :qid internal_req__vstd!seq_lib.impl&__0.drop_last._definition
   :skolemid skolem_internal_req__vstd!seq_lib.impl&__0.drop_last._definition
)))

;; Function-Axioms vstd::seq_lib::impl&%0::drop_last
(assert
 (fuel_bool_default fuel%vstd!seq_lib.impl&%0.drop_last.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!seq_lib.impl&%0.drop_last.)
  (forall ((A&. Dcr) (A& Type) (self! Poly)) (!
    (= (vstd!seq_lib.impl&%0.drop_last.? A&. A& self!) (vstd!seq.Seq.subrange.? A&. A&
      self! (I 0) (I (Sub (vstd!seq.Seq.len.? A&. A& self!) 1))
    ))
    :pattern ((vstd!seq_lib.impl&%0.drop_last.? A&. A& self!))
    :qid internal_vstd!seq_lib.impl&__0.drop_last.?_definition
    :skolemid skolem_internal_vstd!seq_lib.impl&__0.drop_last.?_definition
))))
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly)) (!
   (=>
    (has_type self! (TYPE%vstd!seq.Seq. A&. A&))
    (has_type (vstd!seq_lib.impl&%0.drop_last.? A&. A& self!) (TYPE%vstd!seq.Seq. A&. A&))
   )
   :pattern ((vstd!seq_lib.impl&%0.drop_last.? A&. A& self!))
   :qid internal_vstd!seq_lib.impl&__0.drop_last.?_pre_post_definition
   :skolemid skolem_internal_vstd!seq_lib.impl&__0.drop_last.?_pre_post_definition
)))

;; Function-Axioms vstd::multiset::impl&%0::count
(assert
 (forall ((V&. Dcr) (V& Type) (self! Poly) (value! Poly)) (!
   (=>
    (and
     (has_type self! (TYPE%vstd!multiset.Multiset. V&. V&))
     (has_type value! V&)
    )
    (<= 0 (vstd!multiset.impl&%0.count.? V&. V& self! value!))
   )
   :pattern ((vstd!multiset.impl&%0.count.? V&. V& self! value!))
   :qid internal_vstd!multiset.impl&__0.count.?_pre_post_definition
   :skolemid skolem_internal_vstd!multiset.impl&__0.count.?_pre_post_definition
)))

;; Function-Axioms vstd::multiset::impl&%0::singleton
(assert
 (forall ((V&. Dcr) (V& Type) (v! Poly)) (!
   (=>
    (has_type v! V&)
    (has_type (vstd!multiset.impl&%0.singleton.? V&. V& v!) (TYPE%vstd!multiset.Multiset.
      V&. V&
   )))
   :pattern ((vstd!multiset.impl&%0.singleton.? V&. V& v!))
   :qid internal_vstd!multiset.impl&__0.singleton.?_pre_post_definition
   :skolemid skolem_internal_vstd!multiset.impl&__0.singleton.?_pre_post_definition
)))

;; Broadcast vstd::multiset::axiom_multiset_singleton
(assert
 (=>
  (fuel_bool fuel%vstd!multiset.axiom_multiset_singleton.)
  (forall ((V&. Dcr) (V& Type) (v! Poly)) (!
    (=>
     (has_type v! V&)
     (=>
      (sized V&.)
      (= (vstd!multiset.impl&%0.count.? V&. V& (vstd!multiset.impl&%0.singleton.? V&. V& v!)
        v!
       ) 1
    )))
    :pattern ((vstd!multiset.impl&%0.singleton.? V&. V& v!))
    :qid user_vstd__multiset__axiom_multiset_singleton_0
    :skolemid skolem_user_vstd__multiset__axiom_multiset_singleton_0
))))

;; Broadcast vstd::multiset::axiom_multiset_singleton_different
(assert
 (=>
  (fuel_bool fuel%vstd!multiset.axiom_multiset_singleton_different.)
  (forall ((V&. Dcr) (V& Type) (v! Poly) (w! Poly)) (!
    (=>
     (and
      (has_type v! V&)
      (has_type w! V&)
     )
     (=>
      (sized V&.)
      (=>
       (not (= v! w!))
       (= (vstd!multiset.impl&%0.count.? V&. V& (vstd!multiset.impl&%0.singleton.? V&. V& v!)
         w!
        ) 0
    ))))
    :pattern ((vstd!multiset.impl&%0.count.? V&. V& (vstd!multiset.impl&%0.singleton.? V&.
       V& v!
      ) w!
    ))
    :qid user_vstd__multiset__axiom_multiset_singleton_different_0
    :skolemid skolem_user_vstd__multiset__axiom_multiset_singleton_different_0
))))

;; Function-Axioms vstd::multiset::impl&%0::add
(assert
 (forall ((V&. Dcr) (V& Type) (self! Poly) (m2! Poly)) (!
   (=>
    (and
     (has_type self! (TYPE%vstd!multiset.Multiset. V&. V&))
     (has_type m2! (TYPE%vstd!multiset.Multiset. V&. V&))
    )
    (has_type (vstd!multiset.impl&%0.add.? V&. V& self! m2!) (TYPE%vstd!multiset.Multiset.
      V&. V&
   )))
   :pattern ((vstd!multiset.impl&%0.add.? V&. V& self! m2!))
   :qid internal_vstd!multiset.impl&__0.add.?_pre_post_definition
   :skolemid skolem_internal_vstd!multiset.impl&__0.add.?_pre_post_definition
)))

;; Broadcast vstd::multiset::axiom_multiset_add
(assert
 (=>
  (fuel_bool fuel%vstd!multiset.axiom_multiset_add.)
  (forall ((V&. Dcr) (V& Type) (m1! Poly) (m2! Poly) (v! Poly)) (!
    (=>
     (and
      (has_type m1! (TYPE%vstd!multiset.Multiset. V&. V&))
      (has_type m2! (TYPE%vstd!multiset.Multiset. V&. V&))
      (has_type v! V&)
     )
     (=>
      (sized V&.)
      (= (vstd!multiset.impl&%0.count.? V&. V& (vstd!multiset.impl&%0.add.? V&. V& m1! m2!)
        v!
       ) (nClip (Add (vstd!multiset.impl&%0.count.? V&. V& m1! v!) (vstd!multiset.impl&%0.count.?
          V&. V& m2! v!
    ))))))
    :pattern ((vstd!multiset.impl&%0.count.? V&. V& (vstd!multiset.impl&%0.add.? V&. V&
       m1! m2!
      ) v!
    ))
    :qid user_vstd__multiset__axiom_multiset_add_0
    :skolemid skolem_user_vstd__multiset__axiom_multiset_add_0
))))

;; Broadcast vstd::multiset::axiom_multiset_ext_equal
(assert
 (=>
  (fuel_bool fuel%vstd!multiset.axiom_multiset_ext_equal.)
  (forall ((V&. Dcr) (V& Type) (m1! Poly) (m2! Poly)) (!
    (=>
     (and
      (has_type m1! (TYPE%vstd!multiset.Multiset. V&. V&))
      (has_type m2! (TYPE%vstd!multiset.Multiset. V&. V&))
     )
     (=>
      (sized V&.)
      (= (ext_eq false (TYPE%vstd!multiset.Multiset. V&. V&) m1! m2!) (forall ((v$ Poly))
        (!
         (=>
          (has_type v$ V&)
          (= (vstd!multiset.impl&%0.count.? V&. V& m1! v$) (vstd!multiset.impl&%0.count.? V&.
            V& m2! v$
         )))
         :pattern ((vstd!multiset.impl&%0.count.? V&. V& m1! v$))
         :pattern ((vstd!multiset.impl&%0.count.? V&. V& m2! v$))
         :qid user_vstd__multiset__axiom_multiset_ext_equal_0
         :skolemid skolem_user_vstd__multiset__axiom_multiset_ext_equal_0
    )))))
    :pattern ((ext_eq false (TYPE%vstd!multiset.Multiset. V&. V&) m1! m2!))
    :qid user_vstd__multiset__axiom_multiset_ext_equal_1
    :skolemid skolem_user_vstd__multiset__axiom_multiset_ext_equal_1
))))

;; Broadcast vstd::multiset::axiom_multiset_ext_equal_deep
(assert
 (=>
  (fuel_bool fuel%vstd!multiset.axiom_multiset_ext_equal_deep.)
  (forall ((V&. Dcr) (V& Type) (m1! Poly) (m2! Poly)) (!
    (=>
     (and
      (has_type m1! (TYPE%vstd!multiset.Multiset. V&. V&))
      (has_type m2! (TYPE%vstd!multiset.Multiset. V&. V&))
     )
     (=>
      (sized V&.)
      (= (ext_eq true (TYPE%vstd!multiset.Multiset. V&. V&) m1! m2!) (ext_eq false (TYPE%vstd!multiset.Multiset.
         V&. V&
        ) m1! m2!
    ))))
    :pattern ((ext_eq true (TYPE%vstd!multiset.Multiset. V&. V&) m1! m2!))
    :qid user_vstd__multiset__axiom_multiset_ext_equal_deep_0
    :skolemid skolem_user_vstd__multiset__axiom_multiset_ext_equal_deep_0
))))

;; Function-Axioms vstd::multiset::impl&%0::len
(assert
 (forall ((V&. Dcr) (V& Type) (self! Poly)) (!
   (=>
    (has_type self! (TYPE%vstd!multiset.Multiset. V&. V&))
    (<= 0 (vstd!multiset.impl&%0.len.? V&. V& self!))
   )
   :pattern ((vstd!multiset.impl&%0.len.? V&. V& self!))
   :qid internal_vstd!multiset.impl&__0.len.?_pre_post_definition
   :skolemid skolem_internal_vstd!multiset.impl&__0.len.?_pre_post_definition
)))

;; Broadcast vstd::multiset::axiom_len_singleton
(assert
 (=>
  (fuel_bool fuel%vstd!multiset.axiom_len_singleton.)
  (forall ((V&. Dcr) (V& Type) (v! Poly)) (!
    (=>
     (has_type v! V&)
     (=>
      (sized V&.)
      (= (vstd!multiset.impl&%0.len.? V&. V& (vstd!multiset.impl&%0.singleton.? V&. V& v!))
       1
    )))
    :pattern ((vstd!multiset.impl&%0.len.? V&. V& (vstd!multiset.impl&%0.singleton.? V&.
       V& v!
    )))
    :qid user_vstd__multiset__axiom_len_singleton_0
    :skolemid skolem_user_vstd__multiset__axiom_len_singleton_0
))))

;; Broadcast vstd::multiset::axiom_len_add
(assert
 (=>
  (fuel_bool fuel%vstd!multiset.axiom_len_add.)
  (forall ((V&. Dcr) (V& Type) (m1! Poly) (m2! Poly)) (!
    (=>
     (and
      (has_type m1! (TYPE%vstd!multiset.Multiset. V&. V&))
      (has_type m2! (TYPE%vstd!multiset.Multiset. V&. V&))
     )
     (=>
      (sized V&.)
      (= (vstd!multiset.impl&%0.len.? V&. V& (vstd!multiset.impl&%0.add.? V&. V& m1! m2!))
       (nClip (Add (vstd!multiset.impl&%0.len.? V&. V& m1!) (vstd!multiset.impl&%0.len.? V&.
          V& m2!
    ))))))
    :pattern ((vstd!multiset.impl&%0.len.? V&. V& (vstd!multiset.impl&%0.add.? V&. V& m1!
       m2!
    )))
    :qid user_vstd__multiset__axiom_len_add_0
    :skolemid skolem_user_vstd__multiset__axiom_len_add_0
))))

;; Broadcast vstd::multiset::axiom_count_le_len
(assert
 (=>
  (fuel_bool fuel%vstd!multiset.axiom_count_le_len.)
  (forall ((V&. Dcr) (V& Type) (m! Poly) (v! Poly)) (!
    (=>
     (and
      (has_type m! (TYPE%vstd!multiset.Multiset. V&. V&))
      (has_type v! V&)
     )
     (=>
      (sized V&.)
      (<= (vstd!multiset.impl&%0.count.? V&. V& m! v!) (vstd!multiset.impl&%0.len.? V&. V&
        m!
    ))))
    :pattern ((vstd!multiset.impl&%0.count.? V&. V& m! v!) (vstd!multiset.impl&%0.len.?
      V&. V& m!
    ))
    :qid user_vstd__multiset__axiom_count_le_len_0
    :skolemid skolem_user_vstd__multiset__axiom_count_le_len_0
))))

;; Trait-Impl-Axiom
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.FnMut. F&. F& A&. A&)
    )
    (tr_bound%core!ops.function.FnOnce. $ (MUTREF F&. F&) A&. A&)
   )
   :pattern ((tr_bound%core!ops.function.FnOnce. $ (MUTREF F&. F&) A&. A&))
   :qid internal_core__ops__function__impls__impl&__4_trait_impl_definition
   :skolemid skolem_internal_core__ops__function__impls__impl&__4_trait_impl_definition
)))

;; Broadcast vstd::function::axiom_fn_mut_call_requires
(assert
 (=>
  (fuel_bool fuel%vstd!function.axiom_fn_mut_call_requires.)
  (forall ((Args&. Dcr) (Args& Type) (F&. Dcr) (F& Type) (f! Poly) (args! Poly)) (!
    (=>
     (and
      (has_type f! (MUTREF F&. F&))
      (has_type args! Args&)
     )
     (=>
      (and
       (and
        (and
         (and
          (sized Args&.)
          (sized F&.)
         )
         (tr_bound%core!marker.Tuple. Args&. Args&)
        )
        (tr_bound%core!ops.function.FnMut. F&. F& Args&. Args&)
       )
       (closure_req F& Args&. Args& (mut_ref_current% f!) args!)
      )
      (closure_req (MUTREF F&. F&) Args&. Args& f! args!)
    ))
    :pattern ((closure_req (MUTREF F&. F&) Args&. Args& f! args!))
    :qid user_vstd__function__axiom_fn_mut_call_requires_0
    :skolemid skolem_user_vstd__function__axiom_fn_mut_call_requires_0
))))

;; Broadcast vstd::function::axiom_fn_mut_call_ensures
(assert
 (=>
  (fuel_bool fuel%vstd!function.axiom_fn_mut_call_ensures.)
  (forall ((Args&. Dcr) (Args& Type) (F&. Dcr) (F& Type) (f! Poly) (args! Poly) (output!
     Poly
    )
   ) (!
    (=>
     (and
      (has_type f! (MUTREF F&. F&))
      (has_type args! Args&)
      (has_type output! (proj%core!ops.function.FnOnce./Output F&. F& Args&. Args&))
     )
     (=>
      (and
       (and
        (and
         (and
          (sized Args&.)
          (sized F&.)
         )
         (tr_bound%core!marker.Tuple. Args&. Args&)
        )
        (tr_bound%core!ops.function.FnMut. F&. F& Args&. Args&)
       )
       (closure_ens (MUTREF F&. F&) Args&. Args& f! args! output!)
      )
      (and
       (closure_ens F& Args&. Args& (mut_ref_current% f!) args! output!)
       (= (mut_ref_current% f!) (mut_ref_future% f!))
    )))
    :pattern ((closure_ens (MUTREF F&. F&) Args&. Args& f! args! output!))
    :qid user_vstd__function__axiom_fn_mut_call_ensures_0
    :skolemid skolem_user_vstd__function__axiom_fn_mut_call_ensures_0
))))

;; Function-Axioms vstd::std_specs::cmp::PartialEqSpec::eq_spec
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (Rhs&. Dcr) (Rhs& Type) (self! Poly) (other! Poly))
  (!
   (=>
    (and
     (has_type self! Self%&)
     (has_type other! Rhs&)
    )
    (has_type (vstd!std_specs.cmp.PartialEqSpec.eq_spec.? Self%&. Self%& Rhs&. Rhs& self!
      other!
     ) BOOL
   ))
   :pattern ((vstd!std_specs.cmp.PartialEqSpec.eq_spec.? Self%&. Self%& Rhs&. Rhs& self!
     other!
   ))
   :qid internal_vstd!std_specs.cmp.PartialEqSpec.eq_spec.?_pre_post_definition
   :skolemid skolem_internal_vstd!std_specs.cmp.PartialEqSpec.eq_spec.?_pre_post_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((Rhs&. Dcr) (Rhs& Type) (VERUS_SPEC__A&. Dcr) (VERUS_SPEC__A& Type)) (!
   (=>
    (tr_bound%core!cmp.PartialEq. VERUS_SPEC__A&. VERUS_SPEC__A& Rhs&. Rhs&)
    (tr_bound%vstd!std_specs.cmp.PartialEqSpec. VERUS_SPEC__A&. VERUS_SPEC__A& Rhs&. Rhs&)
   )
   :pattern ((tr_bound%vstd!std_specs.cmp.PartialEqSpec. VERUS_SPEC__A&. VERUS_SPEC__A&
     Rhs&. Rhs&
   ))
   :qid internal_vstd__std_specs__cmp__impl&__6_trait_impl_definition
   :skolemid skolem_internal_vstd__std_specs__cmp__impl&__6_trait_impl_definition
)))

;; Function-Axioms vstd::std_specs::cmp::impl&%2::eq_spec
(assert
 (fuel_bool_default fuel%vstd!std_specs.cmp.impl&%2.eq_spec.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!std_specs.cmp.impl&%2.eq_spec.)
  (forall ((self! Poly) (other! Poly)) (!
    (= (vstd!std_specs.cmp.PartialEqSpec.eq_spec.? $ BOOL $ BOOL self! other!) (B (= self!
       other!
    )))
    :pattern ((vstd!std_specs.cmp.PartialEqSpec.eq_spec.? $ BOOL $ BOOL self! other!))
    :qid internal_vstd!std_specs.cmp.impl&__2.eq_spec.?_definition
    :skolemid skolem_internal_vstd!std_specs.cmp.impl&__2.eq_spec.?_definition
))))

;; Trait-Impl-Axiom
(assert
 (tr_bound%core!cmp.PartialEq. $ BOOL $ BOOL)
)

;; Trait-Impl-Axiom
(assert
 (tr_bound%vstd!std_specs.cmp.PartialEqSpec. $ BOOL $ BOOL)
)

;; Function-Axioms vstd::view::View::view
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (self! Poly)) (!
   (=>
    (has_type self! Self%&)
    (has_type (vstd!view.View.view.? Self%&. Self%& self!) (proj%vstd!view.View./V Self%&.
      Self%&
   )))
   :pattern ((vstd!view.View.view.? Self%&. Self%& self!))
   :qid internal_vstd!view.View.view.?_pre_post_definition
   :skolemid skolem_internal_vstd!view.View.view.?_pre_post_definition
)))

;; Function-Axioms vstd::view::impl&%18::view
(assert
 (fuel_bool_default fuel%vstd!view.impl&%18.view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%18.view.)
  (forall ((self! Poly)) (!
    (= (vstd!view.View.view.? $ BOOL self!) self!)
    :pattern ((vstd!view.View.view.? $ BOOL self!))
    :qid internal_vstd!view.impl&__18.view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__18.view.?_definition
))))

;; Trait-Impl-Axiom
(assert
 (tr_bound%vstd!view.View. $ BOOL)
)

;; Function-Axioms vstd::view::DeepView::deep_view
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (self! Poly)) (!
   (=>
    (has_type self! Self%&)
    (has_type (vstd!view.DeepView.deep_view.? Self%&. Self%& self!) (proj%vstd!view.DeepView./V
      Self%&. Self%&
   )))
   :pattern ((vstd!view.DeepView.deep_view.? Self%&. Self%& self!))
   :qid internal_vstd!view.DeepView.deep_view.?_pre_post_definition
   :skolemid skolem_internal_vstd!view.DeepView.deep_view.?_pre_post_definition
)))

;; Function-Axioms vstd::view::impl&%19::deep_view
(assert
 (fuel_bool_default fuel%vstd!view.impl&%19.deep_view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%19.deep_view.)
  (forall ((self! Poly)) (!
    (= (vstd!view.DeepView.deep_view.? $ BOOL self!) self!)
    :pattern ((vstd!view.DeepView.deep_view.? $ BOOL self!))
    :qid internal_vstd!view.impl&__19.deep_view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__19.deep_view.?_definition
))))

;; Trait-Impl-Axiom
(assert
 (tr_bound%vstd!view.DeepView. $ BOOL)
)

;; Function-Axioms vstd::std_specs::num::usize_specs_tmp::impl&%0::eq_spec
(assert
 (fuel_bool_default fuel%vstd!std_specs.num.usize_specs_tmp.impl&%0.eq_spec.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!std_specs.num.usize_specs_tmp.impl&%0.eq_spec.)
  (forall ((self! Poly) (other! Poly)) (!
    (= (vstd!std_specs.cmp.PartialEqSpec.eq_spec.? $ USIZE $ USIZE self! other!) (B (= self!
       other!
    )))
    :pattern ((vstd!std_specs.cmp.PartialEqSpec.eq_spec.? $ USIZE $ USIZE self! other!))
    :qid internal_vstd!std_specs.num.usize_specs_tmp.impl&__0.eq_spec.?_definition
    :skolemid skolem_internal_vstd!std_specs.num.usize_specs_tmp.impl&__0.eq_spec.?_definition
))))

;; Trait-Impl-Axiom
(assert
 (tr_bound%core!cmp.PartialEq. $ USIZE $ USIZE)
)

;; Trait-Impl-Axiom
(assert
 (tr_bound%vstd!std_specs.cmp.PartialEqSpec. $ USIZE $ USIZE)
)

;; Function-Axioms vstd::view::impl&%30::view
(assert
 (fuel_bool_default fuel%vstd!view.impl&%30.view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%30.view.)
  (forall ((self! Poly)) (!
    (= (vstd!view.View.view.? $ USIZE self!) self!)
    :pattern ((vstd!view.View.view.? $ USIZE self!))
    :qid internal_vstd!view.impl&__30.view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__30.view.?_definition
))))

;; Trait-Impl-Axiom
(assert
 (tr_bound%vstd!view.View. $ USIZE)
)

;; Function-Axioms vstd::view::impl&%31::deep_view
(assert
 (fuel_bool_default fuel%vstd!view.impl&%31.deep_view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%31.deep_view.)
  (forall ((self! Poly)) (!
    (= (vstd!view.DeepView.deep_view.? $ USIZE self!) self!)
    :pattern ((vstd!view.DeepView.deep_view.? $ USIZE self!))
    :qid internal_vstd!view.impl&__31.deep_view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__31.deep_view.?_definition
))))

;; Trait-Impl-Axiom
(assert
 (tr_bound%vstd!view.DeepView. $ USIZE)
)

;; Function-Axioms vstd::std_specs::cmp::impl&%9::eq_spec
(assert
 (fuel_bool_default fuel%vstd!std_specs.cmp.impl&%9.eq_spec.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!std_specs.cmp.impl&%9.eq_spec.)
  (forall ((T&. Dcr) (T& Type) (self! Poly) (other! Poly)) (!
    (=>
     (and
      (sized T&.)
      (tr_bound%core!cmp.PartialEq. T&. T& T&. T&)
      (tr_bound%vstd!std_specs.cmp.PartialEqSpec. T&. T& T&. T&)
     )
     (= (vstd!std_specs.cmp.PartialEqSpec.eq_spec.? (DST T&.) (TYPE%tuple%1. T&. T&) (DST
        T&.
       ) (TYPE%tuple%1. T&. T&) self! other!
      ) (vstd!std_specs.cmp.PartialEqSpec.eq_spec.? T&. T& T&. T& (tuple%1./tuple%1/0 (%Poly%tuple%1.
         self!
        )
       ) (tuple%1./tuple%1/0 (%Poly%tuple%1. other!))
    )))
    :pattern ((vstd!std_specs.cmp.PartialEqSpec.eq_spec.? (DST T&.) (TYPE%tuple%1. T&. T&)
      (DST T&.) (TYPE%tuple%1. T&. T&) self! other!
    ))
    :qid internal_vstd!std_specs.cmp.impl&__9.eq_spec.?_definition
    :skolemid skolem_internal_vstd!std_specs.cmp.impl&__9.eq_spec.?_definition
))))

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (and
     (sized T&.)
     (tr_bound%core!cmp.PartialEq. T&. T& T&. T&)
    )
    (tr_bound%core!cmp.PartialEq. (DST T&.) (TYPE%tuple%1. T&. T&) (DST T&.) (TYPE%tuple%1.
      T&. T&
   )))
   :pattern ((tr_bound%core!cmp.PartialEq. (DST T&.) (TYPE%tuple%1. T&. T&) (DST T&.)
     (TYPE%tuple%1. T&. T&)
   ))
   :qid internal_core__tuple__impl&__0_trait_impl_definition
   :skolemid skolem_internal_core__tuple__impl&__0_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (and
     (sized T&.)
     (tr_bound%core!cmp.PartialEq. T&. T& T&. T&)
     (tr_bound%vstd!std_specs.cmp.PartialEqSpec. T&. T& T&. T&)
    )
    (tr_bound%vstd!std_specs.cmp.PartialEqSpec. (DST T&.) (TYPE%tuple%1. T&. T&) (DST T&.)
     (TYPE%tuple%1. T&. T&)
   ))
   :pattern ((tr_bound%vstd!std_specs.cmp.PartialEqSpec. (DST T&.) (TYPE%tuple%1. T&. T&)
     (DST T&.) (TYPE%tuple%1. T&. T&)
   ))
   :qid internal_vstd__std_specs__cmp__impl&__9_trait_impl_definition
   :skolemid skolem_internal_vstd__std_specs__cmp__impl&__9_trait_impl_definition
)))

;; Function-Axioms vstd::view::impl&%46::view
(assert
 (fuel_bool_default fuel%vstd!view.impl&%46.view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%46.view.)
  (forall ((A0&. Dcr) (A0& Type) (self! Poly)) (!
    (=>
     (and
      (sized A0&.)
      (tr_bound%vstd!view.View. A0&. A0&)
     )
     (= (vstd!view.View.view.? (DST A0&.) (TYPE%tuple%1. A0&. A0&) self!) (Poly%tuple%1.
       (tuple%1./tuple%1 (vstd!view.View.view.? A0&. A0& (tuple%1./tuple%1/0 (%Poly%tuple%1.
           self!
    )))))))
    :pattern ((vstd!view.View.view.? (DST A0&.) (TYPE%tuple%1. A0&. A0&) self!))
    :qid internal_vstd!view.impl&__46.view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__46.view.?_definition
))))

;; Trait-Impl-Axiom
(assert
 (forall ((A0&. Dcr) (A0& Type)) (!
   (=>
    (and
     (sized A0&.)
     (tr_bound%vstd!view.View. A0&. A0&)
    )
    (tr_bound%vstd!view.View. (DST A0&.) (TYPE%tuple%1. A0&. A0&))
   )
   :pattern ((tr_bound%vstd!view.View. (DST A0&.) (TYPE%tuple%1. A0&. A0&)))
   :qid internal_vstd__view__impl&__46_trait_impl_definition
   :skolemid skolem_internal_vstd__view__impl&__46_trait_impl_definition
)))

;; Function-Axioms vstd::view::impl&%47::deep_view
(assert
 (fuel_bool_default fuel%vstd!view.impl&%47.deep_view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%47.deep_view.)
  (forall ((A0&. Dcr) (A0& Type) (self! Poly)) (!
    (=>
     (and
      (sized A0&.)
      (tr_bound%vstd!view.DeepView. A0&. A0&)
     )
     (= (vstd!view.DeepView.deep_view.? (DST A0&.) (TYPE%tuple%1. A0&. A0&) self!) (Poly%tuple%1.
       (tuple%1./tuple%1 (vstd!view.DeepView.deep_view.? A0&. A0& (tuple%1./tuple%1/0 (%Poly%tuple%1.
           self!
    )))))))
    :pattern ((vstd!view.DeepView.deep_view.? (DST A0&.) (TYPE%tuple%1. A0&. A0&) self!))
    :qid internal_vstd!view.impl&__47.deep_view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__47.deep_view.?_definition
))))

;; Trait-Impl-Axiom
(assert
 (forall ((A0&. Dcr) (A0& Type)) (!
   (=>
    (and
     (sized A0&.)
     (tr_bound%vstd!view.DeepView. A0&. A0&)
    )
    (tr_bound%vstd!view.DeepView. (DST A0&.) (TYPE%tuple%1. A0&. A0&))
   )
   :pattern ((tr_bound%vstd!view.DeepView. (DST A0&.) (TYPE%tuple%1. A0&. A0&)))
   :qid internal_vstd__view__impl&__47_trait_impl_definition
   :skolemid skolem_internal_vstd__view__impl&__47_trait_impl_definition
)))

;; Function-Axioms vstd::std_specs::cmp::impl&%12::eq_spec
(assert
 (fuel_bool_default fuel%vstd!std_specs.cmp.impl&%12.eq_spec.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!std_specs.cmp.impl&%12.eq_spec.)
  (forall ((U&. Dcr) (U& Type) (T&. Dcr) (T& Type) (self! Poly) (other! Poly)) (!
    (=>
     (and
      (sized U&.)
      (sized T&.)
      (tr_bound%core!cmp.PartialEq. U&. U& U&. U&)
      (tr_bound%vstd!std_specs.cmp.PartialEqSpec. U&. U& U&. U&)
      (tr_bound%core!cmp.PartialEq. T&. T& T&. T&)
      (tr_bound%vstd!std_specs.cmp.PartialEqSpec. T&. T& T&. T&)
     )
     (= (vstd!std_specs.cmp.PartialEqSpec.eq_spec.? (DST T&.) (TYPE%tuple%2. U&. U& T&. T&)
       (DST T&.) (TYPE%tuple%2. U&. U& T&. T&) self! other!
      ) (B (and
        (%B (vstd!std_specs.cmp.PartialEqSpec.eq_spec.? U&. U& U&. U& (tuple%2./tuple%2/0 (%Poly%tuple%2.
            self!
           )
          ) (tuple%2./tuple%2/0 (%Poly%tuple%2. other!))
        ))
        (%B (vstd!std_specs.cmp.PartialEqSpec.eq_spec.? T&. T& T&. T& (tuple%2./tuple%2/1 (%Poly%tuple%2.
            self!
           )
          ) (tuple%2./tuple%2/1 (%Poly%tuple%2. other!))
    ))))))
    :pattern ((vstd!std_specs.cmp.PartialEqSpec.eq_spec.? (DST T&.) (TYPE%tuple%2. U&. U&
       T&. T&
      ) (DST T&.) (TYPE%tuple%2. U&. U& T&. T&) self! other!
    ))
    :qid internal_vstd!std_specs.cmp.impl&__12.eq_spec.?_definition
    :skolemid skolem_internal_vstd!std_specs.cmp.impl&__12.eq_spec.?_definition
))))

;; Trait-Impl-Axiom
(assert
 (forall ((U&. Dcr) (U& Type) (T&. Dcr) (T& Type)) (!
   (=>
    (and
     (sized U&.)
     (sized T&.)
     (tr_bound%core!cmp.PartialEq. U&. U& U&. U&)
     (tr_bound%core!cmp.PartialEq. T&. T& T&. T&)
    )
    (tr_bound%core!cmp.PartialEq. (DST T&.) (TYPE%tuple%2. U&. U& T&. T&) (DST T&.) (TYPE%tuple%2.
      U&. U& T&. T&
   )))
   :pattern ((tr_bound%core!cmp.PartialEq. (DST T&.) (TYPE%tuple%2. U&. U& T&. T&) (DST
      T&.
     ) (TYPE%tuple%2. U&. U& T&. T&)
   ))
   :qid internal_core__tuple__impl&__10_trait_impl_definition
   :skolemid skolem_internal_core__tuple__impl&__10_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((U&. Dcr) (U& Type) (T&. Dcr) (T& Type)) (!
   (=>
    (and
     (sized U&.)
     (sized T&.)
     (tr_bound%core!cmp.PartialEq. U&. U& U&. U&)
     (tr_bound%vstd!std_specs.cmp.PartialEqSpec. U&. U& U&. U&)
     (tr_bound%core!cmp.PartialEq. T&. T& T&. T&)
     (tr_bound%vstd!std_specs.cmp.PartialEqSpec. T&. T& T&. T&)
    )
    (tr_bound%vstd!std_specs.cmp.PartialEqSpec. (DST T&.) (TYPE%tuple%2. U&. U& T&. T&)
     (DST T&.) (TYPE%tuple%2. U&. U& T&. T&)
   ))
   :pattern ((tr_bound%vstd!std_specs.cmp.PartialEqSpec. (DST T&.) (TYPE%tuple%2. U&. U&
      T&. T&
     ) (DST T&.) (TYPE%tuple%2. U&. U& T&. T&)
   ))
   :qid internal_vstd__std_specs__cmp__impl&__12_trait_impl_definition
   :skolemid skolem_internal_vstd__std_specs__cmp__impl&__12_trait_impl_definition
)))

;; Function-Axioms vstd::view::impl&%48::view
(assert
 (fuel_bool_default fuel%vstd!view.impl&%48.view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%48.view.)
  (forall ((A0&. Dcr) (A0& Type) (A1&. Dcr) (A1& Type) (self! Poly)) (!
    (=>
     (and
      (sized A0&.)
      (sized A1&.)
      (tr_bound%vstd!view.View. A0&. A0&)
      (tr_bound%vstd!view.View. A1&. A1&)
     )
     (= (vstd!view.View.view.? (DST A1&.) (TYPE%tuple%2. A0&. A0& A1&. A1&) self!) (Poly%tuple%2.
       (tuple%2./tuple%2 (vstd!view.View.view.? A0&. A0& (tuple%2./tuple%2/0 (%Poly%tuple%2.
           self!
         ))
        ) (vstd!view.View.view.? A1&. A1& (tuple%2./tuple%2/1 (%Poly%tuple%2. self!)))
    ))))
    :pattern ((vstd!view.View.view.? (DST A1&.) (TYPE%tuple%2. A0&. A0& A1&. A1&) self!))
    :qid internal_vstd!view.impl&__48.view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__48.view.?_definition
))))

;; Trait-Impl-Axiom
(assert
 (forall ((A0&. Dcr) (A0& Type) (A1&. Dcr) (A1& Type)) (!
   (=>
    (and
     (sized A0&.)
     (sized A1&.)
     (tr_bound%vstd!view.View. A0&. A0&)
     (tr_bound%vstd!view.View. A1&. A1&)
    )
    (tr_bound%vstd!view.View. (DST A1&.) (TYPE%tuple%2. A0&. A0& A1&. A1&))
   )
   :pattern ((tr_bound%vstd!view.View. (DST A1&.) (TYPE%tuple%2. A0&. A0& A1&. A1&)))
   :qid internal_vstd__view__impl&__48_trait_impl_definition
   :skolemid skolem_internal_vstd__view__impl&__48_trait_impl_definition
)))

;; Function-Axioms vstd::view::impl&%49::deep_view
(assert
 (fuel_bool_default fuel%vstd!view.impl&%49.deep_view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%49.deep_view.)
  (forall ((A0&. Dcr) (A0& Type) (A1&. Dcr) (A1& Type) (self! Poly)) (!
    (=>
     (and
      (sized A0&.)
      (sized A1&.)
      (tr_bound%vstd!view.DeepView. A0&. A0&)
      (tr_bound%vstd!view.DeepView. A1&. A1&)
     )
     (= (vstd!view.DeepView.deep_view.? (DST A1&.) (TYPE%tuple%2. A0&. A0& A1&. A1&) self!)
      (Poly%tuple%2. (tuple%2./tuple%2 (vstd!view.DeepView.deep_view.? A0&. A0& (tuple%2./tuple%2/0
          (%Poly%tuple%2. self!)
         )
        ) (vstd!view.DeepView.deep_view.? A1&. A1& (tuple%2./tuple%2/1 (%Poly%tuple%2. self!)))
    ))))
    :pattern ((vstd!view.DeepView.deep_view.? (DST A1&.) (TYPE%tuple%2. A0&. A0& A1&. A1&)
      self!
    ))
    :qid internal_vstd!view.impl&__49.deep_view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__49.deep_view.?_definition
))))

;; Trait-Impl-Axiom
(assert
 (forall ((A0&. Dcr) (A0& Type) (A1&. Dcr) (A1& Type)) (!
   (=>
    (and
     (sized A0&.)
     (sized A1&.)
     (tr_bound%vstd!view.DeepView. A0&. A0&)
     (tr_bound%vstd!view.DeepView. A1&. A1&)
    )
    (tr_bound%vstd!view.DeepView. (DST A1&.) (TYPE%tuple%2. A0&. A0& A1&. A1&))
   )
   :pattern ((tr_bound%vstd!view.DeepView. (DST A1&.) (TYPE%tuple%2. A0&. A0& A1&. A1&)))
   :qid internal_vstd__view__impl&__49_trait_impl_definition
   :skolemid skolem_internal_vstd__view__impl&__49_trait_impl_definition
)))

;; Function-Axioms vstd::std_specs::cmp::impl&%15::eq_spec
(assert
 (fuel_bool_default fuel%vstd!std_specs.cmp.impl&%15.eq_spec.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!std_specs.cmp.impl&%15.eq_spec.)
  (forall ((V&. Dcr) (V& Type) (U&. Dcr) (U& Type) (T&. Dcr) (T& Type) (self! Poly) (
     other! Poly
    )
   ) (!
    (=>
     (and
      (sized V&.)
      (sized U&.)
      (sized T&.)
      (tr_bound%core!cmp.PartialEq. V&. V& V&. V&)
      (tr_bound%vstd!std_specs.cmp.PartialEqSpec. V&. V& V&. V&)
      (tr_bound%core!cmp.PartialEq. U&. U& U&. U&)
      (tr_bound%vstd!std_specs.cmp.PartialEqSpec. U&. U& U&. U&)
      (tr_bound%core!cmp.PartialEq. T&. T& T&. T&)
      (tr_bound%vstd!std_specs.cmp.PartialEqSpec. T&. T& T&. T&)
     )
     (= (vstd!std_specs.cmp.PartialEqSpec.eq_spec.? (DST T&.) (TYPE%tuple%3. V&. V& U&. U&
        T&. T&
       ) (DST T&.) (TYPE%tuple%3. V&. V& U&. U& T&. T&) self! other!
      ) (B (and
        (and
         (%B (vstd!std_specs.cmp.PartialEqSpec.eq_spec.? V&. V& V&. V& (tuple%3./tuple%3/0 (%Poly%tuple%3.
             self!
            )
           ) (tuple%3./tuple%3/0 (%Poly%tuple%3. other!))
         ))
         (%B (vstd!std_specs.cmp.PartialEqSpec.eq_spec.? U&. U& U&. U& (tuple%3./tuple%3/1 (%Poly%tuple%3.
             self!
            )
           ) (tuple%3./tuple%3/1 (%Poly%tuple%3. other!))
        )))
        (%B (vstd!std_specs.cmp.PartialEqSpec.eq_spec.? T&. T& T&. T& (tuple%3./tuple%3/2 (%Poly%tuple%3.
            self!
           )
          ) (tuple%3./tuple%3/2 (%Poly%tuple%3. other!))
    ))))))
    :pattern ((vstd!std_specs.cmp.PartialEqSpec.eq_spec.? (DST T&.) (TYPE%tuple%3. V&. V&
       U&. U& T&. T&
      ) (DST T&.) (TYPE%tuple%3. V&. V& U&. U& T&. T&) self! other!
    ))
    :qid internal_vstd!std_specs.cmp.impl&__15.eq_spec.?_definition
    :skolemid skolem_internal_vstd!std_specs.cmp.impl&__15.eq_spec.?_definition
))))

;; Trait-Impl-Axiom
(assert
 (forall ((V&. Dcr) (V& Type) (U&. Dcr) (U& Type) (T&. Dcr) (T& Type)) (!
   (=>
    (and
     (sized V&.)
     (sized U&.)
     (sized T&.)
     (tr_bound%core!cmp.PartialEq. V&. V& V&. V&)
     (tr_bound%core!cmp.PartialEq. U&. U& U&. U&)
     (tr_bound%core!cmp.PartialEq. T&. T& T&. T&)
    )
    (tr_bound%core!cmp.PartialEq. (DST T&.) (TYPE%tuple%3. V&. V& U&. U& T&. T&) (DST T&.)
     (TYPE%tuple%3. V&. V& U&. U& T&. T&)
   ))
   :pattern ((tr_bound%core!cmp.PartialEq. (DST T&.) (TYPE%tuple%3. V&. V& U&. U& T&. T&)
     (DST T&.) (TYPE%tuple%3. V&. V& U&. U& T&. T&)
   ))
   :qid internal_core__tuple__impl&__20_trait_impl_definition
   :skolemid skolem_internal_core__tuple__impl&__20_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((V&. Dcr) (V& Type) (U&. Dcr) (U& Type) (T&. Dcr) (T& Type)) (!
   (=>
    (and
     (sized V&.)
     (sized U&.)
     (sized T&.)
     (tr_bound%core!cmp.PartialEq. V&. V& V&. V&)
     (tr_bound%vstd!std_specs.cmp.PartialEqSpec. V&. V& V&. V&)
     (tr_bound%core!cmp.PartialEq. U&. U& U&. U&)
     (tr_bound%vstd!std_specs.cmp.PartialEqSpec. U&. U& U&. U&)
     (tr_bound%core!cmp.PartialEq. T&. T& T&. T&)
     (tr_bound%vstd!std_specs.cmp.PartialEqSpec. T&. T& T&. T&)
    )
    (tr_bound%vstd!std_specs.cmp.PartialEqSpec. (DST T&.) (TYPE%tuple%3. V&. V& U&. U&
      T&. T&
     ) (DST T&.) (TYPE%tuple%3. V&. V& U&. U& T&. T&)
   ))
   :pattern ((tr_bound%vstd!std_specs.cmp.PartialEqSpec. (DST T&.) (TYPE%tuple%3. V&. V&
      U&. U& T&. T&
     ) (DST T&.) (TYPE%tuple%3. V&. V& U&. U& T&. T&)
   ))
   :qid internal_vstd__std_specs__cmp__impl&__15_trait_impl_definition
   :skolemid skolem_internal_vstd__std_specs__cmp__impl&__15_trait_impl_definition
)))

;; Function-Axioms vstd::view::impl&%50::view
(assert
 (fuel_bool_default fuel%vstd!view.impl&%50.view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%50.view.)
  (forall ((A0&. Dcr) (A0& Type) (A1&. Dcr) (A1& Type) (A2&. Dcr) (A2& Type) (self! Poly))
   (!
    (=>
     (and
      (sized A0&.)
      (sized A1&.)
      (sized A2&.)
      (tr_bound%vstd!view.View. A0&. A0&)
      (tr_bound%vstd!view.View. A1&. A1&)
      (tr_bound%vstd!view.View. A2&. A2&)
     )
     (= (vstd!view.View.view.? (DST A2&.) (TYPE%tuple%3. A0&. A0& A1&. A1& A2&. A2&) self!)
      (Poly%tuple%3. (tuple%3./tuple%3 (vstd!view.View.view.? A0&. A0& (tuple%3./tuple%3/0
          (%Poly%tuple%3. self!)
         )
        ) (vstd!view.View.view.? A1&. A1& (tuple%3./tuple%3/1 (%Poly%tuple%3. self!))) (vstd!view.View.view.?
         A2&. A2& (tuple%3./tuple%3/2 (%Poly%tuple%3. self!))
    )))))
    :pattern ((vstd!view.View.view.? (DST A2&.) (TYPE%tuple%3. A0&. A0& A1&. A1& A2&. A2&)
      self!
    ))
    :qid internal_vstd!view.impl&__50.view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__50.view.?_definition
))))

;; Trait-Impl-Axiom
(assert
 (forall ((A0&. Dcr) (A0& Type) (A1&. Dcr) (A1& Type) (A2&. Dcr) (A2& Type)) (!
   (=>
    (and
     (sized A0&.)
     (sized A1&.)
     (sized A2&.)
     (tr_bound%vstd!view.View. A0&. A0&)
     (tr_bound%vstd!view.View. A1&. A1&)
     (tr_bound%vstd!view.View. A2&. A2&)
    )
    (tr_bound%vstd!view.View. (DST A2&.) (TYPE%tuple%3. A0&. A0& A1&. A1& A2&. A2&))
   )
   :pattern ((tr_bound%vstd!view.View. (DST A2&.) (TYPE%tuple%3. A0&. A0& A1&. A1& A2&.
      A2&
   )))
   :qid internal_vstd__view__impl&__50_trait_impl_definition
   :skolemid skolem_internal_vstd__view__impl&__50_trait_impl_definition
)))

;; Function-Axioms vstd::view::impl&%51::deep_view
(assert
 (fuel_bool_default fuel%vstd!view.impl&%51.deep_view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%51.deep_view.)
  (forall ((A0&. Dcr) (A0& Type) (A1&. Dcr) (A1& Type) (A2&. Dcr) (A2& Type) (self! Poly))
   (!
    (=>
     (and
      (sized A0&.)
      (sized A1&.)
      (sized A2&.)
      (tr_bound%vstd!view.DeepView. A0&. A0&)
      (tr_bound%vstd!view.DeepView. A1&. A1&)
      (tr_bound%vstd!view.DeepView. A2&. A2&)
     )
     (= (vstd!view.DeepView.deep_view.? (DST A2&.) (TYPE%tuple%3. A0&. A0& A1&. A1& A2&.
        A2&
       ) self!
      ) (Poly%tuple%3. (tuple%3./tuple%3 (vstd!view.DeepView.deep_view.? A0&. A0& (tuple%3./tuple%3/0
          (%Poly%tuple%3. self!)
         )
        ) (vstd!view.DeepView.deep_view.? A1&. A1& (tuple%3./tuple%3/1 (%Poly%tuple%3. self!)))
        (vstd!view.DeepView.deep_view.? A2&. A2& (tuple%3./tuple%3/2 (%Poly%tuple%3. self!)))
    ))))
    :pattern ((vstd!view.DeepView.deep_view.? (DST A2&.) (TYPE%tuple%3. A0&. A0& A1&. A1&
       A2&. A2&
      ) self!
    ))
    :qid internal_vstd!view.impl&__51.deep_view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__51.deep_view.?_definition
))))

;; Trait-Impl-Axiom
(assert
 (forall ((A0&. Dcr) (A0& Type) (A1&. Dcr) (A1& Type) (A2&. Dcr) (A2& Type)) (!
   (=>
    (and
     (sized A0&.)
     (sized A1&.)
     (sized A2&.)
     (tr_bound%vstd!view.DeepView. A0&. A0&)
     (tr_bound%vstd!view.DeepView. A1&. A1&)
     (tr_bound%vstd!view.DeepView. A2&. A2&)
    )
    (tr_bound%vstd!view.DeepView. (DST A2&.) (TYPE%tuple%3. A0&. A0& A1&. A1& A2&. A2&))
   )
   :pattern ((tr_bound%vstd!view.DeepView. (DST A2&.) (TYPE%tuple%3. A0&. A0& A1&. A1&
      A2&. A2&
   )))
   :qid internal_vstd__view__impl&__51_trait_impl_definition
   :skolemid skolem_internal_vstd__view__impl&__51_trait_impl_definition
)))

;; Function-Axioms vstd::std_specs::cmp::impl&%3::eq_spec
(assert
 (fuel_bool_default fuel%vstd!std_specs.cmp.impl&%3.eq_spec.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!std_specs.cmp.impl&%3.eq_spec.)
  (forall ((A&. Dcr) (A& Type) (B&. Dcr) (B& Type) (self! Poly) (other! Poly)) (!
    (=>
     (tr_bound%core!cmp.PartialEq. A&. A& B&. B&)
     (= (vstd!std_specs.cmp.PartialEqSpec.eq_spec.? (REF A&.) A& (REF B&.) B& self! other!)
      (vstd!std_specs.cmp.PartialEqSpec.eq_spec.? A&. A& B&. B& self! other!)
    ))
    :pattern ((vstd!std_specs.cmp.PartialEqSpec.eq_spec.? (REF A&.) A& (REF B&.) B& self!
      other!
    ))
    :qid internal_vstd!std_specs.cmp.impl&__3.eq_spec.?_definition
    :skolemid skolem_internal_vstd!std_specs.cmp.impl&__3.eq_spec.?_definition
))))

;; Trait-Impl-Axiom
(assert
 (forall ((A&. Dcr) (A& Type) (B&. Dcr) (B& Type)) (!
   (=>
    (tr_bound%core!cmp.PartialEq. A&. A& B&. B&)
    (tr_bound%core!cmp.PartialEq. (REF A&.) A& (REF B&.) B&)
   )
   :pattern ((tr_bound%core!cmp.PartialEq. (REF A&.) A& (REF B&.) B&))
   :qid internal_core__cmp__impls__impl&__9_trait_impl_definition
   :skolemid skolem_internal_core__cmp__impls__impl&__9_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((A&. Dcr) (A& Type) (B&. Dcr) (B& Type)) (!
   (=>
    (tr_bound%core!cmp.PartialEq. A&. A& B&. B&)
    (tr_bound%vstd!std_specs.cmp.PartialEqSpec. (REF A&.) A& (REF B&.) B&)
   )
   :pattern ((tr_bound%vstd!std_specs.cmp.PartialEqSpec. (REF A&.) A& (REF B&.) B&))
   :qid internal_vstd__std_specs__cmp__impl&__3_trait_impl_definition
   :skolemid skolem_internal_vstd__std_specs__cmp__impl&__3_trait_impl_definition
)))

;; Function-Axioms vstd::view::impl&%0::view
(assert
 (fuel_bool_default fuel%vstd!view.impl&%0.view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%0.view.)
  (forall ((A&. Dcr) (A& Type) (self! Poly)) (!
    (=>
     (tr_bound%vstd!view.View. A&. A&)
     (= (vstd!view.View.view.? (REF A&.) A& self!) (vstd!view.View.view.? A&. A& self!))
    )
    :pattern ((vstd!view.View.view.? (REF A&.) A& self!))
    :qid internal_vstd!view.impl&__0.view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__0.view.?_definition
))))

;; Trait-Impl-Axiom
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (tr_bound%vstd!view.View. A&. A&)
    (tr_bound%vstd!view.View. (REF A&.) A&)
   )
   :pattern ((tr_bound%vstd!view.View. (REF A&.) A&))
   :qid internal_vstd__view__impl&__0_trait_impl_definition
   :skolemid skolem_internal_vstd__view__impl&__0_trait_impl_definition
)))

;; Function-Axioms vstd::view::impl&%1::deep_view
(assert
 (fuel_bool_default fuel%vstd!view.impl&%1.deep_view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%1.deep_view.)
  (forall ((A&. Dcr) (A& Type) (self! Poly)) (!
    (=>
     (tr_bound%vstd!view.DeepView. A&. A&)
     (= (vstd!view.DeepView.deep_view.? (REF A&.) A& self!) (vstd!view.DeepView.deep_view.?
       A&. A& self!
    )))
    :pattern ((vstd!view.DeepView.deep_view.? (REF A&.) A& self!))
    :qid internal_vstd!view.impl&__1.deep_view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__1.deep_view.?_definition
))))

;; Trait-Impl-Axiom
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (tr_bound%vstd!view.DeepView. A&. A&)
    (tr_bound%vstd!view.DeepView. (REF A&.) A&)
   )
   :pattern ((tr_bound%vstd!view.DeepView. (REF A&.) A&))
   :qid internal_vstd__view__impl&__1_trait_impl_definition
   :skolemid skolem_internal_vstd__view__impl&__1_trait_impl_definition
)))

;; Function-Axioms vstd::std_specs::option::impl&%1::eq_spec
(assert
 (fuel_bool_default fuel%vstd!std_specs.option.impl&%1.eq_spec.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!std_specs.option.impl&%1.eq_spec.)
  (forall ((T&. Dcr) (T& Type) (self! Poly) (other! Poly)) (!
    (=>
     (and
      (sized T&.)
      (tr_bound%vstd!std_specs.cmp.PartialEqSpec. T&. T& T&. T&)
     )
     (= (vstd!std_specs.cmp.PartialEqSpec.eq_spec.? $ (TYPE%core!option.Option. T&. T&)
       $ (TYPE%core!option.Option. T&. T&) self! other!
      ) (B (let
        ((tmp%%$ (tuple%2./tuple%2 self! other!)))
        (=>
         (not (and
           (and
            (is-tuple%2./tuple%2 tmp%%$)
            (is-core!option.Option./None (%Poly%core!option.Option. (tuple%2./tuple%2/0 (%Poly%tuple%2.
                (Poly%tuple%2. tmp%%$)
           )))))
           (is-core!option.Option./None (%Poly%core!option.Option. (tuple%2./tuple%2/1 (%Poly%tuple%2.
               (Poly%tuple%2. tmp%%$)
         ))))))
         (and
          (and
           (and
            (is-tuple%2./tuple%2 tmp%%$)
            (is-core!option.Option./Some (%Poly%core!option.Option. (tuple%2./tuple%2/0 (%Poly%tuple%2.
                (Poly%tuple%2. tmp%%$)
           )))))
           (is-core!option.Option./Some (%Poly%core!option.Option. (tuple%2./tuple%2/1 (%Poly%tuple%2.
               (Poly%tuple%2. tmp%%$)
          )))))
          (%B (let
            ((x$ (core!option.Option./Some/0 T&. T& (%Poly%core!option.Option. (tuple%2./tuple%2/0
                 (%Poly%tuple%2. (Poly%tuple%2. tmp%%$))
            )))))
            (let
             ((y$ (core!option.Option./Some/0 T&. T& (%Poly%core!option.Option. (tuple%2./tuple%2/1
                  (%Poly%tuple%2. (Poly%tuple%2. tmp%%$))
             )))))
             (vstd!std_specs.cmp.PartialEqSpec.eq_spec.? T&. T& T&. T& x$ y$)
    )))))))))
    :pattern ((vstd!std_specs.cmp.PartialEqSpec.eq_spec.? $ (TYPE%core!option.Option. T&.
       T&
      ) $ (TYPE%core!option.Option. T&. T&) self! other!
    ))
    :qid internal_vstd!std_specs.option.impl&__1.eq_spec.?_definition
    :skolemid skolem_internal_vstd!std_specs.option.impl&__1.eq_spec.?_definition
))))

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (and
     (sized T&.)
     (tr_bound%core!cmp.PartialEq. T&. T& T&. T&)
    )
    (tr_bound%core!cmp.PartialEq. $ (TYPE%core!option.Option. T&. T&) $ (TYPE%core!option.Option.
      T&. T&
   )))
   :pattern ((tr_bound%core!cmp.PartialEq. $ (TYPE%core!option.Option. T&. T&) $ (TYPE%core!option.Option.
      T&. T&
   )))
   :qid internal_core__option__impl&__17_trait_impl_definition
   :skolemid skolem_internal_core__option__impl&__17_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (and
     (sized T&.)
     (tr_bound%vstd!std_specs.cmp.PartialEqSpec. T&. T& T&. T&)
    )
    (tr_bound%vstd!std_specs.cmp.PartialEqSpec. $ (TYPE%core!option.Option. T&. T&) $
     (TYPE%core!option.Option. T&. T&)
   ))
   :pattern ((tr_bound%vstd!std_specs.cmp.PartialEqSpec. $ (TYPE%core!option.Option. T&.
      T&
     ) $ (TYPE%core!option.Option. T&. T&)
   ))
   :qid internal_vstd__std_specs__option__impl&__1_trait_impl_definition
   :skolemid skolem_internal_vstd__std_specs__option__impl&__1_trait_impl_definition
)))

;; Function-Axioms vstd::view::impl&%14::view
(assert
 (fuel_bool_default fuel%vstd!view.impl&%14.view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%14.view.)
  (forall ((T&. Dcr) (T& Type) (self! Poly)) (!
    (=>
     (sized T&.)
     (= (vstd!view.View.view.? $ (TYPE%core!option.Option. T&. T&) self!) self!)
    )
    :pattern ((vstd!view.View.view.? $ (TYPE%core!option.Option. T&. T&) self!))
    :qid internal_vstd!view.impl&__14.view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__14.view.?_definition
))))

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (sized T&.)
    (tr_bound%vstd!view.View. $ (TYPE%core!option.Option. T&. T&))
   )
   :pattern ((tr_bound%vstd!view.View. $ (TYPE%core!option.Option. T&. T&)))
   :qid internal_vstd__view__impl&__14_trait_impl_definition
   :skolemid skolem_internal_vstd__view__impl&__14_trait_impl_definition
)))

;; Function-Axioms vstd::view::impl&%15::deep_view
(assert
 (fuel_bool_default fuel%vstd!view.impl&%15.deep_view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%15.deep_view.)
  (forall ((T&. Dcr) (T& Type) (self! Poly)) (!
    (=>
     (and
      (sized T&.)
      (tr_bound%vstd!view.DeepView. T&. T&)
     )
     (= (vstd!view.DeepView.deep_view.? $ (TYPE%core!option.Option. T&. T&) self!) (Poly%core!option.Option.
       (ite
        (is-core!option.Option./Some (%Poly%core!option.Option. self!))
        (let
         ((t$ (core!option.Option./Some/0 T&. T& (%Poly%core!option.Option. self!))))
         (core!option.Option./Some (vstd!view.DeepView.deep_view.? T&. T& t$))
        )
        core!option.Option./None
    ))))
    :pattern ((vstd!view.DeepView.deep_view.? $ (TYPE%core!option.Option. T&. T&) self!))
    :qid internal_vstd!view.impl&__15.deep_view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__15.deep_view.?_definition
))))

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (and
     (sized T&.)
     (tr_bound%vstd!view.DeepView. T&. T&)
    )
    (tr_bound%vstd!view.DeepView. $ (TYPE%core!option.Option. T&. T&))
   )
   :pattern ((tr_bound%vstd!view.DeepView. $ (TYPE%core!option.Option. T&. T&)))
   :qid internal_vstd__view__impl&__15_trait_impl_definition
   :skolemid skolem_internal_vstd__view__impl&__15_trait_impl_definition
)))

;; Function-Axioms vstd::slice::spec_slice_len
(assert
 (forall ((T&. Dcr) (T& Type) (slice! Poly)) (!
   (=>
    (has_type slice! (SLICE T&. T&))
    (uInv SZ (vstd!slice.spec_slice_len.? T&. T& slice!))
   )
   :pattern ((vstd!slice.spec_slice_len.? T&. T& slice!))
   :qid internal_vstd!slice.spec_slice_len.?_pre_post_definition
   :skolemid skolem_internal_vstd!slice.spec_slice_len.?_pre_post_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (sized T&.)
    (tr_bound%vstd!view.View. $slice (SLICE T&. T&))
   )
   :pattern ((tr_bound%vstd!view.View. $slice (SLICE T&. T&)))
   :qid internal_vstd__slice__impl&__0_trait_impl_definition
   :skolemid skolem_internal_vstd__slice__impl&__0_trait_impl_definition
)))

;; Broadcast vstd::slice::axiom_spec_len
(assert
 (=>
  (fuel_bool fuel%vstd!slice.axiom_spec_len.)
  (forall ((T&. Dcr) (T& Type) (slice! Poly)) (!
    (=>
     (has_type slice! (SLICE T&. T&))
     (=>
      (sized T&.)
      (= (vstd!slice.spec_slice_len.? T&. T& slice!) (vstd!seq.Seq.len.? T&. T& (vstd!view.View.view.?
         $slice (SLICE T&. T&) slice!
    )))))
    :pattern ((vstd!slice.spec_slice_len.? T&. T& slice!))
    :qid user_vstd__slice__axiom_spec_len_0
    :skolemid skolem_user_vstd__slice__axiom_spec_len_0
))))

;; Function-Axioms vstd::slice::len%returns_clause_autospec
(assert
 (fuel_bool_default fuel%vstd!slice.len%returns_clause_autospec.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!slice.len%returns_clause_autospec.)
  (forall ((T&. Dcr) (T& Type) (slice! Poly)) (!
    (= (vstd!slice.len%returns_clause_autospec.? T&. T& slice!) (vstd!slice.spec_slice_len.?
      T&. T& slice!
    ))
    :pattern ((vstd!slice.len%returns_clause_autospec.? T&. T& slice!))
    :qid internal_vstd!slice.len__returns_clause_autospec.?_definition
    :skolemid skolem_internal_vstd!slice.len__returns_clause_autospec.?_definition
))))
(assert
 (forall ((T&. Dcr) (T& Type) (slice! Poly)) (!
   (=>
    (has_type slice! (SLICE T&. T&))
    (uInv SZ (vstd!slice.len%returns_clause_autospec.? T&. T& slice!))
   )
   :pattern ((vstd!slice.len%returns_clause_autospec.? T&. T& slice!))
   :qid internal_vstd!slice.len__returns_clause_autospec.?_pre_post_definition
   :skolemid skolem_internal_vstd!slice.len__returns_clause_autospec.?_pre_post_definition
)))

;; Function-Specs vstd::slice::SliceAdditionalSpecFns::spec_index
(declare-fun req%vstd!slice.SliceAdditionalSpecFns.spec_index. (Dcr Type Dcr Type Poly
  Poly
 ) Bool
)
(declare-const %%global_location_label%%4 Bool)
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (T&. Dcr) (T& Type) (self! Poly) (i! Poly)) (
   !
   (= (req%vstd!slice.SliceAdditionalSpecFns.spec_index. Self%&. Self%& T&. T& self! i!)
    (=>
     %%global_location_label%%4
     (let
      ((tmp%%$ 0))
      (let
       ((tmp%%$1 (%I i!)))
       (let
        ((tmp%%$2 (vstd!seq.Seq.len.? T&. T& (vstd!view.View.view.? Self%&. Self%& self!))))
        (and
         (<= tmp%%$ tmp%%$1)
         (< tmp%%$1 tmp%%$2)
   ))))))
   :pattern ((req%vstd!slice.SliceAdditionalSpecFns.spec_index. Self%&. Self%& T&. T&
     self! i!
   ))
   :qid internal_req__vstd!slice.SliceAdditionalSpecFns.spec_index._definition
   :skolemid skolem_internal_req__vstd!slice.SliceAdditionalSpecFns.spec_index._definition
)))

;; Function-Axioms vstd::slice::SliceAdditionalSpecFns::spec_index
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (T&. Dcr) (T& Type) (self! Poly) (i! Poly)) (
   !
   (=>
    (and
     (has_type self! Self%&)
     (has_type i! INT)
    )
    (has_type (vstd!slice.SliceAdditionalSpecFns.spec_index.? Self%&. Self%& T&. T& self!
      i!
     ) T&
   ))
   :pattern ((vstd!slice.SliceAdditionalSpecFns.spec_index.? Self%&. Self%& T&. T& self!
     i!
   ))
   :qid internal_vstd!slice.SliceAdditionalSpecFns.spec_index.?_pre_post_definition
   :skolemid skolem_internal_vstd!slice.SliceAdditionalSpecFns.spec_index.?_pre_post_definition
)))

;; Function-Axioms vstd::slice::impl&%2::spec_index
(assert
 (fuel_bool_default fuel%vstd!slice.impl&%2.spec_index.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!slice.impl&%2.spec_index.)
  (forall ((T&. Dcr) (T& Type) (self! Poly) (i! Poly)) (!
    (=>
     (sized T&.)
     (= (vstd!slice.SliceAdditionalSpecFns.spec_index.? $slice (SLICE T&. T&) T&. T& self!
       i!
      ) (vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $slice (SLICE T&. T&) self!)
       i!
    )))
    :pattern ((vstd!slice.SliceAdditionalSpecFns.spec_index.? $slice (SLICE T&. T&) T&.
      T& self! i!
    ))
    :qid internal_vstd!slice.impl&__2.spec_index.?_definition
    :skolemid skolem_internal_vstd!slice.impl&__2.spec_index.?_definition
))))

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (sized T&.)
    (tr_bound%vstd!slice.SliceAdditionalSpecFns. $slice (SLICE T&. T&) T&. T&)
   )
   :pattern ((tr_bound%vstd!slice.SliceAdditionalSpecFns. $slice (SLICE T&. T&) T&. T&))
   :qid internal_vstd__slice__impl&__2_trait_impl_definition
   :skolemid skolem_internal_vstd__slice__impl&__2_trait_impl_definition
)))

;; Broadcast vstd::slice::axiom_slice_ext_equal
(assert
 (=>
  (fuel_bool fuel%vstd!slice.axiom_slice_ext_equal.)
  (forall ((T&. Dcr) (T& Type) (a1! Poly) (a2! Poly)) (!
    (=>
     (and
      (has_type a1! (SLICE T&. T&))
      (has_type a2! (SLICE T&. T&))
     )
     (=>
      (sized T&.)
      (= (ext_eq false (SLICE T&. T&) a1! a2!) (and
        (= (vstd!slice.len%returns_clause_autospec.? T&. T& a1!) (vstd!slice.len%returns_clause_autospec.?
          T&. T& a2!
        ))
        (forall ((i$ Poly)) (!
          (=>
           (has_type i$ INT)
           (=>
            (let
             ((tmp%%$ 0))
             (let
              ((tmp%%$1 (%I i$)))
              (let
               ((tmp%%$2 (vstd!slice.len%returns_clause_autospec.? T&. T& a1!)))
               (and
                (<= tmp%%$ tmp%%$1)
                (< tmp%%$1 tmp%%$2)
            ))))
            (= (vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $slice (SLICE T&. T&) a1!) i$)
             (vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $slice (SLICE T&. T&) a2!) i$)
          )))
          :pattern ((vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $slice (SLICE T&. T&)
             a1!
            ) i$
          ))
          :pattern ((vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $slice (SLICE T&. T&)
             a2!
            ) i$
          ))
          :qid user_vstd__slice__axiom_slice_ext_equal_0
          :skolemid skolem_user_vstd__slice__axiom_slice_ext_equal_0
    ))))))
    :pattern ((ext_eq false (SLICE T&. T&) a1! a2!))
    :qid user_vstd__slice__axiom_slice_ext_equal_1
    :skolemid skolem_user_vstd__slice__axiom_slice_ext_equal_1
))))

;; Broadcast vstd::slice::axiom_slice_has_resolved
(assert
 (=>
  (fuel_bool fuel%vstd!slice.axiom_slice_has_resolved.)
  (forall ((T&. Dcr) (T& Type) (slice! Poly) (i! Poly)) (!
    (=>
     (and
      (has_type slice! (SLICE T&. T&))
      (has_type i! INT)
     )
     (=>
      (sized T&.)
      (=>
       (let
        ((tmp%%$ 0))
        (let
         ((tmp%%$1 (%I i!)))
         (let
          ((tmp%%$2 (vstd!slice.spec_slice_len.? T&. T& slice!)))
          (and
           (<= tmp%%$ tmp%%$1)
           (< tmp%%$1 tmp%%$2)
       ))))
       (=>
        (has_resolved $slice (SLICE T&. T&) slice!)
        (has_resolved T&. T& (vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $slice (SLICE
            T&. T&
           ) slice!
          ) i!
    ))))))
    :pattern ((has_resolved $slice (SLICE T&. T&) slice!) (vstd!seq.Seq.index.? T&. T&
      (vstd!view.View.view.? $slice (SLICE T&. T&) slice!) i!
    ))
    :qid user_vstd__slice__axiom_slice_has_resolved_0
    :skolemid skolem_user_vstd__slice__axiom_slice_has_resolved_0
))))

;; Broadcast vstd::slice::axiom_slice_decreases_to_seq
(assert
 (=>
  (fuel_bool fuel%vstd!slice.axiom_slice_decreases_to_seq.)
  (forall ((T&. Dcr) (T& Type) (s! Poly)) (!
    (=>
     (has_type s! (SLICE T&. T&))
     (=>
      (sized T&.)
      (height_lt (height (vstd!view.View.view.? $slice (SLICE T&. T&) s!)) (height s!))
    ))
    :pattern ((height (vstd!view.View.view.? $slice (SLICE T&. T&) s!)))
    :qid user_vstd__slice__axiom_slice_decreases_to_seq_0
    :skolemid skolem_user_vstd__slice__axiom_slice_decreases_to_seq_0
))))

;; Broadcast vstd::slice::lemma_slice_index_decreases
(assert
 (=>
  (fuel_bool fuel%vstd!slice.lemma_slice_index_decreases.)
  (forall ((T&. Dcr) (T& Type) (s! Poly) (i! Poly)) (!
    (=>
     (and
      (has_type s! (SLICE T&. T&))
      (has_type i! INT)
     )
     (=>
      (and
       (sized T&.)
       (let
        ((tmp%%$ 0))
        (let
         ((tmp%%$1 (%I i!)))
         (let
          ((tmp%%$2 (vstd!seq.Seq.len.? T&. T& (vstd!view.View.view.? $slice (SLICE T&. T&) s!))))
          (and
           (<= tmp%%$ tmp%%$1)
           (< tmp%%$1 tmp%%$2)
      )))))
      (height_lt (height (vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $slice (SLICE T&.
           T&
          ) s!
         ) i!
        )
       ) (height s!)
    )))
    :pattern ((height (vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $slice (SLICE T&.
         T&
        ) s!
       ) i!
    )))
    :qid user_vstd__slice__lemma_slice_index_decreases_0
    :skolemid skolem_user_vstd__slice__lemma_slice_index_decreases_0
))))

;; Function-Axioms vstd::array::array_view
(assert
 (fuel_bool_default fuel%vstd!array.array_view.)
)
(declare-fun %%lambda%%0 (Dcr Type Dcr Type %%Function%%) %%Function%%)
(assert
 (forall ((%%hole%%0 Dcr) (%%hole%%1 Type) (%%hole%%2 Dcr) (%%hole%%3 Type) (%%hole%%4
    %%Function%%
   ) (i$ Poly)
  ) (!
   (= (%%apply%%0 (%%lambda%%0 %%hole%%0 %%hole%%1 %%hole%%2 %%hole%%3 %%hole%%4) i$)
    (array_index %%hole%%0 %%hole%%1 %%hole%%2 %%hole%%3 %%hole%%4 i$)
   )
   :pattern ((%%apply%%0 (%%lambda%%0 %%hole%%0 %%hole%%1 %%hole%%2 %%hole%%3 %%hole%%4)
     i$
)))))
(assert
 (=>
  (fuel_bool fuel%vstd!array.array_view.)
  (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type) (a! Poly)) (!
    (= (vstd!array.array_view.? T&. T& N&. N& a!) (vstd!seq.Seq.new.? T&. T& (I (const_int
        N&
       )
      ) (Poly%fun%1. (mk_fun (%%lambda%%0 T&. T& N&. N& (%Poly%array%. a!))))
    ))
    :pattern ((vstd!array.array_view.? T&. T& N&. N& a!))
    :qid internal_vstd!array.array_view.?_definition
    :skolemid skolem_internal_vstd!array.array_view.?_definition
))))
(assert
 (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type) (a! Poly)) (!
   (=>
    (has_type a! (ARRAY T&. T& N&. N&))
    (has_type (vstd!array.array_view.? T&. T& N&. N& a!) (TYPE%vstd!seq.Seq. T&. T&))
   )
   :pattern ((vstd!array.array_view.? T&. T& N&. N& a!))
   :qid internal_vstd!array.array_view.?_pre_post_definition
   :skolemid skolem_internal_vstd!array.array_view.?_pre_post_definition
)))

;; Function-Axioms vstd::array::impl&%0::view
(assert
 (fuel_bool_default fuel%vstd!array.impl&%0.view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!array.impl&%0.view.)
  (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type) (self! Poly)) (!
    (=>
     (and
      (sized T&.)
      (uInv SZ (const_int N&))
     )
     (= (vstd!view.View.view.? $ (ARRAY T&. T& N&. N&) self!) (vstd!array.array_view.? T&.
       T& N&. N& self!
    )))
    :pattern ((vstd!view.View.view.? $ (ARRAY T&. T& N&. N&) self!))
    :qid internal_vstd!array.impl&__0.view.?_definition
    :skolemid skolem_internal_vstd!array.impl&__0.view.?_definition
))))

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type)) (!
   (=>
    (and
     (sized T&.)
     (uInv SZ (const_int N&))
    )
    (tr_bound%vstd!view.View. $ (ARRAY T&. T& N&. N&))
   )
   :pattern ((tr_bound%vstd!view.View. $ (ARRAY T&. T& N&. N&)))
   :qid internal_vstd__array__impl&__0_trait_impl_definition
   :skolemid skolem_internal_vstd__array__impl&__0_trait_impl_definition
)))

;; Broadcast vstd::array::array_len_matches_n
(assert
 (=>
  (fuel_bool fuel%vstd!array.array_len_matches_n.)
  (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type) (ar! Poly)) (!
    (=>
     (has_type ar! (ARRAY T&. T& N&. N&))
     (=>
      (and
       (sized T&.)
       (uInv SZ (const_int N&))
      )
      (= (vstd!seq.Seq.len.? T&. T& (vstd!view.View.view.? $ (ARRAY T&. T& N&. N&) ar!))
       (const_int N&)
    )))
    :pattern ((vstd!seq.Seq.len.? T&. T& (vstd!view.View.view.? $ (ARRAY T&. T& N&. N&)
       ar!
    )))
    :qid user_vstd__array__array_len_matches_n_0
    :skolemid skolem_user_vstd__array__array_len_matches_n_0
))))

;; Function-Specs vstd::array::ArrayAdditionalSpecFns::spec_index
(declare-fun req%vstd!array.ArrayAdditionalSpecFns.spec_index. (Dcr Type Dcr Type Poly
  Poly
 ) Bool
)
(declare-const %%global_location_label%%5 Bool)
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (T&. Dcr) (T& Type) (self! Poly) (i! Poly)) (
   !
   (= (req%vstd!array.ArrayAdditionalSpecFns.spec_index. Self%&. Self%& T&. T& self! i!)
    (=>
     %%global_location_label%%5
     (let
      ((tmp%%$ 0))
      (let
       ((tmp%%$1 (%I i!)))
       (let
        ((tmp%%$2 (vstd!seq.Seq.len.? T&. T& (vstd!view.View.view.? Self%&. Self%& self!))))
        (and
         (<= tmp%%$ tmp%%$1)
         (< tmp%%$1 tmp%%$2)
   ))))))
   :pattern ((req%vstd!array.ArrayAdditionalSpecFns.spec_index. Self%&. Self%& T&. T&
     self! i!
   ))
   :qid internal_req__vstd!array.ArrayAdditionalSpecFns.spec_index._definition
   :skolemid skolem_internal_req__vstd!array.ArrayAdditionalSpecFns.spec_index._definition
)))

;; Function-Axioms vstd::array::ArrayAdditionalSpecFns::spec_index
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (T&. Dcr) (T& Type) (self! Poly) (i! Poly)) (
   !
   (=>
    (and
     (has_type self! Self%&)
     (has_type i! INT)
    )
    (has_type (vstd!array.ArrayAdditionalSpecFns.spec_index.? Self%&. Self%& T&. T& self!
      i!
     ) T&
   ))
   :pattern ((vstd!array.ArrayAdditionalSpecFns.spec_index.? Self%&. Self%& T&. T& self!
     i!
   ))
   :qid internal_vstd!array.ArrayAdditionalSpecFns.spec_index.?_pre_post_definition
   :skolemid skolem_internal_vstd!array.ArrayAdditionalSpecFns.spec_index.?_pre_post_definition
)))

;; Function-Axioms vstd::array::impl&%2::spec_index
(assert
 (fuel_bool_default fuel%vstd!array.impl&%2.spec_index.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!array.impl&%2.spec_index.)
  (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type) (self! Poly) (i! Poly)) (!
    (=>
     (and
      (sized T&.)
      (uInv SZ (const_int N&))
     )
     (= (vstd!array.ArrayAdditionalSpecFns.spec_index.? $ (ARRAY T&. T& N&. N&) T&. T& self!
       i!
      ) (vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (ARRAY T&. T& N&. N&) self!)
       i!
    )))
    :pattern ((vstd!array.ArrayAdditionalSpecFns.spec_index.? $ (ARRAY T&. T& N&. N&) T&.
      T& self! i!
    ))
    :qid internal_vstd!array.impl&__2.spec_index.?_definition
    :skolemid skolem_internal_vstd!array.impl&__2.spec_index.?_definition
))))

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type)) (!
   (=>
    (and
     (sized T&.)
     (uInv SZ (const_int N&))
    )
    (tr_bound%vstd!array.ArrayAdditionalSpecFns. $ (ARRAY T&. T& N&. N&) T&. T&)
   )
   :pattern ((tr_bound%vstd!array.ArrayAdditionalSpecFns. $ (ARRAY T&. T& N&. N&) T&.
     T&
   ))
   :qid internal_vstd__array__impl&__2_trait_impl_definition
   :skolemid skolem_internal_vstd__array__impl&__2_trait_impl_definition
)))

;; Broadcast vstd::array::lemma_array_index
(assert
 (=>
  (fuel_bool fuel%vstd!array.lemma_array_index.)
  (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type) (a! Poly) (i! Poly)) (!
    (=>
     (and
      (has_type a! (ARRAY T&. T& N&. N&))
      (has_type i! INT)
     )
     (=>
      (and
       (and
        (sized T&.)
        (uInv SZ (const_int N&))
       )
       (let
        ((tmp%%$ 0))
        (let
         ((tmp%%$1 (%I i!)))
         (let
          ((tmp%%$2 (const_int N&)))
          (and
           (<= tmp%%$ tmp%%$1)
           (< tmp%%$1 tmp%%$2)
      )))))
      (= (vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (ARRAY T&. T& N&. N&) a!)
        i!
       ) (vstd!seq.Seq.index.? T&. T& (vstd!array.array_view.? T&. T& N&. N& a!) i!)
    )))
    :pattern ((array_index T&. T& N&. N& (%Poly%array%. a!) i!))
    :qid user_vstd__array__lemma_array_index_0
    :skolemid skolem_user_vstd__array__lemma_array_index_0
))))

;; Broadcast vstd::array::axiom_array_ext_equal
(assert
 (=>
  (fuel_bool fuel%vstd!array.axiom_array_ext_equal.)
  (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type) (a1! Poly) (a2! Poly)) (!
    (=>
     (and
      (has_type a1! (ARRAY T&. T& N&. N&))
      (has_type a2! (ARRAY T&. T& N&. N&))
     )
     (=>
      (and
       (sized T&.)
       (uInv SZ (const_int N&))
      )
      (= (ext_eq false (ARRAY T&. T& N&. N&) a1! a2!) (forall ((i$ Poly)) (!
         (=>
          (has_type i$ INT)
          (=>
           (let
            ((tmp%%$ 0))
            (let
             ((tmp%%$1 (%I i$)))
             (let
              ((tmp%%$2 (const_int N&)))
              (and
               (<= tmp%%$ tmp%%$1)
               (< tmp%%$1 tmp%%$2)
           ))))
           (= (vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (ARRAY T&. T& N&. N&) a1!)
             i$
            ) (vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (ARRAY T&. T& N&. N&) a2!)
             i$
         ))))
         :pattern ((vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (ARRAY T&. T& N&. N&)
            a1!
           ) i$
         ))
         :pattern ((vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (ARRAY T&. T& N&. N&)
            a2!
           ) i$
         ))
         :qid user_vstd__array__axiom_array_ext_equal_0
         :skolemid skolem_user_vstd__array__axiom_array_ext_equal_0
    )))))
    :pattern ((ext_eq false (ARRAY T&. T& N&. N&) a1! a2!))
    :qid user_vstd__array__axiom_array_ext_equal_1
    :skolemid skolem_user_vstd__array__axiom_array_ext_equal_1
))))

;; Broadcast vstd::array::axiom_array_has_resolved
(assert
 (=>
  (fuel_bool fuel%vstd!array.axiom_array_has_resolved.)
  (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type) (array! Poly) (i! Poly)) (!
    (=>
     (and
      (has_type array! (ARRAY T&. T& N&. N&))
      (has_type i! INT)
     )
     (=>
      (and
       (sized T&.)
       (uInv SZ (const_int N&))
      )
      (=>
       (let
        ((tmp%%$ 0))
        (let
         ((tmp%%$1 (%I i!)))
         (let
          ((tmp%%$2 (const_int N&)))
          (and
           (<= tmp%%$ tmp%%$1)
           (< tmp%%$1 tmp%%$2)
       ))))
       (=>
        (has_resolved $ (ARRAY T&. T& N&. N&) array!)
        (has_resolved T&. T& (vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (ARRAY T&.
            T& N&. N&
           ) array!
          ) i!
    ))))))
    :pattern ((has_resolved $ (ARRAY T&. T& N&. N&) array!) (vstd!seq.Seq.index.? T&. T&
      (vstd!view.View.view.? $ (ARRAY T&. T& N&. N&) array!) i!
    ))
    :qid user_vstd__array__axiom_array_has_resolved_0
    :skolemid skolem_user_vstd__array__axiom_array_has_resolved_0
))))

;; Broadcast vstd::array::axiom_array_decreases_to_seq
(assert
 (=>
  (fuel_bool fuel%vstd!array.axiom_array_decreases_to_seq.)
  (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type) (a! Poly)) (!
    (=>
     (has_type a! (ARRAY T&. T& N&. N&))
     (=>
      (and
       (sized T&.)
       (uInv SZ (const_int N&))
      )
      (height_lt (height (vstd!view.View.view.? $ (ARRAY T&. T& N&. N&) a!)) (height a!))
    ))
    :pattern ((height (vstd!view.View.view.? $ (ARRAY T&. T& N&. N&) a!)))
    :qid user_vstd__array__axiom_array_decreases_to_seq_0
    :skolemid skolem_user_vstd__array__axiom_array_decreases_to_seq_0
))))

;; Broadcast vstd::array::lemma_array_index_decreases
(assert
 (=>
  (fuel_bool fuel%vstd!array.lemma_array_index_decreases.)
  (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type) (a! Poly) (i! Poly)) (!
    (=>
     (and
      (has_type a! (ARRAY T&. T& N&. N&))
      (has_type i! INT)
     )
     (=>
      (and
       (and
        (sized T&.)
        (uInv SZ (const_int N&))
       )
       (let
        ((tmp%%$ 0))
        (let
         ((tmp%%$1 (%I i!)))
         (let
          ((tmp%%$2 (vstd!seq.Seq.len.? T&. T& (vstd!view.View.view.? $ (ARRAY T&. T& N&. N&) a!))))
          (and
           (<= tmp%%$ tmp%%$1)
           (< tmp%%$1 tmp%%$2)
      )))))
      (height_lt (height (vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (ARRAY T&. T&
           N&. N&
          ) a!
         ) i!
        )
       ) (height a!)
    )))
    :pattern ((height (vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (ARRAY T&. T&
         N&. N&
        ) a!
       ) i!
    )))
    :qid user_vstd__array__lemma_array_index_decreases_0
    :skolemid skolem_user_vstd__array__lemma_array_index_decreases_0
))))

;; Function-Axioms vstd::raw_ptr::view_reverse_for_eq
(assert
 (forall ((T&. Dcr) (T& Type) (data! Poly)) (!
   (=>
    (has_type data! (TYPE%vstd!raw_ptr.PtrData. T&. T&))
    (has_type (vstd!raw_ptr.view_reverse_for_eq.? T&. T& data!) (PTR T&. T&))
   )
   :pattern ((vstd!raw_ptr.view_reverse_for_eq.? T&. T& data!))
   :qid internal_vstd!raw_ptr.view_reverse_for_eq.?_pre_post_definition
   :skolemid skolem_internal_vstd!raw_ptr.view_reverse_for_eq.?_pre_post_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (tr_bound%vstd!view.View. $ (PTR T&. T&))
   :pattern ((tr_bound%vstd!view.View. $ (PTR T&. T&)))
   :qid internal_vstd__raw_ptr__impl&__2_trait_impl_definition
   :skolemid skolem_internal_vstd__raw_ptr__impl&__2_trait_impl_definition
)))

;; Broadcast vstd::raw_ptr::ptrs_mut_eq
(assert
 (=>
  (fuel_bool fuel%vstd!raw_ptr.ptrs_mut_eq.)
  (forall ((T&. Dcr) (T& Type) (a! Poly)) (!
    (=>
     (has_type a! (PTR T&. T&))
     (= (vstd!raw_ptr.view_reverse_for_eq.? T&. T& (vstd!view.View.view.? $ (PTR T&. T&)
        a!
       )
      ) a!
    ))
    :pattern ((vstd!view.View.view.? $ (PTR T&. T&) a!))
    :qid user_vstd__raw_ptr__ptrs_mut_eq_0
    :skolemid skolem_user_vstd__raw_ptr__ptrs_mut_eq_0
))))

;; Function-Axioms vstd::raw_ptr::view_reverse_for_eq_sized
(assert
 (forall ((T&. Dcr) (T& Type) (addr! Poly) (provenance! Poly)) (!
   (=>
    (and
     (has_type addr! USIZE)
     (has_type provenance! TYPE%vstd!raw_ptr.Provenance.)
    )
    (has_type (vstd!raw_ptr.view_reverse_for_eq_sized.? T&. T& addr! provenance!) (PTR
      T&. T&
   )))
   :pattern ((vstd!raw_ptr.view_reverse_for_eq_sized.? T&. T& addr! provenance!))
   :qid internal_vstd!raw_ptr.view_reverse_for_eq_sized.?_pre_post_definition
   :skolemid skolem_internal_vstd!raw_ptr.view_reverse_for_eq_sized.?_pre_post_definition
)))

;; Broadcast vstd::raw_ptr::ptrs_mut_eq_sized
(assert
 (=>
  (fuel_bool fuel%vstd!raw_ptr.ptrs_mut_eq_sized.)
  (forall ((T&. Dcr) (T& Type) (a! Poly)) (!
    (=>
     (has_type a! (PTR T&. T&))
     (=>
      (sized T&.)
      (= (vstd!raw_ptr.view_reverse_for_eq_sized.? T&. T& (I (vstd!raw_ptr.PtrData./PtrData/addr
          (%Poly%vstd!raw_ptr.PtrData. (vstd!view.View.view.? $ (PTR T&. T&) a!))
         )
        ) (Poly%vstd!raw_ptr.Provenance. (vstd!raw_ptr.PtrData./PtrData/provenance (%Poly%vstd!raw_ptr.PtrData.
           (vstd!view.View.view.? $ (PTR T&. T&) a!)
        )))
       ) a!
    )))
    :pattern ((vstd!view.View.view.? $ (PTR T&. T&) a!))
    :qid user_vstd__raw_ptr__ptrs_mut_eq_sized_0
    :skolemid skolem_user_vstd__raw_ptr__ptrs_mut_eq_sized_0
))))

;; Function-Specs core::clone::Clone::clone
(declare-fun ens%core!clone.Clone.clone. (Dcr Type Poly Poly) Bool)
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (self! Poly) (%return! Poly)) (!
   (= (ens%core!clone.Clone.clone. Self%&. Self%& self! %return!) (has_type %return! Self%&))
   :pattern ((ens%core!clone.Clone.clone. Self%&. Self%& self! %return!))
   :qid internal_ens__core!clone.Clone.clone._definition
   :skolemid skolem_internal_ens__core!clone.Clone.clone._definition
)))
(assert
 (forall ((closure%$ Poly) (Self%&. Dcr) (Self%& Type)) (!
   (=>
    (has_type closure%$ (TYPE%tuple%1. (REF Self%&.) Self%&))
    (=>
     (let
      ((self$ (tuple%1./tuple%1/0 (%Poly%tuple%1. closure%$))))
      true
     )
     (closure_req (FNDEF%core!clone.Clone.clone. Self%&. Self%&) (DST (REF Self%&.)) (TYPE%tuple%1.
       (REF Self%&.) Self%&
      ) (F fndef_singleton) closure%$
   )))
   :pattern ((closure_req (FNDEF%core!clone.Clone.clone. Self%&. Self%&) (DST (REF Self%&.))
     (TYPE%tuple%1. (REF Self%&.) Self%&) (F fndef_singleton) closure%$
   ))
   :qid user_core__clone__Clone__clone_0
   :skolemid skolem_user_core__clone__Clone__clone_0
)))

;; Function-Specs core::clone::impls::impl&%10::clone
(declare-fun ens%core!clone.impls.impl&%10.clone. (Poly Poly) Bool)
(assert
 (forall ((x! Poly) (res! Poly)) (!
   (= (ens%core!clone.impls.impl&%10.clone. x! res!) (and
     (ens%core!clone.Clone.clone. $ USIZE x! res!)
     (= res! x!)
   ))
   :pattern ((ens%core!clone.impls.impl&%10.clone. x! res!))
   :qid internal_ens__core!clone.impls.impl&__10.clone._definition
   :skolemid skolem_internal_ens__core!clone.impls.impl&__10.clone._definition
)))
(assert
 (forall ((closure%$ Poly) (res$ Poly)) (!
   (=>
    (and
     (has_type closure%$ (TYPE%tuple%1. (REF $) USIZE))
     (has_type res$ USIZE)
    )
    (=>
     (closure_ens (FNDEF%core!clone.Clone.clone. $ USIZE) (DST (REF $)) (TYPE%tuple%1. (
        REF $
       ) USIZE
      ) (F fndef_singleton) closure%$ res$
     )
     (let
      ((x$ (%I (tuple%1./tuple%1/0 (%Poly%tuple%1. closure%$)))))
      (= (%I res$) x$)
   )))
   :pattern ((closure_ens (FNDEF%core!clone.Clone.clone. $ USIZE) (DST (REF $)) (TYPE%tuple%1.
      (REF $) USIZE
     ) (F fndef_singleton) closure%$ res$
   ))
   :qid user_core__clone__impls__impl&%10__clone_0
   :skolemid skolem_user_core__clone__impls__impl&%10__clone_0
)))

;; Trait-Impl-Axiom
(assert
 (tr_bound%core!clone.Clone. $ USIZE)
)

;; Function-Axioms vstd::std_specs::vec::spec_vec_len
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type) (v! Poly)) (!
   (=>
    (has_type v! (TYPE%alloc!vec.Vec. T&. T& A&. A&))
    (uInv SZ (vstd!std_specs.vec.spec_vec_len.? T&. T& A&. A& v!))
   )
   :pattern ((vstd!std_specs.vec.spec_vec_len.? T&. T& A&. A& v!))
   :qid internal_vstd!std_specs.vec.spec_vec_len.?_pre_post_definition
   :skolemid skolem_internal_vstd!std_specs.vec.spec_vec_len.?_pre_post_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized T&.)
     (sized A&.)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (tr_bound%vstd!view.View. $ (TYPE%alloc!vec.Vec. T&. T& A&. A&))
   )
   :pattern ((tr_bound%vstd!view.View. $ (TYPE%alloc!vec.Vec. T&. T& A&. A&)))
   :qid internal_vstd__view__impl&__8_trait_impl_definition
   :skolemid skolem_internal_vstd__view__impl&__8_trait_impl_definition
)))

;; Broadcast vstd::std_specs::vec::axiom_spec_len
(assert
 (=>
  (fuel_bool fuel%vstd!std_specs.vec.axiom_spec_len.)
  (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type) (v! Poly)) (!
    (=>
     (has_type v! (TYPE%alloc!vec.Vec. T&. T& A&. A&))
     (=>
      (and
       (and
        (sized T&.)
        (sized A&.)
       )
       (tr_bound%core!alloc.Allocator. A&. A&)
      )
      (= (vstd!std_specs.vec.spec_vec_len.? T&. T& A&. A& v!) (vstd!seq.Seq.len.? T&. T&
        (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. T&. T& A&. A&) v!)
    ))))
    :pattern ((vstd!std_specs.vec.spec_vec_len.? T&. T& A&. A& v!))
    :qid user_vstd__std_specs__vec__axiom_spec_len_0
    :skolemid skolem_user_vstd__std_specs__vec__axiom_spec_len_0
))))

;; Trait-Impl-Axiom
(assert
 (tr_bound%core!alloc.Allocator. $ TYPE%alloc!alloc.Global.)
)

;; Function-Specs vstd::std_specs::vec::VecAdditionalSpecFns::spec_index
(declare-fun req%vstd!std_specs.vec.VecAdditionalSpecFns.spec_index. (Dcr Type Dcr
  Type Poly Poly
 ) Bool
)
(declare-const %%global_location_label%%6 Bool)
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (T&. Dcr) (T& Type) (self! Poly) (i! Poly)) (
   !
   (= (req%vstd!std_specs.vec.VecAdditionalSpecFns.spec_index. Self%&. Self%& T&. T& self!
     i!
    ) (=>
     %%global_location_label%%6
     (let
      ((tmp%%$ 0))
      (let
       ((tmp%%$1 (%I i!)))
       (let
        ((tmp%%$2 (vstd!seq.Seq.len.? T&. T& (vstd!view.View.view.? Self%&. Self%& self!))))
        (and
         (<= tmp%%$ tmp%%$1)
         (< tmp%%$1 tmp%%$2)
   ))))))
   :pattern ((req%vstd!std_specs.vec.VecAdditionalSpecFns.spec_index. Self%&. Self%& T&.
     T& self! i!
   ))
   :qid internal_req__vstd!std_specs.vec.VecAdditionalSpecFns.spec_index._definition
   :skolemid skolem_internal_req__vstd!std_specs.vec.VecAdditionalSpecFns.spec_index._definition
)))

;; Function-Axioms vstd::std_specs::vec::VecAdditionalSpecFns::spec_index
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (T&. Dcr) (T& Type) (self! Poly) (i! Poly)) (
   !
   (=>
    (and
     (has_type self! Self%&)
     (has_type i! INT)
    )
    (has_type (vstd!std_specs.vec.VecAdditionalSpecFns.spec_index.? Self%&. Self%& T&.
      T& self! i!
     ) T&
   ))
   :pattern ((vstd!std_specs.vec.VecAdditionalSpecFns.spec_index.? Self%&. Self%& T&.
     T& self! i!
   ))
   :qid internal_vstd!std_specs.vec.VecAdditionalSpecFns.spec_index.?_pre_post_definition
   :skolemid skolem_internal_vstd!std_specs.vec.VecAdditionalSpecFns.spec_index.?_pre_post_definition
)))

;; Function-Axioms vstd::std_specs::vec::impl&%0::spec_index
(assert
 (fuel_bool_default fuel%vstd!std_specs.vec.impl&%0.spec_index.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!std_specs.vec.impl&%0.spec_index.)
  (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type) (self! Poly) (i! Poly)) (!
    (=>
     (and
      (sized T&.)
      (sized A&.)
      (tr_bound%core!alloc.Allocator. A&. A&)
     )
     (= (vstd!std_specs.vec.VecAdditionalSpecFns.spec_index.? $ (TYPE%alloc!vec.Vec. T&.
        T& A&. A&
       ) T&. T& self! i!
      ) (vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. T&. T&
         A&. A&
        ) self!
       ) i!
    )))
    :pattern ((vstd!std_specs.vec.VecAdditionalSpecFns.spec_index.? $ (TYPE%alloc!vec.Vec.
       T&. T& A&. A&
      ) T&. T& self! i!
    ))
    :qid internal_vstd!std_specs.vec.impl&__0.spec_index.?_definition
    :skolemid skolem_internal_vstd!std_specs.vec.impl&__0.spec_index.?_definition
))))

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized T&.)
     (sized A&.)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (tr_bound%vstd!std_specs.vec.VecAdditionalSpecFns. $ (TYPE%alloc!vec.Vec. T&. T& A&.
      A&
     ) T&. T&
   ))
   :pattern ((tr_bound%vstd!std_specs.vec.VecAdditionalSpecFns. $ (TYPE%alloc!vec.Vec.
      T&. T& A&. A&
     ) T&. T&
   ))
   :qid internal_vstd__std_specs__vec__impl&__0_trait_impl_definition
   :skolemid skolem_internal_vstd__std_specs__vec__impl&__0_trait_impl_definition
)))

;; Broadcast vstd::std_specs::vec::axiom_vec_index_decreases
(assert
 (=>
  (fuel_bool fuel%vstd!std_specs.vec.axiom_vec_index_decreases.)
  (forall ((A&. Dcr) (A& Type) (v! Poly) (i! Poly)) (!
    (=>
     (and
      (has_type v! (TYPE%alloc!vec.Vec. A&. A& $ TYPE%alloc!alloc.Global.))
      (has_type i! INT)
     )
     (=>
      (and
       (sized A&.)
       (let
        ((tmp%%$ 0))
        (let
         ((tmp%%$1 (%I i!)))
         (let
          ((tmp%%$2 (vstd!std_specs.vec.spec_vec_len.? A&. A& $ TYPE%alloc!alloc.Global. v!)))
          (and
           (<= tmp%%$ tmp%%$1)
           (< tmp%%$1 tmp%%$2)
      )))))
      (height_lt (height (vstd!seq.Seq.index.? A&. A& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec.
           A&. A& $ TYPE%alloc!alloc.Global.
          ) v!
         ) i!
        )
       ) (height v!)
    )))
    :pattern ((height (vstd!seq.Seq.index.? A&. A& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec.
         A&. A& $ TYPE%alloc!alloc.Global.
        ) v!
       ) i!
    )))
    :qid user_vstd__std_specs__vec__axiom_vec_index_decreases_0
    :skolemid skolem_user_vstd__std_specs__vec__axiom_vec_index_decreases_0
))))

;; Function-Axioms vstd::std_specs::vec::vec_clone_trigger
(assert
 (fuel_bool_default fuel%vstd!std_specs.vec.vec_clone_trigger.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!std_specs.vec.vec_clone_trigger.)
  (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type) (v1! Poly) (v2! Poly)) (!
    (= (vstd!std_specs.vec.vec_clone_trigger.? T&. T& A&. A& v1! v2!) true)
    :pattern ((vstd!std_specs.vec.vec_clone_trigger.? T&. T& A&. A& v1! v2!))
    :qid internal_vstd!std_specs.vec.vec_clone_trigger.?_definition
    :skolemid skolem_internal_vstd!std_specs.vec.vec_clone_trigger.?_definition
))))

;; Function-Axioms vstd::view::impl&%9::deep_view
(assert
 (fuel_bool_default fuel%vstd!view.impl&%9.deep_view.)
)
(declare-fun %%lambda%%1 (Dcr Type Poly Dcr Type) %%Function%%)
(assert
 (forall ((%%hole%%0 Dcr) (%%hole%%1 Type) (%%hole%%2 Poly) (%%hole%%3 Dcr) (%%hole%%4
    Type
   ) (i$ Poly)
  ) (!
   (= (%%apply%%0 (%%lambda%%1 %%hole%%0 %%hole%%1 %%hole%%2 %%hole%%3 %%hole%%4) i$)
    (vstd!view.DeepView.deep_view.? %%hole%%3 %%hole%%4 (vstd!seq.Seq.index.? %%hole%%0
      %%hole%%1 %%hole%%2 i$
   )))
   :pattern ((%%apply%%0 (%%lambda%%1 %%hole%%0 %%hole%%1 %%hole%%2 %%hole%%3 %%hole%%4)
     i$
)))))
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%9.deep_view.)
  (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type) (self! Poly)) (!
    (=>
     (and
      (sized T&.)
      (sized A&.)
      (tr_bound%vstd!view.DeepView. T&. T&)
      (tr_bound%core!alloc.Allocator. A&. A&)
     )
     (= (vstd!view.DeepView.deep_view.? $ (TYPE%alloc!vec.Vec. T&. T& A&. A&) self!) (let
       ((v$ (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. T&. T& A&. A&) self!)))
       (vstd!seq.Seq.new.? (proj%%vstd!view.DeepView./V T&. T&) (proj%vstd!view.DeepView./V
         T&. T&
        ) (I (vstd!seq.Seq.len.? T&. T& v$)) (Poly%fun%1. (mk_fun (%%lambda%%1 T&. T& v$ T&.
           T&
    )))))))
    :pattern ((vstd!view.DeepView.deep_view.? $ (TYPE%alloc!vec.Vec. T&. T& A&. A&) self!))
    :qid internal_vstd!view.impl&__9.deep_view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__9.deep_view.?_definition
))))

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized T&.)
     (sized A&.)
     (tr_bound%vstd!view.DeepView. T&. T&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (tr_bound%vstd!view.DeepView. $ (TYPE%alloc!vec.Vec. T&. T& A&. A&))
   )
   :pattern ((tr_bound%vstd!view.DeepView. $ (TYPE%alloc!vec.Vec. T&. T& A&. A&)))
   :qid internal_vstd__view__impl&__9_trait_impl_definition
   :skolemid skolem_internal_vstd__view__impl&__9_trait_impl_definition
)))

;; Broadcast vstd::std_specs::vec::vec_clone_deep_view_proof
(assert
 (=>
  (fuel_bool fuel%vstd!std_specs.vec.vec_clone_deep_view_proof.)
  (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type) (v1! Poly) (v2! Poly)) (!
    (=>
     (and
      (has_type v1! (TYPE%alloc!vec.Vec. T&. T& A&. A&))
      (has_type v2! (TYPE%alloc!vec.Vec. T&. T& A&. A&))
     )
     (=>
      (and
       (and
        (and
         (and
          (and
           (sized T&.)
           (sized A&.)
          )
          (tr_bound%vstd!view.DeepView. T&. T&)
         )
         (tr_bound%core!alloc.Allocator. A&. A&)
        )
        (vstd!std_specs.vec.vec_clone_trigger.? T&. T& A&. A& v1! v2!)
       )
       (ext_eq false (TYPE%vstd!seq.Seq. (proj%%vstd!view.DeepView./V T&. T&) (proj%vstd!view.DeepView./V
          T&. T&
         )
        ) (vstd!view.DeepView.deep_view.? $ (TYPE%alloc!vec.Vec. T&. T& A&. A&) v1!) (vstd!view.DeepView.deep_view.?
         $ (TYPE%alloc!vec.Vec. T&. T& A&. A&) v2!
      )))
      (= (vstd!view.DeepView.deep_view.? $ (TYPE%alloc!vec.Vec. T&. T& A&. A&) v1!) (vstd!view.DeepView.deep_view.?
        $ (TYPE%alloc!vec.Vec. T&. T& A&. A&) v2!
    ))))
    :pattern ((vstd!std_specs.vec.vec_clone_trigger.? T&. T& A&. A& v1! v2!))
    :qid user_vstd__std_specs__vec__vec_clone_deep_view_proof_0
    :skolemid skolem_user_vstd__std_specs__vec__vec_clone_deep_view_proof_0
))))

;; Broadcast vstd::std_specs::vec::axiom_vec_has_resolved
(assert
 (=>
  (fuel_bool fuel%vstd!std_specs.vec.axiom_vec_has_resolved.)
  (forall ((T&. Dcr) (T& Type) (vec! Poly) (i! Poly)) (!
    (=>
     (and
      (has_type vec! (TYPE%alloc!vec.Vec. T&. T& $ TYPE%alloc!alloc.Global.))
      (has_type i! INT)
     )
     (=>
      (sized T&.)
      (=>
       (let
        ((tmp%%$ 0))
        (let
         ((tmp%%$1 (%I i!)))
         (let
          ((tmp%%$2 (vstd!std_specs.vec.spec_vec_len.? T&. T& $ TYPE%alloc!alloc.Global. vec!)))
          (and
           (<= tmp%%$ tmp%%$1)
           (< tmp%%$1 tmp%%$2)
       ))))
       (=>
        (has_resolved $ (TYPE%alloc!vec.Vec. T&. T& $ TYPE%alloc!alloc.Global.) vec!)
        (has_resolved T&. T& (vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec.
            T&. T& $ TYPE%alloc!alloc.Global.
           ) vec!
          ) i!
    ))))))
    :pattern ((has_resolved $ (TYPE%alloc!vec.Vec. T&. T& $ TYPE%alloc!alloc.Global.) vec!)
     (vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. T&. T& $
        TYPE%alloc!alloc.Global.
       ) vec!
      ) i!
    ))
    :qid user_vstd__std_specs__vec__axiom_vec_has_resolved_0
    :skolemid skolem_user_vstd__std_specs__vec__axiom_vec_has_resolved_0
))))

;; Broadcast vstd::std_specs::vec::axiom_vec_decreases_to_view
(assert
 (=>
  (fuel_bool fuel%vstd!std_specs.vec.axiom_vec_decreases_to_view.)
  (forall ((T&. Dcr) (T& Type) (v! Poly)) (!
    (=>
     (has_type v! (TYPE%alloc!vec.Vec. T&. T& $ TYPE%alloc!alloc.Global.))
     (=>
      (sized T&.)
      (height_lt (height (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. T&. T& $ TYPE%alloc!alloc.Global.)
         v!
        )
       ) (height v!)
    )))
    :pattern ((height (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. T&. T& $ TYPE%alloc!alloc.Global.)
       v!
    )))
    :qid user_vstd__std_specs__vec__axiom_vec_decreases_to_view_0
    :skolemid skolem_user_vstd__std_specs__vec__axiom_vec_decreases_to_view_0
))))

;; Trait-Impl-Axiom
(assert
 (tr_bound%core!marker.Tuple. $ TYPE%tuple%0.)
)

;; Trait-Impl-Axiom
(assert
 (tr_bound%core!clone.Clone. $ TYPE%tuple%0.)
)

;; Trait-Impl-Axiom
(assert
 (tr_bound%core!marker.Copy. $ TYPE%tuple%0.)
)

;; Trait-Impl-Axiom
(assert
 (forall ((T%0&. Dcr) (T%0& Type)) (!
   (tr_bound%core!marker.Tuple. (DST T%0&.) (TYPE%tuple%1. T%0&. T%0&))
   :pattern ((tr_bound%core!marker.Tuple. (DST T%0&.) (TYPE%tuple%1. T%0&. T%0&)))
   :qid internal_crate__impl_tuple&__Tuple1_trait_impl_definition
   :skolemid skolem_internal_crate__impl_tuple&__Tuple1_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((T%0&. Dcr) (T%0& Type)) (!
   (=>
    (tr_bound%core!clone.Clone. T%0&. T%0&)
    (tr_bound%core!clone.Clone. (DST T%0&.) (TYPE%tuple%1. T%0&. T%0&))
   )
   :pattern ((tr_bound%core!clone.Clone. (DST T%0&.) (TYPE%tuple%1. T%0&. T%0&)))
   :qid internal_crate__impl_tuple&__Clone1_trait_impl_definition
   :skolemid skolem_internal_crate__impl_tuple&__Clone1_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((T%0&. Dcr) (T%0& Type)) (!
   (=>
    (tr_bound%core!marker.Copy. T%0&. T%0&)
    (tr_bound%core!marker.Copy. (DST T%0&.) (TYPE%tuple%1. T%0&. T%0&))
   )
   :pattern ((tr_bound%core!marker.Copy. (DST T%0&.) (TYPE%tuple%1. T%0&. T%0&)))
   :qid internal_crate__impl_tuple&__Copy1_trait_impl_definition
   :skolemid skolem_internal_crate__impl_tuple&__Copy1_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type)) (!
   (tr_bound%core!marker.Tuple. (DST T%1&.) (TYPE%tuple%2. T%0&. T%0& T%1&. T%1&))
   :pattern ((tr_bound%core!marker.Tuple. (DST T%1&.) (TYPE%tuple%2. T%0&. T%0& T%1&. T%1&)))
   :qid internal_crate__impl_tuple&__Tuple2_trait_impl_definition
   :skolemid skolem_internal_crate__impl_tuple&__Tuple2_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type)) (!
   (=>
    (and
     (tr_bound%core!clone.Clone. T%0&. T%0&)
     (tr_bound%core!clone.Clone. T%1&. T%1&)
    )
    (tr_bound%core!clone.Clone. (DST T%1&.) (TYPE%tuple%2. T%0&. T%0& T%1&. T%1&))
   )
   :pattern ((tr_bound%core!clone.Clone. (DST T%1&.) (TYPE%tuple%2. T%0&. T%0& T%1&. T%1&)))
   :qid internal_crate__impl_tuple&__Clone2_trait_impl_definition
   :skolemid skolem_internal_crate__impl_tuple&__Clone2_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type)) (!
   (=>
    (and
     (tr_bound%core!marker.Copy. T%0&. T%0&)
     (tr_bound%core!marker.Copy. T%1&. T%1&)
    )
    (tr_bound%core!marker.Copy. (DST T%1&.) (TYPE%tuple%2. T%0&. T%0& T%1&. T%1&))
   )
   :pattern ((tr_bound%core!marker.Copy. (DST T%1&.) (TYPE%tuple%2. T%0&. T%0& T%1&. T%1&)))
   :qid internal_crate__impl_tuple&__Copy2_trait_impl_definition
   :skolemid skolem_internal_crate__impl_tuple&__Copy2_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (T%2&. Dcr) (T%2& Type))
  (!
   (tr_bound%core!marker.Tuple. (DST T%2&.) (TYPE%tuple%3. T%0&. T%0& T%1&. T%1& T%2&.
     T%2&
   ))
   :pattern ((tr_bound%core!marker.Tuple. (DST T%2&.) (TYPE%tuple%3. T%0&. T%0& T%1&. T%1&
      T%2&. T%2&
   )))
   :qid internal_crate__impl_tuple&__Tuple3_trait_impl_definition
   :skolemid skolem_internal_crate__impl_tuple&__Tuple3_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (T%2&. Dcr) (T%2& Type))
  (!
   (=>
    (and
     (tr_bound%core!clone.Clone. T%0&. T%0&)
     (tr_bound%core!clone.Clone. T%1&. T%1&)
     (tr_bound%core!clone.Clone. T%2&. T%2&)
    )
    (tr_bound%core!clone.Clone. (DST T%2&.) (TYPE%tuple%3. T%0&. T%0& T%1&. T%1& T%2&.
      T%2&
   )))
   :pattern ((tr_bound%core!clone.Clone. (DST T%2&.) (TYPE%tuple%3. T%0&. T%0& T%1&. T%1&
      T%2&. T%2&
   )))
   :qid internal_crate__impl_tuple&__Clone3_trait_impl_definition
   :skolemid skolem_internal_crate__impl_tuple&__Clone3_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (T%2&. Dcr) (T%2& Type))
  (!
   (=>
    (and
     (tr_bound%core!marker.Copy. T%0&. T%0&)
     (tr_bound%core!marker.Copy. T%1&. T%1&)
     (tr_bound%core!marker.Copy. T%2&. T%2&)
    )
    (tr_bound%core!marker.Copy. (DST T%2&.) (TYPE%tuple%3. T%0&. T%0& T%1&. T%1& T%2&.
      T%2&
   )))
   :pattern ((tr_bound%core!marker.Copy. (DST T%2&.) (TYPE%tuple%3. T%0&. T%0& T%1&. T%1&
      T%2&. T%2&
   )))
   :qid internal_crate__impl_tuple&__Copy3_trait_impl_definition
   :skolemid skolem_internal_crate__impl_tuple&__Copy3_trait_impl_definition
)))

;; Function-Axioms vstd::std_specs::option::OptionAdditionalFns::arrow_0
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (T&. Dcr) (T& Type) (self! Poly)) (!
   (=>
    (has_type self! Self%&)
    (has_type (vstd!std_specs.option.OptionAdditionalFns.arrow_0.? Self%&. Self%& T&. T&
      self!
     ) T&
   ))
   :pattern ((vstd!std_specs.option.OptionAdditionalFns.arrow_0.? Self%&. Self%& T&. T&
     self!
   ))
   :qid internal_vstd!std_specs.option.OptionAdditionalFns.arrow_0.?_pre_post_definition
   :skolemid skolem_internal_vstd!std_specs.option.OptionAdditionalFns.arrow_0.?_pre_post_definition
)))

;; Function-Axioms vstd::std_specs::option::impl&%0::arrow_0
(assert
 (fuel_bool_default fuel%vstd!std_specs.option.impl&%0.arrow_0.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!std_specs.option.impl&%0.arrow_0.)
  (forall ((T&. Dcr) (T& Type) (self! Poly)) (!
    (=>
     (sized T&.)
     (= (vstd!std_specs.option.OptionAdditionalFns.arrow_0.? $ (TYPE%core!option.Option.
        T&. T&
       ) T&. T& self!
      ) (core!option.Option./Some/0 T&. T& (%Poly%core!option.Option. self!))
    ))
    :pattern ((vstd!std_specs.option.OptionAdditionalFns.arrow_0.? $ (TYPE%core!option.Option.
       T&. T&
      ) T&. T& self!
    ))
    :qid internal_vstd!std_specs.option.impl&__0.arrow_0.?_definition
    :skolemid skolem_internal_vstd!std_specs.option.impl&__0.arrow_0.?_definition
))))

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (sized T&.)
    (tr_bound%vstd!std_specs.option.OptionAdditionalFns. $ (TYPE%core!option.Option. T&.
      T&
     ) T&. T&
   ))
   :pattern ((tr_bound%vstd!std_specs.option.OptionAdditionalFns. $ (TYPE%core!option.Option.
      T&. T&
     ) T&. T&
   ))
   :qid internal_vstd__std_specs__option__impl&__0_trait_impl_definition
   :skolemid skolem_internal_vstd__std_specs__option__impl&__0_trait_impl_definition
)))

;; Function-Axioms lib::vstdplus::total_order::total_order::TotalOrder::le
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (self! Poly) (other! Poly)) (!
   (=>
    (and
     (has_type self! Self%&)
     (has_type other! Self%&)
    )
    (has_type (lib!vstdplus.total_order.total_order.TotalOrder.le.? Self%&. Self%& self!
      other!
     ) BOOL
   ))
   :pattern ((lib!vstdplus.total_order.total_order.TotalOrder.le.? Self%&. Self%& self!
     other!
   ))
   :qid internal_lib!vstdplus.total_order.total_order.TotalOrder.le.?_pre_post_definition
   :skolemid skolem_internal_lib!vstdplus.total_order.total_order.TotalOrder.le.?_pre_post_definition
)))

;; Function-Specs lib::vstdplus::total_order::total_order::TotalOrder::reflexive
(declare-fun ens%lib!vstdplus.total_order.total_order.TotalOrder.reflexive. (Dcr Type
  Poly
 ) Bool
)
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (x! Poly)) (!
   (= (ens%lib!vstdplus.total_order.total_order.TotalOrder.reflexive. Self%&. Self%& x!)
    (%B (lib!vstdplus.total_order.total_order.TotalOrder.le.? Self%&. Self%& x! x!))
   )
   :pattern ((ens%lib!vstdplus.total_order.total_order.TotalOrder.reflexive. Self%&. Self%&
     x!
   ))
   :qid internal_ens__lib!vstdplus.total_order.total_order.TotalOrder.reflexive._definition
   :skolemid skolem_internal_ens__lib!vstdplus.total_order.total_order.TotalOrder.reflexive._definition
)))

;; Function-Specs lib::vstdplus::total_order::total_order::TotalOrder::transitive
(declare-fun req%lib!vstdplus.total_order.total_order.TotalOrder.transitive. (Dcr Type
  Poly Poly Poly
 ) Bool
)
(declare-const %%global_location_label%%7 Bool)
(declare-const %%global_location_label%%8 Bool)
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (x! Poly) (y! Poly) (z! Poly)) (!
   (= (req%lib!vstdplus.total_order.total_order.TotalOrder.transitive. Self%&. Self%&
     x! y! z!
    ) (and
     (=>
      %%global_location_label%%7
      (%B (lib!vstdplus.total_order.total_order.TotalOrder.le.? Self%&. Self%& x! y!))
     )
     (=>
      %%global_location_label%%8
      (%B (lib!vstdplus.total_order.total_order.TotalOrder.le.? Self%&. Self%& y! z!))
   )))
   :pattern ((req%lib!vstdplus.total_order.total_order.TotalOrder.transitive. Self%&.
     Self%& x! y! z!
   ))
   :qid internal_req__lib!vstdplus.total_order.total_order.TotalOrder.transitive._definition
   :skolemid skolem_internal_req__lib!vstdplus.total_order.total_order.TotalOrder.transitive._definition
)))
(declare-fun ens%lib!vstdplus.total_order.total_order.TotalOrder.transitive. (Dcr Type
  Poly Poly Poly
 ) Bool
)
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (x! Poly) (y! Poly) (z! Poly)) (!
   (= (ens%lib!vstdplus.total_order.total_order.TotalOrder.transitive. Self%&. Self%&
     x! y! z!
    ) (%B (lib!vstdplus.total_order.total_order.TotalOrder.le.? Self%&. Self%& x! z!))
   )
   :pattern ((ens%lib!vstdplus.total_order.total_order.TotalOrder.transitive. Self%&.
     Self%& x! y! z!
   ))
   :qid internal_ens__lib!vstdplus.total_order.total_order.TotalOrder.transitive._definition
   :skolemid skolem_internal_ens__lib!vstdplus.total_order.total_order.TotalOrder.transitive._definition
)))

;; Function-Specs lib::vstdplus::total_order::total_order::TotalOrder::antisymmetric
(declare-fun req%lib!vstdplus.total_order.total_order.TotalOrder.antisymmetric. (Dcr
  Type Poly Poly
 ) Bool
)
(declare-const %%global_location_label%%9 Bool)
(declare-const %%global_location_label%%10 Bool)
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (x! Poly) (y! Poly)) (!
   (= (req%lib!vstdplus.total_order.total_order.TotalOrder.antisymmetric. Self%&. Self%&
     x! y!
    ) (and
     (=>
      %%global_location_label%%9
      (%B (lib!vstdplus.total_order.total_order.TotalOrder.le.? Self%&. Self%& x! y!))
     )
     (=>
      %%global_location_label%%10
      (%B (lib!vstdplus.total_order.total_order.TotalOrder.le.? Self%&. Self%& y! x!))
   )))
   :pattern ((req%lib!vstdplus.total_order.total_order.TotalOrder.antisymmetric. Self%&.
     Self%& x! y!
   ))
   :qid internal_req__lib!vstdplus.total_order.total_order.TotalOrder.antisymmetric._definition
   :skolemid skolem_internal_req__lib!vstdplus.total_order.total_order.TotalOrder.antisymmetric._definition
)))
(declare-fun ens%lib!vstdplus.total_order.total_order.TotalOrder.antisymmetric. (Dcr
  Type Poly Poly
 ) Bool
)
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (x! Poly) (y! Poly)) (!
   (= (ens%lib!vstdplus.total_order.total_order.TotalOrder.antisymmetric. Self%&. Self%&
     x! y!
    ) (= x! y!)
   )
   :pattern ((ens%lib!vstdplus.total_order.total_order.TotalOrder.antisymmetric. Self%&.
     Self%& x! y!
   ))
   :qid internal_ens__lib!vstdplus.total_order.total_order.TotalOrder.antisymmetric._definition
   :skolemid skolem_internal_ens__lib!vstdplus.total_order.total_order.TotalOrder.antisymmetric._definition
)))

;; Function-Specs lib::vstdplus::total_order::total_order::TotalOrder::total
(declare-fun ens%lib!vstdplus.total_order.total_order.TotalOrder.total. (Dcr Type Poly
  Poly
 ) Bool
)
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (x! Poly) (y! Poly)) (!
   (= (ens%lib!vstdplus.total_order.total_order.TotalOrder.total. Self%&. Self%& x! y!)
    (or
     (%B (lib!vstdplus.total_order.total_order.TotalOrder.le.? Self%&. Self%& x! y!))
     (%B (lib!vstdplus.total_order.total_order.TotalOrder.le.? Self%&. Self%& y! x!))
   ))
   :pattern ((ens%lib!vstdplus.total_order.total_order.TotalOrder.total. Self%&. Self%&
     x! y!
   ))
   :qid internal_ens__lib!vstdplus.total_order.total_order.TotalOrder.total._definition
   :skolemid skolem_internal_ens__lib!vstdplus.total_order.total_order.TotalOrder.total._definition
)))

;; Function-Specs lib::vstdplus::total_order::total_order::TotalOrder::cmp
(declare-fun ens%lib!vstdplus.total_order.total_order.TotalOrder.cmp. (Dcr Type Poly
  Poly Poly
 ) Bool
)
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (self! Poly) (other! Poly) (c! Poly)) (!
   (= (ens%lib!vstdplus.total_order.total_order.TotalOrder.cmp. Self%&. Self%& self! other!
     c!
    ) (and
     (has_type c! TYPE%core!cmp.Ordering.)
     (ite
      (is-core!cmp.Ordering./Less (%Poly%core!cmp.Ordering. c!))
      (and
       (%B (lib!vstdplus.total_order.total_order.TotalOrder.le.? Self%&. Self%& self! other!))
       (not (= self! other!))
      )
      (ite
       (is-core!cmp.Ordering./Equal (%Poly%core!cmp.Ordering. c!))
       (= self! other!)
       (and
        (%B (lib!vstdplus.total_order.total_order.TotalOrder.le.? Self%&. Self%& other! self!))
        (not (= self! other!))
   )))))
   :pattern ((ens%lib!vstdplus.total_order.total_order.TotalOrder.cmp. Self%&. Self%&
     self! other! c!
   ))
   :qid internal_ens__lib!vstdplus.total_order.total_order.TotalOrder.cmp._definition
   :skolemid skolem_internal_ens__lib!vstdplus.total_order.total_order.TotalOrder.cmp._definition
)))

;; Function-Axioms vstd::pervasive::strictly_cloned
(assert
 (fuel_bool_default fuel%vstd!pervasive.strictly_cloned.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!pervasive.strictly_cloned.)
  (forall ((T&. Dcr) (T& Type) (a! Poly) (b! Poly)) (!
    (= (vstd!pervasive.strictly_cloned.? T&. T& a! b!) (closure_ens (FNDEF%core!clone.Clone.clone.
       T&. T&
      ) (DST (REF T&.)) (TYPE%tuple%1. (REF T&.) T&) (F fndef_singleton) (Poly%tuple%1.
       (tuple%1./tuple%1 a!)
      ) b!
    ))
    :pattern ((vstd!pervasive.strictly_cloned.? T&. T& a! b!))
    :qid internal_vstd!pervasive.strictly_cloned.?_definition
    :skolemid skolem_internal_vstd!pervasive.strictly_cloned.?_definition
))))

;; Function-Axioms vstd::pervasive::cloned
(assert
 (fuel_bool_default fuel%vstd!pervasive.cloned.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!pervasive.cloned.)
  (forall ((T&. Dcr) (T& Type) (a! Poly) (b! Poly)) (!
    (= (vstd!pervasive.cloned.? T&. T& a! b!) (or
      (vstd!pervasive.strictly_cloned.? T&. T& a! b!)
      (= a! b!)
    ))
    :pattern ((vstd!pervasive.cloned.? T&. T& a! b!))
    :qid internal_vstd!pervasive.cloned.?_definition
    :skolemid skolem_internal_vstd!pervasive.cloned.?_definition
))))

;; Broadcast vstd::seq_lib::lemma_seq_contains
(assert
 (=>
  (fuel_bool fuel%vstd!seq_lib.lemma_seq_contains.)
  (forall ((A&. Dcr) (A& Type) (s! Poly) (x! Poly)) (!
    (=>
     (and
      (has_type s! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type x! A&)
     )
     (=>
      (sized A&.)
      (= (vstd!seq_lib.impl&%0.contains.? A&. A& s! x!) (exists ((i$ Poly)) (!
         (and
          (has_type i$ INT)
          (and
           (let
            ((tmp%%$ 0))
            (let
             ((tmp%%$1 (%I i$)))
             (let
              ((tmp%%$2 (vstd!seq.Seq.len.? A&. A& s!)))
              (and
               (<= tmp%%$ tmp%%$1)
               (< tmp%%$1 tmp%%$2)
           ))))
           (= (vstd!seq.Seq.index.? A&. A& s! i$) x!)
         ))
         :pattern ((vstd!seq.Seq.index.? A&. A& s! i$))
         :qid user_vstd__seq_lib__lemma_seq_contains_0
         :skolemid skolem_user_vstd__seq_lib__lemma_seq_contains_0
    )))))
    :pattern ((vstd!seq_lib.impl&%0.contains.? A&. A& s! x!))
    :qid user_vstd__seq_lib__lemma_seq_contains_1
    :skolemid skolem_user_vstd__seq_lib__lemma_seq_contains_1
))))

;; Broadcast vstd::seq_lib::lemma_seq_empty_contains_nothing
(assert
 (=>
  (fuel_bool fuel%vstd!seq_lib.lemma_seq_empty_contains_nothing.)
  (forall ((A&. Dcr) (A& Type) (x! Poly)) (!
    (=>
     (has_type x! A&)
     (=>
      (sized A&.)
      (not (vstd!seq_lib.impl&%0.contains.? A&. A& (vstd!seq.Seq.empty.? A&. A&) x!))
    ))
    :pattern ((vstd!seq_lib.impl&%0.contains.? A&. A& (vstd!seq.Seq.empty.? A&. A&) x!))
    :qid user_vstd__seq_lib__lemma_seq_empty_contains_nothing_0
    :skolemid skolem_user_vstd__seq_lib__lemma_seq_empty_contains_nothing_0
))))

;; Broadcast vstd::seq_lib::lemma_seq_empty_equality
(assert
 (=>
  (fuel_bool fuel%vstd!seq_lib.lemma_seq_empty_equality.)
  (forall ((A&. Dcr) (A& Type) (s! Poly)) (!
    (=>
     (has_type s! (TYPE%vstd!seq.Seq. A&. A&))
     (=>
      (sized A&.)
      (=>
       (= (vstd!seq.Seq.len.? A&. A& s!) 0)
       (ext_eq false (TYPE%vstd!seq.Seq. A&. A&) s! (vstd!seq.Seq.empty.? A&. A&))
    )))
    :pattern ((vstd!seq.Seq.len.? A&. A& s!))
    :qid user_vstd__seq_lib__lemma_seq_empty_equality_0
    :skolemid skolem_user_vstd__seq_lib__lemma_seq_empty_equality_0
))))

;; Broadcast vstd::seq_lib::lemma_seq_concat_contains_all_elements
(assert
 (=>
  (fuel_bool fuel%vstd!seq_lib.lemma_seq_concat_contains_all_elements.)
  (forall ((A&. Dcr) (A& Type) (x! Poly) (y! Poly) (elt! Poly)) (!
    (=>
     (and
      (has_type x! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type y! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type elt! A&)
     )
     (=>
      (sized A&.)
      (= (vstd!seq_lib.impl&%0.contains.? A&. A& (vstd!seq.Seq.add.? A&. A& x! y!) elt!)
       (or
        (vstd!seq_lib.impl&%0.contains.? A&. A& x! elt!)
        (vstd!seq_lib.impl&%0.contains.? A&. A& y! elt!)
    ))))
    :pattern ((vstd!seq_lib.impl&%0.contains.? A&. A& (vstd!seq.Seq.add.? A&. A& x! y!)
      elt!
    ))
    :qid user_vstd__seq_lib__lemma_seq_concat_contains_all_elements_0
    :skolemid skolem_user_vstd__seq_lib__lemma_seq_concat_contains_all_elements_0
))))

;; Broadcast vstd::seq_lib::lemma_seq_contains_after_push
(assert
 (=>
  (fuel_bool fuel%vstd!seq_lib.lemma_seq_contains_after_push.)
  (forall ((A&. Dcr) (A& Type) (s! Poly) (v! Poly) (x! Poly)) (!
    (=>
     (and
      (has_type s! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type v! A&)
      (has_type x! A&)
     )
     (=>
      (sized A&.)
      (= (vstd!seq_lib.impl&%0.contains.? A&. A& (vstd!seq.Seq.push.? A&. A& s! v!) x!)
       (or
        (= v! x!)
        (vstd!seq_lib.impl&%0.contains.? A&. A& s! x!)
    ))))
    :pattern ((vstd!seq_lib.impl&%0.contains.? A&. A& (vstd!seq.Seq.push.? A&. A& s! v!)
      x!
    ))
    :qid user_vstd__seq_lib__lemma_seq_contains_after_push_0
    :skolemid skolem_user_vstd__seq_lib__lemma_seq_contains_after_push_0
))))

;; Broadcast vstd::seq_lib::lemma_seq_subrange_elements
(assert
 (=>
  (fuel_bool fuel%vstd!seq_lib.lemma_seq_subrange_elements.)
  (forall ((A&. Dcr) (A& Type) (s! Poly) (start! Poly) (stop! Poly) (x! Poly)) (!
    (=>
     (and
      (has_type s! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type start! INT)
      (has_type stop! INT)
      (has_type x! A&)
     )
     (=>
      (and
       (sized A&.)
       (let
        ((tmp%%$ 0))
        (let
         ((tmp%%$1 (%I start!)))
         (let
          ((tmp%%$2 (%I stop!)))
          (let
           ((tmp%%$3 (vstd!seq.Seq.len.? A&. A& s!)))
           (and
            (and
             (<= tmp%%$ tmp%%$1)
             (<= tmp%%$1 tmp%%$2)
            )
            (<= tmp%%$2 tmp%%$3)
      ))))))
      (= (vstd!seq_lib.impl&%0.contains.? A&. A& (vstd!seq.Seq.subrange.? A&. A& s! start!
         stop!
        ) x!
       ) (exists ((i$ Poly)) (!
         (and
          (has_type i$ INT)
          (and
           (let
            ((tmp%%$ 0))
            (let
             ((tmp%%$5 (%I start!)))
             (let
              ((tmp%%$6 (%I i$)))
              (let
               ((tmp%%$7 (%I stop!)))
               (let
                ((tmp%%$8 (vstd!seq.Seq.len.? A&. A& s!)))
                (and
                 (and
                  (and
                   (<= tmp%%$ tmp%%$5)
                   (<= tmp%%$5 tmp%%$6)
                  )
                  (< tmp%%$6 tmp%%$7)
                 )
                 (<= tmp%%$7 tmp%%$8)
           ))))))
           (= (vstd!seq.Seq.index.? A&. A& s! i$) x!)
         ))
         :pattern ((vstd!seq.Seq.index.? A&. A& s! i$))
         :qid user_vstd__seq_lib__lemma_seq_subrange_elements_0
         :skolemid skolem_user_vstd__seq_lib__lemma_seq_subrange_elements_0
    )))))
    :pattern ((vstd!seq_lib.impl&%0.contains.? A&. A& (vstd!seq.Seq.subrange.? A&. A& s!
       start! stop!
      ) x!
    ))
    :qid user_vstd__seq_lib__lemma_seq_subrange_elements_1
    :skolemid skolem_user_vstd__seq_lib__lemma_seq_subrange_elements_1
))))

;; Function-Axioms vstd::seq::impl&%2::take
(assert
 (fuel_bool_default fuel%vstd!seq.impl&%2.take.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!seq.impl&%2.take.)
  (forall ((A&. Dcr) (A& Type) (self! Poly) (n! Poly)) (!
    (= (vstd!seq.impl&%2.take.? A&. A& self! n!) (vstd!seq.Seq.subrange.? A&. A& self!
      (I 0) n!
    ))
    :pattern ((vstd!seq.impl&%2.take.? A&. A& self! n!))
    :qid internal_vstd!seq.impl&__2.take.?_definition
    :skolemid skolem_internal_vstd!seq.impl&__2.take.?_definition
))))
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly) (n! Poly)) (!
   (=>
    (and
     (has_type self! (TYPE%vstd!seq.Seq. A&. A&))
     (has_type n! INT)
    )
    (has_type (vstd!seq.impl&%2.take.? A&. A& self! n!) (TYPE%vstd!seq.Seq. A&. A&))
   )
   :pattern ((vstd!seq.impl&%2.take.? A&. A& self! n!))
   :qid internal_vstd!seq.impl&__2.take.?_pre_post_definition
   :skolemid skolem_internal_vstd!seq.impl&__2.take.?_pre_post_definition
)))

;; Broadcast vstd::seq_lib::lemma_seq_take_len
(assert
 (=>
  (fuel_bool fuel%vstd!seq_lib.lemma_seq_take_len.)
  (forall ((A&. Dcr) (A& Type) (s! Poly) (n! Poly)) (!
    (=>
     (and
      (has_type s! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type n! INT)
     )
     (=>
      (sized A&.)
      (=>
       (let
        ((tmp%%$ 0))
        (let
         ((tmp%%$1 (%I n!)))
         (let
          ((tmp%%$2 (vstd!seq.Seq.len.? A&. A& s!)))
          (and
           (<= tmp%%$ tmp%%$1)
           (<= tmp%%$1 tmp%%$2)
       ))))
       (= (vstd!seq.Seq.len.? A&. A& (vstd!seq.Seq.subrange.? A&. A& s! (I 0) n!)) (%I n!))
    )))
    :pattern ((vstd!seq.Seq.len.? A&. A& (vstd!seq.Seq.subrange.? A&. A& s! (I 0) n!)))
    :qid user_vstd__seq_lib__lemma_seq_take_len_0
    :skolemid skolem_user_vstd__seq_lib__lemma_seq_take_len_0
))))

;; Broadcast vstd::seq_lib::lemma_seq_take_contains
(assert
 (=>
  (fuel_bool fuel%vstd!seq_lib.lemma_seq_take_contains.)
  (forall ((A&. Dcr) (A& Type) (s! Poly) (n! Poly) (x! Poly)) (!
    (=>
     (and
      (has_type s! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type n! INT)
      (has_type x! A&)
     )
     (=>
      (and
       (sized A&.)
       (let
        ((tmp%%$ 0))
        (let
         ((tmp%%$1 (%I n!)))
         (let
          ((tmp%%$2 (vstd!seq.Seq.len.? A&. A& s!)))
          (and
           (<= tmp%%$ tmp%%$1)
           (<= tmp%%$1 tmp%%$2)
      )))))
      (= (vstd!seq_lib.impl&%0.contains.? A&. A& (vstd!seq.Seq.subrange.? A&. A& s! (I 0)
         n!
        ) x!
       ) (exists ((i$ Poly)) (!
         (and
          (has_type i$ INT)
          (and
           (let
            ((tmp%%$ 0))
            (let
             ((tmp%%$4 (%I i$)))
             (let
              ((tmp%%$5 (%I n!)))
              (let
               ((tmp%%$6 (vstd!seq.Seq.len.? A&. A& s!)))
               (and
                (and
                 (<= tmp%%$ tmp%%$4)
                 (< tmp%%$4 tmp%%$5)
                )
                (<= tmp%%$5 tmp%%$6)
           )))))
           (= (vstd!seq.Seq.index.? A&. A& s! i$) x!)
         ))
         :pattern ((vstd!seq.Seq.index.? A&. A& s! i$))
         :qid user_vstd__seq_lib__lemma_seq_take_contains_0
         :skolemid skolem_user_vstd__seq_lib__lemma_seq_take_contains_0
    )))))
    :pattern ((vstd!seq_lib.impl&%0.contains.? A&. A& (vstd!seq.Seq.subrange.? A&. A& s!
       (I 0) n!
      ) x!
    ))
    :qid user_vstd__seq_lib__lemma_seq_take_contains_1
    :skolemid skolem_user_vstd__seq_lib__lemma_seq_take_contains_1
))))

;; Broadcast vstd::seq_lib::lemma_seq_take_index
(assert
 (=>
  (fuel_bool fuel%vstd!seq_lib.lemma_seq_take_index.)
  (forall ((A&. Dcr) (A& Type) (s! Poly) (n! Poly) (j! Poly)) (!
    (=>
     (and
      (has_type s! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type n! INT)
      (has_type j! INT)
     )
     (=>
      (sized A&.)
      (=>
       (let
        ((tmp%%$ 0))
        (let
         ((tmp%%$1 (%I j!)))
         (let
          ((tmp%%$2 (%I n!)))
          (let
           ((tmp%%$3 (vstd!seq.Seq.len.? A&. A& s!)))
           (and
            (and
             (<= tmp%%$ tmp%%$1)
             (< tmp%%$1 tmp%%$2)
            )
            (<= tmp%%$2 tmp%%$3)
       )))))
       (= (vstd!seq.Seq.index.? A&. A& (vstd!seq.Seq.subrange.? A&. A& s! (I 0) n!) j!) (
         vstd!seq.Seq.index.? A&. A& s! j!
    )))))
    :pattern ((vstd!seq.Seq.index.? A&. A& (vstd!seq.Seq.subrange.? A&. A& s! (I 0) n!)
      j!
    ))
    :qid user_vstd__seq_lib__lemma_seq_take_index_0
    :skolemid skolem_user_vstd__seq_lib__lemma_seq_take_index_0
))))

;; Function-Axioms vstd::seq::impl&%2::skip
(assert
 (fuel_bool_default fuel%vstd!seq.impl&%2.skip.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!seq.impl&%2.skip.)
  (forall ((A&. Dcr) (A& Type) (self! Poly) (n! Poly)) (!
    (= (vstd!seq.impl&%2.skip.? A&. A& self! n!) (vstd!seq.Seq.subrange.? A&. A& self!
      n! (I (vstd!seq.Seq.len.? A&. A& self!))
    ))
    :pattern ((vstd!seq.impl&%2.skip.? A&. A& self! n!))
    :qid internal_vstd!seq.impl&__2.skip.?_definition
    :skolemid skolem_internal_vstd!seq.impl&__2.skip.?_definition
))))
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly) (n! Poly)) (!
   (=>
    (and
     (has_type self! (TYPE%vstd!seq.Seq. A&. A&))
     (has_type n! INT)
    )
    (has_type (vstd!seq.impl&%2.skip.? A&. A& self! n!) (TYPE%vstd!seq.Seq. A&. A&))
   )
   :pattern ((vstd!seq.impl&%2.skip.? A&. A& self! n!))
   :qid internal_vstd!seq.impl&__2.skip.?_pre_post_definition
   :skolemid skolem_internal_vstd!seq.impl&__2.skip.?_pre_post_definition
)))

;; Broadcast vstd::seq_lib::lemma_seq_skip_len
(assert
 (=>
  (fuel_bool fuel%vstd!seq_lib.lemma_seq_skip_len.)
  (forall ((A&. Dcr) (A& Type) (s! Poly) (n! Poly)) (!
    (=>
     (and
      (has_type s! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type n! INT)
     )
     (=>
      (sized A&.)
      (=>
       (let
        ((tmp%%$ 0))
        (let
         ((tmp%%$1 (%I n!)))
         (let
          ((tmp%%$2 (vstd!seq.Seq.len.? A&. A& s!)))
          (and
           (<= tmp%%$ tmp%%$1)
           (<= tmp%%$1 tmp%%$2)
       ))))
       (= (vstd!seq.Seq.len.? A&. A& (vstd!seq.Seq.subrange.? A&. A& s! n! (I (vstd!seq.Seq.len.?
            A&. A& s!
         )))
        ) (Sub (vstd!seq.Seq.len.? A&. A& s!) (%I n!))
    ))))
    :pattern ((vstd!seq.Seq.len.? A&. A& (vstd!seq.Seq.subrange.? A&. A& s! n! (I (vstd!seq.Seq.len.?
         A&. A& s!
    )))))
    :qid user_vstd__seq_lib__lemma_seq_skip_len_0
    :skolemid skolem_user_vstd__seq_lib__lemma_seq_skip_len_0
))))

;; Broadcast vstd::seq_lib::lemma_seq_skip_contains
(assert
 (=>
  (fuel_bool fuel%vstd!seq_lib.lemma_seq_skip_contains.)
  (forall ((A&. Dcr) (A& Type) (s! Poly) (n! Poly) (x! Poly)) (!
    (=>
     (and
      (has_type s! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type n! INT)
      (has_type x! A&)
     )
     (=>
      (and
       (sized A&.)
       (let
        ((tmp%%$ 0))
        (let
         ((tmp%%$1 (%I n!)))
         (let
          ((tmp%%$2 (vstd!seq.Seq.len.? A&. A& s!)))
          (and
           (<= tmp%%$ tmp%%$1)
           (<= tmp%%$1 tmp%%$2)
      )))))
      (= (vstd!seq_lib.impl&%0.contains.? A&. A& (vstd!seq.Seq.subrange.? A&. A& s! n! (I (
           vstd!seq.Seq.len.? A&. A& s!
         ))
        ) x!
       ) (exists ((i$ Poly)) (!
         (and
          (has_type i$ INT)
          (and
           (let
            ((tmp%%$ 0))
            (let
             ((tmp%%$4 (%I n!)))
             (let
              ((tmp%%$5 (%I i$)))
              (let
               ((tmp%%$6 (vstd!seq.Seq.len.? A&. A& s!)))
               (and
                (and
                 (<= tmp%%$ tmp%%$4)
                 (<= tmp%%$4 tmp%%$5)
                )
                (< tmp%%$5 tmp%%$6)
           )))))
           (= (vstd!seq.Seq.index.? A&. A& s! i$) x!)
         ))
         :pattern ((vstd!seq.Seq.index.? A&. A& s! i$))
         :qid user_vstd__seq_lib__lemma_seq_skip_contains_0
         :skolemid skolem_user_vstd__seq_lib__lemma_seq_skip_contains_0
    )))))
    :pattern ((vstd!seq_lib.impl&%0.contains.? A&. A& (vstd!seq.Seq.subrange.? A&. A& s!
       n! (I (vstd!seq.Seq.len.? A&. A& s!))
      ) x!
    ))
    :qid user_vstd__seq_lib__lemma_seq_skip_contains_1
    :skolemid skolem_user_vstd__seq_lib__lemma_seq_skip_contains_1
))))

;; Broadcast vstd::seq_lib::lemma_seq_skip_index
(assert
 (=>
  (fuel_bool fuel%vstd!seq_lib.lemma_seq_skip_index.)
  (forall ((A&. Dcr) (A& Type) (s! Poly) (n! Poly) (j! Poly)) (!
    (=>
     (and
      (has_type s! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type n! INT)
      (has_type j! INT)
     )
     (=>
      (sized A&.)
      (=>
       (and
        (<= 0 (%I n!))
        (let
         ((tmp%%$ 0))
         (let
          ((tmp%%$1 (%I j!)))
          (let
           ((tmp%%$2 (Sub (vstd!seq.Seq.len.? A&. A& s!) (%I n!))))
           (and
            (<= tmp%%$ tmp%%$1)
            (< tmp%%$1 tmp%%$2)
       )))))
       (= (vstd!seq.Seq.index.? A&. A& (vstd!seq.Seq.subrange.? A&. A& s! n! (I (vstd!seq.Seq.len.?
            A&. A& s!
          ))
         ) j!
        ) (vstd!seq.Seq.index.? A&. A& s! (I (Add (%I j!) (%I n!))))
    ))))
    :pattern ((vstd!seq.Seq.index.? A&. A& (vstd!seq.Seq.subrange.? A&. A& s! n! (I (vstd!seq.Seq.len.?
         A&. A& s!
       ))
      ) j!
    ))
    :qid user_vstd__seq_lib__lemma_seq_skip_index_0
    :skolemid skolem_user_vstd__seq_lib__lemma_seq_skip_index_0
))))

;; Broadcast vstd::seq_lib::lemma_seq_skip_index2
(assert
 (=>
  (fuel_bool fuel%vstd!seq_lib.lemma_seq_skip_index2.)
  (forall ((A&. Dcr) (A& Type) (s! Poly) (n! Poly) (k! Poly)) (!
    (=>
     (and
      (has_type s! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type n! INT)
      (has_type k! INT)
     )
     (=>
      (sized A&.)
      (=>
       (let
        ((tmp%%$ 0))
        (let
         ((tmp%%$1 (%I n!)))
         (let
          ((tmp%%$2 (%I k!)))
          (let
           ((tmp%%$3 (vstd!seq.Seq.len.? A&. A& s!)))
           (and
            (and
             (<= tmp%%$ tmp%%$1)
             (<= tmp%%$1 tmp%%$2)
            )
            (< tmp%%$2 tmp%%$3)
       )))))
       (= (vstd!seq.Seq.index.? A&. A& (vstd!seq.Seq.subrange.? A&. A& s! n! (I (vstd!seq.Seq.len.?
            A&. A& s!
          ))
         ) (I (Sub (%I k!) (%I n!)))
        ) (vstd!seq.Seq.index.? A&. A& s! k!)
    ))))
    :pattern ((vstd!seq.Seq.subrange.? A&. A& s! n! (I (vstd!seq.Seq.len.? A&. A& s!)))
     (vstd!seq.Seq.index.? A&. A& s! k!)
    )
    :qid user_vstd__seq_lib__lemma_seq_skip_index2_0
    :skolemid skolem_user_vstd__seq_lib__lemma_seq_skip_index2_0
))))

;; Broadcast vstd::seq_lib::lemma_seq_append_take_skip
(assert
 (=>
  (fuel_bool fuel%vstd!seq_lib.lemma_seq_append_take_skip.)
  (forall ((A&. Dcr) (A& Type) (a! Poly) (b! Poly) (n! Poly)) (!
    (=>
     (and
      (has_type a! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type b! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type n! INT)
     )
     (=>
      (sized A&.)
      (=>
       (= (%I n!) (vstd!seq.Seq.len.? A&. A& a!))
       (and
        (ext_eq false (TYPE%vstd!seq.Seq. A&. A&) (vstd!seq.Seq.subrange.? A&. A& (vstd!seq.Seq.add.?
           A&. A& a! b!
          ) (I 0) n!
         ) a!
        )
        (ext_eq false (TYPE%vstd!seq.Seq. A&. A&) (vstd!seq.Seq.subrange.? A&. A& (vstd!seq.Seq.add.?
           A&. A& a! b!
          ) n! (I (vstd!seq.Seq.len.? A&. A& (vstd!seq.Seq.add.? A&. A& a! b!)))
         ) b!
    )))))
    :pattern ((vstd!seq.Seq.subrange.? A&. A& (vstd!seq.Seq.add.? A&. A& a! b!) (I 0) n!))
    :pattern ((vstd!seq.Seq.subrange.? A&. A& (vstd!seq.Seq.add.? A&. A& a! b!) n! (I (vstd!seq.Seq.len.?
        A&. A& (vstd!seq.Seq.add.? A&. A& a! b!)
    ))))
    :qid user_vstd__seq_lib__lemma_seq_append_take_skip_0
    :skolemid skolem_user_vstd__seq_lib__lemma_seq_append_take_skip_0
))))

;; Broadcast vstd::seq_lib::lemma_seq_skip_build_commut
(assert
 (=>
  (fuel_bool fuel%vstd!seq_lib.lemma_seq_skip_build_commut.)
  (forall ((A&. Dcr) (A& Type) (s! Poly) (v! Poly) (n! Poly)) (!
    (=>
     (and
      (has_type s! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type v! A&)
      (has_type n! INT)
     )
     (=>
      (sized A&.)
      (=>
       (let
        ((tmp%%$ 0))
        (let
         ((tmp%%$1 (%I n!)))
         (let
          ((tmp%%$2 (vstd!seq.Seq.len.? A&. A& s!)))
          (and
           (<= tmp%%$ tmp%%$1)
           (<= tmp%%$1 tmp%%$2)
       ))))
       (ext_eq false (TYPE%vstd!seq.Seq. A&. A&) (vstd!seq.Seq.subrange.? A&. A& (vstd!seq.Seq.push.?
          A&. A& s! v!
         ) n! (I (vstd!seq.Seq.len.? A&. A& (vstd!seq.Seq.push.? A&. A& s! v!)))
        ) (vstd!seq.Seq.push.? A&. A& (vstd!seq.Seq.subrange.? A&. A& s! n! (I (vstd!seq.Seq.len.?
            A&. A& s!
          ))
         ) v!
    )))))
    :pattern ((vstd!seq.Seq.subrange.? A&. A& (vstd!seq.Seq.push.? A&. A& s! v!) n! (I (
        vstd!seq.Seq.len.? A&. A& (vstd!seq.Seq.push.? A&. A& s! v!)
    ))))
    :qid user_vstd__seq_lib__lemma_seq_skip_build_commut_0
    :skolemid skolem_user_vstd__seq_lib__lemma_seq_skip_build_commut_0
))))

;; Broadcast vstd::seq_lib::lemma_seq_skip_nothing
(assert
 (=>
  (fuel_bool fuel%vstd!seq_lib.lemma_seq_skip_nothing.)
  (forall ((A&. Dcr) (A& Type) (s! Poly) (n! Poly)) (!
    (=>
     (and
      (has_type s! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type n! INT)
     )
     (=>
      (sized A&.)
      (=>
       (= (%I n!) 0)
       (ext_eq false (TYPE%vstd!seq.Seq. A&. A&) (vstd!seq.Seq.subrange.? A&. A& s! n! (I (
           vstd!seq.Seq.len.? A&. A& s!
         ))
        ) s!
    ))))
    :pattern ((vstd!seq.Seq.subrange.? A&. A& s! n! (I (vstd!seq.Seq.len.? A&. A& s!))))
    :qid user_vstd__seq_lib__lemma_seq_skip_nothing_0
    :skolemid skolem_user_vstd__seq_lib__lemma_seq_skip_nothing_0
))))

;; Broadcast vstd::seq_lib::lemma_seq_take_nothing
(assert
 (=>
  (fuel_bool fuel%vstd!seq_lib.lemma_seq_take_nothing.)
  (forall ((A&. Dcr) (A& Type) (s! Poly) (n! Poly)) (!
    (=>
     (and
      (has_type s! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type n! INT)
     )
     (=>
      (sized A&.)
      (=>
       (= (%I n!) 0)
       (ext_eq false (TYPE%vstd!seq.Seq. A&. A&) (vstd!seq.Seq.subrange.? A&. A& s! (I 0)
         n!
        ) (vstd!seq.Seq.empty.? A&. A&)
    ))))
    :pattern ((vstd!seq.Seq.subrange.? A&. A& s! (I 0) n!))
    :qid user_vstd__seq_lib__lemma_seq_take_nothing_0
    :skolemid skolem_user_vstd__seq_lib__lemma_seq_take_nothing_0
))))

;; Function-Axioms vstd::seq_lib::impl&%0::to_multiset
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly)) (!
   (=>
    (has_type self! (TYPE%vstd!seq.Seq. A&. A&))
    (has_type (vstd!seq_lib.impl&%0.to_multiset.? A&. A& self!) (TYPE%vstd!multiset.Multiset.
      A&. A&
   )))
   :pattern ((vstd!seq_lib.impl&%0.to_multiset.? A&. A& self!))
   :qid internal_vstd!seq_lib.impl&__0.to_multiset.?_pre_post_definition
   :skolemid skolem_internal_vstd!seq_lib.impl&__0.to_multiset.?_pre_post_definition
)))

;; Function-Axioms vstd::multiset::impl&%0::insert
(assert
 (fuel_bool_default fuel%vstd!multiset.impl&%0.insert.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!multiset.impl&%0.insert.)
  (forall ((V&. Dcr) (V& Type) (self! Poly) (v! Poly)) (!
    (= (vstd!multiset.impl&%0.insert.? V&. V& self! v!) (vstd!multiset.impl&%0.add.? V&.
      V& self! (vstd!multiset.impl&%0.singleton.? V&. V& v!)
    ))
    :pattern ((vstd!multiset.impl&%0.insert.? V&. V& self! v!))
    :qid internal_vstd!multiset.impl&__0.insert.?_definition
    :skolemid skolem_internal_vstd!multiset.impl&__0.insert.?_definition
))))
(assert
 (forall ((V&. Dcr) (V& Type) (self! Poly) (v! Poly)) (!
   (=>
    (and
     (has_type self! (TYPE%vstd!multiset.Multiset. V&. V&))
     (has_type v! V&)
    )
    (has_type (vstd!multiset.impl&%0.insert.? V&. V& self! v!) (TYPE%vstd!multiset.Multiset.
      V&. V&
   )))
   :pattern ((vstd!multiset.impl&%0.insert.? V&. V& self! v!))
   :qid internal_vstd!multiset.impl&__0.insert.?_pre_post_definition
   :skolemid skolem_internal_vstd!multiset.impl&__0.insert.?_pre_post_definition
)))

;; Broadcast vstd::seq_lib::to_multiset_build
(assert
 (=>
  (fuel_bool fuel%vstd!seq_lib.to_multiset_build.)
  (forall ((A&. Dcr) (A& Type) (s! Poly) (a! Poly)) (!
    (=>
     (and
      (has_type s! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type a! A&)
     )
     (=>
      (sized A&.)
      (ext_eq false (TYPE%vstd!multiset.Multiset. A&. A&) (vstd!seq_lib.impl&%0.to_multiset.?
        A&. A& (vstd!seq.Seq.push.? A&. A& s! a!)
       ) (vstd!multiset.impl&%0.insert.? A&. A& (vstd!seq_lib.impl&%0.to_multiset.? A&. A&
         s!
        ) a!
    ))))
    :pattern ((vstd!seq_lib.impl&%0.to_multiset.? A&. A& (vstd!seq.Seq.push.? A&. A& s!
       a!
    )))
    :qid user_vstd__seq_lib__to_multiset_build_0
    :skolemid skolem_user_vstd__seq_lib__to_multiset_build_0
))))

;; Broadcast vstd::seq_lib::to_multiset_len
(assert
 (=>
  (fuel_bool fuel%vstd!seq_lib.to_multiset_len.)
  (forall ((A&. Dcr) (A& Type) (s! Poly)) (!
    (=>
     (has_type s! (TYPE%vstd!seq.Seq. A&. A&))
     (=>
      (sized A&.)
      (= (vstd!seq.Seq.len.? A&. A& s!) (vstd!multiset.impl&%0.len.? A&. A& (vstd!seq_lib.impl&%0.to_multiset.?
         A&. A& s!
    )))))
    :pattern ((vstd!multiset.impl&%0.len.? A&. A& (vstd!seq_lib.impl&%0.to_multiset.? A&.
       A& s!
    )))
    :qid user_vstd__seq_lib__to_multiset_len_0
    :skolemid skolem_user_vstd__seq_lib__to_multiset_len_0
))))

;; Broadcast vstd::seq_lib::to_multiset_contains
(assert
 (=>
  (fuel_bool fuel%vstd!seq_lib.to_multiset_contains.)
  (forall ((A&. Dcr) (A& Type) (s! Poly) (a! Poly)) (!
    (=>
     (and
      (has_type s! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type a! A&)
     )
     (=>
      (sized A&.)
      (= (vstd!seq_lib.impl&%0.contains.? A&. A& s! a!) (> (vstd!multiset.impl&%0.count.?
         A&. A& (vstd!seq_lib.impl&%0.to_multiset.? A&. A& s!) a!
        ) 0
    ))))
    :pattern ((vstd!multiset.impl&%0.count.? A&. A& (vstd!seq_lib.impl&%0.to_multiset.?
       A&. A& s!
      ) a!
    ))
    :qid user_vstd__seq_lib__to_multiset_contains_0
    :skolemid skolem_user_vstd__seq_lib__to_multiset_contains_0
))))

;; Function-Axioms lib::vstdplus::feq::feq::obeys_feq_clone
(assert
 (fuel_bool_default fuel%lib!vstdplus.feq.feq.obeys_feq_clone.)
)
(assert
 (=>
  (fuel_bool fuel%lib!vstdplus.feq.feq.obeys_feq_clone.)
  (forall ((T&. Dcr) (T& Type)) (!
    (= (lib!vstdplus.feq.feq.obeys_feq_clone.? T&. T&) (and
      (and
       (and
        (forall ((x$ Poly) (y$ Poly)) (!
          (=>
           (and
            (has_type x$ T&)
            (has_type y$ T&)
           )
           (=>
            (vstd!pervasive.cloned.? T&. T& x$ y$)
            (%B (vstd!std_specs.cmp.PartialEqSpec.eq_spec.? T&. T& T&. T& x$ y$))
          ))
          :pattern ((vstd!pervasive.cloned.? T&. T& x$ y$))
          :qid user_lib__vstdplus__feq__feq__obeys_feq_clone_0
          :skolemid skolem_user_lib__vstdplus__feq__feq__obeys_feq_clone_0
        ))
        (forall ((x$ Poly) (y$ Poly)) (!
          (=>
           (and
            (has_type x$ T&)
            (has_type y$ T&)
           )
           (=>
            (vstd!pervasive.cloned.? T&. T& x$ y$)
            (%B (vstd!std_specs.cmp.PartialEqSpec.eq_spec.? T&. T& T&. T& x$ y$))
          ))
          :pattern ((vstd!pervasive.cloned.? T&. T& x$ y$))
          :qid user_lib__vstdplus__feq__feq__obeys_feq_clone_1
          :skolemid skolem_user_lib__vstdplus__feq__feq__obeys_feq_clone_1
       )))
       (forall ((x$ Poly) (y$ Poly)) (!
         (=>
          (and
           (has_type x$ T&)
           (has_type y$ T&)
          )
          (=>
           (vstd!pervasive.strictly_cloned.? T&. T& x$ y$)
           (%B (vstd!std_specs.cmp.PartialEqSpec.eq_spec.? T&. T& T&. T& x$ y$))
         ))
         :pattern ((vstd!pervasive.strictly_cloned.? T&. T& x$ y$))
         :qid user_lib__vstdplus__feq__feq__obeys_feq_clone_2
         :skolemid skolem_user_lib__vstdplus__feq__feq__obeys_feq_clone_2
      )))
      (forall ((x$ Poly) (y$ Poly)) (!
        (=>
         (and
          (has_type x$ T&)
          (has_type y$ T&)
         )
         (=>
          (vstd!pervasive.strictly_cloned.? T&. T& x$ y$)
          (%B (vstd!std_specs.cmp.PartialEqSpec.eq_spec.? T&. T& T&. T& x$ y$))
        ))
        :pattern ((vstd!pervasive.strictly_cloned.? T&. T& x$ y$))
        :qid user_lib__vstdplus__feq__feq__obeys_feq_clone_3
        :skolemid skolem_user_lib__vstdplus__feq__feq__obeys_feq_clone_3
    ))))
    :pattern ((lib!vstdplus.feq.feq.obeys_feq_clone.? T&. T&))
    :qid internal_lib!vstdplus.feq.feq.obeys_feq_clone.?_definition
    :skolemid skolem_internal_lib!vstdplus.feq.feq.obeys_feq_clone.?_definition
))))

;; Broadcast lib::vstdplus::feq::feq::axiom_cloned_implies_eq
(assert
 (=>
  (fuel_bool fuel%lib!vstdplus.feq.feq.axiom_cloned_implies_eq.)
  (forall ((T&. Dcr) (T& Type) (x! Poly) (y! Poly)) (!
    (=>
     (and
      (has_type x! T&)
      (has_type y! T&)
     )
     (=>
      (and
       (and
        (and
         (and
          (sized T&.)
          (tr_bound%core!cmp.Eq. T&. T&)
         )
         (tr_bound%core!clone.Clone. T&. T&)
        )
        (vstd!pervasive.cloned.? T&. T& x! y!)
       )
       (lib!vstdplus.feq.feq.obeys_feq_clone.? T&. T&)
      )
      (= x! y!)
    ))
    :pattern ((vstd!pervasive.cloned.? T&. T& x! y!))
    :qid user_lib__vstdplus__feq__feq__axiom_cloned_implies_eq_0
    :skolemid skolem_user_lib__vstdplus__feq__feq__axiom_cloned_implies_eq_0
))))

;; Broadcast lib::vstdplus::feq::feq::axiom_cloned_implies_eq_owned
(assert
 (=>
  (fuel_bool fuel%lib!vstdplus.feq.feq.axiom_cloned_implies_eq_owned.)
  (forall ((T&. Dcr) (T& Type) (x! Poly) (y! Poly)) (!
    (=>
     (and
      (has_type x! T&)
      (has_type y! T&)
     )
     (=>
      (and
       (and
        (and
         (and
          (sized T&.)
          (tr_bound%core!cmp.Eq. T&. T&)
         )
         (tr_bound%core!clone.Clone. T&. T&)
        )
        (vstd!pervasive.cloned.? T&. T& x! y!)
       )
       (lib!vstdplus.feq.feq.obeys_feq_clone.? T&. T&)
      )
      (= x! y!)
    ))
    :pattern ((vstd!pervasive.cloned.? T&. T& x! y!))
    :qid user_lib__vstdplus__feq__feq__axiom_cloned_implies_eq_owned_0
    :skolemid skolem_user_lib__vstdplus__feq__feq__axiom_cloned_implies_eq_owned_0
))))

;; Broadcast lib::vstdplus::feq::feq::axiom_strictly_cloned_implies_eq
(assert
 (=>
  (fuel_bool fuel%lib!vstdplus.feq.feq.axiom_strictly_cloned_implies_eq.)
  (forall ((T&. Dcr) (T& Type) (x! Poly) (y! Poly)) (!
    (=>
     (and
      (has_type x! T&)
      (has_type y! T&)
     )
     (=>
      (and
       (and
        (and
         (and
          (sized T&.)
          (tr_bound%core!cmp.Eq. T&. T&)
         )
         (tr_bound%core!clone.Clone. T&. T&)
        )
        (vstd!pervasive.strictly_cloned.? T&. T& x! y!)
       )
       (lib!vstdplus.feq.feq.obeys_feq_clone.? T&. T&)
      )
      (= x! y!)
    ))
    :pattern ((vstd!pervasive.strictly_cloned.? T&. T& x! y!))
    :qid user_lib__vstdplus__feq__feq__axiom_strictly_cloned_implies_eq_0
    :skolemid skolem_user_lib__vstdplus__feq__feq__axiom_strictly_cloned_implies_eq_0
))))

;; Broadcast lib::vstdplus::feq::feq::axiom_strictly_cloned_implies_eq_owned
(assert
 (=>
  (fuel_bool fuel%lib!vstdplus.feq.feq.axiom_strictly_cloned_implies_eq_owned.)
  (forall ((T&. Dcr) (T& Type) (x! Poly) (y! Poly)) (!
    (=>
     (and
      (has_type x! T&)
      (has_type y! T&)
     )
     (=>
      (and
       (and
        (and
         (and
          (sized T&.)
          (tr_bound%core!cmp.Eq. T&. T&)
         )
         (tr_bound%core!clone.Clone. T&. T&)
        )
        (vstd!pervasive.strictly_cloned.? T&. T& x! y!)
       )
       (lib!vstdplus.feq.feq.obeys_feq_clone.? T&. T&)
      )
      (= x! y!)
    ))
    :pattern ((vstd!pervasive.strictly_cloned.? T&. T& x! y!))
    :qid user_lib__vstdplus__feq__feq__axiom_strictly_cloned_implies_eq_owned_0
    :skolemid skolem_user_lib__vstdplus__feq__feq__axiom_strictly_cloned_implies_eq_owned_0
))))

;; Trait-Impl-Axiom
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.Fn. F&. F& A&. A&)
    )
    (tr_bound%core!ops.function.FnOnce. (REF F&.) F& A&. A&)
   )
   :pattern ((tr_bound%core!ops.function.FnOnce. (REF F&.) F& A&. A&))
   :qid internal_core__ops__function__impls__impl&__2_trait_impl_definition
   :skolemid skolem_internal_core__ops__function__impls__impl&__2_trait_impl_definition
)))

;; Function-Axioms vstd::pervasive::FnWithRequiresEnsures::requires
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (Args&. Dcr) (Args& Type) (Output&. Dcr) (Output&
    Type
   ) (self! Poly) (args! Poly)
  ) (!
   (=>
    (and
     (has_type self! Self%&)
     (has_type args! Args&)
    )
    (has_type (vstd!pervasive.FnWithRequiresEnsures.requires.? Self%&. Self%& Args&. Args&
      Output&. Output& self! args!
     ) BOOL
   ))
   :pattern ((vstd!pervasive.FnWithRequiresEnsures.requires.? Self%&. Self%& Args&. Args&
     Output&. Output& self! args!
   ))
   :qid internal_vstd!pervasive.FnWithRequiresEnsures.requires.?_pre_post_definition
   :skolemid skolem_internal_vstd!pervasive.FnWithRequiresEnsures.requires.?_pre_post_definition
)))

;; Function-Axioms vstd::pervasive::FnWithRequiresEnsures::ensures
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (Args&. Dcr) (Args& Type) (Output&. Dcr) (Output&
    Type
   ) (self! Poly) (args! Poly) (output! Poly)
  ) (!
   (=>
    (and
     (has_type self! Self%&)
     (has_type args! Args&)
     (has_type output! Output&)
    )
    (has_type (vstd!pervasive.FnWithRequiresEnsures.ensures.? Self%&. Self%& Args&. Args&
      Output&. Output& self! args! output!
     ) BOOL
   ))
   :pattern ((vstd!pervasive.FnWithRequiresEnsures.ensures.? Self%&. Self%& Args&. Args&
     Output&. Output& self! args! output!
   ))
   :qid internal_vstd!pervasive.FnWithRequiresEnsures.ensures.?_pre_post_definition
   :skolemid skolem_internal_vstd!pervasive.FnWithRequiresEnsures.ensures.?_pre_post_definition
)))

;; Function-Axioms vstd::pervasive::impl&%0::requires
(assert
 (fuel_bool_default fuel%vstd!pervasive.impl&%0.requires.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!pervasive.impl&%0.requires.)
  (forall ((Args&. Dcr) (Args& Type) (Output&. Dcr) (Output& Type) (F&. Dcr) (F& Type)
    (self! Poly) (args! Poly)
   ) (!
    (=>
     (and
      (and
       (= Output&. (proj%%core!ops.function.FnOnce./Output F&. F& Args&. Args&))
       (= Output& (proj%core!ops.function.FnOnce./Output F&. F& Args&. Args&))
      )
      (sized Output&.)
      (sized F&.)
      (tr_bound%core!marker.Tuple. Args&. Args&)
      (tr_bound%core!ops.function.FnOnce. F&. F& Args&. Args&)
      (sized Args&.)
     )
     (= (vstd!pervasive.FnWithRequiresEnsures.requires.? F&. F& Args&. Args& Output&. Output&
       self! args!
      ) (B (closure_req F& Args&. Args& self! args!))
    ))
    :pattern ((vstd!pervasive.FnWithRequiresEnsures.requires.? F&. F& Args&. Args& Output&.
      Output& self! args!
    ))
    :qid internal_vstd!pervasive.impl&__0.requires.?_definition
    :skolemid skolem_internal_vstd!pervasive.impl&__0.requires.?_definition
))))

;; Function-Axioms vstd::pervasive::impl&%0::ensures
(assert
 (fuel_bool_default fuel%vstd!pervasive.impl&%0.ensures.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!pervasive.impl&%0.ensures.)
  (forall ((Args&. Dcr) (Args& Type) (Output&. Dcr) (Output& Type) (F&. Dcr) (F& Type)
    (self! Poly) (args! Poly) (output! Poly)
   ) (!
    (=>
     (and
      (and
       (= Output&. (proj%%core!ops.function.FnOnce./Output F&. F& Args&. Args&))
       (= Output& (proj%core!ops.function.FnOnce./Output F&. F& Args&. Args&))
      )
      (sized Output&.)
      (sized F&.)
      (tr_bound%core!marker.Tuple. Args&. Args&)
      (tr_bound%core!ops.function.FnOnce. F&. F& Args&. Args&)
      (sized Args&.)
     )
     (= (vstd!pervasive.FnWithRequiresEnsures.ensures.? F&. F& Args&. Args& Output&. Output&
       self! args! output!
      ) (B (closure_ens F& Args&. Args& self! args! output!))
    ))
    :pattern ((vstd!pervasive.FnWithRequiresEnsures.ensures.? F&. F& Args&. Args& Output&.
      Output& self! args! output!
    ))
    :qid internal_vstd!pervasive.impl&__0.ensures.?_definition
    :skolemid skolem_internal_vstd!pervasive.impl&__0.ensures.?_definition
))))

;; Trait-Impl-Axiom
(assert
 (forall ((Args&. Dcr) (Args& Type) (Output&. Dcr) (Output& Type) (F&. Dcr) (F& Type))
  (!
   (=>
    (and
     (and
      (= Output&. (proj%%core!ops.function.FnOnce./Output F&. F& Args&. Args&))
      (= Output& (proj%core!ops.function.FnOnce./Output F&. F& Args&. Args&))
     )
     (sized Output&.)
     (sized F&.)
     (tr_bound%core!marker.Tuple. Args&. Args&)
     (tr_bound%core!ops.function.FnOnce. F&. F& Args&. Args&)
     (sized Args&.)
    )
    (tr_bound%vstd!pervasive.FnWithRequiresEnsures. F&. F& Args&. Args& Output&. Output&)
   )
   :pattern ((tr_bound%vstd!pervasive.FnWithRequiresEnsures. F&. F& Args&. Args& Output&.
     Output&
   ))
   :qid internal_vstd__pervasive__impl&__0_trait_impl_definition
   :skolemid skolem_internal_vstd__pervasive__impl&__0_trait_impl_definition
)))

;; Function-Specs alloc::vec::impl&%1::len
(declare-fun ens%alloc!vec.impl&%1.len. (Dcr Type Dcr Type Poly Int) Bool)
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type) (vec! Poly) (len! Int)) (!
   (= (ens%alloc!vec.impl&%1.len. T&. T& A&. A& vec! len!) (and
     (uInv SZ len!)
     (= len! (vstd!std_specs.vec.spec_vec_len.? T&. T& A&. A& vec!))
   ))
   :pattern ((ens%alloc!vec.impl&%1.len. T&. T& A&. A& vec! len!))
   :qid internal_ens__alloc!vec.impl&__1.len._definition
   :skolemid skolem_internal_ens__alloc!vec.impl&__1.len._definition
)))

;; Function-Specs vstd::std_specs::vec::vec_index
(declare-fun req%vstd!std_specs.vec.vec_index. (Dcr Type Dcr Type Poly Int) Bool)
(declare-const %%global_location_label%%11 Bool)
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type) (vec! Poly) (i! Int)) (!
   (= (req%vstd!std_specs.vec.vec_index. T&. T& A&. A& vec! i!) (=>
     %%global_location_label%%11
     (< i! (vstd!seq.Seq.len.? T&. T& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. T&. T&
         A&. A&
        ) vec!
   )))))
   :pattern ((req%vstd!std_specs.vec.vec_index. T&. T& A&. A& vec! i!))
   :qid internal_req__vstd!std_specs.vec.vec_index._definition
   :skolemid skolem_internal_req__vstd!std_specs.vec.vec_index._definition
)))
(declare-fun ens%vstd!std_specs.vec.vec_index. (Dcr Type Dcr Type Poly Int Poly) Bool)
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type) (vec! Poly) (i! Int) (element! Poly))
  (!
   (= (ens%vstd!std_specs.vec.vec_index. T&. T& A&. A& vec! i! element!) (and
     (has_type element! T&)
     (= element! (vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec.
         T&. T& A&. A&
        ) vec!
       ) (I i!)
   ))))
   :pattern ((ens%vstd!std_specs.vec.vec_index. T&. T& A&. A& vec! i! element!))
   :qid internal_ens__vstd!std_specs.vec.vec_index._definition
   :skolemid skolem_internal_ens__vstd!std_specs.vec.vec_index._definition
)))

;; Function-Specs alloc::vec::impl&%43::push
(declare-fun ens%alloc!vec.impl&%43.push. (Dcr Type Dcr Type Poly Poly) Bool)
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type) (vec! Poly) (value! Poly)) (!
   (= (ens%alloc!vec.impl&%43.push. T&. T& A&. A& vec! value!) (= (vstd!view.View.view.?
      $ (TYPE%alloc!vec.Vec. T&. T& A&. A&) (mut_ref_future% vec!)
     ) (vstd!seq.Seq.push.? T&. T& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. T&. T& A&.
        A&
       ) (mut_ref_current% vec!)
      ) value!
   )))
   :pattern ((ens%alloc!vec.impl&%43.push. T&. T& A&. A& vec! value!))
   :qid internal_ens__alloc!vec.impl&__43.push._definition
   :skolemid skolem_internal_ens__alloc!vec.impl&__43.push._definition
)))

;; Function-Axioms lib::Chap19::ArraySeqMtEphSlice::ArraySeqMtEphSlice::ArraySeqMtEphSliceTrait::spec_arrayseqmtephslice_wf
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (T&. Dcr) (T& Type) (self! Poly)) (!
   (=>
    (has_type self! Self%&)
    (has_type (lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceTrait.spec_arrayseqmtephslice_wf.?
      Self%&. Self%& T&. T& self!
     ) BOOL
   ))
   :pattern ((lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceTrait.spec_arrayseqmtephslice_wf.?
     Self%&. Self%& T&. T& self!
   ))
   :qid internal_lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceTrait.spec_arrayseqmtephslice_wf.?_pre_post_definition
   :skolemid skolem_internal_lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceTrait.spec_arrayseqmtephslice_wf.?_pre_post_definition
)))

;; Function-Axioms lib::Chap19::ArraySeqMtEphSlice::ArraySeqMtEphSlice::ArraySeqMtEphSliceTrait::spec_len
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (T&. Dcr) (T& Type) (self! Poly)) (!
   (=>
    (has_type self! Self%&)
    (has_type (lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceTrait.spec_len.?
      Self%&. Self%& T&. T& self!
     ) NAT
   ))
   :pattern ((lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceTrait.spec_len.?
     Self%&. Self%& T&. T& self!
   ))
   :qid internal_lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceTrait.spec_len.?_pre_post_definition
   :skolemid skolem_internal_lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceTrait.spec_len.?_pre_post_definition
)))

;; Function-Specs lib::Chap19::ArraySeqMtEphSlice::ArraySeqMtEphSlice::ArraySeqMtEphSliceTrait::spec_index
(declare-fun req%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceTrait.spec_index.
 (Dcr Type Dcr Type Poly Poly) Bool
)
(declare-const %%global_location_label%%12 Bool)
(declare-const %%global_location_label%%13 Bool)
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (T&. Dcr) (T& Type) (self! Poly) (i! Poly)) (
   !
   (= (req%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceTrait.spec_index.
     Self%&. Self%& T&. T& self! i!
    ) (and
     (=>
      %%global_location_label%%12
      (%B (lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceTrait.spec_arrayseqmtephslice_wf.?
        Self%&. Self%& T&. T& self!
     )))
     (=>
      %%global_location_label%%13
      (< (%I i!) (%I (lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceTrait.spec_len.?
         Self%&. Self%& T&. T& self!
   ))))))
   :pattern ((req%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceTrait.spec_index.
     Self%&. Self%& T&. T& self! i!
   ))
   :qid internal_req__lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceTrait.spec_index._definition
   :skolemid skolem_internal_req__lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceTrait.spec_index._definition
)))

;; Function-Axioms lib::Chap19::ArraySeqMtEphSlice::ArraySeqMtEphSlice::ArraySeqMtEphSliceTrait::spec_index
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (T&. Dcr) (T& Type) (self! Poly) (i! Poly)) (
   !
   (=>
    (and
     (has_type self! Self%&)
     (has_type i! INT)
    )
    (has_type (lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceTrait.spec_index.?
      Self%&. Self%& T&. T& self! i!
     ) T&
   ))
   :pattern ((lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceTrait.spec_index.?
     Self%&. Self%& T&. T& self! i!
   ))
   :qid internal_lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceTrait.spec_index.?_pre_post_definition
   :skolemid skolem_internal_lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceTrait.spec_index.?_pre_post_definition
)))

;; Function-Specs lib::Chap19::ArraySeqMtEphSlice::ArraySeqMtEphSlice::ArraySeqMtEphSliceTrait::length
(declare-fun req%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceTrait.length.
 (Dcr Type Dcr Type Poly) Bool
)
(declare-const %%global_location_label%%14 Bool)
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (T&. Dcr) (T& Type) (self! Poly)) (!
   (= (req%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceTrait.length.
     Self%&. Self%& T&. T& self!
    ) (=>
     %%global_location_label%%14
     (%B (lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceTrait.spec_arrayseqmtephslice_wf.?
       Self%&. Self%& T&. T& self!
   ))))
   :pattern ((req%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceTrait.length.
     Self%&. Self%& T&. T& self!
   ))
   :qid internal_req__lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceTrait.length._definition
   :skolemid skolem_internal_req__lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceTrait.length._definition
)))
(declare-fun ens%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceTrait.length.
 (Dcr Type Dcr Type Poly Poly) Bool
)
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (T&. Dcr) (T& Type) (self! Poly) (len! Poly))
  (!
   (= (ens%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceTrait.length.
     Self%&. Self%& T&. T& self! len!
    ) (and
     (has_type len! USIZE)
     (= len! (lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceTrait.spec_len.?
       Self%&. Self%& T&. T& self!
   ))))
   :pattern ((ens%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceTrait.length.
     Self%&. Self%& T&. T& self! len!
   ))
   :qid internal_ens__lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceTrait.length._definition
   :skolemid skolem_internal_ens__lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceTrait.length._definition
)))

;; Function-Specs lib::Chap19::ArraySeqMtEphSlice::ArraySeqMtEphSlice::ArraySeqMtEphSliceTrait::nth_cloned
(declare-fun req%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceTrait.nth_cloned.
 (Dcr Type Dcr Type Poly Poly) Bool
)
(declare-const %%global_location_label%%15 Bool)
(declare-const %%global_location_label%%16 Bool)
(declare-const %%global_location_label%%17 Bool)
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (T&. Dcr) (T& Type) (self! Poly) (index! Poly))
  (!
   (= (req%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceTrait.nth_cloned.
     Self%&. Self%& T&. T& self! index!
    ) (and
     (=>
      %%global_location_label%%15
      (%B (lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceTrait.spec_arrayseqmtephslice_wf.?
        Self%&. Self%& T&. T& self!
     )))
     (=>
      %%global_location_label%%16
      (< (%I index!) (%I (lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceTrait.spec_len.?
         Self%&. Self%& T&. T& self!
     ))))
     (=>
      %%global_location_label%%17
      (lib!vstdplus.feq.feq.obeys_feq_clone.? T&. T&)
   )))
   :pattern ((req%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceTrait.nth_cloned.
     Self%&. Self%& T&. T& self! index!
   ))
   :qid internal_req__lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceTrait.nth_cloned._definition
   :skolemid skolem_internal_req__lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceTrait.nth_cloned._definition
)))
(declare-fun ens%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceTrait.nth_cloned.
 (Dcr Type Dcr Type Poly Poly Poly) Bool
)
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (T&. Dcr) (T& Type) (self! Poly) (index! Poly)
   (elem! Poly)
  ) (!
   (= (ens%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceTrait.nth_cloned.
     Self%&. Self%& T&. T& self! index! elem!
    ) (and
     (has_type elem! T&)
     (= elem! (lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceTrait.spec_index.?
       Self%&. Self%& T&. T& self! index!
   ))))
   :pattern ((ens%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceTrait.nth_cloned.
     Self%&. Self%& T&. T& self! index! elem!
   ))
   :qid internal_ens__lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceTrait.nth_cloned._definition
   :skolemid skolem_internal_ens__lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceTrait.nth_cloned._definition
)))

;; Function-Specs lib::Chap19::ArraySeqMtEphSlice::ArraySeqMtEphSlice::ArraySeqMtEphSliceTrait::slice
(declare-fun req%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceTrait.slice.
 (Dcr Type Dcr Type Poly Poly Poly) Bool
)
(declare-const %%global_location_label%%18 Bool)
(declare-const %%global_location_label%%19 Bool)
(declare-const %%global_location_label%%20 Bool)
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (T&. Dcr) (T& Type) (self! Poly) (start! Poly)
   (length! Poly)
  ) (!
   (= (req%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceTrait.slice.
     Self%&. Self%& T&. T& self! start! length!
    ) (and
     (=>
      %%global_location_label%%18
      (%B (lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceTrait.spec_arrayseqmtephslice_wf.?
        Self%&. Self%& T&. T& self!
     )))
     (=>
      %%global_location_label%%19
      (<= (Add (%I start!) (%I length!)) (- (uHi SZ) 1))
     )
     (=>
      %%global_location_label%%20
      (<= (Add (%I start!) (%I length!)) (%I (lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceTrait.spec_len.?
         Self%&. Self%& T&. T& self!
   ))))))
   :pattern ((req%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceTrait.slice.
     Self%&. Self%& T&. T& self! start! length!
   ))
   :qid internal_req__lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceTrait.slice._definition
   :skolemid skolem_internal_req__lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceTrait.slice._definition
)))
(declare-fun ens%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceTrait.slice.
 (Dcr Type Dcr Type Poly Poly Poly Poly) Bool
)
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (T&. Dcr) (T& Type) (self! Poly) (start! Poly)
   (length! Poly) (sliced! Poly)
  ) (!
   (= (ens%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceTrait.slice.
     Self%&. Self%& T&. T& self! start! length! sliced!
    ) (and
     (has_type sliced! Self%&)
     (%B (lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceTrait.spec_arrayseqmtephslice_wf.?
       Self%&. Self%& T&. T& sliced!
     ))
     (= (lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceTrait.spec_len.?
       Self%&. Self%& T&. T& sliced!
      ) length!
     )
     (forall ((i$ Poly)) (!
       (=>
        (has_type i$ INT)
        (=>
         (let
          ((tmp%%$ 0))
          (let
           ((tmp%%$1 (%I i$)))
           (let
            ((tmp%%$2 (%I length!)))
            (and
             (<= tmp%%$ tmp%%$1)
             (< tmp%%$1 tmp%%$2)
         ))))
         (= (lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceTrait.spec_index.?
           Self%&. Self%& T&. T& sliced! i$
          ) (lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceTrait.spec_index.?
           Self%&. Self%& T&. T& self! (I (Add (%I start!) (%I i$)))
       ))))
       :pattern ((lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceTrait.spec_index.?
         Self%&. Self%& T&. T& sliced! i$
       ))
       :qid user_lib__Chap19__ArraySeqMtEphSlice__ArraySeqMtEphSlice__ArraySeqMtEphSliceTrait__slice_0
       :skolemid skolem_user_lib__Chap19__ArraySeqMtEphSlice__ArraySeqMtEphSlice__ArraySeqMtEphSliceTrait__slice_0
   ))))
   :pattern ((ens%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceTrait.slice.
     Self%&. Self%& T&. T& self! start! length! sliced!
   ))
   :qid internal_ens__lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceTrait.slice._definition
   :skolemid skolem_internal_ens__lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceTrait.slice._definition
)))

;; Function-Specs lib::Chap19::ArraySeqMtEphSlice::ArraySeqMtEphSlice::ArraySeqMtEphSliceTrait::from_vec
(declare-fun ens%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceTrait.from_vec.
 (Dcr Type Dcr Type Poly Poly) Bool
)
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (T&. Dcr) (T& Type) (data! Poly) (seq! Poly))
  (!
   (= (ens%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceTrait.from_vec.
     Self%&. Self%& T&. T& data! seq!
    ) (and
     (has_type seq! Self%&)
     (%B (lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceTrait.spec_arrayseqmtephslice_wf.?
       Self%&. Self%& T&. T& seq!
     ))
     (= (%I (lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceTrait.spec_len.?
        Self%&. Self%& T&. T& seq!
       )
      ) (vstd!seq.Seq.len.? T&. T& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. T&. T& $
         TYPE%alloc!alloc.Global.
        ) data!
     )))
     (forall ((i$ Poly)) (!
       (=>
        (has_type i$ INT)
        (=>
         (let
          ((tmp%%$ 0))
          (let
           ((tmp%%$1 (%I i$)))
           (let
            ((tmp%%$2 (vstd!seq.Seq.len.? T&. T& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. T&.
                 T& $ TYPE%alloc!alloc.Global.
                ) data!
            ))))
            (and
             (<= tmp%%$ tmp%%$1)
             (< tmp%%$1 tmp%%$2)
         ))))
         (= (lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceTrait.spec_index.?
           Self%&. Self%& T&. T& seq! i$
          ) (vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. T&. T&
             $ TYPE%alloc!alloc.Global.
            ) data!
           ) i$
       ))))
       :pattern ((lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceTrait.spec_index.?
         Self%&. Self%& T&. T& seq! i$
       ))
       :qid user_lib__Chap19__ArraySeqMtEphSlice__ArraySeqMtEphSlice__ArraySeqMtEphSliceTrait__from_vec_0
       :skolemid skolem_user_lib__Chap19__ArraySeqMtEphSlice__ArraySeqMtEphSlice__ArraySeqMtEphSliceTrait__from_vec_0
   ))))
   :pattern ((ens%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceTrait.from_vec.
     Self%&. Self%& T&. T& data! seq!
   ))
   :qid internal_ens__lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceTrait.from_vec._definition
   :skolemid skolem_internal_ens__lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceTrait.from_vec._definition
)))

;; Function-Axioms vstd::relations::reflexive
(assert
 (fuel_bool_default fuel%vstd!relations.reflexive.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!relations.reflexive.)
  (forall ((T&. Dcr) (T& Type) (r! Poly)) (!
    (= (vstd!relations.reflexive.? T&. T& r!) (forall ((x$ Poly)) (!
       (=>
        (has_type x$ T&)
        (%B (%%apply%%1 (%Poly%fun%2. r!) x$ x$))
       )
       :pattern ((%%apply%%1 (%Poly%fun%2. r!) x$ x$))
       :qid user_vstd__relations__reflexive_0
       :skolemid skolem_user_vstd__relations__reflexive_0
    )))
    :pattern ((vstd!relations.reflexive.? T&. T& r!))
    :qid internal_vstd!relations.reflexive.?_definition
    :skolemid skolem_internal_vstd!relations.reflexive.?_definition
))))

;; Function-Axioms vstd::relations::antisymmetric
(assert
 (fuel_bool_default fuel%vstd!relations.antisymmetric.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!relations.antisymmetric.)
  (forall ((T&. Dcr) (T& Type) (r! Poly)) (!
    (= (vstd!relations.antisymmetric.? T&. T& r!) (forall ((x$ Poly) (y$ Poly)) (!
       (=>
        (and
         (has_type x$ T&)
         (has_type y$ T&)
        )
        (=>
         (and
          (%B (%%apply%%1 (%Poly%fun%2. r!) x$ y$))
          (%B (%%apply%%1 (%Poly%fun%2. r!) y$ x$))
         )
         (= x$ y$)
       ))
       :pattern ((%%apply%%1 (%Poly%fun%2. r!) x$ y$) (%%apply%%1 (%Poly%fun%2. r!) y$ x$))
       :qid user_vstd__relations__antisymmetric_0
       :skolemid skolem_user_vstd__relations__antisymmetric_0
    )))
    :pattern ((vstd!relations.antisymmetric.? T&. T& r!))
    :qid internal_vstd!relations.antisymmetric.?_definition
    :skolemid skolem_internal_vstd!relations.antisymmetric.?_definition
))))

;; Function-Axioms vstd::relations::transitive
(assert
 (fuel_bool_default fuel%vstd!relations.transitive.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!relations.transitive.)
  (forall ((T&. Dcr) (T& Type) (r! Poly)) (!
    (= (vstd!relations.transitive.? T&. T& r!) (forall ((x$ Poly) (y$ Poly) (z$ Poly))
      (!
       (=>
        (and
         (has_type x$ T&)
         (has_type y$ T&)
         (has_type z$ T&)
        )
        (=>
         (and
          (%B (%%apply%%1 (%Poly%fun%2. r!) x$ y$))
          (%B (%%apply%%1 (%Poly%fun%2. r!) y$ z$))
         )
         (%B (%%apply%%1 (%Poly%fun%2. r!) x$ z$))
       ))
       :pattern ((%%apply%%1 (%Poly%fun%2. r!) x$ y$) (%%apply%%1 (%Poly%fun%2. r!) y$ z$))
       :qid user_vstd__relations__transitive_0
       :skolemid skolem_user_vstd__relations__transitive_0
    )))
    :pattern ((vstd!relations.transitive.? T&. T& r!))
    :qid internal_vstd!relations.transitive.?_definition
    :skolemid skolem_internal_vstd!relations.transitive.?_definition
))))

;; Function-Axioms vstd::relations::strongly_connected
(assert
 (fuel_bool_default fuel%vstd!relations.strongly_connected.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!relations.strongly_connected.)
  (forall ((T&. Dcr) (T& Type) (r! Poly)) (!
    (= (vstd!relations.strongly_connected.? T&. T& r!) (forall ((x$ Poly) (y$ Poly)) (!
       (=>
        (and
         (has_type x$ T&)
         (has_type y$ T&)
        )
        (or
         (%B (%%apply%%1 (%Poly%fun%2. r!) x$ y$))
         (%B (%%apply%%1 (%Poly%fun%2. r!) y$ x$))
       ))
       :pattern ((%%apply%%1 (%Poly%fun%2. r!) x$ y$) (%%apply%%1 (%Poly%fun%2. r!) y$ x$))
       :qid user_vstd__relations__strongly_connected_0
       :skolemid skolem_user_vstd__relations__strongly_connected_0
    )))
    :pattern ((vstd!relations.strongly_connected.? T&. T& r!))
    :qid internal_vstd!relations.strongly_connected.?_definition
    :skolemid skolem_internal_vstd!relations.strongly_connected.?_definition
))))

;; Function-Axioms vstd::relations::total_ordering
(assert
 (fuel_bool_default fuel%vstd!relations.total_ordering.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!relations.total_ordering.)
  (forall ((T&. Dcr) (T& Type) (r! Poly)) (!
    (= (vstd!relations.total_ordering.? T&. T& r!) (and
      (and
       (and
        (vstd!relations.reflexive.? T&. T& r!)
        (vstd!relations.antisymmetric.? T&. T& r!)
       )
       (vstd!relations.transitive.? T&. T& r!)
      )
      (vstd!relations.strongly_connected.? T&. T& r!)
    ))
    :pattern ((vstd!relations.total_ordering.? T&. T& r!))
    :qid internal_vstd!relations.total_ordering.?_definition
    :skolemid skolem_internal_vstd!relations.total_ordering.?_definition
))))

;; Function-Specs vstd::seq_lib::impl&%0::sort_by
(declare-fun req%vstd!seq_lib.impl&%0.sort_by. (Dcr Type Poly Poly) Bool)
(declare-const %%global_location_label%%21 Bool)
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly) (leq! Poly)) (!
   (= (req%vstd!seq_lib.impl&%0.sort_by. A&. A& self! leq!) (=>
     %%global_location_label%%21
     (vstd!relations.total_ordering.? A&. A& leq!)
   ))
   :pattern ((req%vstd!seq_lib.impl&%0.sort_by. A&. A& self! leq!))
   :qid internal_req__vstd!seq_lib.impl&__0.sort_by._definition
   :skolemid skolem_internal_req__vstd!seq_lib.impl&__0.sort_by._definition
)))

;; Function-Axioms vstd::seq_lib::impl&%0::sort_by
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly) (leq! Poly)) (!
   (=>
    (and
     (has_type self! (TYPE%vstd!seq.Seq. A&. A&))
     (has_type leq! (TYPE%fun%2. A&. A& A&. A& $ BOOL))
    )
    (has_type (vstd!seq_lib.impl&%0.sort_by.? A&. A& self! leq!) (TYPE%vstd!seq.Seq. A&.
      A&
   )))
   :pattern ((vstd!seq_lib.impl&%0.sort_by.? A&. A& self! leq!))
   :qid internal_vstd!seq_lib.impl&__0.sort_by.?_pre_post_definition
   :skolemid skolem_internal_vstd!seq_lib.impl&__0.sort_by.?_pre_post_definition
)))

;; Trait-Impl-Axiom
(assert
 (tr_bound%core!clone.Clone. $ TYPE%alloc!alloc.Global.)
)

;; Function-Specs alloc::vec::impl&%12::clone
(declare-fun ens%alloc!vec.impl&%12.clone. (Dcr Type Dcr Type Poly Poly) Bool)
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type) (vec! Poly) (res! Poly)) (!
   (= (ens%alloc!vec.impl&%12.clone. T&. T& A&. A& vec! res!) (and
     (ens%core!clone.Clone.clone. $ (TYPE%alloc!vec.Vec. T&. T& A&. A&) vec! res!)
     (= (vstd!std_specs.vec.spec_vec_len.? T&. T& A&. A& res!) (vstd!std_specs.vec.spec_vec_len.?
       T&. T& A&. A& vec!
     ))
     (forall ((i$ Poly)) (!
       (=>
        (has_type i$ INT)
        (=>
         (let
          ((tmp%%$ 0))
          (let
           ((tmp%%$1 (%I i$)))
           (let
            ((tmp%%$2 (vstd!std_specs.vec.spec_vec_len.? T&. T& A&. A& vec!)))
            (and
             (<= tmp%%$ tmp%%$1)
             (< tmp%%$1 tmp%%$2)
         ))))
         (vstd!pervasive.cloned.? T&. T& (vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.?
            $ (TYPE%alloc!vec.Vec. T&. T& A&. A&) vec!
           ) i$
          ) (vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. T&. T&
             A&. A&
            ) res!
           ) i$
       ))))
       :pattern ((vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec.
           T&. T& A&. A&
          ) vec!
         ) i$
       ))
       :pattern ((vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec.
           T&. T& A&. A&
          ) res!
         ) i$
       ))
       :pattern ((vstd!pervasive.cloned.? T&. T& (vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.?
           $ (TYPE%alloc!vec.Vec. T&. T& A&. A&) vec!
          ) i$
         ) (vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. T&. T&
            A&. A&
           ) res!
          ) i$
       )))
       :qid user_alloc__vec__impl&%12__clone_0
       :skolemid skolem_user_alloc__vec__impl&%12__clone_0
     ))
     (vstd!std_specs.vec.vec_clone_trigger.? T&. T& A&. A& vec! res!)
     (=>
      (ext_eq false (TYPE%vstd!seq.Seq. T&. T&) (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec.
         T&. T& A&. A&
        ) vec!
       ) (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. T&. T& A&. A&) res!)
      )
      (= (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. T&. T& A&. A&) vec!) (vstd!view.View.view.?
        $ (TYPE%alloc!vec.Vec. T&. T& A&. A&) res!
   )))))
   :pattern ((ens%alloc!vec.impl&%12.clone. T&. T& A&. A& vec! res!))
   :qid internal_ens__alloc!vec.impl&__12.clone._definition
   :skolemid skolem_internal_ens__alloc!vec.impl&__12.clone._definition
)))
(assert
 (forall ((closure%$ Poly) (res$ Poly) (T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (has_type closure%$ (TYPE%tuple%1. (REF $) (TYPE%alloc!vec.Vec. T&. T& A&. A&)))
     (has_type res$ (TYPE%alloc!vec.Vec. T&. T& A&. A&))
    )
    (=>
     (closure_ens (FNDEF%core!clone.Clone.clone. $ (TYPE%alloc!vec.Vec. T&. T& A&. A&))
      (DST (REF $)) (TYPE%tuple%1. (REF $) (TYPE%alloc!vec.Vec. T&. T& A&. A&)) (F fndef_singleton)
      closure%$ res$
     )
     (let
      ((vec$ (tuple%1./tuple%1/0 (%Poly%tuple%1. closure%$))))
      (and
       (and
        (and
         (= (vstd!std_specs.vec.spec_vec_len.? T&. T& A&. A& res$) (vstd!std_specs.vec.spec_vec_len.?
           T&. T& A&. A& vec$
         ))
         (forall ((i$ Poly)) (!
           (=>
            (has_type i$ INT)
            (=>
             (let
              ((tmp%%$ 0))
              (let
               ((tmp%%$1 (%I i$)))
               (let
                ((tmp%%$2 (vstd!std_specs.vec.spec_vec_len.? T&. T& A&. A& vec$)))
                (and
                 (<= tmp%%$ tmp%%$1)
                 (< tmp%%$1 tmp%%$2)
             ))))
             (vstd!pervasive.cloned.? T&. T& (vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.?
                $ (TYPE%alloc!vec.Vec. T&. T& A&. A&) vec$
               ) i$
              ) (vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. T&. T&
                 A&. A&
                ) res$
               ) i$
           ))))
           :pattern ((vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec.
               T&. T& A&. A&
              ) vec$
             ) i$
           ))
           :pattern ((vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec.
               T&. T& A&. A&
              ) res$
             ) i$
           ))
           :pattern ((vstd!pervasive.cloned.? T&. T& (vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.?
               $ (TYPE%alloc!vec.Vec. T&. T& A&. A&) vec$
              ) i$
             ) (vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. T&. T&
                A&. A&
               ) res$
              ) i$
           )))
           :qid user_alloc__vec__impl&%12__clone_1
           :skolemid skolem_user_alloc__vec__impl&%12__clone_1
        )))
        (vstd!std_specs.vec.vec_clone_trigger.? T&. T& A&. A& vec$ res$)
       )
       (=>
        (ext_eq false (TYPE%vstd!seq.Seq. T&. T&) (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec.
           T&. T& A&. A&
          ) vec$
         ) (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. T&. T& A&. A&) res$)
        )
        (= (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. T&. T& A&. A&) vec$) (vstd!view.View.view.?
          $ (TYPE%alloc!vec.Vec. T&. T& A&. A&) res$
   )))))))
   :pattern ((closure_ens (FNDEF%core!clone.Clone.clone. $ (TYPE%alloc!vec.Vec. T&. T& A&.
       A&
      )
     ) (DST (REF $)) (TYPE%tuple%1. (REF $) (TYPE%alloc!vec.Vec. T&. T& A&. A&)) (F fndef_singleton)
     closure%$ res$
   ))
   :qid user_alloc__vec__impl&%12__clone_2
   :skolemid skolem_user_alloc__vec__impl&%12__clone_2
)))

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized T&.)
     (sized A&.)
     (tr_bound%core!clone.Clone. T&. T&)
     (tr_bound%core!alloc.Allocator. A&. A&)
     (tr_bound%core!clone.Clone. A&. A&)
    )
    (tr_bound%core!clone.Clone. $ (TYPE%alloc!vec.Vec. T&. T& A&. A&))
   )
   :pattern ((tr_bound%core!clone.Clone. $ (TYPE%alloc!vec.Vec. T&. T& A&. A&)))
   :qid internal_alloc__vec__impl&__12_trait_impl_definition
   :skolemid skolem_internal_alloc__vec__impl&__12_trait_impl_definition
)))

;; Function-Specs alloc::vec::impl&%0::new
(declare-fun ens%alloc!vec.impl&%0.new. (Dcr Type Poly) Bool)
(assert
 (forall ((T&. Dcr) (T& Type) (v! Poly)) (!
   (= (ens%alloc!vec.impl&%0.new. T&. T& v!) (and
     (has_type v! (TYPE%alloc!vec.Vec. T&. T& $ TYPE%alloc!alloc.Global.))
     (= (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. T&. T& $ TYPE%alloc!alloc.Global.)
       v!
      ) (vstd!seq.Seq.empty.? T&. T&)
   )))
   :pattern ((ens%alloc!vec.impl&%0.new. T&. T& v!))
   :qid internal_ens__alloc!vec.impl&__0.new._definition
   :skolemid skolem_internal_ens__alloc!vec.impl&__0.new._definition
)))

;; Function-Axioms lib::Chap19::ArraySeqMtEph::ArraySeqMtEph::ArraySeqMtEphTrait::spec_len
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (T&. Dcr) (T& Type) (self! Poly)) (!
   (=>
    (has_type self! Self%&)
    (has_type (lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphTrait.spec_len.? Self%&.
      Self%& T&. T& self!
     ) NAT
   ))
   :pattern ((lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphTrait.spec_len.? Self%&.
     Self%& T&. T& self!
   ))
   :qid internal_lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphTrait.spec_len.?_pre_post_definition
   :skolemid skolem_internal_lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphTrait.spec_len.?_pre_post_definition
)))

;; Function-Specs lib::Chap19::ArraySeqMtEph::ArraySeqMtEph::ArraySeqMtEphTrait::spec_index
(declare-fun req%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphTrait.spec_index.
 (Dcr Type Dcr Type Poly Poly) Bool
)
(declare-const %%global_location_label%%22 Bool)
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (T&. Dcr) (T& Type) (self! Poly) (i! Poly)) (
   !
   (= (req%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphTrait.spec_index. Self%&.
     Self%& T&. T& self! i!
    ) (=>
     %%global_location_label%%22
     (< (%I i!) (%I (lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphTrait.spec_len.?
        Self%&. Self%& T&. T& self!
   )))))
   :pattern ((req%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphTrait.spec_index.
     Self%&. Self%& T&. T& self! i!
   ))
   :qid internal_req__lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphTrait.spec_index._definition
   :skolemid skolem_internal_req__lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphTrait.spec_index._definition
)))

;; Function-Axioms lib::Chap19::ArraySeqMtEph::ArraySeqMtEph::ArraySeqMtEphTrait::spec_index
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (T&. Dcr) (T& Type) (self! Poly) (i! Poly)) (
   !
   (=>
    (and
     (has_type self! Self%&)
     (has_type i! INT)
    )
    (has_type (lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphTrait.spec_index.? Self%&.
      Self%& T&. T& self! i!
     ) T&
   ))
   :pattern ((lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphTrait.spec_index.? Self%&.
     Self%& T&. T& self! i!
   ))
   :qid internal_lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphTrait.spec_index.?_pre_post_definition
   :skolemid skolem_internal_lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphTrait.spec_index.?_pre_post_definition
)))

;; Function-Specs lib::Chap19::ArraySeqMtEph::ArraySeqMtEph::ArraySeqMtEphTrait::length
(declare-fun ens%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphTrait.length.
 (Dcr Type Dcr Type Poly Poly) Bool
)
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (T&. Dcr) (T& Type) (self! Poly) (len! Poly))
  (!
   (= (ens%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphTrait.length. Self%&. Self%&
     T&. T& self! len!
    ) (and
     (has_type len! USIZE)
     (= len! (lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphTrait.spec_len.? Self%&.
       Self%& T&. T& self!
   ))))
   :pattern ((ens%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphTrait.length. Self%&.
     Self%& T&. T& self! len!
   ))
   :qid internal_ens__lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphTrait.length._definition
   :skolemid skolem_internal_ens__lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphTrait.length._definition
)))

;; Function-Specs lib::Chap19::ArraySeqMtEph::ArraySeqMtEph::ArraySeqMtEphTrait::nth
(declare-fun req%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphTrait.nth. (Dcr
  Type Dcr Type Poly Poly
 ) Bool
)
(declare-const %%global_location_label%%23 Bool)
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (T&. Dcr) (T& Type) (self! Poly) (index! Poly))
  (!
   (= (req%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphTrait.nth. Self%&. Self%&
     T&. T& self! index!
    ) (=>
     %%global_location_label%%23
     (< (%I index!) (%I (lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphTrait.spec_len.?
        Self%&. Self%& T&. T& self!
   )))))
   :pattern ((req%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphTrait.nth. Self%&.
     Self%& T&. T& self! index!
   ))
   :qid internal_req__lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphTrait.nth._definition
   :skolemid skolem_internal_req__lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphTrait.nth._definition
)))
(declare-fun ens%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphTrait.nth. (Dcr
  Type Dcr Type Poly Poly Poly
 ) Bool
)
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (T&. Dcr) (T& Type) (self! Poly) (index! Poly)
   (nth_elem! Poly)
  ) (!
   (= (ens%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphTrait.nth. Self%&. Self%&
     T&. T& self! index! nth_elem!
    ) (and
     (has_type nth_elem! T&)
     (= nth_elem! (lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphTrait.spec_index.?
       Self%&. Self%& T&. T& self! index!
   ))))
   :pattern ((ens%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphTrait.nth. Self%&.
     Self%& T&. T& self! index! nth_elem!
   ))
   :qid internal_ens__lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphTrait.nth._definition
   :skolemid skolem_internal_ens__lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphTrait.nth._definition
)))

;; Function-Axioms lib::Chap19::ArraySeqMtEph::ArraySeqMtEph::ArraySeqMtEphS::spec_len
(assert
 (fuel_bool_default fuel%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.impl&%3.spec_len.)
)
(assert
 (=>
  (fuel_bool fuel%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.impl&%3.spec_len.)
  (forall ((T&. Dcr) (T& Type) (self! Poly)) (!
    (=>
     (sized T&.)
     (= (lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphTrait.spec_len.? $ (TYPE%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS.
        T&. T&
       ) T&. T& self!
      ) (I (vstd!seq.Seq.len.? T&. T& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. T&. T&
          $ TYPE%alloc!alloc.Global.
         ) (lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS./ArraySeqMtEphS/seq (%Poly%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS.
           self!
    )))))))
    :pattern ((lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphTrait.spec_len.? $ (
       TYPE%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS. T&. T&
      ) T&. T& self!
    ))
    :qid internal_lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.impl&__3.spec_len.?_definition
    :skolemid skolem_internal_lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.impl&__3.spec_len.?_definition
))))

;; Function-Axioms lib::Chap35::OrderStatSelectMtEph::OrderStatSelectMtEph::spec_leq
(assert
 (fuel_bool_default fuel%lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.spec_leq.)
)
(declare-fun %%lambda%%2 (Dcr Type) %%Function%%)
(assert
 (forall ((%%hole%%0 Dcr) (%%hole%%1 Type) (x$ Poly) (y$ Poly)) (!
   (= (%%apply%%1 (%%lambda%%2 %%hole%%0 %%hole%%1) x$ y$) (lib!vstdplus.total_order.total_order.TotalOrder.le.?
     %%hole%%0 %%hole%%1 x$ y$
   ))
   :pattern ((%%apply%%1 (%%lambda%%2 %%hole%%0 %%hole%%1) x$ y$))
)))
(assert
 (=>
  (fuel_bool fuel%lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.spec_leq.)
  (forall ((T&. Dcr) (T& Type)) (!
    (= (lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.spec_leq.? T&. T&) (mk_fun
      (%%lambda%%2 T&. T&)
    ))
    :pattern ((lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.spec_leq.? T&. T&))
    :qid internal_lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.spec_leq.?_definition
    :skolemid skolem_internal_lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.spec_leq.?_definition
))))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (has_type (Poly%fun%2. (lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.spec_leq.?
      T&. T&
     )
    ) (TYPE%fun%2. T&. T& T&. T& $ BOOL)
   )
   :pattern ((lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.spec_leq.? T&. T&))
   :qid internal_lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.spec_leq.?_pre_post_definition
   :skolemid skolem_internal_lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.spec_leq.?_pre_post_definition
)))

;; Function-Specs lib::Chap35::OrderStatSelectMtEph::OrderStatSelectMtEph::spec_kth
(declare-fun req%lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.spec_kth. (Dcr
  Type Poly Poly
 ) Bool
)
(declare-const %%global_location_label%%24 Bool)
(assert
 (forall ((T&. Dcr) (T& Type) (s! Poly) (k! Poly)) (!
   (= (req%lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.spec_kth. T&. T& s! k!)
    (=>
     %%global_location_label%%24
     (let
      ((tmp%%$ 0))
      (let
       ((tmp%%$1 (%I k!)))
       (let
        ((tmp%%$2 (vstd!seq.Seq.len.? T&. T& s!)))
        (and
         (<= tmp%%$ tmp%%$1)
         (< tmp%%$1 tmp%%$2)
   ))))))
   :pattern ((req%lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.spec_kth. T&. T&
     s! k!
   ))
   :qid internal_req__lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.spec_kth._definition
   :skolemid skolem_internal_req__lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.spec_kth._definition
)))

;; Function-Axioms lib::Chap35::OrderStatSelectMtEph::OrderStatSelectMtEph::spec_kth
(assert
 (fuel_bool_default fuel%lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.spec_kth.)
)
(assert
 (=>
  (fuel_bool fuel%lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.spec_kth.)
  (forall ((T&. Dcr) (T& Type) (s! Poly) (k! Poly)) (!
    (= (lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.spec_kth.? T&. T& s! k!)
     (vstd!seq.Seq.index.? T&. T& (vstd!seq_lib.impl&%0.sort_by.? T&. T& s! (Poly%fun%2.
        (lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.spec_leq.? T&. T&)
       )
      ) k!
    ))
    :pattern ((lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.spec_kth.? T&. T& s!
      k!
    ))
    :qid internal_lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.spec_kth.?_definition
    :skolemid skolem_internal_lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.spec_kth.?_definition
))))
(assert
 (forall ((T&. Dcr) (T& Type) (s! Poly) (k! Poly)) (!
   (=>
    (and
     (has_type s! (TYPE%vstd!seq.Seq. T&. T&))
     (has_type k! INT)
    )
    (has_type (lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.spec_kth.? T&. T& s!
      k!
     ) T&
   ))
   :pattern ((lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.spec_kth.? T&. T& s!
     k!
   ))
   :qid internal_lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.spec_kth.?_pre_post_definition
   :skolemid skolem_internal_lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.spec_kth.?_pre_post_definition
)))

;; Function-Axioms lib::Chap19::ArraySeqMtEph::ArraySeqMtEph::ArraySeqMtEphS::spec_index
(assert
 (fuel_bool_default fuel%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.impl&%3.spec_index.)
)
(assert
 (=>
  (fuel_bool fuel%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.impl&%3.spec_index.)
  (forall ((T&. Dcr) (T& Type) (self! Poly) (i! Poly)) (!
    (=>
     (sized T&.)
     (= (lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphTrait.spec_index.? $ (TYPE%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS.
        T&. T&
       ) T&. T& self! i!
      ) (vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. T&. T&
         $ TYPE%alloc!alloc.Global.
        ) (lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS./ArraySeqMtEphS/seq (%Poly%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS.
          self!
        ))
       ) i!
    )))
    :pattern ((lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphTrait.spec_index.? $
      (TYPE%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS. T&. T&) T&. T& self!
      i!
    ))
    :qid internal_lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.impl&__3.spec_index.?_definition
    :skolemid skolem_internal_lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.impl&__3.spec_index.?_definition
))))

;; Function-Specs lib::Chap02::HFSchedulerMtEph::HFSchedulerMtEph::join
(declare-fun req%lib!Chap02.HFSchedulerMtEph.HFSchedulerMtEph.join. (Dcr Type Dcr Type
  Dcr Type Dcr Type Poly Poly
 ) Bool
)
(declare-const %%global_location_label%%25 Bool)
(declare-const %%global_location_label%%26 Bool)
(assert
 (forall ((A&. Dcr) (A& Type) (B&. Dcr) (B& Type) (FA&. Dcr) (FA& Type) (FB&. Dcr) (
    FB& Type
   ) (fa! Poly) (fb! Poly)
  ) (!
   (= (req%lib!Chap02.HFSchedulerMtEph.HFSchedulerMtEph.join. A&. A& B&. B& FA&. FA& FB&.
     FB& fa! fb!
    ) (and
     (=>
      %%global_location_label%%25
      (closure_req FA& $ TYPE%tuple%0. fa! (Poly%tuple%0. tuple%0./tuple%0))
     )
     (=>
      %%global_location_label%%26
      (closure_req FB& $ TYPE%tuple%0. fb! (Poly%tuple%0. tuple%0./tuple%0))
   )))
   :pattern ((req%lib!Chap02.HFSchedulerMtEph.HFSchedulerMtEph.join. A&. A& B&. B& FA&.
     FA& FB&. FB& fa! fb!
   ))
   :qid internal_req__lib!Chap02.HFSchedulerMtEph.HFSchedulerMtEph.join._definition
   :skolemid skolem_internal_req__lib!Chap02.HFSchedulerMtEph.HFSchedulerMtEph.join._definition
)))
(declare-fun ens%lib!Chap02.HFSchedulerMtEph.HFSchedulerMtEph.join. (Dcr Type Dcr Type
  Dcr Type Dcr Type Poly Poly tuple%2.
 ) Bool
)
(assert
 (forall ((A&. Dcr) (A& Type) (B&. Dcr) (B& Type) (FA&. Dcr) (FA& Type) (FB&. Dcr) (
    FB& Type
   ) (fa! Poly) (fb! Poly) (joined_pair! tuple%2.)
  ) (!
   (= (ens%lib!Chap02.HFSchedulerMtEph.HFSchedulerMtEph.join. A&. A& B&. B& FA&. FA& FB&.
     FB& fa! fb! joined_pair!
    ) (and
     (has_type (Poly%tuple%2. joined_pair!) (TYPE%tuple%2. A&. A& B&. B&))
     (closure_ens FA& $ TYPE%tuple%0. fa! (Poly%tuple%0. tuple%0./tuple%0) (tuple%2./tuple%2/0
       (%Poly%tuple%2. (Poly%tuple%2. joined_pair!))
     ))
     (closure_ens FB& $ TYPE%tuple%0. fb! (Poly%tuple%0. tuple%0./tuple%0) (tuple%2./tuple%2/1
       (%Poly%tuple%2. (Poly%tuple%2. joined_pair!))
   ))))
   :pattern ((ens%lib!Chap02.HFSchedulerMtEph.HFSchedulerMtEph.join. A&. A& B&. B& FA&.
     FA& FB&. FB& fa! fb! joined_pair!
   ))
   :qid internal_ens__lib!Chap02.HFSchedulerMtEph.HFSchedulerMtEph.join._definition
   :skolemid skolem_internal_ens__lib!Chap02.HFSchedulerMtEph.HFSchedulerMtEph.join._definition
)))

;; Function-Specs vstd::seq_lib::lemma_multiset_commutative
(declare-fun ens%vstd!seq_lib.lemma_multiset_commutative. (Dcr Type Poly Poly) Bool)
(assert
 (forall ((A&. Dcr) (A& Type) (a! Poly) (b! Poly)) (!
   (= (ens%vstd!seq_lib.lemma_multiset_commutative. A&. A& a! b!) (ext_eq false (TYPE%vstd!multiset.Multiset.
      A&. A&
     ) (vstd!seq_lib.impl&%0.to_multiset.? A&. A& (vstd!seq.Seq.add.? A&. A& a! b!)) (
      vstd!multiset.impl&%0.add.? A&. A& (vstd!seq_lib.impl&%0.to_multiset.? A&. A& a!)
      (vstd!seq_lib.impl&%0.to_multiset.? A&. A& b!)
   )))
   :pattern ((ens%vstd!seq_lib.lemma_multiset_commutative. A&. A& a! b!))
   :qid internal_ens__vstd!seq_lib.lemma_multiset_commutative._definition
   :skolemid skolem_internal_ens__vstd!seq_lib.lemma_multiset_commutative._definition
)))

;; Broadcast vstd::seq_lib::lemma_multiset_commutative
(assert
 (=>
  (fuel_bool fuel%vstd!seq_lib.lemma_multiset_commutative.)
  (forall ((A&. Dcr) (A& Type) (a! Poly) (b! Poly)) (!
    (=>
     (and
      (has_type a! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type b! (TYPE%vstd!seq.Seq. A&. A&))
     )
     (=>
      (sized A&.)
      (ext_eq false (TYPE%vstd!multiset.Multiset. A&. A&) (vstd!seq_lib.impl&%0.to_multiset.?
        A&. A& (vstd!seq.Seq.add.? A&. A& a! b!)
       ) (vstd!multiset.impl&%0.add.? A&. A& (vstd!seq_lib.impl&%0.to_multiset.? A&. A& a!)
        (vstd!seq_lib.impl&%0.to_multiset.? A&. A& b!)
    ))))
    :pattern ((vstd!seq_lib.impl&%0.to_multiset.? A&. A& (vstd!seq.Seq.add.? A&. A& a! b!)))
    :qid user_vstd__seq_lib__lemma_multiset_commutative_0
    :skolemid skolem_user_vstd__seq_lib__lemma_multiset_commutative_0
))))

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (sized T&.)
    (tr_bound%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphTrait. $ (TYPE%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS.
      T&. T&
     ) T&. T&
   ))
   :pattern ((tr_bound%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphTrait. $ (TYPE%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS.
      T&. T&
     ) T&. T&
   ))
   :qid internal_lib__Chap19__ArraySeqMtEph__ArraySeqMtEph__impl&__3_trait_impl_definition
   :skolemid skolem_internal_lib__Chap19__ArraySeqMtEph__ArraySeqMtEph__impl&__3_trait_impl_definition
)))

;; Function-Specs lib::Chap35::OrderStatSelectMtEph::OrderStatSelectMtEph::OrderStatSelectMtEphTrait::select
(declare-fun req%lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.OrderStatSelectMtEphTrait.select.
 (Dcr Type Dcr Type Poly Poly) Bool
)
(declare-const %%global_location_label%%27 Bool)
(declare-const %%global_location_label%%28 Bool)
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (T&. Dcr) (T& Type) (a! Poly) (k! Poly)) (!
   (= (req%lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.OrderStatSelectMtEphTrait.select.
     Self%&. Self%& T&. T& a! k!
    ) (and
     (=>
      %%global_location_label%%27
      (<= (%I (lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphTrait.spec_len.? $ (TYPE%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS.
          T&. T&
         ) T&. T& a!
        )
       ) (- (uHi SZ) 1)
     ))
     (=>
      %%global_location_label%%28
      (lib!vstdplus.feq.feq.obeys_feq_clone.? T&. T&)
   )))
   :pattern ((req%lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.OrderStatSelectMtEphTrait.select.
     Self%&. Self%& T&. T& a! k!
   ))
   :qid internal_req__lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.OrderStatSelectMtEphTrait.select._definition
   :skolemid skolem_internal_req__lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.OrderStatSelectMtEphTrait.select._definition
)))
(declare-fun ens%lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.OrderStatSelectMtEphTrait.select.
 (Dcr Type Dcr Type Poly Poly Poly) Bool
)
(declare-fun %%lambda%%3 (Dcr Type Dcr Type Poly) %%Function%%)
(assert
 (forall ((%%hole%%0 Dcr) (%%hole%%1 Type) (%%hole%%2 Dcr) (%%hole%%3 Type) (%%hole%%4
    Poly
   ) (i$ Poly)
  ) (!
   (= (%%apply%%0 (%%lambda%%3 %%hole%%0 %%hole%%1 %%hole%%2 %%hole%%3 %%hole%%4) i$)
    (lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphTrait.spec_index.? %%hole%%0
     %%hole%%1 %%hole%%2 %%hole%%3 %%hole%%4 i$
   ))
   :pattern ((%%apply%%0 (%%lambda%%3 %%hole%%0 %%hole%%1 %%hole%%2 %%hole%%3 %%hole%%4)
     i$
)))))
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (T&. Dcr) (T& Type) (a! Poly) (k! Poly) (found!
    Poly
   )
  ) (!
   (= (ens%lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.OrderStatSelectMtEphTrait.select.
     Self%&. Self%& T&. T& a! k! found!
    ) (and
     (has_type found! (TYPE%core!option.Option. T&. T&))
     (=>
      (>= (%I k!) (%I (lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphTrait.spec_len.?
         $ (TYPE%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS. T&. T&) T&. T& a!
      )))
      (is-core!option.Option./None (%Poly%core!option.Option. found!))
     )
     (=>
      (< (%I k!) (%I (lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphTrait.spec_len.?
         $ (TYPE%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS. T&. T&) T&. T& a!
      )))
      (= (%Poly%core!option.Option. found!) (core!option.Option./Some (lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.spec_kth.?
         T&. T& (vstd!seq.Seq.new.? T&. T& (lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphTrait.spec_len.?
           $ (TYPE%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS. T&. T&) T&. T& a!
          ) (Poly%fun%1. (mk_fun (%%lambda%%3 $ (TYPE%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS.
              T&. T&
             ) T&. T& a!
          )))
         ) k!
   ))))))
   :pattern ((ens%lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.OrderStatSelectMtEphTrait.select.
     Self%&. Self%& T&. T& a! k! found!
   ))
   :qid internal_ens__lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.OrderStatSelectMtEphTrait.select._definition
   :skolemid skolem_internal_ens__lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.OrderStatSelectMtEphTrait.select._definition
)))

;; Function-Specs core::clone::impls::impl&%42::clone
(declare-fun ens%core!clone.impls.impl&%42.clone. (Poly Poly) Bool)
(assert
 (forall ((b! Poly) (%return! Poly)) (!
   (= (ens%core!clone.impls.impl&%42.clone. b! %return!) (and
     (ens%core!clone.Clone.clone. $ BOOL b! %return!)
     (= %return! b!)
   ))
   :pattern ((ens%core!clone.impls.impl&%42.clone. b! %return!))
   :qid internal_ens__core!clone.impls.impl&__42.clone._definition
   :skolemid skolem_internal_ens__core!clone.impls.impl&__42.clone._definition
)))
(assert
 (forall ((closure%$ Poly) (%return$ Poly)) (!
   (=>
    (and
     (has_type closure%$ (TYPE%tuple%1. (REF $) BOOL))
     (has_type %return$ BOOL)
    )
    (=>
     (closure_ens (FNDEF%core!clone.Clone.clone. $ BOOL) (DST (REF $)) (TYPE%tuple%1. (REF
        $
       ) BOOL
      ) (F fndef_singleton) closure%$ %return$
     )
     (let
      ((b$ (%B (tuple%1./tuple%1/0 (%Poly%tuple%1. closure%$)))))
      (= (%B %return$) b$)
   )))
   :pattern ((closure_ens (FNDEF%core!clone.Clone.clone. $ BOOL) (DST (REF $)) (TYPE%tuple%1.
      (REF $) BOOL
     ) (F fndef_singleton) closure%$ %return$
   ))
   :qid user_core__clone__impls__impl&%42__clone_0
   :skolemid skolem_user_core__clone__impls__impl&%42__clone_0
)))

;; Function-Specs core::clone::impls::impl&%6::clone
(declare-fun ens%core!clone.impls.impl&%6.clone. (Dcr Type Poly Poly) Bool)
(assert
 (forall ((T&. Dcr) (T& Type) (b! Poly) (res! Poly)) (!
   (= (ens%core!clone.impls.impl&%6.clone. T&. T& b! res!) (and
     (ens%core!clone.Clone.clone. (REF T&.) T& b! res!)
     (= res! b!)
   ))
   :pattern ((ens%core!clone.impls.impl&%6.clone. T&. T& b! res!))
   :qid internal_ens__core!clone.impls.impl&__6.clone._definition
   :skolemid skolem_internal_ens__core!clone.impls.impl&__6.clone._definition
)))
(assert
 (forall ((closure%$ Poly) (res$ Poly) (T&. Dcr) (T& Type)) (!
   (=>
    (and
     (has_type closure%$ (TYPE%tuple%1. (REF (REF T&.)) T&))
     (has_type res$ T&)
    )
    (=>
     (closure_ens (FNDEF%core!clone.Clone.clone. (REF T&.) T&) (DST (REF (REF T&.))) (TYPE%tuple%1.
       (REF (REF T&.)) T&
      ) (F fndef_singleton) closure%$ res$
     )
     (let
      ((b$ (tuple%1./tuple%1/0 (%Poly%tuple%1. closure%$))))
      (= res$ b$)
   )))
   :pattern ((closure_ens (FNDEF%core!clone.Clone.clone. (REF T&.) T&) (DST (REF (REF T&.)))
     (TYPE%tuple%1. (REF (REF T&.)) T&) (F fndef_singleton) closure%$ res$
   ))
   :qid user_core__clone__impls__impl&%6__clone_0
   :skolemid skolem_user_core__clone__impls__impl&%6__clone_0
)))

;; Function-Specs core::array::impl&%20::clone
(declare-fun ens%core!array.impl&%20.clone. (Dcr Type Dcr Type Poly Poly) Bool)
(assert
 (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type) (a! Poly) (res! Poly)) (!
   (= (ens%core!array.impl&%20.clone. T&. T& N&. N& a! res!) (and
     (ens%core!clone.Clone.clone. $ (ARRAY T&. T& N&. N&) a! res!)
     (forall ((i$ Poly)) (!
       (=>
        (has_type i$ INT)
        (=>
         (let
          ((tmp%%$ 0))
          (let
           ((tmp%%$1 (%I i$)))
           (let
            ((tmp%%$2 (const_int N&)))
            (and
             (<= tmp%%$ tmp%%$1)
             (< tmp%%$1 tmp%%$2)
         ))))
         (vstd!pervasive.cloned.? T&. T& (vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.?
            $ (ARRAY T&. T& N&. N&) a!
           ) i$
          ) (vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (ARRAY T&. T& N&. N&) res!)
           i$
       ))))
       :pattern ((vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (ARRAY T&. T& N&. N&)
          a!
         ) i$
       ))
       :pattern ((vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (ARRAY T&. T& N&. N&)
          res!
         ) i$
       ))
       :pattern ((vstd!pervasive.cloned.? T&. T& (vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.?
           $ (ARRAY T&. T& N&. N&) a!
          ) i$
         ) (vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (ARRAY T&. T& N&. N&) res!)
          i$
       )))
       :qid user_core__array__impl&%20__clone_0
       :skolemid skolem_user_core__array__impl&%20__clone_0
     ))
     (=>
      (ext_eq false (TYPE%vstd!seq.Seq. T&. T&) (vstd!view.View.view.? $ (ARRAY T&. T& N&.
         N&
        ) a!
       ) (vstd!view.View.view.? $ (ARRAY T&. T& N&. N&) res!)
      )
      (= (vstd!view.View.view.? $ (ARRAY T&. T& N&. N&) a!) (vstd!view.View.view.? $ (ARRAY
         T&. T& N&. N&
        ) res!
   )))))
   :pattern ((ens%core!array.impl&%20.clone. T&. T& N&. N& a! res!))
   :qid internal_ens__core!array.impl&__20.clone._definition
   :skolemid skolem_internal_ens__core!array.impl&__20.clone._definition
)))
(assert
 (forall ((closure%$ Poly) (res$ Poly) (T&. Dcr) (T& Type) (N&. Dcr) (N& Type)) (!
   (=>
    (and
     (has_type closure%$ (TYPE%tuple%1. (REF $) (ARRAY T&. T& N&. N&)))
     (has_type res$ (ARRAY T&. T& N&. N&))
    )
    (=>
     (closure_ens (FNDEF%core!clone.Clone.clone. $ (ARRAY T&. T& N&. N&)) (DST (REF $))
      (TYPE%tuple%1. (REF $) (ARRAY T&. T& N&. N&)) (F fndef_singleton) closure%$ res$
     )
     (let
      ((a$ (%Poly%array%. (tuple%1./tuple%1/0 (%Poly%tuple%1. closure%$)))))
      (and
       (forall ((i$ Poly)) (!
         (=>
          (has_type i$ INT)
          (=>
           (let
            ((tmp%%$ 0))
            (let
             ((tmp%%$1 (%I i$)))
             (let
              ((tmp%%$2 (const_int N&)))
              (and
               (<= tmp%%$ tmp%%$1)
               (< tmp%%$1 tmp%%$2)
           ))))
           (vstd!pervasive.cloned.? T&. T& (vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.?
              $ (ARRAY T&. T& N&. N&) (Poly%array%. a$)
             ) i$
            ) (vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (ARRAY T&. T& N&. N&) res$)
             i$
         ))))
         :pattern ((vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (ARRAY T&. T& N&. N&)
            (Poly%array%. a$)
           ) i$
         ))
         :pattern ((vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (ARRAY T&. T& N&. N&)
            res$
           ) i$
         ))
         :pattern ((vstd!pervasive.cloned.? T&. T& (vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.?
             $ (ARRAY T&. T& N&. N&) (Poly%array%. a$)
            ) i$
           ) (vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (ARRAY T&. T& N&. N&) res$)
            i$
         )))
         :qid user_core__array__impl&%20__clone_1
         :skolemid skolem_user_core__array__impl&%20__clone_1
       ))
       (=>
        (ext_eq false (TYPE%vstd!seq.Seq. T&. T&) (vstd!view.View.view.? $ (ARRAY T&. T& N&.
           N&
          ) (Poly%array%. a$)
         ) (vstd!view.View.view.? $ (ARRAY T&. T& N&. N&) res$)
        )
        (= (vstd!view.View.view.? $ (ARRAY T&. T& N&. N&) (Poly%array%. a$)) (vstd!view.View.view.?
          $ (ARRAY T&. T& N&. N&) res$
   )))))))
   :pattern ((closure_ens (FNDEF%core!clone.Clone.clone. $ (ARRAY T&. T& N&. N&)) (DST
      (REF $)
     ) (TYPE%tuple%1. (REF $) (ARRAY T&. T& N&. N&)) (F fndef_singleton) closure%$ res$
   ))
   :qid user_core__array__impl&%20__clone_2
   :skolemid skolem_user_core__array__impl&%20__clone_2
)))

;; Function-Specs verus_builtin::impl&%9::clone
(declare-fun ens%verus_builtin!impl&%9.clone. (Dcr Type Poly Poly) Bool)
(assert
 (forall ((T&. Dcr) (T& Type) (b! Poly) (res! Poly)) (!
   (= (ens%verus_builtin!impl&%9.clone. T&. T& b! res!) (and
     (ens%core!clone.Clone.clone. (TRACKED T&.) T& b! res!)
     (= res! b!)
   ))
   :pattern ((ens%verus_builtin!impl&%9.clone. T&. T& b! res!))
   :qid internal_ens__verus_builtin!impl&__9.clone._definition
   :skolemid skolem_internal_ens__verus_builtin!impl&__9.clone._definition
)))
(assert
 (forall ((closure%$ Poly) (res$ Poly) (T&. Dcr) (T& Type)) (!
   (=>
    (and
     (has_type closure%$ (TYPE%tuple%1. (REF (TRACKED T&.)) T&))
     (has_type res$ T&)
    )
    (=>
     (closure_ens (FNDEF%core!clone.Clone.clone. (TRACKED T&.) T&) (DST (REF (TRACKED T&.)))
      (TYPE%tuple%1. (REF (TRACKED T&.)) T&) (F fndef_singleton) closure%$ res$
     )
     (let
      ((b$ (tuple%1./tuple%1/0 (%Poly%tuple%1. closure%$))))
      (= res$ b$)
   )))
   :pattern ((closure_ens (FNDEF%core!clone.Clone.clone. (TRACKED T&.) T&) (DST (REF (TRACKED
        T&.
      ))
     ) (TYPE%tuple%1. (REF (TRACKED T&.)) T&) (F fndef_singleton) closure%$ res$
   ))
   :qid user_verus_builtin__impl&%9__clone_0
   :skolemid skolem_user_verus_builtin__impl&%9__clone_0
)))

;; Function-Specs verus_builtin::impl&%7::clone
(declare-fun ens%verus_builtin!impl&%7.clone. (Dcr Type Poly Poly) Bool)
(assert
 (forall ((T&. Dcr) (T& Type) (b! Poly) (res! Poly)) (!
   (= (ens%verus_builtin!impl&%7.clone. T&. T& b! res!) (and
     (ens%core!clone.Clone.clone. (GHOST T&.) T& b! res!)
     (= res! b!)
   ))
   :pattern ((ens%verus_builtin!impl&%7.clone. T&. T& b! res!))
   :qid internal_ens__verus_builtin!impl&__7.clone._definition
   :skolemid skolem_internal_ens__verus_builtin!impl&__7.clone._definition
)))
(assert
 (forall ((closure%$ Poly) (res$ Poly) (T&. Dcr) (T& Type)) (!
   (=>
    (and
     (has_type closure%$ (TYPE%tuple%1. (REF (GHOST T&.)) T&))
     (has_type res$ T&)
    )
    (=>
     (closure_ens (FNDEF%core!clone.Clone.clone. (GHOST T&.) T&) (DST (REF (GHOST T&.)))
      (TYPE%tuple%1. (REF (GHOST T&.)) T&) (F fndef_singleton) closure%$ res$
     )
     (let
      ((b$ (tuple%1./tuple%1/0 (%Poly%tuple%1. closure%$))))
      (= res$ b$)
   )))
   :pattern ((closure_ens (FNDEF%core!clone.Clone.clone. (GHOST T&.) T&) (DST (REF (GHOST
        T&.
      ))
     ) (TYPE%tuple%1. (REF (GHOST T&.)) T&) (F fndef_singleton) closure%$ res$
   ))
   :qid user_verus_builtin__impl&%7__clone_0
   :skolemid skolem_user_verus_builtin__impl&%7__clone_0
)))

;; Function-Axioms vstd::std_specs::option::is_some
(assert
 (fuel_bool_default fuel%vstd!std_specs.option.is_some.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!std_specs.option.is_some.)
  (forall ((T&. Dcr) (T& Type) (option! Poly)) (!
    (= (vstd!std_specs.option.is_some.? T&. T& option!) (is-core!option.Option./Some (%Poly%core!option.Option.
       option!
    )))
    :pattern ((vstd!std_specs.option.is_some.? T&. T& option!))
    :qid internal_vstd!std_specs.option.is_some.?_definition
    :skolemid skolem_internal_vstd!std_specs.option.is_some.?_definition
))))

;; Function-Axioms vstd::std_specs::option::is_none
(assert
 (fuel_bool_default fuel%vstd!std_specs.option.is_none.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!std_specs.option.is_none.)
  (forall ((T&. Dcr) (T& Type) (option! Poly)) (!
    (= (vstd!std_specs.option.is_none.? T&. T& option!) (is-core!option.Option./None (%Poly%core!option.Option.
       option!
    )))
    :pattern ((vstd!std_specs.option.is_none.? T&. T& option!))
    :qid internal_vstd!std_specs.option.is_none.?_definition
    :skolemid skolem_internal_vstd!std_specs.option.is_none.?_definition
))))

;; Function-Specs vstd::std_specs::option::spec_unwrap
(declare-fun req%vstd!std_specs.option.spec_unwrap. (Dcr Type Poly) Bool)
(declare-const %%global_location_label%%29 Bool)
(assert
 (forall ((T&. Dcr) (T& Type) (option! Poly)) (!
   (= (req%vstd!std_specs.option.spec_unwrap. T&. T& option!) (=>
     %%global_location_label%%29
     (is-core!option.Option./Some (%Poly%core!option.Option. option!))
   ))
   :pattern ((req%vstd!std_specs.option.spec_unwrap. T&. T& option!))
   :qid internal_req__vstd!std_specs.option.spec_unwrap._definition
   :skolemid skolem_internal_req__vstd!std_specs.option.spec_unwrap._definition
)))

;; Function-Axioms vstd::std_specs::option::spec_unwrap
(assert
 (fuel_bool_default fuel%vstd!std_specs.option.spec_unwrap.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!std_specs.option.spec_unwrap.)
  (forall ((T&. Dcr) (T& Type) (option! Poly)) (!
    (= (vstd!std_specs.option.spec_unwrap.? T&. T& option!) (core!option.Option./Some/0
      T&. T& (%Poly%core!option.Option. option!)
    ))
    :pattern ((vstd!std_specs.option.spec_unwrap.? T&. T& option!))
    :qid internal_vstd!std_specs.option.spec_unwrap.?_definition
    :skolemid skolem_internal_vstd!std_specs.option.spec_unwrap.?_definition
))))
(assert
 (forall ((T&. Dcr) (T& Type) (option! Poly)) (!
   (=>
    (has_type option! (TYPE%core!option.Option. T&. T&))
    (has_type (vstd!std_specs.option.spec_unwrap.? T&. T& option!) T&)
   )
   :pattern ((vstd!std_specs.option.spec_unwrap.? T&. T& option!))
   :qid internal_vstd!std_specs.option.spec_unwrap.?_pre_post_definition
   :skolemid skolem_internal_vstd!std_specs.option.spec_unwrap.?_pre_post_definition
)))

;; Function-Specs core::option::impl&%6::clone
(declare-fun ens%core!option.impl&%6.clone. (Dcr Type Poly Poly) Bool)
(assert
 (forall ((T&. Dcr) (T& Type) (opt! Poly) (res! Poly)) (!
   (= (ens%core!option.impl&%6.clone. T&. T& opt! res!) (and
     (ens%core!clone.Clone.clone. $ (TYPE%core!option.Option. T&. T&) opt! res!)
     (=>
      (is-core!option.Option./None (%Poly%core!option.Option. opt!))
      (is-core!option.Option./None (%Poly%core!option.Option. res!))
     )
     (=>
      (is-core!option.Option./Some (%Poly%core!option.Option. opt!))
      (and
       (is-core!option.Option./Some (%Poly%core!option.Option. res!))
       (vstd!pervasive.cloned.? T&. T& (core!option.Option./Some/0 T&. T& (%Poly%core!option.Option.
          opt!
         )
        ) (core!option.Option./Some/0 T&. T& (%Poly%core!option.Option. res!))
   )))))
   :pattern ((ens%core!option.impl&%6.clone. T&. T& opt! res!))
   :qid internal_ens__core!option.impl&__6.clone._definition
   :skolemid skolem_internal_ens__core!option.impl&__6.clone._definition
)))
(assert
 (forall ((closure%$ Poly) (res$ Poly) (T&. Dcr) (T& Type)) (!
   (=>
    (and
     (has_type closure%$ (TYPE%tuple%1. (REF $) (TYPE%core!option.Option. T&. T&)))
     (has_type res$ (TYPE%core!option.Option. T&. T&))
    )
    (=>
     (closure_ens (FNDEF%core!clone.Clone.clone. $ (TYPE%core!option.Option. T&. T&)) (
       DST (REF $)
      ) (TYPE%tuple%1. (REF $) (TYPE%core!option.Option. T&. T&)) (F fndef_singleton) closure%$
      res$
     )
     (let
      ((opt$ (%Poly%core!option.Option. (tuple%1./tuple%1/0 (%Poly%tuple%1. closure%$)))))
      (and
       (=>
        (is-core!option.Option./None opt$)
        (is-core!option.Option./None (%Poly%core!option.Option. res$))
       )
       (=>
        (is-core!option.Option./Some opt$)
        (and
         (is-core!option.Option./Some (%Poly%core!option.Option. res$))
         (vstd!pervasive.cloned.? T&. T& (core!option.Option./Some/0 T&. T& (%Poly%core!option.Option.
            (Poly%core!option.Option. opt$)
           )
          ) (core!option.Option./Some/0 T&. T& (%Poly%core!option.Option. res$))
   )))))))
   :pattern ((closure_ens (FNDEF%core!clone.Clone.clone. $ (TYPE%core!option.Option. T&.
       T&
      )
     ) (DST (REF $)) (TYPE%tuple%1. (REF $) (TYPE%core!option.Option. T&. T&)) (F fndef_singleton)
     closure%$ res$
   ))
   :qid user_core__option__impl&%6__clone_0
   :skolemid skolem_user_core__option__impl&%6__clone_0
)))

;; Function-Specs alloc::boxed::impl&%15::clone
(declare-fun ens%alloc!boxed.impl&%15.clone. (Dcr Type Dcr Type Poly Poly) Bool)
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type) (b! Poly) (res! Poly)) (!
   (= (ens%alloc!boxed.impl&%15.clone. T&. T& A&. A& b! res!) (and
     (ens%core!clone.Clone.clone. (BOX A&. A& T&.) T& b! res!)
     (vstd!pervasive.cloned.? T&. T& b! res!)
   ))
   :pattern ((ens%alloc!boxed.impl&%15.clone. T&. T& A&. A& b! res!))
   :qid internal_ens__alloc!boxed.impl&__15.clone._definition
   :skolemid skolem_internal_ens__alloc!boxed.impl&__15.clone._definition
)))
(assert
 (forall ((closure%$ Poly) (res$ Poly) (T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (has_type closure%$ (TYPE%tuple%1. (REF (BOX A&. A& T&.)) T&))
     (has_type res$ T&)
    )
    (=>
     (closure_ens (FNDEF%core!clone.Clone.clone. (BOX A&. A& T&.) T&) (DST (REF (BOX A&. A&
         T&.
       ))
      ) (TYPE%tuple%1. (REF (BOX A&. A& T&.)) T&) (F fndef_singleton) closure%$ res$
     )
     (let
      ((b$ (tuple%1./tuple%1/0 (%Poly%tuple%1. closure%$))))
      (vstd!pervasive.cloned.? T&. T& b$ res$)
   )))
   :pattern ((closure_ens (FNDEF%core!clone.Clone.clone. (BOX A&. A& T&.) T&) (DST (REF
       (BOX A&. A& T&.)
      )
     ) (TYPE%tuple%1. (REF (BOX A&. A& T&.)) T&) (F fndef_singleton) closure%$ res$
   ))
   :qid user_alloc__boxed__impl&%15__clone_0
   :skolemid skolem_user_alloc__boxed__impl&%15__clone_0
)))

;; Function-Axioms vstd::raw_ptr::impl&%3::view
(assert
 (fuel_bool_default fuel%vstd!raw_ptr.impl&%3.view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!raw_ptr.impl&%3.view.)
  (forall ((T&. Dcr) (T& Type) (self! Poly)) (!
    (= (vstd!view.View.view.? (CONST_PTR $) (PTR T&. T&) self!) (vstd!view.View.view.?
      $ (PTR T&. T&) self!
    ))
    :pattern ((vstd!view.View.view.? (CONST_PTR $) (PTR T&. T&) self!))
    :qid internal_vstd!raw_ptr.impl&__3.view.?_definition
    :skolemid skolem_internal_vstd!raw_ptr.impl&__3.view.?_definition
))))

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (tr_bound%vstd!view.View. (CONST_PTR $) (PTR T&. T&))
   :pattern ((tr_bound%vstd!view.View. (CONST_PTR $) (PTR T&. T&)))
   :qid internal_vstd__raw_ptr__impl&__3_trait_impl_definition
   :skolemid skolem_internal_vstd__raw_ptr__impl&__3_trait_impl_definition
)))

;; Function-Axioms vstd::relations::sorted_by
(assert
 (fuel_bool_default fuel%vstd!relations.sorted_by.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!relations.sorted_by.)
  (forall ((T&. Dcr) (T& Type) (a! Poly) (less_than! Poly)) (!
    (= (vstd!relations.sorted_by.? T&. T& a! less_than!) (forall ((i$ Poly) (j$ Poly))
      (!
       (=>
        (and
         (has_type i$ INT)
         (has_type j$ INT)
        )
        (=>
         (let
          ((tmp%%$ 0))
          (let
           ((tmp%%$1 (%I i$)))
           (let
            ((tmp%%$2 (%I j$)))
            (let
             ((tmp%%$3 (vstd!seq.Seq.len.? T&. T& a!)))
             (and
              (and
               (<= tmp%%$ tmp%%$1)
               (< tmp%%$1 tmp%%$2)
              )
              (< tmp%%$2 tmp%%$3)
         )))))
         (%B (%%apply%%1 (%Poly%fun%2. less_than!) (vstd!seq.Seq.index.? T&. T& a! i$) (vstd!seq.Seq.index.?
            T&. T& a! j$
       )))))
       :pattern ((%%apply%%1 (%Poly%fun%2. less_than!) (vstd!seq.Seq.index.? T&. T& a! i$)
         (vstd!seq.Seq.index.? T&. T& a! j$)
       ))
       :qid user_vstd__relations__sorted_by_0
       :skolemid skolem_user_vstd__relations__sorted_by_0
    )))
    :pattern ((vstd!relations.sorted_by.? T&. T& a! less_than!))
    :qid internal_vstd!relations.sorted_by.?_definition
    :skolemid skolem_internal_vstd!relations.sorted_by.?_definition
))))

;; Function-Specs vstd::seq_lib::impl&%0::lemma_sort_by_ensures
(declare-fun req%vstd!seq_lib.impl&%0.lemma_sort_by_ensures. (Dcr Type Poly %%Function%%)
 Bool
)
(declare-const %%global_location_label%%30 Bool)
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly) (leq! %%Function%%)) (!
   (= (req%vstd!seq_lib.impl&%0.lemma_sort_by_ensures. A&. A& self! leq!) (=>
     %%global_location_label%%30
     (vstd!relations.total_ordering.? A&. A& (Poly%fun%2. leq!))
   ))
   :pattern ((req%vstd!seq_lib.impl&%0.lemma_sort_by_ensures. A&. A& self! leq!))
   :qid internal_req__vstd!seq_lib.impl&__0.lemma_sort_by_ensures._definition
   :skolemid skolem_internal_req__vstd!seq_lib.impl&__0.lemma_sort_by_ensures._definition
)))
(declare-fun ens%vstd!seq_lib.impl&%0.lemma_sort_by_ensures. (Dcr Type Poly %%Function%%)
 Bool
)
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly) (leq! %%Function%%)) (!
   (= (ens%vstd!seq_lib.impl&%0.lemma_sort_by_ensures. A&. A& self! leq!) (and
     (ext_eq false (TYPE%vstd!multiset.Multiset. A&. A&) (vstd!seq_lib.impl&%0.to_multiset.?
       A&. A& self!
      ) (vstd!seq_lib.impl&%0.to_multiset.? A&. A& (vstd!seq_lib.impl&%0.sort_by.? A&. A&
        self! (Poly%fun%2. leq!)
     )))
     (vstd!relations.sorted_by.? A&. A& (vstd!seq_lib.impl&%0.sort_by.? A&. A& self! (Poly%fun%2.
        leq!
       )
      ) (Poly%fun%2. leq!)
     )
     (forall ((x$ Poly)) (!
       (=>
        (has_type x$ A&)
        (=>
         (not (vstd!seq_lib.impl&%0.contains.? A&. A& self! x$))
         (not (vstd!seq_lib.impl&%0.contains.? A&. A& (vstd!seq_lib.impl&%0.sort_by.? A&. A&
            self! (Poly%fun%2. leq!)
           ) x$
       ))))
       :pattern ((vstd!seq_lib.impl&%0.contains.? A&. A& (vstd!seq_lib.impl&%0.sort_by.? A&.
          A& self! (Poly%fun%2. leq!)
         ) x$
       ))
       :qid user_vstd__seq_lib__impl&%0__lemma_sort_by_ensures_0
       :skolemid skolem_user_vstd__seq_lib__impl&%0__lemma_sort_by_ensures_0
   ))))
   :pattern ((ens%vstd!seq_lib.impl&%0.lemma_sort_by_ensures. A&. A& self! leq!))
   :qid internal_ens__vstd!seq_lib.impl&__0.lemma_sort_by_ensures._definition
   :skolemid skolem_internal_ens__vstd!seq_lib.impl&__0.lemma_sort_by_ensures._definition
)))

;; Function-Specs vstd::seq_lib::lemma_sorted_unique
(declare-fun req%vstd!seq_lib.lemma_sorted_unique. (Dcr Type Poly Poly %%Function%%)
 Bool
)
(declare-const %%global_location_label%%31 Bool)
(declare-const %%global_location_label%%32 Bool)
(declare-const %%global_location_label%%33 Bool)
(declare-const %%global_location_label%%34 Bool)
(assert
 (forall ((A&. Dcr) (A& Type) (x! Poly) (y! Poly) (leq! %%Function%%)) (!
   (= (req%vstd!seq_lib.lemma_sorted_unique. A&. A& x! y! leq!) (and
     (=>
      %%global_location_label%%31
      (vstd!relations.sorted_by.? A&. A& x! (Poly%fun%2. leq!))
     )
     (=>
      %%global_location_label%%32
      (vstd!relations.sorted_by.? A&. A& y! (Poly%fun%2. leq!))
     )
     (=>
      %%global_location_label%%33
      (vstd!relations.total_ordering.? A&. A& (Poly%fun%2. leq!))
     )
     (=>
      %%global_location_label%%34
      (= (vstd!seq_lib.impl&%0.to_multiset.? A&. A& x!) (vstd!seq_lib.impl&%0.to_multiset.?
        A&. A& y!
   )))))
   :pattern ((req%vstd!seq_lib.lemma_sorted_unique. A&. A& x! y! leq!))
   :qid internal_req__vstd!seq_lib.lemma_sorted_unique._definition
   :skolemid skolem_internal_req__vstd!seq_lib.lemma_sorted_unique._definition
)))
(declare-fun ens%vstd!seq_lib.lemma_sorted_unique. (Dcr Type Poly Poly %%Function%%)
 Bool
)
(assert
 (forall ((A&. Dcr) (A& Type) (x! Poly) (y! Poly) (leq! %%Function%%)) (!
   (= (ens%vstd!seq_lib.lemma_sorted_unique. A&. A& x! y! leq!) (ext_eq false (TYPE%vstd!seq.Seq.
      A&. A&
     ) x! y!
   ))
   :pattern ((ens%vstd!seq_lib.lemma_sorted_unique. A&. A& x! y! leq!))
   :qid internal_ens__vstd!seq_lib.lemma_sorted_unique._definition
   :skolemid skolem_internal_ens__vstd!seq_lib.lemma_sorted_unique._definition
)))

;; Function-Specs alloc::sync::impl&%32::clone
(declare-fun ens%alloc!sync.impl&%32.clone. (Dcr Type Dcr Type Poly Poly) Bool)
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type) (a! Poly) (res! Poly)) (!
   (= (ens%alloc!sync.impl&%32.clone. T&. T& A&. A& a! res!) (and
     (ens%core!clone.Clone.clone. (ARC A&. A& T&.) T& a! res!)
     (= res! a!)
   ))
   :pattern ((ens%alloc!sync.impl&%32.clone. T&. T& A&. A& a! res!))
   :qid internal_ens__alloc!sync.impl&__32.clone._definition
   :skolemid skolem_internal_ens__alloc!sync.impl&__32.clone._definition
)))
(assert
 (forall ((closure%$ Poly) (res$ Poly) (T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (has_type closure%$ (TYPE%tuple%1. (REF (ARC A&. A& T&.)) T&))
     (has_type res$ T&)
    )
    (=>
     (closure_ens (FNDEF%core!clone.Clone.clone. (ARC A&. A& T&.) T&) (DST (REF (ARC A&. A&
         T&.
       ))
      ) (TYPE%tuple%1. (REF (ARC A&. A& T&.)) T&) (F fndef_singleton) closure%$ res$
     )
     (let
      ((a$ (tuple%1./tuple%1/0 (%Poly%tuple%1. closure%$))))
      (= res$ a$)
   )))
   :pattern ((closure_ens (FNDEF%core!clone.Clone.clone. (ARC A&. A& T&.) T&) (DST (REF
       (ARC A&. A& T&.)
      )
     ) (TYPE%tuple%1. (REF (ARC A&. A& T&.)) T&) (F fndef_singleton) closure%$ res$
   ))
   :qid user_alloc__sync__impl&%32__clone_0
   :skolemid skolem_user_alloc__sync__impl&%32__clone_0
)))

;; Function-Axioms vstd::view::impl&%6::view
(assert
 (fuel_bool_default fuel%vstd!view.impl&%6.view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%6.view.)
  (forall ((A&. Dcr) (A& Type) (self! Poly)) (!
    (=>
     (and
      (sized A&.)
      (tr_bound%vstd!view.View. A&. A&)
     )
     (= (vstd!view.View.view.? (ARC $ TYPE%alloc!alloc.Global. A&.) A& self!) (vstd!view.View.view.?
       A&. A& self!
    )))
    :pattern ((vstd!view.View.view.? (ARC $ TYPE%alloc!alloc.Global. A&.) A& self!))
    :qid internal_vstd!view.impl&__6.view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__6.view.?_definition
))))

;; Trait-Impl-Axiom
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%vstd!view.View. A&. A&)
    )
    (tr_bound%vstd!view.View. (ARC $ TYPE%alloc!alloc.Global. A&.) A&)
   )
   :pattern ((tr_bound%vstd!view.View. (ARC $ TYPE%alloc!alloc.Global. A&.) A&))
   :qid internal_vstd__view__impl&__6_trait_impl_definition
   :skolemid skolem_internal_vstd__view__impl&__6_trait_impl_definition
)))

;; Function-Specs lib::vstdplus::rand::rand::random_usize_range
(declare-fun req%lib!vstdplus.rand.rand.random_usize_range. (Int Int) Bool)
(declare-const %%global_location_label%%35 Bool)
(assert
 (forall ((lo! Int) (hi! Int)) (!
   (= (req%lib!vstdplus.rand.rand.random_usize_range. lo! hi!) (=>
     %%global_location_label%%35
     (< lo! hi!)
   ))
   :pattern ((req%lib!vstdplus.rand.rand.random_usize_range. lo! hi!))
   :qid internal_req__lib!vstdplus.rand.rand.random_usize_range._definition
   :skolemid skolem_internal_req__lib!vstdplus.rand.rand.random_usize_range._definition
)))
(declare-fun ens%lib!vstdplus.rand.rand.random_usize_range. (Int Int Int) Bool)
(assert
 (forall ((lo! Int) (hi! Int) (result! Int)) (!
   (= (ens%lib!vstdplus.rand.rand.random_usize_range. lo! hi! result!) (and
     (uInv SZ result!)
     (and
      (<= lo! result!)
      (< result! hi!)
   )))
   :pattern ((ens%lib!vstdplus.rand.rand.random_usize_range. lo! hi! result!))
   :qid internal_ens__lib!vstdplus.rand.rand.random_usize_range._definition
   :skolemid skolem_internal_ens__lib!vstdplus.rand.rand.random_usize_range._definition
)))

;; Function-Axioms vstd::std_specs::array::impl&%0::eq_spec
(assert
 (fuel_bool_default fuel%vstd!std_specs.array.impl&%0.eq_spec.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!std_specs.array.impl&%0.eq_spec.)
  (forall ((T&. Dcr) (T& Type) (U&. Dcr) (U& Type) (N&. Dcr) (N& Type) (self! Poly) (
     other! Poly
    )
   ) (!
    (=>
     (and
      (sized T&.)
      (sized U&.)
      (uInv SZ (const_int N&))
      (tr_bound%core!cmp.PartialEq. T&. T& U&. U&)
      (tr_bound%vstd!std_specs.cmp.PartialEqSpec. T&. T& U&. U&)
     )
     (= (vstd!std_specs.cmp.PartialEqSpec.eq_spec.? $ (ARRAY T&. T& N&. N&) $ (ARRAY U&.
        U& N&. N&
       ) self! other!
      ) (B (forall ((i$ Poly)) (!
         (=>
          (has_type i$ INT)
          (=>
           (let
            ((tmp%%$ 0))
            (let
             ((tmp%%$1 (%I i$)))
             (let
              ((tmp%%$2 (const_int N&)))
              (and
               (<= tmp%%$ tmp%%$1)
               (< tmp%%$1 tmp%%$2)
           ))))
           (%B (vstd!std_specs.cmp.PartialEqSpec.eq_spec.? T&. T& U&. U& (vstd!seq.Seq.index.?
              T&. T& (vstd!view.View.view.? $ (ARRAY T&. T& N&. N&) self!) i$
             ) (vstd!seq.Seq.index.? U&. U& (vstd!view.View.view.? $ (ARRAY U&. U& N&. N&) other!)
              i$
         )))))
         :pattern ((vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (ARRAY T&. T& N&. N&)
            self!
           ) i$
         ))
         :pattern ((vstd!seq.Seq.index.? U&. U& (vstd!view.View.view.? $ (ARRAY U&. U& N&. N&)
            other!
           ) i$
         ))
         :qid user_vstd__std_specs__array__impl&%0__eq_spec_0
         :skolemid skolem_user_vstd__std_specs__array__impl&%0__eq_spec_0
    )))))
    :pattern ((vstd!std_specs.cmp.PartialEqSpec.eq_spec.? $ (ARRAY T&. T& N&. N&) $ (ARRAY
       U&. U& N&. N&
      ) self! other!
    ))
    :qid internal_vstd!std_specs.array.impl&__0.eq_spec.?_definition
    :skolemid skolem_internal_vstd!std_specs.array.impl&__0.eq_spec.?_definition
))))

;; Function-Axioms vstd::std_specs::array::impl&%1::eq_spec
(assert
 (fuel_bool_default fuel%vstd!std_specs.array.impl&%1.eq_spec.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!std_specs.array.impl&%1.eq_spec.)
  (forall ((T&. Dcr) (T& Type) (U&. Dcr) (U& Type) (N&. Dcr) (N& Type) (self! Poly) (
     other! Poly
    )
   ) (!
    (=>
     (and
      (sized T&.)
      (sized U&.)
      (uInv SZ (const_int N&))
      (tr_bound%core!cmp.PartialEq. T&. T& U&. U&)
      (tr_bound%vstd!std_specs.cmp.PartialEqSpec. T&. T& U&. U&)
     )
     (= (vstd!std_specs.cmp.PartialEqSpec.eq_spec.? (REF $slice) (SLICE T&. T&) $ (ARRAY
        U&. U& N&. N&
       ) self! other!
      ) (B (and
        (= (vstd!seq.Seq.len.? T&. T& (vstd!view.View.view.? $slice (SLICE T&. T&) self!))
         (vstd!seq.Seq.len.? U&. U& (vstd!view.View.view.? $ (ARRAY U&. U& N&. N&) other!))
        )
        (forall ((i$ Poly)) (!
          (=>
           (has_type i$ INT)
           (=>
            (let
             ((tmp%%$ 0))
             (let
              ((tmp%%$1 (%I i$)))
              (let
               ((tmp%%$2 (vstd!seq.Seq.len.? T&. T& (vstd!view.View.view.? $slice (SLICE T&. T&) self!))))
               (and
                (<= tmp%%$ tmp%%$1)
                (< tmp%%$1 tmp%%$2)
            ))))
            (%B (vstd!std_specs.cmp.PartialEqSpec.eq_spec.? T&. T& U&. U& (vstd!seq.Seq.index.?
               T&. T& (vstd!view.View.view.? $slice (SLICE T&. T&) self!) i$
              ) (vstd!seq.Seq.index.? U&. U& (vstd!view.View.view.? $ (ARRAY U&. U& N&. N&) other!)
               i$
          )))))
          :pattern ((vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $slice (SLICE T&. T&)
             self!
            ) i$
          ))
          :qid user_vstd__std_specs__array__impl&%1__eq_spec_0
          :skolemid skolem_user_vstd__std_specs__array__impl&%1__eq_spec_0
    ))))))
    :pattern ((vstd!std_specs.cmp.PartialEqSpec.eq_spec.? (REF $slice) (SLICE T&. T&) $
      (ARRAY U&. U& N&. N&) self! other!
    ))
    :qid internal_vstd!std_specs.array.impl&__1.eq_spec.?_definition
    :skolemid skolem_internal_vstd!std_specs.array.impl&__1.eq_spec.?_definition
))))

;; Function-Axioms vstd::std_specs::array::impl&%2::eq_spec
(assert
 (fuel_bool_default fuel%vstd!std_specs.array.impl&%2.eq_spec.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!std_specs.array.impl&%2.eq_spec.)
  (forall ((T&. Dcr) (T& Type) (U&. Dcr) (U& Type) (N&. Dcr) (N& Type) (self! Poly) (
     other! Poly
    )
   ) (!
    (=>
     (and
      (sized T&.)
      (sized U&.)
      (uInv SZ (const_int N&))
      (tr_bound%core!cmp.PartialEq. T&. T& U&. U&)
      (tr_bound%vstd!std_specs.cmp.PartialEqSpec. T&. T& U&. U&)
     )
     (= (vstd!std_specs.cmp.PartialEqSpec.eq_spec.? $ (ARRAY T&. T& N&. N&) (REF $slice)
       (SLICE U&. U&) self! other!
      ) (B (and
        (= (vstd!seq.Seq.len.? T&. T& (vstd!view.View.view.? $ (ARRAY T&. T& N&. N&) self!))
         (vstd!seq.Seq.len.? U&. U& (vstd!view.View.view.? $slice (SLICE U&. U&) other!))
        )
        (forall ((i$ Poly)) (!
          (=>
           (has_type i$ INT)
           (=>
            (let
             ((tmp%%$ 0))
             (let
              ((tmp%%$1 (%I i$)))
              (let
               ((tmp%%$2 (vstd!seq.Seq.len.? T&. T& (vstd!view.View.view.? $ (ARRAY T&. T& N&. N&) self!))))
               (and
                (<= tmp%%$ tmp%%$1)
                (< tmp%%$1 tmp%%$2)
            ))))
            (%B (vstd!std_specs.cmp.PartialEqSpec.eq_spec.? T&. T& U&. U& (vstd!seq.Seq.index.?
               T&. T& (vstd!view.View.view.? $ (ARRAY T&. T& N&. N&) self!) i$
              ) (vstd!seq.Seq.index.? U&. U& (vstd!view.View.view.? $slice (SLICE U&. U&) other!)
               i$
          )))))
          :pattern ((vstd!seq.Seq.index.? U&. U& (vstd!view.View.view.? $slice (SLICE U&. U&)
             other!
            ) i$
          ))
          :qid user_vstd__std_specs__array__impl&%2__eq_spec_0
          :skolemid skolem_user_vstd__std_specs__array__impl&%2__eq_spec_0
    ))))))
    :pattern ((vstd!std_specs.cmp.PartialEqSpec.eq_spec.? $ (ARRAY T&. T& N&. N&) (REF $slice)
      (SLICE U&. U&) self! other!
    ))
    :qid internal_vstd!std_specs.array.impl&__2.eq_spec.?_definition
    :skolemid skolem_internal_vstd!std_specs.array.impl&__2.eq_spec.?_definition
))))

;; Function-Axioms vstd::std_specs::array::impl&%3::eq_spec
(assert
 (fuel_bool_default fuel%vstd!std_specs.array.impl&%3.eq_spec.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!std_specs.array.impl&%3.eq_spec.)
  (forall ((T&. Dcr) (T& Type) (U&. Dcr) (U& Type) (N&. Dcr) (N& Type) (self! Poly) (
     other! Poly
    )
   ) (!
    (=>
     (and
      (sized T&.)
      (sized U&.)
      (uInv SZ (const_int N&))
      (tr_bound%core!cmp.PartialEq. T&. T& U&. U&)
      (tr_bound%vstd!std_specs.cmp.PartialEqSpec. T&. T& U&. U&)
     )
     (= (vstd!std_specs.cmp.PartialEqSpec.eq_spec.? $slice (SLICE T&. T&) $ (ARRAY U&. U&
        N&. N&
       ) self! other!
      ) (B (and
        (= (vstd!seq.Seq.len.? T&. T& (vstd!view.View.view.? $slice (SLICE T&. T&) self!))
         (vstd!seq.Seq.len.? U&. U& (vstd!view.View.view.? $ (ARRAY U&. U& N&. N&) other!))
        )
        (forall ((i$ Poly)) (!
          (=>
           (has_type i$ INT)
           (=>
            (let
             ((tmp%%$ 0))
             (let
              ((tmp%%$1 (%I i$)))
              (let
               ((tmp%%$2 (vstd!seq.Seq.len.? T&. T& (vstd!view.View.view.? $slice (SLICE T&. T&) self!))))
               (and
                (<= tmp%%$ tmp%%$1)
                (< tmp%%$1 tmp%%$2)
            ))))
            (%B (vstd!std_specs.cmp.PartialEqSpec.eq_spec.? T&. T& U&. U& (vstd!seq.Seq.index.?
               T&. T& (vstd!view.View.view.? $slice (SLICE T&. T&) self!) i$
              ) (vstd!seq.Seq.index.? U&. U& (vstd!view.View.view.? $ (ARRAY U&. U& N&. N&) other!)
               i$
          )))))
          :pattern ((vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $slice (SLICE T&. T&)
             self!
            ) i$
          ))
          :qid user_vstd__std_specs__array__impl&%3__eq_spec_0
          :skolemid skolem_user_vstd__std_specs__array__impl&%3__eq_spec_0
    ))))))
    :pattern ((vstd!std_specs.cmp.PartialEqSpec.eq_spec.? $slice (SLICE T&. T&) $ (ARRAY
       U&. U& N&. N&
      ) self! other!
    ))
    :qid internal_vstd!std_specs.array.impl&__3.eq_spec.?_definition
    :skolemid skolem_internal_vstd!std_specs.array.impl&__3.eq_spec.?_definition
))))

;; Function-Axioms vstd::std_specs::array::impl&%4::eq_spec
(assert
 (fuel_bool_default fuel%vstd!std_specs.array.impl&%4.eq_spec.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!std_specs.array.impl&%4.eq_spec.)
  (forall ((T&. Dcr) (T& Type) (U&. Dcr) (U& Type) (N&. Dcr) (N& Type) (self! Poly) (
     other! Poly
    )
   ) (!
    (=>
     (and
      (sized T&.)
      (sized U&.)
      (uInv SZ (const_int N&))
      (tr_bound%core!cmp.PartialEq. T&. T& U&. U&)
      (tr_bound%vstd!std_specs.cmp.PartialEqSpec. T&. T& U&. U&)
     )
     (= (vstd!std_specs.cmp.PartialEqSpec.eq_spec.? $ (ARRAY T&. T& N&. N&) $slice (SLICE
        U&. U&
       ) self! other!
      ) (B (and
        (= (vstd!seq.Seq.len.? T&. T& (vstd!view.View.view.? $ (ARRAY T&. T& N&. N&) self!))
         (vstd!seq.Seq.len.? U&. U& (vstd!view.View.view.? $slice (SLICE U&. U&) other!))
        )
        (forall ((i$ Poly)) (!
          (=>
           (has_type i$ INT)
           (=>
            (let
             ((tmp%%$ 0))
             (let
              ((tmp%%$1 (%I i$)))
              (let
               ((tmp%%$2 (vstd!seq.Seq.len.? T&. T& (vstd!view.View.view.? $ (ARRAY T&. T& N&. N&) self!))))
               (and
                (<= tmp%%$ tmp%%$1)
                (< tmp%%$1 tmp%%$2)
            ))))
            (%B (vstd!std_specs.cmp.PartialEqSpec.eq_spec.? T&. T& U&. U& (vstd!seq.Seq.index.?
               T&. T& (vstd!view.View.view.? $ (ARRAY T&. T& N&. N&) self!) i$
              ) (vstd!seq.Seq.index.? U&. U& (vstd!view.View.view.? $slice (SLICE U&. U&) other!)
               i$
          )))))
          :pattern ((vstd!seq.Seq.index.? U&. U& (vstd!view.View.view.? $slice (SLICE U&. U&)
             other!
            ) i$
          ))
          :qid user_vstd__std_specs__array__impl&%4__eq_spec_0
          :skolemid skolem_user_vstd__std_specs__array__impl&%4__eq_spec_0
    ))))))
    :pattern ((vstd!std_specs.cmp.PartialEqSpec.eq_spec.? $ (ARRAY T&. T& N&. N&) $slice
      (SLICE U&. U&) self! other!
    ))
    :qid internal_vstd!std_specs.array.impl&__4.eq_spec.?_definition
    :skolemid skolem_internal_vstd!std_specs.array.impl&__4.eq_spec.?_definition
))))

;; Function-Axioms vstd::std_specs::slice::impl&%9::eq_spec
(assert
 (fuel_bool_default fuel%vstd!std_specs.slice.impl&%9.eq_spec.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!std_specs.slice.impl&%9.eq_spec.)
  (forall ((T&. Dcr) (T& Type) (U&. Dcr) (U& Type) (self! Poly) (other! Poly)) (!
    (=>
     (and
      (sized T&.)
      (sized U&.)
      (tr_bound%core!cmp.PartialEq. T&. T& U&. U&)
      (tr_bound%vstd!std_specs.cmp.PartialEqSpec. T&. T& U&. U&)
     )
     (= (vstd!std_specs.cmp.PartialEqSpec.eq_spec.? $slice (SLICE T&. T&) $slice (SLICE U&.
        U&
       ) self! other!
      ) (B (and
        (= (vstd!seq.Seq.len.? T&. T& (vstd!view.View.view.? $slice (SLICE T&. T&) self!))
         (vstd!seq.Seq.len.? U&. U& (vstd!view.View.view.? $slice (SLICE U&. U&) other!))
        )
        (forall ((i$ Poly)) (!
          (=>
           (has_type i$ INT)
           (=>
            (let
             ((tmp%%$ 0))
             (let
              ((tmp%%$1 (%I i$)))
              (let
               ((tmp%%$2 (vstd!seq.Seq.len.? T&. T& (vstd!view.View.view.? $slice (SLICE T&. T&) self!))))
               (and
                (<= tmp%%$ tmp%%$1)
                (< tmp%%$1 tmp%%$2)
            ))))
            (%B (vstd!std_specs.cmp.PartialEqSpec.eq_spec.? T&. T& U&. U& (vstd!seq.Seq.index.?
               T&. T& (vstd!view.View.view.? $slice (SLICE T&. T&) self!) i$
              ) (vstd!seq.Seq.index.? U&. U& (vstd!view.View.view.? $slice (SLICE U&. U&) other!)
               i$
          )))))
          :pattern ((vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $slice (SLICE T&. T&)
             self!
            ) i$
          ))
          :pattern ((vstd!seq.Seq.index.? U&. U& (vstd!view.View.view.? $slice (SLICE U&. U&)
             other!
            ) i$
          ))
          :qid user_vstd__std_specs__slice__impl&%9__eq_spec_0
          :skolemid skolem_user_vstd__std_specs__slice__impl&%9__eq_spec_0
    ))))))
    :pattern ((vstd!std_specs.cmp.PartialEqSpec.eq_spec.? $slice (SLICE T&. T&) $slice
      (SLICE U&. U&) self! other!
    ))
    :qid internal_vstd!std_specs.slice.impl&__9.eq_spec.?_definition
    :skolemid skolem_internal_vstd!std_specs.slice.impl&__9.eq_spec.?_definition
))))

;; Function-Axioms vstd::std_specs::vec::impl&%2::eq_spec
(assert
 (fuel_bool_default fuel%vstd!std_specs.vec.impl&%2.eq_spec.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!std_specs.vec.impl&%2.eq_spec.)
  (forall ((T&. Dcr) (T& Type) (U&. Dcr) (U& Type) (A1&. Dcr) (A1& Type) (A2&. Dcr) (
     A2& Type
    ) (self! Poly) (other! Poly)
   ) (!
    (=>
     (and
      (sized T&.)
      (sized U&.)
      (sized A1&.)
      (sized A2&.)
      (tr_bound%vstd!std_specs.cmp.PartialEqSpec. T&. T& U&. U&)
      (tr_bound%core!alloc.Allocator. A1&. A1&)
      (tr_bound%core!alloc.Allocator. A2&. A2&)
     )
     (= (vstd!std_specs.cmp.PartialEqSpec.eq_spec.? $ (TYPE%alloc!vec.Vec. T&. T& A1&. A1&)
       $ (TYPE%alloc!vec.Vec. U&. U& A2&. A2&) self! other!
      ) (B (and
        (= (vstd!std_specs.vec.spec_vec_len.? T&. T& A1&. A1& self!) (vstd!std_specs.vec.spec_vec_len.?
          U&. U& A2&. A2& other!
        ))
        (forall ((i$ Poly)) (!
          (=>
           (has_type i$ INT)
           (=>
            (let
             ((tmp%%$ 0))
             (let
              ((tmp%%$1 (%I i$)))
              (let
               ((tmp%%$2 (vstd!std_specs.vec.spec_vec_len.? T&. T& A1&. A1& self!)))
               (and
                (<= tmp%%$ tmp%%$1)
                (< tmp%%$1 tmp%%$2)
            ))))
            (%B (vstd!std_specs.cmp.PartialEqSpec.eq_spec.? T&. T& U&. U& (vstd!seq.Seq.index.?
               T&. T& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. T&. T& A1&. A1&) self!) i$
              ) (vstd!seq.Seq.index.? U&. U& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. U&. U&
                 A2&. A2&
                ) other!
               ) i$
          )))))
          :pattern ((vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec.
              T&. T& A1&. A1&
             ) self!
            ) i$
          ))
          :pattern ((vstd!seq.Seq.index.? U&. U& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec.
              U&. U& A2&. A2&
             ) other!
            ) i$
          ))
          :qid user_vstd__std_specs__vec__impl&%2__eq_spec_0
          :skolemid skolem_user_vstd__std_specs__vec__impl&%2__eq_spec_0
    ))))))
    :pattern ((vstd!std_specs.cmp.PartialEqSpec.eq_spec.? $ (TYPE%alloc!vec.Vec. T&. T&
       A1&. A1&
      ) $ (TYPE%alloc!vec.Vec. U&. U& A2&. A2&) self! other!
    ))
    :qid internal_vstd!std_specs.vec.impl&__2.eq_spec.?_definition
    :skolemid skolem_internal_vstd!std_specs.vec.impl&__2.eq_spec.?_definition
))))

;; Function-Axioms vstd::array::impl&%1::deep_view
(assert
 (fuel_bool_default fuel%vstd!array.impl&%1.deep_view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!array.impl&%1.deep_view.)
  (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type) (self! Poly)) (!
    (=>
     (and
      (sized T&.)
      (uInv SZ (const_int N&))
      (tr_bound%vstd!view.DeepView. T&. T&)
     )
     (= (vstd!view.DeepView.deep_view.? $ (ARRAY T&. T& N&. N&) self!) (let
       ((v$ (vstd!view.View.view.? $ (ARRAY T&. T& N&. N&) self!)))
       (vstd!seq.Seq.new.? (proj%%vstd!view.DeepView./V T&. T&) (proj%vstd!view.DeepView./V
         T&. T&
        ) (I (vstd!seq.Seq.len.? T&. T& v$)) (Poly%fun%1. (mk_fun (%%lambda%%1 T&. T& v$ T&.
           T&
    )))))))
    :pattern ((vstd!view.DeepView.deep_view.? $ (ARRAY T&. T& N&. N&) self!))
    :qid internal_vstd!array.impl&__1.deep_view.?_definition
    :skolemid skolem_internal_vstd!array.impl&__1.deep_view.?_definition
))))

;; Function-Axioms vstd::seq_lib::impl&%0::map
(assert
 (fuel_bool_default fuel%vstd!seq_lib.impl&%0.map.)
)
(declare-fun %%lambda%%4 (Dcr Type Poly %%Function%%) %%Function%%)
(assert
 (forall ((%%hole%%0 Dcr) (%%hole%%1 Type) (%%hole%%2 Poly) (%%hole%%3 %%Function%%)
   (i$ Poly)
  ) (!
   (= (%%apply%%0 (%%lambda%%4 %%hole%%0 %%hole%%1 %%hole%%2 %%hole%%3) i$) (%%apply%%1
     %%hole%%3 i$ (vstd!seq.Seq.index.? %%hole%%0 %%hole%%1 %%hole%%2 i$)
   ))
   :pattern ((%%apply%%0 (%%lambda%%4 %%hole%%0 %%hole%%1 %%hole%%2 %%hole%%3) i$))
)))
(assert
 (=>
  (fuel_bool fuel%vstd!seq_lib.impl&%0.map.)
  (forall ((A&. Dcr) (A& Type) (B&. Dcr) (B& Type) (self! Poly) (f! Poly)) (!
    (= (vstd!seq_lib.impl&%0.map.? A&. A& B&. B& self! f!) (vstd!seq.Seq.new.? B&. B& (
       I (vstd!seq.Seq.len.? A&. A& self!)
      ) (Poly%fun%1. (mk_fun (%%lambda%%4 A&. A& self! (%Poly%fun%2. f!))))
    ))
    :pattern ((vstd!seq_lib.impl&%0.map.? A&. A& B&. B& self! f!))
    :qid internal_vstd!seq_lib.impl&__0.map.?_definition
    :skolemid skolem_internal_vstd!seq_lib.impl&__0.map.?_definition
))))
(assert
 (forall ((A&. Dcr) (A& Type) (B&. Dcr) (B& Type) (self! Poly) (f! Poly)) (!
   (=>
    (and
     (has_type self! (TYPE%vstd!seq.Seq. A&. A&))
     (has_type f! (TYPE%fun%2. $ INT A&. A& B&. B&))
    )
    (has_type (vstd!seq_lib.impl&%0.map.? A&. A& B&. B& self! f!) (TYPE%vstd!seq.Seq. B&.
      B&
   )))
   :pattern ((vstd!seq_lib.impl&%0.map.? A&. A& B&. B& self! f!))
   :qid internal_vstd!seq_lib.impl&__0.map.?_pre_post_definition
   :skolemid skolem_internal_vstd!seq_lib.impl&__0.map.?_pre_post_definition
)))

;; Function-Axioms vstd::slice::impl&%1::deep_view
(assert
 (fuel_bool_default fuel%vstd!slice.impl&%1.deep_view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!slice.impl&%1.deep_view.)
  (forall ((T&. Dcr) (T& Type) (self! Poly)) (!
    (=>
     (and
      (sized T&.)
      (tr_bound%vstd!view.DeepView. T&. T&)
     )
     (= (vstd!view.DeepView.deep_view.? $slice (SLICE T&. T&) self!) (let
       ((v$ (vstd!view.View.view.? $slice (SLICE T&. T&) self!)))
       (vstd!seq.Seq.new.? (proj%%vstd!view.DeepView./V T&. T&) (proj%vstd!view.DeepView./V
         T&. T&
        ) (I (vstd!seq.Seq.len.? T&. T& v$)) (Poly%fun%1. (mk_fun (%%lambda%%1 T&. T& v$ T&.
           T&
    )))))))
    :pattern ((vstd!view.DeepView.deep_view.? $slice (SLICE T&. T&) self!))
    :qid internal_vstd!slice.impl&__1.deep_view.?_definition
    :skolemid skolem_internal_vstd!slice.impl&__1.deep_view.?_definition
))))

;; Function-Axioms vstd::view::impl&%2::view
(assert
 (fuel_bool_default fuel%vstd!view.impl&%2.view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%2.view.)
  (forall ((A&. Dcr) (A& Type) (self! Poly)) (!
    (=>
     (tr_bound%vstd!view.View. A&. A&)
     (= (vstd!view.View.view.? (BOX $ TYPE%alloc!alloc.Global. A&.) A& self!) (vstd!view.View.view.?
       A&. A& self!
    )))
    :pattern ((vstd!view.View.view.? (BOX $ TYPE%alloc!alloc.Global. A&.) A& self!))
    :qid internal_vstd!view.impl&__2.view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__2.view.?_definition
))))

;; Function-Axioms vstd::view::impl&%3::deep_view
(assert
 (fuel_bool_default fuel%vstd!view.impl&%3.deep_view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%3.deep_view.)
  (forall ((A&. Dcr) (A& Type) (self! Poly)) (!
    (=>
     (tr_bound%vstd!view.DeepView. A&. A&)
     (= (vstd!view.DeepView.deep_view.? (BOX $ TYPE%alloc!alloc.Global. A&.) A& self!)
      (vstd!view.DeepView.deep_view.? A&. A& self!)
    ))
    :pattern ((vstd!view.DeepView.deep_view.? (BOX $ TYPE%alloc!alloc.Global. A&.) A& self!))
    :qid internal_vstd!view.impl&__3.deep_view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__3.deep_view.?_definition
))))

;; Function-Axioms vstd::view::impl&%4::view
(assert
 (fuel_bool_default fuel%vstd!view.impl&%4.view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%4.view.)
  (forall ((A&. Dcr) (A& Type) (self! Poly)) (!
    (=>
     (and
      (sized A&.)
      (tr_bound%vstd!view.View. A&. A&)
     )
     (= (vstd!view.View.view.? (RC $ TYPE%alloc!alloc.Global. A&.) A& self!) (vstd!view.View.view.?
       A&. A& self!
    )))
    :pattern ((vstd!view.View.view.? (RC $ TYPE%alloc!alloc.Global. A&.) A& self!))
    :qid internal_vstd!view.impl&__4.view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__4.view.?_definition
))))

;; Function-Axioms vstd::view::impl&%5::deep_view
(assert
 (fuel_bool_default fuel%vstd!view.impl&%5.deep_view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%5.deep_view.)
  (forall ((A&. Dcr) (A& Type) (self! Poly)) (!
    (=>
     (and
      (sized A&.)
      (tr_bound%vstd!view.DeepView. A&. A&)
     )
     (= (vstd!view.DeepView.deep_view.? (RC $ TYPE%alloc!alloc.Global. A&.) A& self!) (
       vstd!view.DeepView.deep_view.? A&. A& self!
    )))
    :pattern ((vstd!view.DeepView.deep_view.? (RC $ TYPE%alloc!alloc.Global. A&.) A& self!))
    :qid internal_vstd!view.impl&__5.deep_view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__5.deep_view.?_definition
))))

;; Function-Axioms vstd::view::impl&%7::deep_view
(assert
 (fuel_bool_default fuel%vstd!view.impl&%7.deep_view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%7.deep_view.)
  (forall ((A&. Dcr) (A& Type) (self! Poly)) (!
    (=>
     (and
      (sized A&.)
      (tr_bound%vstd!view.DeepView. A&. A&)
     )
     (= (vstd!view.DeepView.deep_view.? (ARC $ TYPE%alloc!alloc.Global. A&.) A& self!)
      (vstd!view.DeepView.deep_view.? A&. A& self!)
    ))
    :pattern ((vstd!view.DeepView.deep_view.? (ARC $ TYPE%alloc!alloc.Global. A&.) A& self!))
    :qid internal_vstd!view.impl&__7.deep_view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__7.deep_view.?_definition
))))

;; Function-Axioms vstd::view::impl&%16::view
(assert
 (fuel_bool_default fuel%vstd!view.impl&%16.view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%16.view.)
  (forall ((self! Poly)) (!
    (= (vstd!view.View.view.? $ TYPE%tuple%0. self!) self!)
    :pattern ((vstd!view.View.view.? $ TYPE%tuple%0. self!))
    :qid internal_vstd!view.impl&__16.view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__16.view.?_definition
))))

;; Function-Axioms vstd::view::impl&%17::deep_view
(assert
 (fuel_bool_default fuel%vstd!view.impl&%17.deep_view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%17.deep_view.)
  (forall ((self! Poly)) (!
    (= (vstd!view.DeepView.deep_view.? $ TYPE%tuple%0. self!) self!)
    :pattern ((vstd!view.DeepView.deep_view.? $ TYPE%tuple%0. self!))
    :qid internal_vstd!view.impl&__17.deep_view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__17.deep_view.?_definition
))))

;; Function-Axioms lib::vstdplus::total_order::total_order::impl&%5::le
(assert
 (fuel_bool_default fuel%lib!vstdplus.total_order.total_order.impl&%5.le.)
)
(assert
 (=>
  (fuel_bool fuel%lib!vstdplus.total_order.total_order.impl&%5.le.)
  (forall ((self! Poly) (other! Poly)) (!
    (= (lib!vstdplus.total_order.total_order.TotalOrder.le.? $ USIZE self! other!) (B (
       <= (%I self!) (%I other!)
    )))
    :pattern ((lib!vstdplus.total_order.total_order.TotalOrder.le.? $ USIZE self! other!))
    :qid internal_lib!vstdplus.total_order.total_order.impl&__5.le.?_definition
    :skolemid skolem_internal_lib!vstdplus.total_order.total_order.impl&__5.le.?_definition
))))

;; Trait-Impl-Axiom
(assert
 (tr_bound%core!cmp.Eq. $ BOOL)
)

;; Trait-Impl-Axiom
(assert
 (tr_bound%core!cmp.Eq. $ USIZE)
)

;; Function-Axioms lib::Chap19::ArraySeqMtEph::ArraySeqMtEph::ArraySeqMtEphS::view
(assert
 (fuel_bool_default fuel%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.impl&%2.view.)
)
(declare-fun %%lambda%%5 (Dcr Type) %%Function%%)
(assert
 (forall ((%%hole%%0 Dcr) (%%hole%%1 Type) (_i$ Poly) (t$ Poly)) (!
   (= (%%apply%%1 (%%lambda%%5 %%hole%%0 %%hole%%1) _i$ t$) (vstd!view.View.view.? %%hole%%0
     %%hole%%1 t$
   ))
   :pattern ((%%apply%%1 (%%lambda%%5 %%hole%%0 %%hole%%1) _i$ t$))
)))
(assert
 (=>
  (fuel_bool fuel%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.impl&%2.view.)
  (forall ((T&. Dcr) (T& Type) (self! Poly)) (!
    (=>
     (and
      (sized T&.)
      (tr_bound%vstd!view.View. T&. T&)
     )
     (= (vstd!view.View.view.? $ (TYPE%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS.
        T&. T&
       ) self!
      ) (vstd!seq_lib.impl&%0.map.? T&. T& (proj%%vstd!view.View./V T&. T&) (proj%vstd!view.View./V
        T&. T&
       ) (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. T&. T& $ TYPE%alloc!alloc.Global.)
        (lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS./ArraySeqMtEphS/seq (%Poly%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS.
          self!
        ))
       ) (Poly%fun%2. (mk_fun (%%lambda%%5 T&. T&)))
    )))
    :pattern ((vstd!view.View.view.? $ (TYPE%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS.
       T&. T&
      ) self!
    ))
    :qid internal_lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.impl&__2.view.?_definition
    :skolemid skolem_internal_lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.impl&__2.view.?_definition
))))

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (and
     (sized T&.)
     (tr_bound%vstd!view.View. T&. T&)
    )
    (tr_bound%vstd!view.View. $ (TYPE%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS.
      T&. T&
   )))
   :pattern ((tr_bound%vstd!view.View. $ (TYPE%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS.
      T&. T&
   )))
   :qid internal_lib__Chap19__ArraySeqMtEph__ArraySeqMtEph__impl&__2_trait_impl_definition
   :skolemid skolem_internal_lib__Chap19__ArraySeqMtEph__ArraySeqMtEph__impl&__2_trait_impl_definition
)))

;; Function-Axioms lib::Chap19::ArraySeqMtEph::ArraySeqMtEph::ArraySeqMtEphS::eq_spec
(assert
 (fuel_bool_default fuel%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.impl&%7.eq_spec.)
)
(assert
 (=>
  (fuel_bool fuel%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.impl&%7.eq_spec.)
  (forall ((T&. Dcr) (T& Type) (self! Poly) (other! Poly)) (!
    (=>
     (and
      (sized T&.)
      (tr_bound%vstd!view.View. T&. T&)
      (tr_bound%core!cmp.PartialEq. T&. T& T&. T&)
     )
     (= (vstd!std_specs.cmp.PartialEqSpec.eq_spec.? $ (TYPE%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS.
        T&. T&
       ) $ (TYPE%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS. T&. T&) self! other!
      ) (B (= (vstd!view.View.view.? $ (TYPE%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS.
          T&. T&
         ) self!
        ) (vstd!view.View.view.? $ (TYPE%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS.
          T&. T&
         ) other!
    )))))
    :pattern ((vstd!std_specs.cmp.PartialEqSpec.eq_spec.? $ (TYPE%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS.
       T&. T&
      ) $ (TYPE%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS. T&. T&) self! other!
    ))
    :qid internal_lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.impl&__7.eq_spec.?_definition
    :skolemid skolem_internal_lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.impl&__7.eq_spec.?_definition
))))

;; Function-Axioms lib::Chap19::ArraySeqMtEphSlice::ArraySeqMtEphSlice::ArraySeqMtEphSliceS::view
(assert
 (fuel_bool_default fuel%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.impl&%2.view.)
)
(assert
 (=>
  (fuel_bool fuel%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.impl&%2.view.)
  (forall ((T&. Dcr) (T& Type) (self! Poly)) (!
    (=>
     (and
      (sized T&.)
      (tr_bound%vstd!view.View. T&. T&)
     )
     (= (vstd!view.View.view.? $ (TYPE%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS.
        T&. T&
       ) self!
      ) (vstd!seq.Seq.subrange.? (proj%%vstd!view.View./V T&. T&) (proj%vstd!view.View./V
        T&. T&
       ) (vstd!seq_lib.impl&%0.map.? T&. T& (proj%%vstd!view.View./V T&. T&) (proj%vstd!view.View./V
         T&. T&
        ) (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. T&. T& $ TYPE%alloc!alloc.Global.)
         (lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS./ArraySeqMtEphSliceS/data
          (%Poly%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS. self!)
         )
        ) (Poly%fun%2. (mk_fun (%%lambda%%5 T&. T&)))
       ) (I (lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS./ArraySeqMtEphSliceS/start
         (%Poly%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS. self!)
        )
       ) (I (Add (lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS./ArraySeqMtEphSliceS/start
          (%Poly%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS. self!)
         ) (lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS./ArraySeqMtEphSliceS/len
          (%Poly%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS. self!)
    ))))))
    :pattern ((vstd!view.View.view.? $ (TYPE%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS.
       T&. T&
      ) self!
    ))
    :qid internal_lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.impl&__2.view.?_definition
    :skolemid skolem_internal_lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.impl&__2.view.?_definition
))))

;; Function-Axioms lib::Chap19::ArraySeqMtEphSlice::ArraySeqMtEphSlice::ArraySeqMtEphSliceS::spec_arrayseqmtephslice_wf
(assert
 (fuel_bool_default fuel%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.impl&%3.spec_arrayseqmtephslice_wf.)
)
(assert
 (=>
  (fuel_bool fuel%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.impl&%3.spec_arrayseqmtephslice_wf.)
  (forall ((T&. Dcr) (T& Type) (self! Poly)) (!
    (=>
     (and
      (sized T&.)
      (tr_bound%lib!Concurrency.Concurrency.StTInMtT. T&. T&)
     )
     (= (lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceTrait.spec_arrayseqmtephslice_wf.?
       $ (TYPE%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS. T&.
        T&
       ) T&. T& self!
      ) (B (and
        (<= (Add (lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS./ArraySeqMtEphSliceS/start
           (%Poly%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS. self!)
          ) (lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS./ArraySeqMtEphSliceS/len
           (%Poly%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS. self!)
          )
         ) (vstd!seq.Seq.len.? T&. T& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. T&. T& $
            TYPE%alloc!alloc.Global.
           ) (lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS./ArraySeqMtEphSliceS/data
            (%Poly%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS. self!)
        ))))
        (<= (Add (lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS./ArraySeqMtEphSliceS/start
           (%Poly%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS. self!)
          ) (lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS./ArraySeqMtEphSliceS/len
           (%Poly%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS. self!)
          )
         ) (- (uHi SZ) 1)
    )))))
    :pattern ((lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceTrait.spec_arrayseqmtephslice_wf.?
      $ (TYPE%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS. T&.
       T&
      ) T&. T& self!
    ))
    :qid internal_lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.impl&__3.spec_arrayseqmtephslice_wf.?_definition
    :skolemid skolem_internal_lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.impl&__3.spec_arrayseqmtephslice_wf.?_definition
))))

;; Function-Axioms lib::Chap19::ArraySeqMtEphSlice::ArraySeqMtEphSlice::ArraySeqMtEphSliceS::spec_len
(assert
 (fuel_bool_default fuel%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.impl&%3.spec_len.)
)
(assert
 (=>
  (fuel_bool fuel%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.impl&%3.spec_len.)
  (forall ((T&. Dcr) (T& Type) (self! Poly)) (!
    (=>
     (and
      (sized T&.)
      (tr_bound%lib!Concurrency.Concurrency.StTInMtT. T&. T&)
     )
     (= (lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceTrait.spec_len.?
       $ (TYPE%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS. T&.
        T&
       ) T&. T& self!
      ) (I (lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS./ArraySeqMtEphSliceS/len
        (%Poly%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS. self!)
    ))))
    :pattern ((lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceTrait.spec_len.?
      $ (TYPE%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS. T&.
       T&
      ) T&. T& self!
    ))
    :qid internal_lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.impl&__3.spec_len.?_definition
    :skolemid skolem_internal_lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.impl&__3.spec_len.?_definition
))))

;; Function-Axioms lib::Chap19::ArraySeqMtEphSlice::ArraySeqMtEphSlice::ArraySeqMtEphSliceS::spec_index
(assert
 (fuel_bool_default fuel%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.impl&%3.spec_index.)
)
(assert
 (=>
  (fuel_bool fuel%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.impl&%3.spec_index.)
  (forall ((T&. Dcr) (T& Type) (self! Poly) (i! Poly)) (!
    (=>
     (and
      (sized T&.)
      (tr_bound%lib!Concurrency.Concurrency.StTInMtT. T&. T&)
     )
     (= (lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceTrait.spec_index.?
       $ (TYPE%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS. T&.
        T&
       ) T&. T& self! i!
      ) (vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. T&. T&
         $ TYPE%alloc!alloc.Global.
        ) (lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS./ArraySeqMtEphSliceS/data
         (%Poly%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS. self!)
        )
       ) (I (Add (lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS./ArraySeqMtEphSliceS/start
          (%Poly%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS. self!)
         ) (%I i!)
    )))))
    :pattern ((lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceTrait.spec_index.?
      $ (TYPE%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS. T&.
       T&
      ) T&. T& self! i!
    ))
    :qid internal_lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.impl&__3.spec_index.?_definition
    :skolemid skolem_internal_lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.impl&__3.spec_index.?_definition
))))

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (and
     (sized T&.)
     (tr_bound%vstd!view.View. T&. T&)
    )
    (tr_bound%vstd!view.View. $ (TYPE%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS.
      T&. T&
   )))
   :pattern ((tr_bound%vstd!view.View. $ (TYPE%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS.
      T&. T&
   )))
   :qid internal_lib__Chap19__ArraySeqMtEphSlice__ArraySeqMtEphSlice__impl&__2_trait_impl_definition
   :skolemid skolem_internal_lib__Chap19__ArraySeqMtEphSlice__ArraySeqMtEphSlice__impl&__2_trait_impl_definition
)))

;; Function-Axioms lib::Chap19::ArraySeqMtEphSlice::ArraySeqMtEphSlice::ArraySeqMtEphSliceS::eq_spec
(assert
 (fuel_bool_default fuel%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.impl&%5.eq_spec.)
)
(assert
 (=>
  (fuel_bool fuel%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.impl&%5.eq_spec.)
  (forall ((T&. Dcr) (T& Type) (self! Poly) (other! Poly)) (!
    (=>
     (and
      (sized T&.)
      (tr_bound%vstd!view.View. T&. T&)
      (tr_bound%core!cmp.PartialEq. T&. T& T&. T&)
      (tr_bound%core!cmp.Eq. T&. T&)
      (tr_bound%core!clone.Clone. T&. T&)
     )
     (= (vstd!std_specs.cmp.PartialEqSpec.eq_spec.? $ (TYPE%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS.
        T&. T&
       ) $ (TYPE%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS. T&.
        T&
       ) self! other!
      ) (B (= (vstd!view.View.view.? $ (TYPE%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS.
          T&. T&
         ) self!
        ) (vstd!view.View.view.? $ (TYPE%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS.
          T&. T&
         ) other!
    )))))
    :pattern ((vstd!std_specs.cmp.PartialEqSpec.eq_spec.? $ (TYPE%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS.
       T&. T&
      ) $ (TYPE%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS. T&.
       T&
      ) self! other!
    ))
    :qid internal_lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.impl&__5.eq_spec.?_definition
    :skolemid skolem_internal_lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.impl&__5.eq_spec.?_definition
))))

;; Function-Axioms lib::Chap35::OrderStatSelectMtEph::OrderStatSelectMtEph::spec_const_seq
(assert
 (fuel_bool_default fuel%lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.spec_const_seq.)
)
(declare-fun %%lambda%%6 (Poly) %%Function%%)
(assert
 (forall ((%%hole%%0 Poly) (unused$ Poly)) (!
   (= (%%apply%%0 (%%lambda%%6 %%hole%%0) unused$) %%hole%%0)
   :pattern ((%%apply%%0 (%%lambda%%6 %%hole%%0) unused$))
)))
(assert
 (=>
  (fuel_bool fuel%lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.spec_const_seq.)
  (forall ((T&. Dcr) (T& Type) (n! Poly) (v! Poly)) (!
    (= (lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.spec_const_seq.? T&. T& n!
      v!
     ) (vstd!seq.Seq.new.? T&. T& n! (Poly%fun%1. (mk_fun (%%lambda%%6 v!))))
    )
    :pattern ((lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.spec_const_seq.? T&.
      T& n! v!
    ))
    :qid internal_lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.spec_const_seq.?_definition
    :skolemid skolem_internal_lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.spec_const_seq.?_definition
))))
(assert
 (forall ((T&. Dcr) (T& Type) (n! Poly) (v! Poly)) (!
   (=>
    (and
     (has_type n! NAT)
     (has_type v! T&)
    )
    (has_type (lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.spec_const_seq.? T&.
      T& n! v!
     ) (TYPE%vstd!seq.Seq. T&. T&)
   ))
   :pattern ((lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.spec_const_seq.? T&.
     T& n! v!
   ))
   :qid internal_lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.spec_const_seq.?_pre_post_definition
   :skolemid skolem_internal_lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.spec_const_seq.?_pre_post_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (and
     (sized T&.)
     (tr_bound%lib!Concurrency.Concurrency.StTInMtT. T&. T&)
    )
    (tr_bound%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceTrait.
     $ (TYPE%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS. T&.
      T&
     ) T&. T&
   ))
   :pattern ((tr_bound%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceTrait.
     $ (TYPE%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS. T&.
      T&
     ) T&. T&
   ))
   :qid internal_lib__Chap19__ArraySeqMtEphSlice__ArraySeqMtEphSlice__impl&__3_trait_impl_definition
   :skolemid skolem_internal_lib__Chap19__ArraySeqMtEphSlice__ArraySeqMtEphSlice__impl&__3_trait_impl_definition
)))

;; Function-Axioms lib::Chap35::OrderStatSelectMtEph::OrderStatSelectMtEph::spec_slice_elements
(assert
 (fuel_bool_default fuel%lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.spec_slice_elements.)
)
(declare-fun %%lambda%%7 (Dcr Type Dcr Type Poly) %%Function%%)
(assert
 (forall ((%%hole%%0 Dcr) (%%hole%%1 Type) (%%hole%%2 Dcr) (%%hole%%3 Type) (%%hole%%4
    Poly
   ) (i$ Poly)
  ) (!
   (= (%%apply%%0 (%%lambda%%7 %%hole%%0 %%hole%%1 %%hole%%2 %%hole%%3 %%hole%%4) i$)
    (lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceTrait.spec_index.?
     %%hole%%0 %%hole%%1 %%hole%%2 %%hole%%3 %%hole%%4 i$
   ))
   :pattern ((%%apply%%0 (%%lambda%%7 %%hole%%0 %%hole%%1 %%hole%%2 %%hole%%3 %%hole%%4)
     i$
)))))
(assert
 (=>
  (fuel_bool fuel%lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.spec_slice_elements.)
  (forall ((T&. Dcr) (T& Type) (a! Poly)) (!
    (= (lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.spec_slice_elements.? T&.
      T& a!
     ) (vstd!seq.Seq.new.? T&. T& (lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceTrait.spec_len.?
       $ (TYPE%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS. T&.
        T&
       ) T&. T& a!
      ) (Poly%fun%1. (mk_fun (%%lambda%%7 $ (TYPE%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS.
          T&. T&
         ) T&. T& a!
    )))))
    :pattern ((lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.spec_slice_elements.?
      T&. T& a!
    ))
    :qid internal_lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.spec_slice_elements.?_definition
    :skolemid skolem_internal_lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.spec_slice_elements.?_definition
))))
(assert
 (forall ((T&. Dcr) (T& Type) (a! Poly)) (!
   (=>
    (has_type a! (TYPE%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS.
      T&. T&
    ))
    (has_type (lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.spec_slice_elements.?
      T&. T& a!
     ) (TYPE%vstd!seq.Seq. T&. T&)
   ))
   :pattern ((lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.spec_slice_elements.?
     T&. T& a!
   ))
   :qid internal_lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.spec_slice_elements.?_pre_post_definition
   :skolemid skolem_internal_lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.spec_slice_elements.?_pre_post_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type)) (!
   (=>
    (and
     (sized T&.)
     (uInv SZ (const_int N&))
     (tr_bound%vstd!view.DeepView. T&. T&)
    )
    (tr_bound%vstd!view.DeepView. $ (ARRAY T&. T& N&. N&))
   )
   :pattern ((tr_bound%vstd!view.DeepView. $ (ARRAY T&. T& N&. N&)))
   :qid internal_vstd__array__impl&__1_trait_impl_definition
   :skolemid skolem_internal_vstd__array__impl&__1_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (and
     (sized T&.)
     (tr_bound%vstd!view.DeepView. T&. T&)
    )
    (tr_bound%vstd!view.DeepView. $slice (SLICE T&. T&))
   )
   :pattern ((tr_bound%vstd!view.DeepView. $slice (SLICE T&. T&)))
   :qid internal_vstd__slice__impl&__1_trait_impl_definition
   :skolemid skolem_internal_vstd__slice__impl&__1_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (tr_bound%vstd!view.View. A&. A&)
    (tr_bound%vstd!view.View. (BOX $ TYPE%alloc!alloc.Global. A&.) A&)
   )
   :pattern ((tr_bound%vstd!view.View. (BOX $ TYPE%alloc!alloc.Global. A&.) A&))
   :qid internal_vstd__view__impl&__2_trait_impl_definition
   :skolemid skolem_internal_vstd__view__impl&__2_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (tr_bound%vstd!view.DeepView. A&. A&)
    (tr_bound%vstd!view.DeepView. (BOX $ TYPE%alloc!alloc.Global. A&.) A&)
   )
   :pattern ((tr_bound%vstd!view.DeepView. (BOX $ TYPE%alloc!alloc.Global. A&.) A&))
   :qid internal_vstd__view__impl&__3_trait_impl_definition
   :skolemid skolem_internal_vstd__view__impl&__3_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%vstd!view.View. A&. A&)
    )
    (tr_bound%vstd!view.View. (RC $ TYPE%alloc!alloc.Global. A&.) A&)
   )
   :pattern ((tr_bound%vstd!view.View. (RC $ TYPE%alloc!alloc.Global. A&.) A&))
   :qid internal_vstd__view__impl&__4_trait_impl_definition
   :skolemid skolem_internal_vstd__view__impl&__4_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%vstd!view.DeepView. A&. A&)
    )
    (tr_bound%vstd!view.DeepView. (RC $ TYPE%alloc!alloc.Global. A&.) A&)
   )
   :pattern ((tr_bound%vstd!view.DeepView. (RC $ TYPE%alloc!alloc.Global. A&.) A&))
   :qid internal_vstd__view__impl&__5_trait_impl_definition
   :skolemid skolem_internal_vstd__view__impl&__5_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%vstd!view.DeepView. A&. A&)
    )
    (tr_bound%vstd!view.DeepView. (ARC $ TYPE%alloc!alloc.Global. A&.) A&)
   )
   :pattern ((tr_bound%vstd!view.DeepView. (ARC $ TYPE%alloc!alloc.Global. A&.) A&))
   :qid internal_vstd__view__impl&__7_trait_impl_definition
   :skolemid skolem_internal_vstd__view__impl&__7_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (tr_bound%vstd!view.View. $ TYPE%tuple%0.)
)

;; Trait-Impl-Axiom
(assert
 (tr_bound%vstd!view.DeepView. $ TYPE%tuple%0.)
)

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type) (U&. Dcr) (U& Type) (N&. Dcr) (N& Type)) (!
   (=>
    (and
     (sized T&.)
     (sized U&.)
     (uInv SZ (const_int N&))
     (tr_bound%core!cmp.PartialEq. T&. T& U&. U&)
    )
    (tr_bound%core!cmp.PartialEq. $ (ARRAY T&. T& N&. N&) $ (ARRAY U&. U& N&. N&))
   )
   :pattern ((tr_bound%core!cmp.PartialEq. $ (ARRAY T&. T& N&. N&) $ (ARRAY U&. U& N&.
      N&
   )))
   :qid internal_core__array__equality__impl&__0_trait_impl_definition
   :skolemid skolem_internal_core__array__equality__impl&__0_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type) (U&. Dcr) (U& Type) (N&. Dcr) (N& Type)) (!
   (=>
    (and
     (sized T&.)
     (sized U&.)
     (uInv SZ (const_int N&))
     (tr_bound%core!cmp.PartialEq. T&. T& U&. U&)
     (tr_bound%vstd!std_specs.cmp.PartialEqSpec. T&. T& U&. U&)
    )
    (tr_bound%vstd!std_specs.cmp.PartialEqSpec. $ (ARRAY T&. T& N&. N&) $ (ARRAY U&. U&
      N&. N&
   )))
   :pattern ((tr_bound%vstd!std_specs.cmp.PartialEqSpec. $ (ARRAY T&. T& N&. N&) $ (ARRAY
      U&. U& N&. N&
   )))
   :qid internal_vstd__std_specs__array__impl&__0_trait_impl_definition
   :skolemid skolem_internal_vstd__std_specs__array__impl&__0_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type) (U&. Dcr) (U& Type) (N&. Dcr) (N& Type)) (!
   (=>
    (and
     (sized T&.)
     (sized U&.)
     (uInv SZ (const_int N&))
     (tr_bound%core!cmp.PartialEq. T&. T& U&. U&)
    )
    (tr_bound%core!cmp.PartialEq. (REF $slice) (SLICE T&. T&) $ (ARRAY U&. U& N&. N&))
   )
   :pattern ((tr_bound%core!cmp.PartialEq. (REF $slice) (SLICE T&. T&) $ (ARRAY U&. U&
      N&. N&
   )))
   :qid internal_core__array__equality__impl&__4_trait_impl_definition
   :skolemid skolem_internal_core__array__equality__impl&__4_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type) (U&. Dcr) (U& Type) (N&. Dcr) (N& Type)) (!
   (=>
    (and
     (sized T&.)
     (sized U&.)
     (uInv SZ (const_int N&))
     (tr_bound%core!cmp.PartialEq. T&. T& U&. U&)
     (tr_bound%vstd!std_specs.cmp.PartialEqSpec. T&. T& U&. U&)
    )
    (tr_bound%vstd!std_specs.cmp.PartialEqSpec. (REF $slice) (SLICE T&. T&) $ (ARRAY U&.
      U& N&. N&
   )))
   :pattern ((tr_bound%vstd!std_specs.cmp.PartialEqSpec. (REF $slice) (SLICE T&. T&) $
     (ARRAY U&. U& N&. N&)
   ))
   :qid internal_vstd__std_specs__array__impl&__1_trait_impl_definition
   :skolemid skolem_internal_vstd__std_specs__array__impl&__1_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type) (U&. Dcr) (U& Type) (N&. Dcr) (N& Type)) (!
   (=>
    (and
     (sized T&.)
     (sized U&.)
     (uInv SZ (const_int N&))
     (tr_bound%core!cmp.PartialEq. T&. T& U&. U&)
    )
    (tr_bound%core!cmp.PartialEq. $ (ARRAY T&. T& N&. N&) (REF $slice) (SLICE U&. U&))
   )
   :pattern ((tr_bound%core!cmp.PartialEq. $ (ARRAY T&. T& N&. N&) (REF $slice) (SLICE
      U&. U&
   )))
   :qid internal_core__array__equality__impl&__3_trait_impl_definition
   :skolemid skolem_internal_core__array__equality__impl&__3_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type) (U&. Dcr) (U& Type) (N&. Dcr) (N& Type)) (!
   (=>
    (and
     (sized T&.)
     (sized U&.)
     (uInv SZ (const_int N&))
     (tr_bound%core!cmp.PartialEq. T&. T& U&. U&)
     (tr_bound%vstd!std_specs.cmp.PartialEqSpec. T&. T& U&. U&)
    )
    (tr_bound%vstd!std_specs.cmp.PartialEqSpec. $ (ARRAY T&. T& N&. N&) (REF $slice) (
      SLICE U&. U&
   )))
   :pattern ((tr_bound%vstd!std_specs.cmp.PartialEqSpec. $ (ARRAY T&. T& N&. N&) (REF $slice)
     (SLICE U&. U&)
   ))
   :qid internal_vstd__std_specs__array__impl&__2_trait_impl_definition
   :skolemid skolem_internal_vstd__std_specs__array__impl&__2_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type) (U&. Dcr) (U& Type) (N&. Dcr) (N& Type)) (!
   (=>
    (and
     (sized T&.)
     (sized U&.)
     (uInv SZ (const_int N&))
     (tr_bound%core!cmp.PartialEq. T&. T& U&. U&)
    )
    (tr_bound%core!cmp.PartialEq. $slice (SLICE T&. T&) $ (ARRAY U&. U& N&. N&))
   )
   :pattern ((tr_bound%core!cmp.PartialEq. $slice (SLICE T&. T&) $ (ARRAY U&. U& N&. N&)))
   :qid internal_core__array__equality__impl&__2_trait_impl_definition
   :skolemid skolem_internal_core__array__equality__impl&__2_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type) (U&. Dcr) (U& Type) (N&. Dcr) (N& Type)) (!
   (=>
    (and
     (sized T&.)
     (sized U&.)
     (uInv SZ (const_int N&))
     (tr_bound%core!cmp.PartialEq. T&. T& U&. U&)
     (tr_bound%vstd!std_specs.cmp.PartialEqSpec. T&. T& U&. U&)
    )
    (tr_bound%vstd!std_specs.cmp.PartialEqSpec. $slice (SLICE T&. T&) $ (ARRAY U&. U& N&.
      N&
   )))
   :pattern ((tr_bound%vstd!std_specs.cmp.PartialEqSpec. $slice (SLICE T&. T&) $ (ARRAY
      U&. U& N&. N&
   )))
   :qid internal_vstd__std_specs__array__impl&__3_trait_impl_definition
   :skolemid skolem_internal_vstd__std_specs__array__impl&__3_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type) (U&. Dcr) (U& Type) (N&. Dcr) (N& Type)) (!
   (=>
    (and
     (sized T&.)
     (sized U&.)
     (uInv SZ (const_int N&))
     (tr_bound%core!cmp.PartialEq. T&. T& U&. U&)
    )
    (tr_bound%core!cmp.PartialEq. $ (ARRAY T&. T& N&. N&) $slice (SLICE U&. U&))
   )
   :pattern ((tr_bound%core!cmp.PartialEq. $ (ARRAY T&. T& N&. N&) $slice (SLICE U&. U&)))
   :qid internal_core__array__equality__impl&__1_trait_impl_definition
   :skolemid skolem_internal_core__array__equality__impl&__1_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type) (U&. Dcr) (U& Type) (N&. Dcr) (N& Type)) (!
   (=>
    (and
     (sized T&.)
     (sized U&.)
     (uInv SZ (const_int N&))
     (tr_bound%core!cmp.PartialEq. T&. T& U&. U&)
     (tr_bound%vstd!std_specs.cmp.PartialEqSpec. T&. T& U&. U&)
    )
    (tr_bound%vstd!std_specs.cmp.PartialEqSpec. $ (ARRAY T&. T& N&. N&) $slice (SLICE U&.
      U&
   )))
   :pattern ((tr_bound%vstd!std_specs.cmp.PartialEqSpec. $ (ARRAY T&. T& N&. N&) $slice
     (SLICE U&. U&)
   ))
   :qid internal_vstd__std_specs__array__impl&__4_trait_impl_definition
   :skolemid skolem_internal_vstd__std_specs__array__impl&__4_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (tr_bound%core!cmp.Eq. A&. A&)
    (tr_bound%core!cmp.Eq. (REF A&.) A&)
   )
   :pattern ((tr_bound%core!cmp.Eq. (REF A&.) A&))
   :qid internal_core__cmp__impls__impl&__12_trait_impl_definition
   :skolemid skolem_internal_core__cmp__impls__impl&__12_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (and
     (sized T&.)
     (tr_bound%core!cmp.Eq. T&. T&)
    )
    (tr_bound%core!cmp.Eq. (DST T&.) (TYPE%tuple%1. T&. T&))
   )
   :pattern ((tr_bound%core!cmp.Eq. (DST T&.) (TYPE%tuple%1. T&. T&)))
   :qid internal_core__tuple__impl&__1_trait_impl_definition
   :skolemid skolem_internal_core__tuple__impl&__1_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((U&. Dcr) (U& Type) (T&. Dcr) (T& Type)) (!
   (=>
    (and
     (sized U&.)
     (sized T&.)
     (tr_bound%core!cmp.Eq. U&. U&)
     (tr_bound%core!cmp.Eq. T&. T&)
    )
    (tr_bound%core!cmp.Eq. (DST T&.) (TYPE%tuple%2. U&. U& T&. T&))
   )
   :pattern ((tr_bound%core!cmp.Eq. (DST T&.) (TYPE%tuple%2. U&. U& T&. T&)))
   :qid internal_core__tuple__impl&__11_trait_impl_definition
   :skolemid skolem_internal_core__tuple__impl&__11_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((V&. Dcr) (V& Type) (U&. Dcr) (U& Type) (T&. Dcr) (T& Type)) (!
   (=>
    (and
     (sized V&.)
     (sized U&.)
     (sized T&.)
     (tr_bound%core!cmp.Eq. V&. V&)
     (tr_bound%core!cmp.Eq. U&. U&)
     (tr_bound%core!cmp.Eq. T&. T&)
    )
    (tr_bound%core!cmp.Eq. (DST T&.) (TYPE%tuple%3. V&. V& U&. U& T&. T&))
   )
   :pattern ((tr_bound%core!cmp.Eq. (DST T&.) (TYPE%tuple%3. V&. V& U&. U& T&. T&)))
   :qid internal_core__tuple__impl&__21_trait_impl_definition
   :skolemid skolem_internal_core__tuple__impl&__21_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (and
     (sized T&.)
     (tr_bound%core!cmp.Eq. T&. T&)
    )
    (tr_bound%core!cmp.Eq. $ (TYPE%core!option.Option. T&. T&))
   )
   :pattern ((tr_bound%core!cmp.Eq. $ (TYPE%core!option.Option. T&. T&)))
   :qid internal_core__option__impl&__57_trait_impl_definition
   :skolemid skolem_internal_core__option__impl&__57_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type) (U&. Dcr) (U& Type)) (!
   (=>
    (and
     (sized T&.)
     (sized U&.)
     (tr_bound%core!cmp.PartialEq. T&. T& U&. U&)
    )
    (tr_bound%core!cmp.PartialEq. $slice (SLICE T&. T&) $slice (SLICE U&. U&))
   )
   :pattern ((tr_bound%core!cmp.PartialEq. $slice (SLICE T&. T&) $slice (SLICE U&. U&)))
   :qid internal_core__slice__cmp__impl&__0_trait_impl_definition
   :skolemid skolem_internal_core__slice__cmp__impl&__0_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type) (U&. Dcr) (U& Type)) (!
   (=>
    (and
     (sized T&.)
     (sized U&.)
     (tr_bound%core!cmp.PartialEq. T&. T& U&. U&)
     (tr_bound%vstd!std_specs.cmp.PartialEqSpec. T&. T& U&. U&)
    )
    (tr_bound%vstd!std_specs.cmp.PartialEqSpec. $slice (SLICE T&. T&) $slice (SLICE U&.
      U&
   )))
   :pattern ((tr_bound%vstd!std_specs.cmp.PartialEqSpec. $slice (SLICE T&. T&) $slice
     (SLICE U&. U&)
   ))
   :qid internal_vstd__std_specs__slice__impl&__9_trait_impl_definition
   :skolemid skolem_internal_vstd__std_specs__slice__impl&__9_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type) (U&. Dcr) (U& Type) (A1&. Dcr) (A1& Type) (A2&. Dcr) (
    A2& Type
   )
  ) (!
   (=>
    (and
     (sized T&.)
     (sized U&.)
     (sized A1&.)
     (sized A2&.)
     (tr_bound%core!alloc.Allocator. A1&. A1&)
     (tr_bound%core!alloc.Allocator. A2&. A2&)
     (tr_bound%core!cmp.PartialEq. T&. T& U&. U&)
    )
    (tr_bound%core!cmp.PartialEq. $ (TYPE%alloc!vec.Vec. T&. T& A1&. A1&) $ (TYPE%alloc!vec.Vec.
      U&. U& A2&. A2&
   )))
   :pattern ((tr_bound%core!cmp.PartialEq. $ (TYPE%alloc!vec.Vec. T&. T& A1&. A1&) $ (
      TYPE%alloc!vec.Vec. U&. U& A2&. A2&
   )))
   :qid internal_alloc__vec__partial_eq__impl&__0_trait_impl_definition
   :skolemid skolem_internal_alloc__vec__partial_eq__impl&__0_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type) (U&. Dcr) (U& Type) (A1&. Dcr) (A1& Type) (A2&. Dcr) (
    A2& Type
   )
  ) (!
   (=>
    (and
     (sized T&.)
     (sized U&.)
     (sized A1&.)
     (sized A2&.)
     (tr_bound%vstd!std_specs.cmp.PartialEqSpec. T&. T& U&. U&)
     (tr_bound%core!alloc.Allocator. A1&. A1&)
     (tr_bound%core!alloc.Allocator. A2&. A2&)
    )
    (tr_bound%vstd!std_specs.cmp.PartialEqSpec. $ (TYPE%alloc!vec.Vec. T&. T& A1&. A1&)
     $ (TYPE%alloc!vec.Vec. U&. U& A2&. A2&)
   ))
   :pattern ((tr_bound%vstd!std_specs.cmp.PartialEqSpec. $ (TYPE%alloc!vec.Vec. T&. T&
      A1&. A1&
     ) $ (TYPE%alloc!vec.Vec. U&. U& A2&. A2&)
   ))
   :qid internal_vstd__std_specs__vec__impl&__2_trait_impl_definition
   :skolemid skolem_internal_vstd__std_specs__vec__impl&__2_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized T&.)
     (sized A&.)
     (tr_bound%core!clone.Clone. T&. T&)
     (tr_bound%core!alloc.Allocator. A&. A&)
     (tr_bound%core!clone.Clone. A&. A&)
    )
    (tr_bound%core!clone.Clone. (BOX A&. A& T&.) T&)
   )
   :pattern ((tr_bound%core!clone.Clone. (BOX A&. A& T&.) T&))
   :qid internal_alloc__boxed__impl&__15_trait_impl_definition
   :skolemid skolem_internal_alloc__boxed__impl&__15_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized T&.)
     (sized A&.)
     (tr_bound%core!clone.Clone. T&. T&)
     (tr_bound%core!alloc.Allocator. A&. A&)
     (tr_bound%core!clone.Clone. A&. A&)
    )
    (tr_bound%core!clone.Clone. (BOX A&. A& $slice) (SLICE T&. T&))
   )
   :pattern ((tr_bound%core!clone.Clone. (BOX A&. A& $slice) (SLICE T&. T&)))
   :qid internal_alloc__boxed__impl&__16_trait_impl_definition
   :skolemid skolem_internal_alloc__boxed__impl&__16_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (tr_bound%core!clone.Clone. $ BOOL)
)

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (tr_bound%core!clone.Clone. (CONST_PTR $) (PTR T&. T&))
   :pattern ((tr_bound%core!clone.Clone. (CONST_PTR $) (PTR T&. T&)))
   :qid internal_core__clone__impls__impl&__2_trait_impl_definition
   :skolemid skolem_internal_core__clone__impls__impl&__2_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (tr_bound%core!clone.Clone. $ (PTR T&. T&))
   :pattern ((tr_bound%core!clone.Clone. $ (PTR T&. T&)))
   :qid internal_core__clone__impls__impl&__4_trait_impl_definition
   :skolemid skolem_internal_core__clone__impls__impl&__4_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (tr_bound%core!clone.Clone. (REF T&.) T&)
   :pattern ((tr_bound%core!clone.Clone. (REF T&.) T&))
   :qid internal_core__clone__impls__impl&__6_trait_impl_definition
   :skolemid skolem_internal_core__clone__impls__impl&__6_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (tr_bound%core!clone.Clone. $ TYPE%core!cmp.Ordering.)
)

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type)) (!
   (=>
    (and
     (sized T&.)
     (uInv SZ (const_int N&))
     (tr_bound%core!clone.Clone. T&. T&)
    )
    (tr_bound%core!clone.Clone. $ (ARRAY T&. T& N&. N&))
   )
   :pattern ((tr_bound%core!clone.Clone. $ (ARRAY T&. T& N&. N&)))
   :qid internal_core__array__impl&__20_trait_impl_definition
   :skolemid skolem_internal_core__array__impl&__20_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!alloc.Allocator. A&. A&)
     (tr_bound%core!clone.Clone. A&. A&)
    )
    (tr_bound%core!clone.Clone. (RC A&. A& T&.) T&)
   )
   :pattern ((tr_bound%core!clone.Clone. (RC A&. A& T&.) T&))
   :qid internal_alloc__rc__impl&__35_trait_impl_definition
   :skolemid skolem_internal_alloc__rc__impl&__35_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!alloc.Allocator. A&. A&)
     (tr_bound%core!clone.Clone. A&. A&)
    )
    (tr_bound%core!clone.Clone. (ARC A&. A& T&.) T&)
   )
   :pattern ((tr_bound%core!clone.Clone. (ARC A&. A& T&.) T&))
   :qid internal_alloc__sync__impl&__32_trait_impl_definition
   :skolemid skolem_internal_alloc__sync__impl&__32_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (sized A&.)
    (tr_bound%core!clone.Clone. (GHOST A&.) A&)
   )
   :pattern ((tr_bound%core!clone.Clone. (GHOST A&.) A&))
   :qid internal_verus_builtin__impl&__7_trait_impl_definition
   :skolemid skolem_internal_verus_builtin__impl&__7_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Copy. A&. A&)
    )
    (tr_bound%core!clone.Clone. (TRACKED A&.) A&)
   )
   :pattern ((tr_bound%core!clone.Clone. (TRACKED A&.) A&))
   :qid internal_verus_builtin__impl&__9_trait_impl_definition
   :skolemid skolem_internal_verus_builtin__impl&__9_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (tr_bound%core!clone.Clone. $ INT)
)

;; Trait-Impl-Axiom
(assert
 (tr_bound%core!clone.Clone. $ NAT)
)

;; Trait-Impl-Axiom
(assert
 (forall ((A&. Dcr) (A& Type) (B&. Dcr) (B& Type)) (!
   (=>
    (tr_bound%core!cmp.PartialEq. A&. A& B&. B&)
    (tr_bound%core!cmp.PartialEq. (REF A&.) A& $ (MUTREF B&. B&))
   )
   :pattern ((tr_bound%core!cmp.PartialEq. (REF A&.) A& $ (MUTREF B&. B&)))
   :qid internal_core__cmp__impls__impl&__17_trait_impl_definition
   :skolemid skolem_internal_core__cmp__impls__impl&__17_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type) (U&. Dcr) (U& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized T&.)
     (sized U&.)
     (sized A&.)
     (tr_bound%core!alloc.Allocator. A&. A&)
     (tr_bound%core!cmp.PartialEq. T&. T& U&. U&)
    )
    (tr_bound%core!cmp.PartialEq. (REF $slice) (SLICE T&. T&) $ (TYPE%alloc!vec.Vec. U&.
      U& A&. A&
   )))
   :pattern ((tr_bound%core!cmp.PartialEq. (REF $slice) (SLICE T&. T&) $ (TYPE%alloc!vec.Vec.
      U&. U& A&. A&
   )))
   :qid internal_alloc__vec__partial_eq__impl&__3_trait_impl_definition
   :skolemid skolem_internal_alloc__vec__partial_eq__impl&__3_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (tr_bound%core!cmp.PartialEq. (CONST_PTR $) (PTR T&. T&) (CONST_PTR $) (PTR T&. T&))
   :pattern ((tr_bound%core!cmp.PartialEq. (CONST_PTR $) (PTR T&. T&) (CONST_PTR $) (PTR
      T&. T&
   )))
   :qid internal_core__ptr__const_ptr__impl&__7_trait_impl_definition
   :skolemid skolem_internal_core__ptr__const_ptr__impl&__7_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (tr_bound%core!cmp.PartialEq. $ (PTR T&. T&) $ (PTR T&. T&))
   :pattern ((tr_bound%core!cmp.PartialEq. $ (PTR T&. T&) $ (PTR T&. T&)))
   :qid internal_core__ptr__mut_ptr__impl&__7_trait_impl_definition
   :skolemid skolem_internal_core__ptr__mut_ptr__impl&__7_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (tr_bound%core!cmp.PartialEq. $ TYPE%core!cmp.Ordering. $ TYPE%core!cmp.Ordering.)
)

;; Trait-Impl-Axiom
(assert
 (tr_bound%core!cmp.PartialEq. $ TYPE%tuple%0. $ TYPE%tuple%0.)
)

;; Trait-Impl-Axiom
(assert
 (forall ((A&. Dcr) (A& Type) (B&. Dcr) (B& Type)) (!
   (=>
    (tr_bound%core!cmp.PartialEq. A&. A& B&. B&)
    (tr_bound%core!cmp.PartialEq. $ (MUTREF A&. A&) $ (MUTREF B&. B&))
   )
   :pattern ((tr_bound%core!cmp.PartialEq. $ (MUTREF A&. A&) $ (MUTREF B&. B&)))
   :qid internal_core__cmp__impls__impl&__13_trait_impl_definition
   :skolemid skolem_internal_core__cmp__impls__impl&__13_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((A&. Dcr) (A& Type) (B&. Dcr) (B& Type)) (!
   (=>
    (tr_bound%core!cmp.PartialEq. A&. A& B&. B&)
    (tr_bound%core!cmp.PartialEq. $ (MUTREF A&. A&) (REF B&.) B&)
   )
   :pattern ((tr_bound%core!cmp.PartialEq. $ (MUTREF A&. A&) (REF B&.) B&))
   :qid internal_core__cmp__impls__impl&__18_trait_impl_definition
   :skolemid skolem_internal_core__cmp__impls__impl&__18_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type) (U&. Dcr) (U& Type) (N&. Dcr) (N& Type)) (!
   (=>
    (and
     (sized T&.)
     (sized U&.)
     (uInv SZ (const_int N&))
     (tr_bound%core!cmp.PartialEq. T&. T& U&. U&)
    )
    (tr_bound%core!cmp.PartialEq. $ (MUTREF $slice (SLICE T&. T&)) $ (ARRAY U&. U& N&.
      N&
   )))
   :pattern ((tr_bound%core!cmp.PartialEq. $ (MUTREF $slice (SLICE T&. T&)) $ (ARRAY U&.
      U& N&. N&
   )))
   :qid internal_core__array__equality__impl&__6_trait_impl_definition
   :skolemid skolem_internal_core__array__equality__impl&__6_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type) (U&. Dcr) (U& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized T&.)
     (sized U&.)
     (sized A&.)
     (tr_bound%core!alloc.Allocator. A&. A&)
     (tr_bound%core!cmp.PartialEq. T&. T& U&. U&)
    )
    (tr_bound%core!cmp.PartialEq. $ (MUTREF $slice (SLICE T&. T&)) $ (TYPE%alloc!vec.Vec.
      U&. U& A&. A&
   )))
   :pattern ((tr_bound%core!cmp.PartialEq. $ (MUTREF $slice (SLICE T&. T&)) $ (TYPE%alloc!vec.Vec.
      U&. U& A&. A&
   )))
   :qid internal_alloc__vec__partial_eq__impl&__4_trait_impl_definition
   :skolemid skolem_internal_alloc__vec__partial_eq__impl&__4_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type) (U&. Dcr) (U& Type) (N&. Dcr) (N& Type)) (!
   (=>
    (and
     (sized T&.)
     (sized U&.)
     (uInv SZ (const_int N&))
     (tr_bound%core!cmp.PartialEq. T&. T& U&. U&)
    )
    (tr_bound%core!cmp.PartialEq. $ (ARRAY T&. T& N&. N&) $ (MUTREF $slice (SLICE U&. U&)))
   )
   :pattern ((tr_bound%core!cmp.PartialEq. $ (ARRAY T&. T& N&. N&) $ (MUTREF $slice (SLICE
       U&. U&
   ))))
   :qid internal_core__array__equality__impl&__5_trait_impl_definition
   :skolemid skolem_internal_core__array__equality__impl&__5_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type) (U&. Dcr) (U& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized T&.)
     (sized U&.)
     (sized A&.)
     (tr_bound%core!alloc.Allocator. A&. A&)
     (tr_bound%core!cmp.PartialEq. T&. T& U&. U&)
    )
    (tr_bound%core!cmp.PartialEq. $slice (SLICE T&. T&) $ (TYPE%alloc!vec.Vec. U&. U& A&.
      A&
   )))
   :pattern ((tr_bound%core!cmp.PartialEq. $slice (SLICE T&. T&) $ (TYPE%alloc!vec.Vec.
      U&. U& A&. A&
   )))
   :qid internal_alloc__vec__partial_eq__impl&__6_trait_impl_definition
   :skolemid skolem_internal_alloc__vec__partial_eq__impl&__6_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!cmp.PartialEq. T&. T& T&. T&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (tr_bound%core!cmp.PartialEq. (BOX A&. A& T&.) T& (BOX A&. A& T&.) T&)
   )
   :pattern ((tr_bound%core!cmp.PartialEq. (BOX A&. A& T&.) T& (BOX A&. A& T&.) T&))
   :qid internal_alloc__boxed__impl&__18_trait_impl_definition
   :skolemid skolem_internal_alloc__boxed__impl&__18_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type) (U&. Dcr) (U& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized T&.)
     (sized U&.)
     (sized A&.)
     (tr_bound%core!alloc.Allocator. A&. A&)
     (tr_bound%core!cmp.PartialEq. T&. T& U&. U&)
    )
    (tr_bound%core!cmp.PartialEq. $ (TYPE%alloc!vec.Vec. T&. T& A&. A&) (REF $slice) (
      SLICE U&. U&
   )))
   :pattern ((tr_bound%core!cmp.PartialEq. $ (TYPE%alloc!vec.Vec. T&. T& A&. A&) (REF $slice)
     (SLICE U&. U&)
   ))
   :qid internal_alloc__vec__partial_eq__impl&__1_trait_impl_definition
   :skolemid skolem_internal_alloc__vec__partial_eq__impl&__1_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type) (U&. Dcr) (U& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized T&.)
     (sized U&.)
     (sized A&.)
     (tr_bound%core!alloc.Allocator. A&. A&)
     (tr_bound%core!cmp.PartialEq. T&. T& U&. U&)
    )
    (tr_bound%core!cmp.PartialEq. $ (TYPE%alloc!vec.Vec. T&. T& A&. A&) $ (MUTREF $slice
      (SLICE U&. U&)
   )))
   :pattern ((tr_bound%core!cmp.PartialEq. $ (TYPE%alloc!vec.Vec. T&. T& A&. A&) $ (MUTREF
      $slice (SLICE U&. U&)
   )))
   :qid internal_alloc__vec__partial_eq__impl&__2_trait_impl_definition
   :skolemid skolem_internal_alloc__vec__partial_eq__impl&__2_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type) (U&. Dcr) (U& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized T&.)
     (sized U&.)
     (sized A&.)
     (tr_bound%core!alloc.Allocator. A&. A&)
     (tr_bound%core!cmp.PartialEq. T&. T& U&. U&)
    )
    (tr_bound%core!cmp.PartialEq. $ (TYPE%alloc!vec.Vec. T&. T& A&. A&) $slice (SLICE U&.
      U&
   )))
   :pattern ((tr_bound%core!cmp.PartialEq. $ (TYPE%alloc!vec.Vec. T&. T& A&. A&) $slice
     (SLICE U&. U&)
   ))
   :qid internal_alloc__vec__partial_eq__impl&__5_trait_impl_definition
   :skolemid skolem_internal_alloc__vec__partial_eq__impl&__5_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type) (U&. Dcr) (U& Type) (A&. Dcr) (A& Type) (N&. Dcr) (N& Type))
  (!
   (=>
    (and
     (sized T&.)
     (sized U&.)
     (sized A&.)
     (uInv SZ (const_int N&))
     (tr_bound%core!alloc.Allocator. A&. A&)
     (tr_bound%core!cmp.PartialEq. T&. T& U&. U&)
    )
    (tr_bound%core!cmp.PartialEq. $ (TYPE%alloc!vec.Vec. T&. T& A&. A&) $ (ARRAY U&. U&
      N&. N&
   )))
   :pattern ((tr_bound%core!cmp.PartialEq. $ (TYPE%alloc!vec.Vec. T&. T& A&. A&) $ (ARRAY
      U&. U& N&. N&
   )))
   :qid internal_alloc__vec__partial_eq__impl&__10_trait_impl_definition
   :skolemid skolem_internal_alloc__vec__partial_eq__impl&__10_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type) (U&. Dcr) (U& Type) (A&. Dcr) (A& Type) (N&. Dcr) (N& Type))
  (!
   (=>
    (and
     (sized T&.)
     (sized U&.)
     (sized A&.)
     (uInv SZ (const_int N&))
     (tr_bound%core!alloc.Allocator. A&. A&)
     (tr_bound%core!cmp.PartialEq. T&. T& U&. U&)
    )
    (tr_bound%core!cmp.PartialEq. $ (TYPE%alloc!vec.Vec. T&. T& A&. A&) (REF $) (ARRAY
      U&. U& N&. N&
   )))
   :pattern ((tr_bound%core!cmp.PartialEq. $ (TYPE%alloc!vec.Vec. T&. T& A&. A&) (REF $)
     (ARRAY U&. U& N&. N&)
   ))
   :qid internal_alloc__vec__partial_eq__impl&__11_trait_impl_definition
   :skolemid skolem_internal_alloc__vec__partial_eq__impl&__11_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!cmp.PartialEq. T&. T& T&. T&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (tr_bound%core!cmp.PartialEq. (RC A&. A& T&.) T& (RC A&. A& T&.) T&)
   )
   :pattern ((tr_bound%core!cmp.PartialEq. (RC A&. A& T&.) T& (RC A&. A& T&.) T&))
   :qid internal_alloc__rc__impl&__45_trait_impl_definition
   :skolemid skolem_internal_alloc__rc__impl&__45_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!cmp.PartialEq. T&. T& T&. T&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (tr_bound%core!cmp.PartialEq. (ARC A&. A& T&.) T& (ARC A&. A& T&.) T&)
   )
   :pattern ((tr_bound%core!cmp.PartialEq. (ARC A&. A& T&.) T& (ARC A&. A& T&.) T&))
   :qid internal_alloc__sync__impl&__55_trait_impl_definition
   :skolemid skolem_internal_alloc__sync__impl&__55_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (tr_bound%core!cmp.PartialEq. $ INT $ INT)
)

;; Trait-Impl-Axiom
(assert
 (tr_bound%core!cmp.PartialEq. $ NAT $ NAT)
)

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (tr_bound%core!cmp.Eq. (CONST_PTR $) (PTR T&. T&))
   :pattern ((tr_bound%core!cmp.Eq. (CONST_PTR $) (PTR T&. T&)))
   :qid internal_core__ptr__const_ptr__impl&__8_trait_impl_definition
   :skolemid skolem_internal_core__ptr__const_ptr__impl&__8_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (tr_bound%core!cmp.Eq. $ (PTR T&. T&))
   :pattern ((tr_bound%core!cmp.Eq. $ (PTR T&. T&)))
   :qid internal_core__ptr__mut_ptr__impl&__8_trait_impl_definition
   :skolemid skolem_internal_core__ptr__mut_ptr__impl&__8_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (tr_bound%core!cmp.Eq. $ TYPE%core!cmp.Ordering.)
)

;; Trait-Impl-Axiom
(assert
 (tr_bound%core!cmp.Eq. $ TYPE%tuple%0.)
)

;; Trait-Impl-Axiom
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (tr_bound%core!cmp.Eq. A&. A&)
    (tr_bound%core!cmp.Eq. $ (MUTREF A&. A&))
   )
   :pattern ((tr_bound%core!cmp.Eq. $ (MUTREF A&. A&)))
   :qid internal_core__cmp__impls__impl&__16_trait_impl_definition
   :skolemid skolem_internal_core__cmp__impls__impl&__16_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type)) (!
   (=>
    (and
     (sized T&.)
     (uInv SZ (const_int N&))
     (tr_bound%core!cmp.Eq. T&. T&)
    )
    (tr_bound%core!cmp.Eq. $ (ARRAY T&. T& N&. N&))
   )
   :pattern ((tr_bound%core!cmp.Eq. $ (ARRAY T&. T& N&. N&)))
   :qid internal_core__array__equality__impl&__7_trait_impl_definition
   :skolemid skolem_internal_core__array__equality__impl&__7_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (and
     (sized T&.)
     (tr_bound%core!cmp.Eq. T&. T&)
    )
    (tr_bound%core!cmp.Eq. $slice (SLICE T&. T&))
   )
   :pattern ((tr_bound%core!cmp.Eq. $slice (SLICE T&. T&)))
   :qid internal_core__slice__cmp__impl&__1_trait_impl_definition
   :skolemid skolem_internal_core__slice__cmp__impl&__1_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!cmp.Eq. T&. T&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (tr_bound%core!cmp.Eq. (BOX A&. A& T&.) T&)
   )
   :pattern ((tr_bound%core!cmp.Eq. (BOX A&. A& T&.) T&))
   :qid internal_alloc__boxed__impl&__21_trait_impl_definition
   :skolemid skolem_internal_alloc__boxed__impl&__21_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!cmp.Eq. T&. T&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (tr_bound%core!cmp.Eq. (RC A&. A& T&.) T&)
   )
   :pattern ((tr_bound%core!cmp.Eq. (RC A&. A& T&.) T&))
   :qid internal_alloc__rc__impl&__46_trait_impl_definition
   :skolemid skolem_internal_alloc__rc__impl&__46_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!cmp.Eq. T&. T&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (tr_bound%core!cmp.Eq. (ARC A&. A& T&.) T&)
   )
   :pattern ((tr_bound%core!cmp.Eq. (ARC A&. A& T&.) T&))
   :qid internal_alloc__sync__impl&__58_trait_impl_definition
   :skolemid skolem_internal_alloc__sync__impl&__58_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized T&.)
     (sized A&.)
     (tr_bound%core!cmp.Eq. T&. T&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (tr_bound%core!cmp.Eq. $ (TYPE%alloc!vec.Vec. T&. T& A&. A&))
   )
   :pattern ((tr_bound%core!cmp.Eq. $ (TYPE%alloc!vec.Vec. T&. T& A&. A&)))
   :qid internal_alloc__vec__impl&__24_trait_impl_definition
   :skolemid skolem_internal_alloc__vec__impl&__24_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (tr_bound%core!cmp.Eq. $ INT)
)

;; Trait-Impl-Axiom
(assert
 (tr_bound%core!cmp.Eq. $ NAT)
)

;; Trait-Impl-Axiom
(assert
 (tr_bound%core!marker.Copy. $ TYPE%core!cmp.Ordering.)
)

;; Trait-Impl-Axiom
(assert
 (tr_bound%core!marker.Copy. $ USIZE)
)

;; Trait-Impl-Axiom
(assert
 (tr_bound%core!marker.Copy. $ BOOL)
)

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (tr_bound%core!marker.Copy. (CONST_PTR $) (PTR T&. T&))
   :pattern ((tr_bound%core!marker.Copy. (CONST_PTR $) (PTR T&. T&)))
   :qid internal_core__marker__impl&__58_trait_impl_definition
   :skolemid skolem_internal_core__marker__impl&__58_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (tr_bound%core!marker.Copy. $ (PTR T&. T&))
   :pattern ((tr_bound%core!marker.Copy. $ (PTR T&. T&)))
   :qid internal_core__marker__impl&__59_trait_impl_definition
   :skolemid skolem_internal_core__marker__impl&__59_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (tr_bound%core!marker.Copy. (REF T&.) T&)
   :pattern ((tr_bound%core!marker.Copy. (REF T&.) T&))
   :qid internal_core__marker__impl&__4_trait_impl_definition
   :skolemid skolem_internal_core__marker__impl&__4_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type)) (!
   (=>
    (and
     (sized T&.)
     (uInv SZ (const_int N&))
     (tr_bound%core!marker.Copy. T&. T&)
    )
    (tr_bound%core!marker.Copy. $ (ARRAY T&. T& N&. N&))
   )
   :pattern ((tr_bound%core!marker.Copy. $ (ARRAY T&. T& N&. N&)))
   :qid internal_core__array__impl&__19_trait_impl_definition
   :skolemid skolem_internal_core__array__impl&__19_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (and
     (sized T&.)
     (tr_bound%core!clone.Clone. T&. T&)
    )
    (tr_bound%core!clone.Clone. $ (TYPE%core!option.Option. T&. T&))
   )
   :pattern ((tr_bound%core!clone.Clone. $ (TYPE%core!option.Option. T&. T&)))
   :qid internal_core__option__impl&__6_trait_impl_definition
   :skolemid skolem_internal_core__option__impl&__6_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (and
     (sized T&.)
     (tr_bound%core!marker.Copy. T&. T&)
    )
    (tr_bound%core!marker.Copy. $ (TYPE%core!option.Option. T&. T&))
   )
   :pattern ((tr_bound%core!marker.Copy. $ (TYPE%core!option.Option. T&. T&)))
   :qid internal_core__option__impl&__54_trait_impl_definition
   :skolemid skolem_internal_core__option__impl&__54_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (tr_bound%core!marker.Copy. $ TYPE%alloc!alloc.Global.)
)

;; Trait-Impl-Axiom
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (sized A&.)
    (tr_bound%core!marker.Copy. (GHOST A&.) A&)
   )
   :pattern ((tr_bound%core!marker.Copy. (GHOST A&.) A&))
   :qid internal_verus_builtin__impl&__8_trait_impl_definition
   :skolemid skolem_internal_verus_builtin__impl&__8_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Copy. A&. A&)
    )
    (tr_bound%core!marker.Copy. (TRACKED A&.) A&)
   )
   :pattern ((tr_bound%core!marker.Copy. (TRACKED A&.) A&))
   :qid internal_verus_builtin__impl&__10_trait_impl_definition
   :skolemid skolem_internal_verus_builtin__impl&__10_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (tr_bound%core!marker.Copy. $ INT)
)

;; Trait-Impl-Axiom
(assert
 (tr_bound%core!marker.Copy. $ NAT)
)

;; Trait-Impl-Axiom
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.Fn. F&. F& A&. A&)
    )
    (tr_bound%core!ops.function.FnMut. (REF F&.) F& A&. A&)
   )
   :pattern ((tr_bound%core!ops.function.FnMut. (REF F&.) F& A&. A&))
   :qid internal_core__ops__function__impls__impl&__1_trait_impl_definition
   :skolemid skolem_internal_core__ops__function__impls__impl&__1_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.Fn. F&. F& A&. A&)
    )
    (tr_bound%core!ops.function.Fn. (REF F&.) F& A&. A&)
   )
   :pattern ((tr_bound%core!ops.function.Fn. (REF F&.) F& A&. A&))
   :qid internal_core__ops__function__impls__impl&__0_trait_impl_definition
   :skolemid skolem_internal_core__ops__function__impls__impl&__0_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((Args&. Dcr) (Args& Type) (F&. Dcr) (F& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized Args&.)
     (sized A&.)
     (tr_bound%core!marker.Tuple. Args&. Args&)
     (tr_bound%core!ops.function.FnOnce. F&. F& Args&. Args&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (tr_bound%core!ops.function.FnOnce. (BOX A&. A& F&.) F& Args&. Args&)
   )
   :pattern ((tr_bound%core!ops.function.FnOnce. (BOX A&. A& F&.) F& Args&. Args&))
   :qid internal_alloc__boxed__impl&__31_trait_impl_definition
   :skolemid skolem_internal_alloc__boxed__impl&__31_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((Args&. Dcr) (Args& Type) (F&. Dcr) (F& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized Args&.)
     (sized A&.)
     (tr_bound%core!marker.Tuple. Args&. Args&)
     (tr_bound%core!ops.function.FnMut. F&. F& Args&. Args&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (tr_bound%core!ops.function.FnMut. (BOX A&. A& F&.) F& Args&. Args&)
   )
   :pattern ((tr_bound%core!ops.function.FnMut. (BOX A&. A& F&.) F& Args&. Args&))
   :qid internal_alloc__boxed__impl&__32_trait_impl_definition
   :skolemid skolem_internal_alloc__boxed__impl&__32_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((Args&. Dcr) (Args& Type) (F&. Dcr) (F& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized Args&.)
     (sized A&.)
     (tr_bound%core!marker.Tuple. Args&. Args&)
     (tr_bound%core!ops.function.Fn. F&. F& Args&. Args&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (tr_bound%core!ops.function.Fn. (BOX A&. A& F&.) F& Args&. Args&)
   )
   :pattern ((tr_bound%core!ops.function.Fn. (BOX A&. A& F&.) F& Args&. Args&))
   :qid internal_alloc__boxed__impl&__33_trait_impl_definition
   :skolemid skolem_internal_alloc__boxed__impl&__33_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.FnMut. F&. F& A&. A&)
    )
    (tr_bound%core!ops.function.FnMut. $ (MUTREF F&. F&) A&. A&)
   )
   :pattern ((tr_bound%core!ops.function.FnMut. $ (MUTREF F&. F&) A&. A&))
   :qid internal_core__ops__function__impls__impl&__3_trait_impl_definition
   :skolemid skolem_internal_core__ops__function__impls__impl&__3_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (tr_bound%core!fmt.Debug. $ TYPE%core!cmp.Ordering.)
)

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type)) (!
   (=>
    (and
     (sized T&.)
     (uInv SZ (const_int N&))
     (tr_bound%core!fmt.Debug. T&. T&)
    )
    (tr_bound%core!fmt.Debug. $ (ARRAY T&. T& N&. N&))
   )
   :pattern ((tr_bound%core!fmt.Debug. $ (ARRAY T&. T& N&. N&)))
   :qid internal_core__array__impl&__12_trait_impl_definition
   :skolemid skolem_internal_core__array__impl&__12_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (and
     (sized T&.)
     (tr_bound%core!fmt.Debug. T&. T&)
    )
    (tr_bound%core!fmt.Debug. $ (TYPE%core!option.Option. T&. T&))
   )
   :pattern ((tr_bound%core!fmt.Debug. $ (TYPE%core!option.Option. T&. T&)))
   :qid internal_core__option__impl&__55_trait_impl_definition
   :skolemid skolem_internal_core__option__impl&__55_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (tr_bound%core!fmt.Debug. $ USIZE)
)

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (tr_bound%core!fmt.Debug. T&. T&)
    (tr_bound%core!fmt.Debug. (REF T&.) T&)
   )
   :pattern ((tr_bound%core!fmt.Debug. (REF T&.) T&))
   :qid internal_core__fmt__impl&__80_trait_impl_definition
   :skolemid skolem_internal_core__fmt__impl&__80_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (tr_bound%core!fmt.Debug. T&. T&)
    (tr_bound%core!fmt.Debug. $ (MUTREF T&. T&))
   )
   :pattern ((tr_bound%core!fmt.Debug. $ (MUTREF T&. T&)))
   :qid internal_core__fmt__impl&__81_trait_impl_definition
   :skolemid skolem_internal_core__fmt__impl&__81_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (tr_bound%core!fmt.Debug. $ BOOL)
)

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (tr_bound%core!fmt.Debug. (CONST_PTR $) (PTR T&. T&))
   :pattern ((tr_bound%core!fmt.Debug. (CONST_PTR $) (PTR T&. T&)))
   :qid internal_core__fmt__impl&__27_trait_impl_definition
   :skolemid skolem_internal_core__fmt__impl&__27_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (tr_bound%core!fmt.Debug. $ (PTR T&. T&))
   :pattern ((tr_bound%core!fmt.Debug. $ (PTR T&. T&)))
   :qid internal_core__fmt__impl&__28_trait_impl_definition
   :skolemid skolem_internal_core__fmt__impl&__28_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((V&. Dcr) (V& Type) (U&. Dcr) (U& Type) (T&. Dcr) (T& Type)) (!
   (=>
    (and
     (sized V&.)
     (sized U&.)
     (sized T&.)
     (tr_bound%core!fmt.Debug. V&. V&)
     (tr_bound%core!fmt.Debug. U&. U&)
     (tr_bound%core!fmt.Debug. T&. T&)
    )
    (tr_bound%core!fmt.Debug. (DST T&.) (TYPE%tuple%3. V&. V& U&. U& T&. T&))
   )
   :pattern ((tr_bound%core!fmt.Debug. (DST T&.) (TYPE%tuple%3. V&. V& U&. U& T&. T&)))
   :qid internal_core__fmt__impl&__105_trait_impl_definition
   :skolemid skolem_internal_core__fmt__impl&__105_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((U&. Dcr) (U& Type) (T&. Dcr) (T& Type)) (!
   (=>
    (and
     (sized U&.)
     (sized T&.)
     (tr_bound%core!fmt.Debug. U&. U&)
     (tr_bound%core!fmt.Debug. T&. T&)
    )
    (tr_bound%core!fmt.Debug. (DST T&.) (TYPE%tuple%2. U&. U& T&. T&))
   )
   :pattern ((tr_bound%core!fmt.Debug. (DST T&.) (TYPE%tuple%2. U&. U& T&. T&)))
   :qid internal_core__fmt__impl&__106_trait_impl_definition
   :skolemid skolem_internal_core__fmt__impl&__106_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (and
     (sized T&.)
     (tr_bound%core!fmt.Debug. T&. T&)
    )
    (tr_bound%core!fmt.Debug. (DST T&.) (TYPE%tuple%1. T&. T&))
   )
   :pattern ((tr_bound%core!fmt.Debug. (DST T&.) (TYPE%tuple%1. T&. T&)))
   :qid internal_core__fmt__impl&__107_trait_impl_definition
   :skolemid skolem_internal_core__fmt__impl&__107_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (and
     (sized T&.)
     (tr_bound%core!fmt.Debug. T&. T&)
    )
    (tr_bound%core!fmt.Debug. $slice (SLICE T&. T&))
   )
   :pattern ((tr_bound%core!fmt.Debug. $slice (SLICE T&. T&)))
   :qid internal_core__fmt__impl&__29_trait_impl_definition
   :skolemid skolem_internal_core__fmt__impl&__29_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (tr_bound%core!fmt.Debug. $ TYPE%tuple%0.)
)

;; Trait-Impl-Axiom
(assert
 (tr_bound%core!fmt.Debug. $ TYPE%alloc!alloc.Global.)
)

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!fmt.Debug. T&. T&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (tr_bound%core!fmt.Debug. (BOX A&. A& T&.) T&)
   )
   :pattern ((tr_bound%core!fmt.Debug. (BOX A&. A& T&.) T&))
   :qid internal_alloc__boxed__impl&__25_trait_impl_definition
   :skolemid skolem_internal_alloc__boxed__impl&__25_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!fmt.Debug. T&. T&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (tr_bound%core!fmt.Debug. (RC A&. A& T&.) T&)
   )
   :pattern ((tr_bound%core!fmt.Debug. (RC A&. A& T&.) T&))
   :qid internal_alloc__rc__impl&__51_trait_impl_definition
   :skolemid skolem_internal_alloc__rc__impl&__51_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!fmt.Debug. T&. T&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (tr_bound%core!fmt.Debug. (ARC A&. A& T&.) T&)
   )
   :pattern ((tr_bound%core!fmt.Debug. (ARC A&. A& T&.) T&))
   :qid internal_alloc__sync__impl&__60_trait_impl_definition
   :skolemid skolem_internal_alloc__sync__impl&__60_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized T&.)
     (sized A&.)
     (tr_bound%core!fmt.Debug. T&. T&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (tr_bound%core!fmt.Debug. $ (TYPE%alloc!vec.Vec. T&. T& A&. A&))
   )
   :pattern ((tr_bound%core!fmt.Debug. $ (TYPE%alloc!vec.Vec. T&. T& A&. A&)))
   :qid internal_alloc__vec__impl&__28_trait_impl_definition
   :skolemid skolem_internal_alloc__vec__impl&__28_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (sized A&.)
    (tr_bound%core!fmt.Debug. (TRACKED A&.) A&)
   )
   :pattern ((tr_bound%core!fmt.Debug. (TRACKED A&.) A&))
   :qid internal_verus_builtin__impl&__0_trait_impl_definition
   :skolemid skolem_internal_verus_builtin__impl&__0_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (tr_bound%core!fmt.Display. $ USIZE)
)

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (tr_bound%core!fmt.Display. T&. T&)
    (tr_bound%core!fmt.Display. (REF T&.) T&)
   )
   :pattern ((tr_bound%core!fmt.Display. (REF T&.) T&))
   :qid internal_core__fmt__impl&__82_trait_impl_definition
   :skolemid skolem_internal_core__fmt__impl&__82_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (tr_bound%core!fmt.Display. T&. T&)
    (tr_bound%core!fmt.Display. $ (MUTREF T&. T&))
   )
   :pattern ((tr_bound%core!fmt.Display. $ (MUTREF T&. T&)))
   :qid internal_core__fmt__impl&__83_trait_impl_definition
   :skolemid skolem_internal_core__fmt__impl&__83_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (tr_bound%core!fmt.Display. $ BOOL)
)

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!fmt.Display. T&. T&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (tr_bound%core!fmt.Display. (BOX A&. A& T&.) T&)
   )
   :pattern ((tr_bound%core!fmt.Display. (BOX A&. A& T&.) T&))
   :qid internal_alloc__boxed__impl&__24_trait_impl_definition
   :skolemid skolem_internal_alloc__boxed__impl&__24_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!fmt.Display. T&. T&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (tr_bound%core!fmt.Display. (RC A&. A& T&.) T&)
   )
   :pattern ((tr_bound%core!fmt.Display. (RC A&. A& T&.) T&))
   :qid internal_alloc__rc__impl&__50_trait_impl_definition
   :skolemid skolem_internal_alloc__rc__impl&__50_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!fmt.Display. T&. T&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (tr_bound%core!fmt.Display. (ARC A&. A& T&.) T&)
   )
   :pattern ((tr_bound%core!fmt.Display. (ARC A&. A& T&.) T&))
   :qid internal_alloc__sync__impl&__59_trait_impl_definition
   :skolemid skolem_internal_alloc__sync__impl&__59_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (tr_bound%core!alloc.Allocator. A&. A&)
    (tr_bound%core!alloc.Allocator. (REF A&.) A&)
   )
   :pattern ((tr_bound%core!alloc.Allocator. (REF A&.) A&))
   :qid internal_core__alloc__impl&__2_trait_impl_definition
   :skolemid skolem_internal_core__alloc__impl&__2_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (tr_bound%core!alloc.Allocator. A&. A&)
    (tr_bound%core!alloc.Allocator. $ (MUTREF A&. A&))
   )
   :pattern ((tr_bound%core!alloc.Allocator. $ (MUTREF A&. A&)))
   :qid internal_core__alloc__impl&__3_trait_impl_definition
   :skolemid skolem_internal_core__alloc__impl&__3_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!alloc.Allocator. T&. T&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (tr_bound%core!alloc.Allocator. (BOX A&. A& T&.) T&)
   )
   :pattern ((tr_bound%core!alloc.Allocator. (BOX A&. A& T&.) T&))
   :qid internal_alloc__boxed__impl&__49_trait_impl_definition
   :skolemid skolem_internal_alloc__boxed__impl&__49_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!alloc.Allocator. T&. T&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (tr_bound%core!alloc.Allocator. (RC A&. A& T&.) T&)
   )
   :pattern ((tr_bound%core!alloc.Allocator. (RC A&. A& T&.) T&))
   :qid internal_alloc__rc__impl&__116_trait_impl_definition
   :skolemid skolem_internal_alloc__rc__impl&__116_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!alloc.Allocator. T&. T&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (tr_bound%core!alloc.Allocator. (ARC A&. A& T&.) T&)
   )
   :pattern ((tr_bound%core!alloc.Allocator. (ARC A&. A& T&.) T&))
   :qid internal_alloc__sync__impl&__118_trait_impl_definition
   :skolemid skolem_internal_alloc__sync__impl&__118_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (and
     (sized T&.)
     (tr_bound%core!cmp.Eq. T&. T&)
     (tr_bound%core!clone.Clone. T&. T&)
     (tr_bound%core!fmt.Display. T&. T&)
     (tr_bound%core!fmt.Debug. T&. T&)
     (tr_bound%vstd!view.View. T&. T&)
    )
    (tr_bound%lib!Types.Types.StT. T&. T&)
   )
   :pattern ((tr_bound%lib!Types.Types.StT. T&. T&))
   :qid internal_lib__Types__Types__impl&__16_trait_impl_definition
   :skolemid skolem_internal_lib__Types__Types__impl&__16_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (and
     (sized T&.)
     (tr_bound%lib!Types.Types.StT. T&. T&)
    )
    (tr_bound%lib!Concurrency.Concurrency.StTInMtT. T&. T&)
   )
   :pattern ((tr_bound%lib!Concurrency.Concurrency.StTInMtT. T&. T&))
   :qid internal_lib__Concurrency__Concurrency__impl&__0_trait_impl_definition
   :skolemid skolem_internal_lib__Concurrency__Concurrency__impl&__0_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (tr_bound%lib!vstdplus.total_order.total_order.TotalOrder. $ USIZE)
)

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (and
     (sized T&.)
     (tr_bound%core!cmp.PartialEq. T&. T& T&. T&)
     (tr_bound%vstd!view.View. T&. T&)
    )
    (tr_bound%core!cmp.PartialEq. $ (TYPE%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS.
      T&. T&
     ) $ (TYPE%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS. T&. T&)
   ))
   :pattern ((tr_bound%core!cmp.PartialEq. $ (TYPE%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS.
      T&. T&
     ) $ (TYPE%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS. T&. T&)
   ))
   :qid internal_lib__Chap19__ArraySeqMtEph__ArraySeqMtEph__impl&__10_trait_impl_definition
   :skolemid skolem_internal_lib__Chap19__ArraySeqMtEph__ArraySeqMtEph__impl&__10_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (and
     (sized T&.)
     (tr_bound%vstd!view.View. T&. T&)
     (tr_bound%core!cmp.PartialEq. T&. T& T&. T&)
    )
    (tr_bound%vstd!std_specs.cmp.PartialEqSpec. $ (TYPE%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS.
      T&. T&
     ) $ (TYPE%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS. T&. T&)
   ))
   :pattern ((tr_bound%vstd!std_specs.cmp.PartialEqSpec. $ (TYPE%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS.
      T&. T&
     ) $ (TYPE%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS. T&. T&)
   ))
   :qid internal_lib__Chap19__ArraySeqMtEph__ArraySeqMtEph__impl&__7_trait_impl_definition
   :skolemid skolem_internal_lib__Chap19__ArraySeqMtEph__ArraySeqMtEph__impl&__7_trait_impl_definition
)))

;; Function-Specs lib::Chap19::ArraySeqMtEph::ArraySeqMtEph::ArraySeqMtEphS::clone
(declare-fun ens%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.impl&%8.clone. (Dcr Type Poly
  Poly
 ) Bool
)
(assert
 (forall ((T&. Dcr) (T& Type) (self! Poly) (res! Poly)) (!
   (= (ens%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.impl&%8.clone. T&. T& self! res!) (
     and
     (ens%core!clone.Clone.clone. $ (TYPE%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS.
       T&. T&
      ) self! res!
     )
     (= (vstd!seq.Seq.len.? T&. T& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. T&. T& $
         TYPE%alloc!alloc.Global.
        ) (lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS./ArraySeqMtEphS/seq (%Poly%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS.
          res!
       )))
      ) (vstd!seq.Seq.len.? T&. T& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. T&. T& $
         TYPE%alloc!alloc.Global.
        ) (lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS./ArraySeqMtEphS/seq (%Poly%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS.
          self!
     )))))
     (forall ((i$ Poly)) (!
       (=>
        (has_type i$ INT)
        (=>
         (let
          ((tmp%%$ 0))
          (let
           ((tmp%%$1 (%I i$)))
           (let
            ((tmp%%$2 (vstd!seq.Seq.len.? T&. T& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. T&.
                 T& $ TYPE%alloc!alloc.Global.
                ) (lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS./ArraySeqMtEphS/seq (%Poly%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS.
                  self!
            ))))))
            (and
             (<= tmp%%$ tmp%%$1)
             (< tmp%%$1 tmp%%$2)
         ))))
         (vstd!pervasive.cloned.? T&. T& (vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.?
            $ (TYPE%alloc!vec.Vec. T&. T& $ TYPE%alloc!alloc.Global.) (lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS./ArraySeqMtEphS/seq
             (%Poly%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS. self!)
            )
           ) i$
          ) (vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. T&. T&
             $ TYPE%alloc!alloc.Global.
            ) (lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS./ArraySeqMtEphS/seq (%Poly%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS.
              res!
            ))
           ) i$
       ))))
       :pattern ((vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec.
           T&. T& $ TYPE%alloc!alloc.Global.
          ) (lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS./ArraySeqMtEphS/seq (%Poly%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS.
            res!
          ))
         ) i$
       ))
       :qid user_lib__Chap19__ArraySeqMtEph__ArraySeqMtEph__ArraySeqMtEphS__clone_0
       :skolemid skolem_user_lib__Chap19__ArraySeqMtEph__ArraySeqMtEph__ArraySeqMtEphS__clone_0
   ))))
   :pattern ((ens%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.impl&%8.clone. T&. T& self! res!))
   :qid internal_ens__lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.impl&__8.clone._definition
   :skolemid skolem_internal_ens__lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.impl&__8.clone._definition
)))
(assert
 (forall ((closure%$ Poly) (res$ Poly) (T&. Dcr) (T& Type)) (!
   (=>
    (and
     (has_type closure%$ (TYPE%tuple%1. (REF $) (TYPE%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS.
        T&. T&
     )))
     (has_type res$ (TYPE%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS. T&. T&))
    )
    (=>
     (closure_ens (FNDEF%core!clone.Clone.clone. $ (TYPE%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS.
        T&. T&
       )
      ) (DST (REF $)) (TYPE%tuple%1. (REF $) (TYPE%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS.
        T&. T&
       )
      ) (F fndef_singleton) closure%$ res$
     )
     (let
      ((self$ (%Poly%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS. (tuple%1./tuple%1/0
          (%Poly%tuple%1. closure%$)
      ))))
      (and
       (= (vstd!seq.Seq.len.? T&. T& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. T&. T& $
           TYPE%alloc!alloc.Global.
          ) (lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS./ArraySeqMtEphS/seq (%Poly%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS.
            res$
         )))
        ) (vstd!seq.Seq.len.? T&. T& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. T&. T& $
           TYPE%alloc!alloc.Global.
          ) (lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS./ArraySeqMtEphS/seq (%Poly%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS.
            (Poly%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS. self$)
       )))))
       (forall ((i$ Poly)) (!
         (=>
          (has_type i$ INT)
          (=>
           (let
            ((tmp%%$ 0))
            (let
             ((tmp%%$1 (%I i$)))
             (let
              ((tmp%%$2 (vstd!seq.Seq.len.? T&. T& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. T&.
                   T& $ TYPE%alloc!alloc.Global.
                  ) (lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS./ArraySeqMtEphS/seq (%Poly%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS.
                    (Poly%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS. self$)
              ))))))
              (and
               (<= tmp%%$ tmp%%$1)
               (< tmp%%$1 tmp%%$2)
           ))))
           (vstd!pervasive.cloned.? T&. T& (vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.?
              $ (TYPE%alloc!vec.Vec. T&. T& $ TYPE%alloc!alloc.Global.) (lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS./ArraySeqMtEphS/seq
               (%Poly%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS. (Poly%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS.
                 self$
              )))
             ) i$
            ) (vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. T&. T&
               $ TYPE%alloc!alloc.Global.
              ) (lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS./ArraySeqMtEphS/seq (%Poly%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS.
                res$
              ))
             ) i$
         ))))
         :pattern ((vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec.
             T&. T& $ TYPE%alloc!alloc.Global.
            ) (lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS./ArraySeqMtEphS/seq (%Poly%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS.
              res$
            ))
           ) i$
         ))
         :qid user_lib__Chap19__ArraySeqMtEph__ArraySeqMtEph__ArraySeqMtEphS__clone_1
         :skolemid skolem_user_lib__Chap19__ArraySeqMtEph__ArraySeqMtEph__ArraySeqMtEphS__clone_1
   ))))))
   :pattern ((closure_ens (FNDEF%core!clone.Clone.clone. $ (TYPE%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS.
       T&. T&
      )
     ) (DST (REF $)) (TYPE%tuple%1. (REF $) (TYPE%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS.
       T&. T&
      )
     ) (F fndef_singleton) closure%$ res$
   ))
   :qid user_lib__Chap19__ArraySeqMtEph__ArraySeqMtEph__ArraySeqMtEphS__clone_2
   :skolemid skolem_user_lib__Chap19__ArraySeqMtEph__ArraySeqMtEph__ArraySeqMtEphS__clone_2
)))

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (and
     (sized T&.)
     (tr_bound%core!clone.Clone. T&. T&)
    )
    (tr_bound%core!clone.Clone. $ (TYPE%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS.
      T&. T&
   )))
   :pattern ((tr_bound%core!clone.Clone. $ (TYPE%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS.
      T&. T&
   )))
   :qid internal_lib__Chap19__ArraySeqMtEph__ArraySeqMtEph__impl&__8_trait_impl_definition
   :skolemid skolem_internal_lib__Chap19__ArraySeqMtEph__ArraySeqMtEph__impl&__8_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (and
     (sized T&.)
     (tr_bound%core!cmp.Eq. T&. T&)
     (tr_bound%vstd!view.View. T&. T&)
    )
    (tr_bound%core!cmp.Eq. $ (TYPE%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS.
      T&. T&
   )))
   :pattern ((tr_bound%core!cmp.Eq. $ (TYPE%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS.
      T&. T&
   )))
   :qid internal_lib__Chap19__ArraySeqMtEph__ArraySeqMtEph__impl&__9_trait_impl_definition
   :skolemid skolem_internal_lib__Chap19__ArraySeqMtEph__ArraySeqMtEph__impl&__9_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (and
     (sized T&.)
     (tr_bound%core!cmp.PartialEq. T&. T& T&. T&)
     (tr_bound%vstd!view.View. T&. T&)
     (tr_bound%core!cmp.Eq. T&. T&)
     (tr_bound%core!clone.Clone. T&. T&)
    )
    (tr_bound%core!cmp.PartialEq. $ (TYPE%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS.
      T&. T&
     ) $ (TYPE%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS. T&.
      T&
   )))
   :pattern ((tr_bound%core!cmp.PartialEq. $ (TYPE%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS.
      T&. T&
     ) $ (TYPE%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS. T&.
      T&
   )))
   :qid internal_lib__Chap19__ArraySeqMtEphSlice__ArraySeqMtEphSlice__impl&__7_trait_impl_definition
   :skolemid skolem_internal_lib__Chap19__ArraySeqMtEphSlice__ArraySeqMtEphSlice__impl&__7_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (and
     (sized T&.)
     (tr_bound%vstd!view.View. T&. T&)
     (tr_bound%core!cmp.PartialEq. T&. T& T&. T&)
     (tr_bound%core!cmp.Eq. T&. T&)
     (tr_bound%core!clone.Clone. T&. T&)
    )
    (tr_bound%vstd!std_specs.cmp.PartialEqSpec. $ (TYPE%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS.
      T&. T&
     ) $ (TYPE%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS. T&.
      T&
   )))
   :pattern ((tr_bound%vstd!std_specs.cmp.PartialEqSpec. $ (TYPE%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS.
      T&. T&
     ) $ (TYPE%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS. T&.
      T&
   )))
   :qid internal_lib__Chap19__ArraySeqMtEphSlice__ArraySeqMtEphSlice__impl&__5_trait_impl_definition
   :skolemid skolem_internal_lib__Chap19__ArraySeqMtEphSlice__ArraySeqMtEphSlice__impl&__5_trait_impl_definition
)))

;; Function-Specs lib::Chap19::ArraySeqMtEphSlice::ArraySeqMtEphSlice::ArraySeqMtEphSliceS::clone
(declare-fun ens%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.impl&%6.clone. (
  Dcr Type Poly Poly
 ) Bool
)
(assert
 (forall ((T&. Dcr) (T& Type) (self! Poly) (cloned! Poly)) (!
   (= (ens%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.impl&%6.clone. T&. T& self!
     cloned!
    ) (and
     (ens%core!clone.Clone.clone. $ (TYPE%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS.
       T&. T&
      ) self! cloned!
     )
     (= (lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS./ArraySeqMtEphSliceS/data
       (%Poly%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS. cloned!)
      ) (lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS./ArraySeqMtEphSliceS/data
       (%Poly%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS. self!)
     ))
     (= (lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS./ArraySeqMtEphSliceS/start
       (%Poly%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS. cloned!)
      ) (lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS./ArraySeqMtEphSliceS/start
       (%Poly%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS. self!)
     ))
     (= (lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS./ArraySeqMtEphSliceS/len
       (%Poly%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS. cloned!)
      ) (lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS./ArraySeqMtEphSliceS/len
       (%Poly%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS. self!)
   ))))
   :pattern ((ens%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.impl&%6.clone. T&.
     T& self! cloned!
   ))
   :qid internal_ens__lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.impl&__6.clone._definition
   :skolemid skolem_internal_ens__lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.impl&__6.clone._definition
)))
(assert
 (forall ((closure%$ Poly) (cloned$ Poly) (T&. Dcr) (T& Type)) (!
   (=>
    (and
     (has_type closure%$ (TYPE%tuple%1. (REF $) (TYPE%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS.
        T&. T&
     )))
     (has_type cloned$ (TYPE%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS.
       T&. T&
    )))
    (=>
     (closure_ens (FNDEF%core!clone.Clone.clone. $ (TYPE%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS.
        T&. T&
       )
      ) (DST (REF $)) (TYPE%tuple%1. (REF $) (TYPE%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS.
        T&. T&
       )
      ) (F fndef_singleton) closure%$ cloned$
     )
     (let
      ((self$ (%Poly%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS.
         (tuple%1./tuple%1/0 (%Poly%tuple%1. closure%$))
      )))
      (and
       (and
        (= (lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS./ArraySeqMtEphSliceS/data
          (%Poly%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS. cloned$)
         ) (lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS./ArraySeqMtEphSliceS/data
          (%Poly%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS. (Poly%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS.
            self$
        ))))
        (= (lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS./ArraySeqMtEphSliceS/start
          (%Poly%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS. cloned$)
         ) (lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS./ArraySeqMtEphSliceS/start
          (%Poly%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS. (Poly%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS.
            self$
       )))))
       (= (lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS./ArraySeqMtEphSliceS/len
         (%Poly%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS. cloned$)
        ) (lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS./ArraySeqMtEphSliceS/len
         (%Poly%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS. (Poly%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS.
           self$
   ))))))))
   :pattern ((closure_ens (FNDEF%core!clone.Clone.clone. $ (TYPE%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS.
       T&. T&
      )
     ) (DST (REF $)) (TYPE%tuple%1. (REF $) (TYPE%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS.
       T&. T&
      )
     ) (F fndef_singleton) closure%$ cloned$
   ))
   :qid user_lib__Chap19__ArraySeqMtEphSlice__ArraySeqMtEphSlice__ArraySeqMtEphSliceS__clone_0
   :skolemid skolem_user_lib__Chap19__ArraySeqMtEphSlice__ArraySeqMtEphSlice__ArraySeqMtEphSliceS__clone_0
)))

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (and
     (sized T&.)
     (tr_bound%core!clone.Clone. T&. T&)
    )
    (tr_bound%core!clone.Clone. $ (TYPE%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS.
      T&. T&
   )))
   :pattern ((tr_bound%core!clone.Clone. $ (TYPE%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS.
      T&. T&
   )))
   :qid internal_lib__Chap19__ArraySeqMtEphSlice__ArraySeqMtEphSlice__impl&__6_trait_impl_definition
   :skolemid skolem_internal_lib__Chap19__ArraySeqMtEphSlice__ArraySeqMtEphSlice__impl&__6_trait_impl_definition
)))

;; Trait-Impl-Axiom
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (and
     (sized T&.)
     (tr_bound%core!cmp.Eq. T&. T&)
     (tr_bound%vstd!view.View. T&. T&)
     (tr_bound%core!clone.Clone. T&. T&)
    )
    (tr_bound%core!cmp.Eq. $ (TYPE%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS.
      T&. T&
   )))
   :pattern ((tr_bound%core!cmp.Eq. $ (TYPE%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS.
      T&. T&
   )))
   :qid internal_lib__Chap19__ArraySeqMtEphSlice__ArraySeqMtEphSlice__impl&__8_trait_impl_definition
   :skolemid skolem_internal_lib__Chap19__ArraySeqMtEphSlice__ArraySeqMtEphSlice__impl&__8_trait_impl_definition
)))

;; Function-Specs lib::Chap35::OrderStatSelectMtEph::OrderStatSelectMtEph::lemma_total_ordering
(declare-fun ens%lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.lemma_total_ordering.
 (Dcr Type) Bool
)
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (= (ens%lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.lemma_total_ordering.
     T&. T&
    ) (vstd!relations.total_ordering.? T&. T& (Poly%fun%2. (lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.spec_leq.?
       T&. T&
   ))))
   :pattern ((ens%lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.lemma_total_ordering.
     T&. T&
   ))
   :qid internal_ens__lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.lemma_total_ordering._definition
   :skolemid skolem_internal_ens__lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.lemma_total_ordering._definition
)))

;; Function-Specs lib::Chap35::OrderStatSelectMtEph::OrderStatSelectMtEph::append_vec
(declare-fun ens%lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.append_vec.
 (Dcr Type Poly Poly) Bool
)
(assert
 (forall ((T&. Dcr) (T& Type) (a! Poly) (b! Poly)) (!
   (= (ens%lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.append_vec. T&. T& a!
     b!
    ) (ext_eq false (TYPE%vstd!seq.Seq. T&. T&) (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec.
       T&. T& $ TYPE%alloc!alloc.Global.
      ) (mut_ref_future% a!)
     ) (vstd!seq.Seq.add.? T&. T& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. T&. T& $
        TYPE%alloc!alloc.Global.
       ) (mut_ref_current% a!)
      ) (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. T&. T& $ TYPE%alloc!alloc.Global.)
       b!
   ))))
   :pattern ((ens%lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.append_vec. T&.
     T& a! b!
   ))
   :qid internal_ens__lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.append_vec._definition
   :skolemid skolem_internal_ens__lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.append_vec._definition
)))

;; Function-Specs lib::Chap35::OrderStatSelectMtEph::OrderStatSelectMtEph::partition_three_dc
(declare-fun req%lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.partition_three_dc.
 (Dcr Type lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS. Poly)
 Bool
)
(declare-const %%global_location_label%%36 Bool)
(declare-const %%global_location_label%%37 Bool)
(assert
 (forall ((T&. Dcr) (T& Type) (a! lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS.)
   (pivot! Poly)
  ) (!
   (= (req%lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.partition_three_dc. T&.
     T& a! pivot!
    ) (and
     (=>
      %%global_location_label%%36
      (%B (lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceTrait.spec_arrayseqmtephslice_wf.?
        $ (TYPE%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS. T&.
         T&
        ) T&. T& (Poly%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS.
         a!
     ))))
     (=>
      %%global_location_label%%37
      (lib!vstdplus.feq.feq.obeys_feq_clone.? T&. T&)
   )))
   :pattern ((req%lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.partition_three_dc.
     T&. T& a! pivot!
   ))
   :qid internal_req__lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.partition_three_dc._definition
   :skolemid skolem_internal_req__lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.partition_three_dc._definition
)))
(declare-fun ens%lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.partition_three_dc.
 (Dcr Type lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS. Poly
  tuple%3.
 ) Bool
)
(assert
 (forall ((T&. Dcr) (T& Type) (a! lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS.)
   (pivot! Poly) (partitioned! tuple%3.)
  ) (!
   (= (ens%lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.partition_three_dc. T&.
     T& a! pivot! partitioned!
    ) (and
     (has_type (Poly%tuple%3. partitioned!) (TYPE%tuple%3. $ (TYPE%alloc!vec.Vec. T&. T&
        $ TYPE%alloc!alloc.Global.
       ) $ (TYPE%alloc!vec.Vec. T&. T& $ TYPE%alloc!alloc.Global.) $ (TYPE%alloc!vec.Vec.
        T&. T& $ TYPE%alloc!alloc.Global.
     )))
     (forall ((j$ Poly)) (!
       (=>
        (has_type j$ INT)
        (=>
         (let
          ((tmp%%$ 0))
          (let
           ((tmp%%$1 (%I j$)))
           (let
            ((tmp%%$2 (vstd!seq.Seq.len.? T&. T& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. T&.
                 T& $ TYPE%alloc!alloc.Global.
                ) (tuple%3./tuple%3/0 (%Poly%tuple%3. (Poly%tuple%3. partitioned!)))
            ))))
            (and
             (<= tmp%%$ tmp%%$1)
             (< tmp%%$1 tmp%%$2)
         ))))
         (and
          (%B (lib!vstdplus.total_order.total_order.TotalOrder.le.? T&. T& (vstd!seq.Seq.index.?
             T&. T& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. T&. T& $ TYPE%alloc!alloc.Global.)
              (tuple%3./tuple%3/0 (%Poly%tuple%3. (Poly%tuple%3. partitioned!)))
             ) j$
            ) pivot!
          ))
          (not (= (vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. T&.
               T& $ TYPE%alloc!alloc.Global.
              ) (tuple%3./tuple%3/0 (%Poly%tuple%3. (Poly%tuple%3. partitioned!)))
             ) j$
            ) pivot!
       )))))
       :pattern ((vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec.
           T&. T& $ TYPE%alloc!alloc.Global.
          ) (tuple%3./tuple%3/0 (%Poly%tuple%3. (Poly%tuple%3. partitioned!)))
         ) j$
       ))
       :qid user_lib__Chap35__OrderStatSelectMtEph__OrderStatSelectMtEph__partition_three_dc_0
       :skolemid skolem_user_lib__Chap35__OrderStatSelectMtEph__OrderStatSelectMtEph__partition_three_dc_0
     ))
     (forall ((j$ Poly)) (!
       (=>
        (has_type j$ INT)
        (=>
         (let
          ((tmp%%$ 0))
          (let
           ((tmp%%$1 (%I j$)))
           (let
            ((tmp%%$2 (vstd!seq.Seq.len.? T&. T& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. T&.
                 T& $ TYPE%alloc!alloc.Global.
                ) (tuple%3./tuple%3/1 (%Poly%tuple%3. (Poly%tuple%3. partitioned!)))
            ))))
            (and
             (<= tmp%%$ tmp%%$1)
             (< tmp%%$1 tmp%%$2)
         ))))
         (= (vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. T&. T&
             $ TYPE%alloc!alloc.Global.
            ) (tuple%3./tuple%3/1 (%Poly%tuple%3. (Poly%tuple%3. partitioned!)))
           ) j$
          ) pivot!
       )))
       :pattern ((vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec.
           T&. T& $ TYPE%alloc!alloc.Global.
          ) (tuple%3./tuple%3/1 (%Poly%tuple%3. (Poly%tuple%3. partitioned!)))
         ) j$
       ))
       :qid user_lib__Chap35__OrderStatSelectMtEph__OrderStatSelectMtEph__partition_three_dc_1
       :skolemid skolem_user_lib__Chap35__OrderStatSelectMtEph__OrderStatSelectMtEph__partition_three_dc_1
     ))
     (forall ((j$ Poly)) (!
       (=>
        (has_type j$ INT)
        (=>
         (let
          ((tmp%%$ 0))
          (let
           ((tmp%%$1 (%I j$)))
           (let
            ((tmp%%$2 (vstd!seq.Seq.len.? T&. T& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. T&.
                 T& $ TYPE%alloc!alloc.Global.
                ) (tuple%3./tuple%3/2 (%Poly%tuple%3. (Poly%tuple%3. partitioned!)))
            ))))
            (and
             (<= tmp%%$ tmp%%$1)
             (< tmp%%$1 tmp%%$2)
         ))))
         (and
          (%B (lib!vstdplus.total_order.total_order.TotalOrder.le.? T&. T& pivot! (vstd!seq.Seq.index.?
             T&. T& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. T&. T& $ TYPE%alloc!alloc.Global.)
              (tuple%3./tuple%3/2 (%Poly%tuple%3. (Poly%tuple%3. partitioned!)))
             ) j$
          )))
          (not (= (vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. T&.
               T& $ TYPE%alloc!alloc.Global.
              ) (tuple%3./tuple%3/2 (%Poly%tuple%3. (Poly%tuple%3. partitioned!)))
             ) j$
            ) pivot!
       )))))
       :pattern ((vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec.
           T&. T& $ TYPE%alloc!alloc.Global.
          ) (tuple%3./tuple%3/2 (%Poly%tuple%3. (Poly%tuple%3. partitioned!)))
         ) j$
       ))
       :qid user_lib__Chap35__OrderStatSelectMtEph__OrderStatSelectMtEph__partition_three_dc_2
       :skolemid skolem_user_lib__Chap35__OrderStatSelectMtEph__OrderStatSelectMtEph__partition_three_dc_2
     ))
     (ext_eq false (TYPE%vstd!multiset.Multiset. T&. T&) (vstd!seq_lib.impl&%0.to_multiset.?
       T&. T& (lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.spec_slice_elements.?
        T&. T& (Poly%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS.
         a!
       ))
      ) (vstd!multiset.impl&%0.add.? T&. T& (vstd!multiset.impl&%0.add.? T&. T& (vstd!seq_lib.impl&%0.to_multiset.?
         T&. T& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. T&. T& $ TYPE%alloc!alloc.Global.)
          (tuple%3./tuple%3/0 (%Poly%tuple%3. (Poly%tuple%3. partitioned!)))
         )
        ) (vstd!seq_lib.impl&%0.to_multiset.? T&. T& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec.
           T&. T& $ TYPE%alloc!alloc.Global.
          ) (tuple%3./tuple%3/2 (%Poly%tuple%3. (Poly%tuple%3. partitioned!)))
        ))
       ) (vstd!seq_lib.impl&%0.to_multiset.? T&. T& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec.
          T&. T& $ TYPE%alloc!alloc.Global.
         ) (tuple%3./tuple%3/1 (%Poly%tuple%3. (Poly%tuple%3. partitioned!)))
     ))))
     (= (nClip (Add (nClip (Add (vstd!seq.Seq.len.? T&. T& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec.
             T&. T& $ TYPE%alloc!alloc.Global.
            ) (tuple%3./tuple%3/0 (%Poly%tuple%3. (Poly%tuple%3. partitioned!)))
           )
          ) (vstd!seq.Seq.len.? T&. T& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. T&. T& $
             TYPE%alloc!alloc.Global.
            ) (tuple%3./tuple%3/1 (%Poly%tuple%3. (Poly%tuple%3. partitioned!)))
         )))
        ) (vstd!seq.Seq.len.? T&. T& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. T&. T& $
           TYPE%alloc!alloc.Global.
          ) (tuple%3./tuple%3/2 (%Poly%tuple%3. (Poly%tuple%3. partitioned!)))
       )))
      ) (%I (lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceTrait.spec_len.?
        $ (TYPE%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS. T&.
         T&
        ) T&. T& (Poly%lib!Chap19.ArraySeqMtEphSlice.ArraySeqMtEphSlice.ArraySeqMtEphSliceS.
         a!
   ))))))
   :pattern ((ens%lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.partition_three_dc.
     T&. T& a! pivot! partitioned!
   ))
   :qid internal_ens__lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.partition_three_dc._definition
   :skolemid skolem_internal_ens__lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.partition_three_dc._definition
)))

;; Function-Specs lib::Chap35::OrderStatSelectMtEph::OrderStatSelectMtEph::lemma_const_seq_multiset
(declare-fun ens%lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.lemma_const_seq_multiset.
 (Dcr Type Int Poly) Bool
)
(assert
 (forall ((T&. Dcr) (T& Type) (n! Int) (v! Poly)) (!
   (= (ens%lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.lemma_const_seq_multiset.
     T&. T& n! v!
    ) (and
     (= (vstd!multiset.impl&%0.count.? T&. T& (vstd!seq_lib.impl&%0.to_multiset.? T&. T&
        (lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.spec_const_seq.? T&. T& (I n!)
         v!
        )
       ) v!
      ) n!
     )
     (forall ((x$ Poly)) (!
       (=>
        (has_type x$ T&)
        (=>
         (not (= x$ v!))
         (= (vstd!multiset.impl&%0.count.? T&. T& (vstd!seq_lib.impl&%0.to_multiset.? T&. T&
            (lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.spec_const_seq.? T&. T& (I n!)
             v!
            )
           ) x$
          ) 0
       )))
       :pattern ((vstd!multiset.impl&%0.count.? T&. T& (vstd!seq_lib.impl&%0.to_multiset.?
          T&. T& (lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.spec_const_seq.? T&.
           T& (I n!) v!
          )
         ) x$
       ))
       :qid user_lib__Chap35__OrderStatSelectMtEph__OrderStatSelectMtEph__lemma_const_seq_multiset_0
       :skolemid skolem_user_lib__Chap35__OrderStatSelectMtEph__OrderStatSelectMtEph__lemma_const_seq_multiset_0
   ))))
   :pattern ((ens%lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.lemma_const_seq_multiset.
     T&. T& n! v!
   ))
   :qid internal_ens__lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.lemma_const_seq_multiset._definition
   :skolemid skolem_internal_ens__lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.lemma_const_seq_multiset._definition
)))

;; Function-Specs lib::Chap35::OrderStatSelectMtEph::OrderStatSelectMtEph::lemma_all_equal_multiset
(declare-fun req%lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.lemma_all_equal_multiset.
 (Dcr Type Poly Poly) Bool
)
(declare-const %%global_location_label%%38 Bool)
(assert
 (forall ((T&. Dcr) (T& Type) (s! Poly) (v! Poly)) (!
   (= (req%lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.lemma_all_equal_multiset.
     T&. T& s! v!
    ) (=>
     %%global_location_label%%38
     (forall ((i$ Poly)) (!
       (=>
        (has_type i$ INT)
        (=>
         (let
          ((tmp%%$ 0))
          (let
           ((tmp%%$1 (%I i$)))
           (let
            ((tmp%%$2 (vstd!seq.Seq.len.? T&. T& s!)))
            (and
             (<= tmp%%$ tmp%%$1)
             (< tmp%%$1 tmp%%$2)
         ))))
         (= (vstd!seq.Seq.index.? T&. T& s! i$) v!)
       ))
       :pattern ((vstd!seq.Seq.index.? T&. T& s! i$))
       :qid user_lib__Chap35__OrderStatSelectMtEph__OrderStatSelectMtEph__lemma_all_equal_multiset_0
       :skolemid skolem_user_lib__Chap35__OrderStatSelectMtEph__OrderStatSelectMtEph__lemma_all_equal_multiset_0
   ))))
   :pattern ((req%lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.lemma_all_equal_multiset.
     T&. T& s! v!
   ))
   :qid internal_req__lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.lemma_all_equal_multiset._definition
   :skolemid skolem_internal_req__lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.lemma_all_equal_multiset._definition
)))
(declare-fun ens%lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.lemma_all_equal_multiset.
 (Dcr Type Poly Poly) Bool
)
(assert
 (forall ((T&. Dcr) (T& Type) (s! Poly) (v! Poly)) (!
   (= (ens%lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.lemma_all_equal_multiset.
     T&. T& s! v!
    ) (and
     (= (vstd!multiset.impl&%0.count.? T&. T& (vstd!seq_lib.impl&%0.to_multiset.? T&. T&
        s!
       ) v!
      ) (vstd!seq.Seq.len.? T&. T& s!)
     )
     (forall ((x$ Poly)) (!
       (=>
        (has_type x$ T&)
        (=>
         (not (= x$ v!))
         (= (vstd!multiset.impl&%0.count.? T&. T& (vstd!seq_lib.impl&%0.to_multiset.? T&. T&
            s!
           ) x$
          ) 0
       )))
       :pattern ((vstd!multiset.impl&%0.count.? T&. T& (vstd!seq_lib.impl&%0.to_multiset.?
          T&. T& s!
         ) x$
       ))
       :qid user_lib__Chap35__OrderStatSelectMtEph__OrderStatSelectMtEph__lemma_all_equal_multiset_1
       :skolemid skolem_user_lib__Chap35__OrderStatSelectMtEph__OrderStatSelectMtEph__lemma_all_equal_multiset_1
   ))))
   :pattern ((ens%lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.lemma_all_equal_multiset.
     T&. T& s! v!
   ))
   :qid internal_ens__lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.lemma_all_equal_multiset._definition
   :skolemid skolem_internal_ens__lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.lemma_all_equal_multiset._definition
)))

;; Function-Specs lib::Chap35::OrderStatSelectMtEph::OrderStatSelectMtEph::parallel_three_way_partition
(declare-fun req%lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.parallel_three_way_partition.
 (Dcr Type lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS. Poly Int Int) Bool
)
(declare-const %%global_location_label%%39 Bool)
(declare-const %%global_location_label%%40 Bool)
(declare-const %%global_location_label%%41 Bool)
(declare-const %%global_location_label%%42 Bool)
(declare-const %%global_location_label%%43 Bool)
(declare-const %%global_location_label%%44 Bool)
(assert
 (forall ((T&. Dcr) (T& Type) (a! lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS.)
   (pivot! Poly) (pivot_idx! Int) (n! Int)
  ) (!
   (= (req%lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.parallel_three_way_partition.
     T&. T& a! pivot! pivot_idx! n!
    ) (and
     (=>
      %%global_location_label%%39
      (= n! (%I (lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphTrait.spec_len.? $ (TYPE%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS.
          T&. T&
         ) T&. T& (Poly%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS. a!)
     ))))
     (=>
      %%global_location_label%%40
      (<= n! (- (uHi SZ) 1))
     )
     (=>
      %%global_location_label%%41
      (>= n! 2)
     )
     (=>
      %%global_location_label%%42
      (< pivot_idx! n!)
     )
     (=>
      %%global_location_label%%43
      (= pivot! (lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphTrait.spec_index.? $
        (TYPE%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS. T&. T&) T&. T& (Poly%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS.
         a!
        ) (I pivot_idx!)
     )))
     (=>
      %%global_location_label%%44
      (lib!vstdplus.feq.feq.obeys_feq_clone.? T&. T&)
   )))
   :pattern ((req%lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.parallel_three_way_partition.
     T&. T& a! pivot! pivot_idx! n!
   ))
   :qid internal_req__lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.parallel_three_way_partition._definition
   :skolemid skolem_internal_req__lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.parallel_three_way_partition._definition
)))
(declare-fun ens%lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.parallel_three_way_partition.
 (Dcr Type lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS. Poly Int Int tuple%3.)
 Bool
)
(assert
 (forall ((T&. Dcr) (T& Type) (a! lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS.)
   (pivot! Poly) (pivot_idx! Int) (n! Int) (partition! tuple%3.)
  ) (!
   (= (ens%lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.parallel_three_way_partition.
     T&. T& a! pivot! pivot_idx! n! partition!
    ) (and
     (has_type (Poly%tuple%3. partition!) (TYPE%tuple%3. $ (TYPE%alloc!vec.Vec. T&. T& $
        TYPE%alloc!alloc.Global.
       ) $ USIZE $ (TYPE%alloc!vec.Vec. T&. T& $ TYPE%alloc!alloc.Global.)
     ))
     (forall ((j$ Poly)) (!
       (=>
        (has_type j$ INT)
        (=>
         (let
          ((tmp%%$ 0))
          (let
           ((tmp%%$1 (%I j$)))
           (let
            ((tmp%%$2 (vstd!seq.Seq.len.? T&. T& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. T&.
                 T& $ TYPE%alloc!alloc.Global.
                ) (tuple%3./tuple%3/0 (%Poly%tuple%3. (Poly%tuple%3. partition!)))
            ))))
            (and
             (<= tmp%%$ tmp%%$1)
             (< tmp%%$1 tmp%%$2)
         ))))
         (and
          (%B (lib!vstdplus.total_order.total_order.TotalOrder.le.? T&. T& (vstd!seq.Seq.index.?
             T&. T& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. T&. T& $ TYPE%alloc!alloc.Global.)
              (tuple%3./tuple%3/0 (%Poly%tuple%3. (Poly%tuple%3. partition!)))
             ) j$
            ) pivot!
          ))
          (not (= (vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. T&.
               T& $ TYPE%alloc!alloc.Global.
              ) (tuple%3./tuple%3/0 (%Poly%tuple%3. (Poly%tuple%3. partition!)))
             ) j$
            ) pivot!
       )))))
       :pattern ((lib!vstdplus.total_order.total_order.TotalOrder.le.? T&. T& (vstd!seq.Seq.index.?
          T&. T& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. T&. T& $ TYPE%alloc!alloc.Global.)
           (tuple%3./tuple%3/0 (%Poly%tuple%3. (Poly%tuple%3. partition!)))
          ) j$
         ) pivot!
       ))
       :qid user_lib__Chap35__OrderStatSelectMtEph__OrderStatSelectMtEph__parallel_three_way_partition_0
       :skolemid skolem_user_lib__Chap35__OrderStatSelectMtEph__OrderStatSelectMtEph__parallel_three_way_partition_0
     ))
     (forall ((j$ Poly)) (!
       (=>
        (has_type j$ INT)
        (=>
         (let
          ((tmp%%$ 0))
          (let
           ((tmp%%$1 (%I j$)))
           (let
            ((tmp%%$2 (vstd!seq.Seq.len.? T&. T& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. T&.
                 T& $ TYPE%alloc!alloc.Global.
                ) (tuple%3./tuple%3/2 (%Poly%tuple%3. (Poly%tuple%3. partition!)))
            ))))
            (and
             (<= tmp%%$ tmp%%$1)
             (< tmp%%$1 tmp%%$2)
         ))))
         (and
          (%B (lib!vstdplus.total_order.total_order.TotalOrder.le.? T&. T& pivot! (vstd!seq.Seq.index.?
             T&. T& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. T&. T& $ TYPE%alloc!alloc.Global.)
              (tuple%3./tuple%3/2 (%Poly%tuple%3. (Poly%tuple%3. partition!)))
             ) j$
          )))
          (not (= (vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. T&.
               T& $ TYPE%alloc!alloc.Global.
              ) (tuple%3./tuple%3/2 (%Poly%tuple%3. (Poly%tuple%3. partition!)))
             ) j$
            ) pivot!
       )))))
       :pattern ((lib!vstdplus.total_order.total_order.TotalOrder.le.? T&. T& pivot! (vstd!seq.Seq.index.?
          T&. T& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. T&. T& $ TYPE%alloc!alloc.Global.)
           (tuple%3./tuple%3/2 (%Poly%tuple%3. (Poly%tuple%3. partition!)))
          ) j$
       )))
       :qid user_lib__Chap35__OrderStatSelectMtEph__OrderStatSelectMtEph__parallel_three_way_partition_1
       :skolemid skolem_user_lib__Chap35__OrderStatSelectMtEph__OrderStatSelectMtEph__parallel_three_way_partition_1
     ))
     (= (Add (Add (vstd!seq.Seq.len.? T&. T& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. T&.
           T& $ TYPE%alloc!alloc.Global.
          ) (tuple%3./tuple%3/0 (%Poly%tuple%3. (Poly%tuple%3. partition!)))
         )
        ) (%I (tuple%3./tuple%3/1 (%Poly%tuple%3. (Poly%tuple%3. partition!))))
       ) (vstd!seq.Seq.len.? T&. T& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. T&. T& $
          TYPE%alloc!alloc.Global.
         ) (tuple%3./tuple%3/2 (%Poly%tuple%3. (Poly%tuple%3. partition!)))
       ))
      ) n!
     )
     (< (nClip (Add (vstd!seq.Seq.len.? T&. T& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec.
           T&. T& $ TYPE%alloc!alloc.Global.
          ) (tuple%3./tuple%3/0 (%Poly%tuple%3. (Poly%tuple%3. partition!)))
         )
        ) (vstd!seq.Seq.len.? T&. T& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. T&. T& $
           TYPE%alloc!alloc.Global.
          ) (tuple%3./tuple%3/2 (%Poly%tuple%3. (Poly%tuple%3. partition!)))
       )))
      ) n!
     )
     (let
      ((s$ (vstd!seq.Seq.new.? T&. T& (I n!) (Poly%fun%1. (mk_fun (%%lambda%%3 $ (TYPE%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS.
             T&. T&
            ) T&. T& (Poly%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS. a!)
      ))))))
      (let
       ((eq_seq$ (vstd!seq.Seq.new.? T&. T& (tuple%3./tuple%3/1 (%Poly%tuple%3. (Poly%tuple%3.
             partition!
           ))
          ) (Poly%fun%1. (mk_fun (%%lambda%%6 pivot!)))
       )))
       (ext_eq false (TYPE%vstd!multiset.Multiset. T&. T&) (vstd!seq_lib.impl&%0.to_multiset.?
         T&. T& s$
        ) (vstd!multiset.impl&%0.add.? T&. T& (vstd!multiset.impl&%0.add.? T&. T& (vstd!seq_lib.impl&%0.to_multiset.?
           T&. T& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. T&. T& $ TYPE%alloc!alloc.Global.)
            (tuple%3./tuple%3/0 (%Poly%tuple%3. (Poly%tuple%3. partition!)))
           )
          ) (vstd!seq_lib.impl&%0.to_multiset.? T&. T& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec.
             T&. T& $ TYPE%alloc!alloc.Global.
            ) (tuple%3./tuple%3/2 (%Poly%tuple%3. (Poly%tuple%3. partition!)))
          ))
         ) (vstd!seq_lib.impl&%0.to_multiset.? T&. T& eq_seq$)
     ))))
     (>= (%I (tuple%3./tuple%3/1 (%Poly%tuple%3. (Poly%tuple%3. partition!)))) 1)
   ))
   :pattern ((ens%lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.parallel_three_way_partition.
     T&. T& a! pivot! pivot_idx! n! partition!
   ))
   :qid internal_ens__lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.parallel_three_way_partition._definition
   :skolemid skolem_internal_ens__lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.parallel_three_way_partition._definition
)))

;; Function-Specs lib::Chap35::OrderStatSelectMtEph::OrderStatSelectMtEph::select_inner
(declare-fun req%lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.select_inner.
 (Dcr Type lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS. Int) Bool
)
(declare-const %%global_location_label%%45 Bool)
(declare-const %%global_location_label%%46 Bool)
(declare-const %%global_location_label%%47 Bool)
(assert
 (forall ((T&. Dcr) (T& Type) (a! lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS.)
   (k! Int)
  ) (!
   (= (req%lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.select_inner. T&. T& a!
     k!
    ) (and
     (=>
      %%global_location_label%%45
      (<= (%I (lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphTrait.spec_len.? $ (TYPE%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS.
          T&. T&
         ) T&. T& (Poly%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS. a!)
        )
       ) (- (uHi SZ) 1)
     ))
     (=>
      %%global_location_label%%46
      (let
       ((tmp%%$ 0))
       (let
        ((tmp%%$1 k!))
        (let
         ((tmp%%$2 (%I (lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphTrait.spec_len.? $
             (TYPE%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS. T&. T&) T&. T& (Poly%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS.
              a!
         )))))
         (and
          (<= tmp%%$ tmp%%$1)
          (< tmp%%$1 tmp%%$2)
     )))))
     (=>
      %%global_location_label%%47
      (lib!vstdplus.feq.feq.obeys_feq_clone.? T&. T&)
   )))
   :pattern ((req%lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.select_inner. T&.
     T& a! k!
   ))
   :qid internal_req__lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.select_inner._definition
   :skolemid skolem_internal_req__lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.select_inner._definition
)))
(declare-fun ens%lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.select_inner.
 (Dcr Type lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS. Int core!option.Option.)
 Bool
)
(assert
 (forall ((T&. Dcr) (T& Type) (a! lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS.)
   (k! Int) (found! core!option.Option.)
  ) (!
   (= (ens%lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.select_inner. T&. T& a!
     k! found!
    ) (and
     (has_type (Poly%core!option.Option. found!) (TYPE%core!option.Option. T&. T&))
     (= found! (core!option.Option./Some (lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.spec_kth.?
        T&. T& (vstd!seq.Seq.new.? T&. T& (lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphTrait.spec_len.?
          $ (TYPE%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS. T&. T&) T&. T& (Poly%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS.
           a!
          )
         ) (Poly%fun%1. (mk_fun (%%lambda%%3 $ (TYPE%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS.
             T&. T&
            ) T&. T& (Poly%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS. a!)
         )))
        ) (I k!)
   )))))
   :pattern ((ens%lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.select_inner. T&.
     T& a! k! found!
   ))
   :qid internal_ens__lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.select_inner._definition
   :skolemid skolem_internal_ens__lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.select_inner._definition
)))

;; Function-Recommends lib::Chap35::OrderStatSelectMtEph::OrderStatSelectMtEph::select_inner
;; src/Chap35/OrderStatSelectMtEph.rs:493:5: 495:27 (#0)
(push)
 (get-info :all-statistics)
 (declare-const T&. Dcr)
 (declare-const T& Type)
 (declare-const found! core!option.Option.)
 (declare-const a! lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS.)
 (declare-const k! Int)
 (declare-const i@ Poly)
 (declare-const tmp%1 Poly)
 (declare-const tmp%2 Poly)
 (declare-const tmp%3 Poly)
 (declare-const tmp%4 core!option.Option.)
 (declare-const tmp%5 Poly)
 (declare-const i$1@ Poly)
 (declare-const tmp%6 Poly)
 (declare-const verus_tmp_s@ Poly)
 (declare-const verus_tmp_leq@ %%Function%%)
 (declare-const tmp%7 Poly)
 (declare-const tmp%8 Poly)
 (declare-const elem@ Poly)
 (declare-const i$2@ Poly)
 (declare-const tmp%9 Poly)
 (declare-const verus_tmp_equals_seq@ Poly)
 (declare-const tmp%10 Poly)
 (declare-const tmp%11 Poly)
 (declare-const verus_tmp_sorted_left@ Poly)
 (declare-const tmp%12 Poly)
 (declare-const tmp%13 Poly)
 (declare-const verus_tmp_sorted_right@ Poly)
 (declare-const verus_tmp_candidate@ Poly)
 (declare-const tmp%14 Poly)
 (declare-const tmp%15 Poly)
 (declare-const tmp%16 Poly)
 (declare-const tmp%17 Poly)
 (declare-const tmp%18 Int)
 (declare-const j@ Poly)
 (declare-const tmp%19 Poly)
 (declare-const tmp%20 Poly)
 (declare-const idx$1@ Poly)
 (declare-const tmp%21 Poly)
 (declare-const tmp%22 Poly)
 (declare-const tmp%23 Poly)
 (declare-const tmp%24 Poly)
 (declare-const tmp%25 Bool)
 (declare-const idx$2@ Poly)
 (declare-const idx@ Int)
 (declare-const tmp%26 Poly)
 (declare-const tmp%27 Poly)
 (declare-const tmp%28 Bool)
 (declare-const j$1@ Poly)
 (declare-const tmp%29 Poly)
 (declare-const tmp%30 Poly)
 (declare-const idx$5@ Poly)
 (declare-const tmp%31 Poly)
 (declare-const tmp%32 Poly)
 (declare-const tmp%33 Poly)
 (declare-const tmp%34 Poly)
 (declare-const tmp%35 Bool)
 (declare-const idx$6@ Poly)
 (declare-const idx$4@ Int)
 (declare-const tmp%36 Poly)
 (declare-const tmp%37 Poly)
 (declare-const tmp%38 Poly)
 (declare-const tmp%39 Bool)
 (declare-const ai@ Poly)
 (declare-const bi@ Poly)
 (declare-const tmp%40 Poly)
 (declare-const tmp%41 Poly)
 (declare-const tmp%42 Poly)
 (declare-const tmp%43 Poly)
 (declare-const ll@ Int)
 (declare-const el@ Int)
 (declare-const tmp%44 Poly)
 (declare-const tmp%45 Poly)
 (declare-const tmp%46 Poly)
 (declare-const tmp%47 Poly)
 (declare-const j$2@ Poly)
 (declare-const tmp%48 Poly)
 (declare-const left_a_view@ Poly)
 (declare-const tmp%49 core!option.Option.)
 (declare-const left_a@ lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS.)
 (declare-const tmp%50 Int)
 (declare-const tmp%51 Int)
 (declare-const j$3@ Poly)
 (declare-const tmp%52 Poly)
 (declare-const ll$1@ Int)
 (declare-const el$1@ Int)
 (declare-const right_a_view@ Poly)
 (declare-const tmp%53 core!option.Option.)
 (declare-const right_a@ lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS.)
 (declare-const new_k@ Int)
 (declare-const tmp%54 core!option.Option.)
 (declare-const tmp%55 core!option.Option.)
 (declare-const n@ Int)
 (declare-const verus_tmp@0 Poly)
 (declare-const s@0 Poly)
 (declare-const verus_tmp$1@0 %%Function%%)
 (declare-const leq@0 %%Function%%)
 (declare-const pivot_idx@ Int)
 (declare-const pivot@ Poly)
 (declare-const tmp%%$3@ tuple%3.)
 (declare-const left@ Poly)
 (declare-const eq_count@ Int)
 (declare-const right@ Poly)
 (declare-const verus_tmp$2@0 Poly)
 (declare-const equals_seq@0 Poly)
 (declare-const left_count@ Int)
 (declare-const right_count@ Int)
 (declare-const verus_tmp$3@0 Poly)
 (declare-const sorted_left@0 Poly)
 (declare-const verus_tmp$4@0 Poly)
 (declare-const sorted_right@0 Poly)
 (declare-const verus_tmp$5@0 Poly)
 (declare-const candidate@0 Poly)
 (assert
  fuel_defaults
 )
 (assert
  (sized T&.)
 )
 (assert
  (tr_bound%lib!Concurrency.Concurrency.StTInMtT. T&. T&)
 )
 (assert
  (tr_bound%lib!vstdplus.total_order.total_order.TotalOrder. T&. T&)
 )
 (assert
  (tr_bound%core!marker.Copy. T&. T&)
 )
 (assert
  (has_type (Poly%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS. a!) (TYPE%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS.
    T&. T&
 )))
 (assert
  (uInv SZ k!)
 )
 (declare-fun %%choose%%0 (Type Int Int Dcr Type Poly Poly Dcr Type Poly) Poly)
 (assert
  (forall ((%%hole%%0 Type) (%%hole%%1 Int) (%%hole%%2 Int) (%%hole%%3 Dcr) (%%hole%%4
     Type
    ) (%%hole%%5 Poly) (%%hole%%6 Poly) (%%hole%%7 Dcr) (%%hole%%8 Type) (%%hole%%9 Poly)
   ) (!
    (=>
     (exists ((idx$3 Poly)) (!
       (and
        (has_type idx$3 %%hole%%0)
        (and
         (let
          ((tmp%%$7 %%hole%%2))
          (let
           ((tmp%%$8 (%I idx$3)))
           (let
            ((tmp%%$9 %%hole%%1))
            (and
             (<= tmp%%$7 tmp%%$8)
             (< tmp%%$8 tmp%%$9)
         ))))
         (= (vstd!seq.Seq.index.? %%hole%%3 %%hole%%4 %%hole%%5 idx$3) %%hole%%6)
       ))
       :pattern ((vstd!seq.Seq.index.? %%hole%%7 %%hole%%8 %%hole%%9 idx$3))
       :qid user_lib__Chap35__OrderStatSelectMtEph__OrderStatSelectMtEph__select_inner_7
       :skolemid skolem_user_lib__Chap35__OrderStatSelectMtEph__OrderStatSelectMtEph__select_inner_7
     ))
     (exists ((idx$3 Poly)) (!
       (and
        (and
         (has_type idx$3 %%hole%%0)
         (and
          (let
           ((tmp%%$7 %%hole%%2))
           (let
            ((tmp%%$8 (%I idx$3)))
            (let
             ((tmp%%$9 %%hole%%1))
             (and
              (<= tmp%%$7 tmp%%$8)
              (< tmp%%$8 tmp%%$9)
          ))))
          (= (vstd!seq.Seq.index.? %%hole%%3 %%hole%%4 %%hole%%5 idx$3) %%hole%%6)
        ))
        (= (%%choose%%0 %%hole%%0 %%hole%%1 %%hole%%2 %%hole%%3 %%hole%%4 %%hole%%5 %%hole%%6
          %%hole%%7 %%hole%%8 %%hole%%9
         ) idx$3
       ))
       :pattern ((vstd!seq.Seq.index.? %%hole%%7 %%hole%%8 %%hole%%9 idx$3))
    )))
    :pattern ((%%choose%%0 %%hole%%0 %%hole%%1 %%hole%%2 %%hole%%3 %%hole%%4 %%hole%%5
      %%hole%%6 %%hole%%7 %%hole%%8 %%hole%%9
 )))))
 (declare-const verus_tmp@1 Poly)
 (declare-const s@1 Poly)
 (declare-const verus_tmp$1@1 %%Function%%)
 (declare-const leq@1 %%Function%%)
 (declare-const verus_tmp$2@1 Poly)
 (declare-const equals_seq@1 Poly)
 (declare-const verus_tmp$3@1 Poly)
 (declare-const sorted_left@1 Poly)
 (declare-const verus_tmp$4@1 Poly)
 (declare-const sorted_right@1 Poly)
 (declare-const verus_tmp$5@1 Poly)
 (declare-const candidate@1 Poly)
 (declare-const %%switch_label%%0 Bool)
 (declare-const %%switch_label%%1 Bool)
 (declare-const %%switch_label%%2 Bool)
 (declare-const %%switch_label%%3 Bool)
 (declare-const %%switch_label%%4 Bool)
 (declare-const %%switch_label%%5 Bool)
 (declare-const %%switch_label%%6 Bool)
 (declare-const %%switch_label%%7 Bool)
 (declare-const %%switch_label%%8 Bool)
 (declare-const %%switch_label%%9 Bool)
 (declare-const %%switch_label%%10 Bool)
 (declare-const %%switch_label%%11 Bool)
 ;; recommendation not met
 (declare-const %%location_label%%0 Bool)
 ;; recommendation not met
 (declare-const %%location_label%%1 Bool)
 ;; recommendation not met
 (declare-const %%location_label%%2 Bool)
 ;; recommendation not met
 (declare-const %%location_label%%3 Bool)
 ;; recommendation not met
 (declare-const %%location_label%%4 Bool)
 ;; recommendation not met
 (declare-const %%location_label%%5 Bool)
 ;; recommendation not met
 (declare-const %%location_label%%6 Bool)
 ;; recommendation not met
 (declare-const %%location_label%%7 Bool)
 ;; recommendation not met
 (declare-const %%location_label%%8 Bool)
 ;; recommendation not met: cannot prove that there exists values that satisfy the condition of the choose expression
 (declare-const %%location_label%%9 Bool)
 ;; recommendation not met
 (declare-const %%location_label%%10 Bool)
 ;; recommendation not met
 (declare-const %%location_label%%11 Bool)
 ;; recommendation not met
 (declare-const %%location_label%%12 Bool)
 ;; recommendation not met
 (declare-const %%location_label%%13 Bool)
 ;; recommendation not met
 (declare-const %%location_label%%14 Bool)
 ;; recommendation not met: cannot prove that there exists values that satisfy the condition of the choose expression
 (declare-const %%location_label%%15 Bool)
 ;; recommendation not met
 (declare-const %%location_label%%16 Bool)
 ;; recommendation not met
 (declare-const %%location_label%%17 Bool)
 ;; recommendation not met
 (declare-const %%location_label%%18 Bool)
 ;; recommendation not met
 (declare-const %%location_label%%19 Bool)
 ;; recommendation not met
 (declare-const %%location_label%%20 Bool)
 ;; recommendation not met
 (declare-const %%location_label%%21 Bool)
 ;; recommendation not met
 (declare-const %%location_label%%22 Bool)
 ;; recommendation not met
 (declare-const %%location_label%%23 Bool)
 (assert
  (not (=>
    (<= (%I (lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphTrait.spec_len.? $ (TYPE%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS.
        T&. T&
       ) T&. T& (Poly%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS. a!)
      )
     ) (- (uHi SZ) 1)
    )
    (=>
     (let
      ((tmp%%$ 0))
      (let
       ((tmp%%$1 k!))
       (let
        ((tmp%%$2 (%I (lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphTrait.spec_len.? $
            (TYPE%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS. T&. T&) T&. T& (Poly%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS.
             a!
        )))))
        (and
         (<= tmp%%$ tmp%%$1)
         (< tmp%%$1 tmp%%$2)
     ))))
     (=>
      (lib!vstdplus.feq.feq.obeys_feq_clone.? T&. T&)
      (=>
       (ens%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphTrait.length. $ (TYPE%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS.
         T&. T&
        ) T&. T& (Poly%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS. a!) tmp%5
       )
       (=>
        (= n@ (%I tmp%5))
        (=>
         (= tmp%6 (I n@))
         (=>
          (has_type i$1@ INT)
          (=>
           (= verus_tmp@1 (vstd!seq.Seq.new.? T&. T& tmp%6 (Poly%fun%1. (mk_fun (%%lambda%%3 $ (TYPE%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS.
                 T&. T&
                ) T&. T& (Poly%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS. a!)
           )))))
           (=>
            (= verus_tmp_s@ verus_tmp@1)
            (=>
             (= s@1 verus_tmp_s@)
             (=>
              (= verus_tmp$1@1 (lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.spec_leq.? T&.
                T&
              ))
              (=>
               (= verus_tmp_leq@ verus_tmp$1@1)
               (=>
                (= leq@1 verus_tmp_leq@)
                (or
                 (and
                  (=>
                   (= n@ 1)
                   (=>
                    (ens%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphTrait.nth. $ (TYPE%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS.
                      T&. T&
                     ) T&. T& (Poly%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS. a!) (I 0) elem@
                    )
                    (=>
                     (has_resolved T&. T& elem@)
                     (=>
                      (ens%lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.lemma_total_ordering. T&.
                       T&
                      )
                      (=>
                       (ens%vstd!seq_lib.impl&%0.lemma_sort_by_ensures. T&. T& s@1 leq@1)
                       (=>
                        (= tmp%8 s@1)
                        (and
                         (=>
                          %%location_label%%0
                          (req%vstd!seq_lib.impl&%0.sort_by. T&. T& s@1 (Poly%fun%2. leq@1))
                         )
                         (=>
                          (= tmp%7 (vstd!seq_lib.impl&%0.sort_by.? T&. T& s@1 (Poly%fun%2. leq@1)))
                          (=>
                           (ens%vstd!seq_lib.lemma_sorted_unique. T&. T& tmp%8 tmp%7 leq@1)
                           (=>
                            (= found! (core!option.Option./Some elem@))
                            (=>
                             (= tmp%4 found!)
                             (=>
                              (= tmp%1 (lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphTrait.spec_len.? $ (TYPE%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS.
                                 T&. T&
                                ) T&. T& (Poly%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS. a!)
                              ))
                              (=>
                               (has_type i@ INT)
                               (=>
                                (= tmp%3 (vstd!seq.Seq.new.? T&. T& tmp%1 (Poly%fun%1. (mk_fun (%%lambda%%3 $ (TYPE%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS.
                                      T&. T&
                                     ) T&. T& (Poly%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS. a!)
                                )))))
                                (=>
                                 %%location_label%%1
                                 (req%lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.spec_kth. T&. T& tmp%3 (
                                   I k!
                  )))))))))))))))))
                  (=>
                   (not (= n@ 1))
                   %%switch_label%%11
                 ))
                 (and
                  (not %%switch_label%%11)
                  (=>
                   (ens%lib!vstdplus.rand.rand.random_usize_range. 0 n@ pivot_idx@)
                   (=>
                    (ens%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphTrait.nth. $ (TYPE%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS.
                      T&. T&
                     ) T&. T& (Poly%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS. a!) (I pivot_idx@)
                     pivot@
                    )
                    (=>
                     (has_resolved T&. T& pivot@)
                     (=>
                      (ens%lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.parallel_three_way_partition.
                       T&. T& a! pivot@ pivot_idx@ n@ tmp%%$3@
                      )
                      (=>
                       (= left@ (tuple%3./tuple%3/0 (%Poly%tuple%3. (Poly%tuple%3. tmp%%$3@))))
                       (=>
                        (= eq_count@ (%I (tuple%3./tuple%3/1 (%Poly%tuple%3. (Poly%tuple%3. tmp%%$3@)))))
                        (=>
                         (= right@ (tuple%3./tuple%3/2 (%Poly%tuple%3. (Poly%tuple%3. tmp%%$3@))))
                         (=>
                          (= tmp%9 (I eq_count@))
                          (=>
                           (has_type i$2@ INT)
                           (=>
                            (= verus_tmp$2@1 (vstd!seq.Seq.new.? T&. T& tmp%9 (Poly%fun%1. (mk_fun (%%lambda%%6 pivot@)))))
                            (=>
                             (= verus_tmp_equals_seq@ verus_tmp$2@1)
                             (=>
                              (= equals_seq@1 verus_tmp_equals_seq@)
                              (=>
                               (ens%alloc!vec.impl&%1.len. T&. T& $ TYPE%alloc!alloc.Global. left@ left_count@)
                               (=>
                                (ens%alloc!vec.impl&%1.len. T&. T& $ TYPE%alloc!alloc.Global. right@ right_count@)
                                (=>
                                 (ens%lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.lemma_total_ordering. T&.
                                  T&
                                 )
                                 (=>
                                  (= tmp%11 (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. T&. T& $ TYPE%alloc!alloc.Global.)
                                    left@
                                  ))
                                  (and
                                   (=>
                                    %%location_label%%2
                                    (req%vstd!seq_lib.impl&%0.sort_by. T&. T& tmp%11 (Poly%fun%2. leq@1))
                                   )
                                   (=>
                                    (= tmp%10 (vstd!seq_lib.impl&%0.sort_by.? T&. T& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec.
                                        T&. T& $ TYPE%alloc!alloc.Global.
                                       ) left@
                                      ) (Poly%fun%2. leq@1)
                                    ))
                                    (=>
                                     (= verus_tmp$3@1 tmp%10)
                                     (=>
                                      (= verus_tmp_sorted_left@ verus_tmp$3@1)
                                      (=>
                                       (= sorted_left@1 verus_tmp_sorted_left@)
                                       (=>
                                        (= tmp%13 (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. T&. T& $ TYPE%alloc!alloc.Global.)
                                          right@
                                        ))
                                        (and
                                         (=>
                                          %%location_label%%3
                                          (req%vstd!seq_lib.impl&%0.sort_by. T&. T& tmp%13 (Poly%fun%2. leq@1))
                                         )
                                         (=>
                                          (= tmp%12 (vstd!seq_lib.impl&%0.sort_by.? T&. T& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec.
                                              T&. T& $ TYPE%alloc!alloc.Global.
                                             ) right@
                                            ) (Poly%fun%2. leq@1)
                                          ))
                                          (=>
                                           (= verus_tmp$4@1 tmp%12)
                                           (=>
                                            (= verus_tmp_sorted_right@ verus_tmp$4@1)
                                            (=>
                                             (= sorted_right@1 verus_tmp_sorted_right@)
                                             (=>
                                              (= verus_tmp$5@1 (vstd!seq.Seq.add.? T&. T& (vstd!seq.Seq.add.? T&. T& sorted_left@1
                                                 equals_seq@1
                                                ) sorted_right@1
                                              ))
                                              (=>
                                               (= verus_tmp_candidate@ verus_tmp$5@1)
                                               (=>
                                                (= candidate@1 verus_tmp_candidate@)
                                                (=>
                                                 (= tmp%14 (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. T&. T& $ TYPE%alloc!alloc.Global.)
                                                   left@
                                                 ))
                                                 (=>
                                                  (ens%vstd!seq_lib.impl&%0.lemma_sort_by_ensures. T&. T& tmp%14 leq@1)
                                                  (=>
                                                   (= tmp%15 (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. T&. T& $ TYPE%alloc!alloc.Global.)
                                                     right@
                                                   ))
                                                   (=>
                                                    (ens%vstd!seq_lib.impl&%0.lemma_sort_by_ensures. T&. T& tmp%15 leq@1)
                                                    (=>
                                                     (ens%vstd!seq_lib.impl&%0.lemma_sort_by_ensures. T&. T& s@1 leq@1)
                                                     (and
                                                      (=>
                                                       %%location_label%%4
                                                       (req%vstd!seq_lib.impl&%0.sort_by. T&. T& s@1 (Poly%fun%2. leq@1))
                                                      )
                                                      (=>
                                                       (= tmp%16 (vstd!seq_lib.impl&%0.sort_by.? T&. T& s@1 (Poly%fun%2. leq@1)))
                                                       (=>
                                                        (= tmp%18 (vstd!multiset.impl&%0.len.? T&. T& (vstd!seq_lib.impl&%0.to_multiset.? T&.
                                                           T& tmp%16
                                                        )))
                                                        (and
                                                         (=>
                                                          %%location_label%%5
                                                          (req%vstd!seq_lib.impl&%0.sort_by. T&. T& s@1 (Poly%fun%2. leq@1))
                                                         )
                                                         (=>
                                                          (= tmp%17 (vstd!seq_lib.impl&%0.sort_by.? T&. T& s@1 (Poly%fun%2. leq@1)))
                                                          (=>
                                                           (= tmp%18 (vstd!seq.Seq.len.? T&. T& tmp%17))
                                                           (and
                                                            (=>
                                                             (has_type j@ INT)
                                                             (=>
                                                              (let
                                                               ((tmp%%$10 0))
                                                               (let
                                                                ((tmp%%$11 (%I j@)))
                                                                (let
                                                                 ((tmp%%$12 (vstd!seq.Seq.len.? T&. T& sorted_left@1)))
                                                                 (and
                                                                  (<= tmp%%$10 tmp%%$11)
                                                                  (< tmp%%$11 tmp%%$12)
                                                              ))))
                                                              (=>
                                                               (= tmp%20 (vstd!seq_lib.impl&%0.to_multiset.? T&. T& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec.
                                                                   T&. T& $ TYPE%alloc!alloc.Global.
                                                                  ) left@
                                                               )))
                                                               (and
                                                                (=>
                                                                 %%location_label%%6
                                                                 (req%vstd!seq.impl&%2.spec_index. T&. T& sorted_left@1 j@)
                                                                )
                                                                (=>
                                                                 (= tmp%19 (vstd!seq.Seq.index.? T&. T& sorted_left@1 j@))
                                                                 (=>
                                                                  (> (vstd!multiset.impl&%0.count.? T&. T& tmp%20 tmp%19) 0)
                                                                  (=>
                                                                   (has_type idx$1@ INT)
                                                                   (or
                                                                    (and
                                                                     (=>
                                                                      (let
                                                                       ((tmp%%$4 0))
                                                                       (let
                                                                        ((tmp%%$5 (%I idx$1@)))
                                                                        (let
                                                                         ((tmp%%$6 (vstd!seq.Seq.len.? T&. T& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. T&.
                                                                              T& $ TYPE%alloc!alloc.Global.
                                                                             ) left@
                                                                         ))))
                                                                         (and
                                                                          (<= tmp%%$4 tmp%%$5)
                                                                          (< tmp%%$5 tmp%%$6)
                                                                      ))))
                                                                      (=>
                                                                       (= tmp%22 (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. T&. T& $ TYPE%alloc!alloc.Global.)
                                                                         left@
                                                                       ))
                                                                       (and
                                                                        (=>
                                                                         %%location_label%%7
                                                                         (req%vstd!seq.impl&%2.spec_index. T&. T& tmp%22 idx$1@)
                                                                        )
                                                                        (=>
                                                                         (= tmp%21 (vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec.
                                                                             T&. T& $ TYPE%alloc!alloc.Global.
                                                                            ) left@
                                                                           ) idx$1@
                                                                         ))
                                                                         (=>
                                                                          (= tmp%24 tmp%21)
                                                                          (and
                                                                           (=>
                                                                            %%location_label%%8
                                                                            (req%vstd!seq.impl&%2.spec_index. T&. T& sorted_left@1 j@)
                                                                           )
                                                                           (=>
                                                                            (= tmp%23 (vstd!seq.Seq.index.? T&. T& sorted_left@1 j@))
                                                                            (=>
                                                                             (= tmp%25 (= tmp%24 tmp%23))
                                                                             %%switch_label%%10
                                                                     ))))))))
                                                                     (=>
                                                                      (not (let
                                                                        ((tmp%%$4 0))
                                                                        (let
                                                                         ((tmp%%$5 (%I idx$1@)))
                                                                         (let
                                                                          ((tmp%%$6 (vstd!seq.Seq.len.? T&. T& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. T&.
                                                                               T& $ TYPE%alloc!alloc.Global.
                                                                              ) left@
                                                                          ))))
                                                                          (and
                                                                           (<= tmp%%$4 tmp%%$5)
                                                                           (< tmp%%$5 tmp%%$6)
                                                                      )))))
                                                                      (=>
                                                                       (= tmp%25 false)
                                                                       %%switch_label%%10
                                                                    )))
                                                                    (and
                                                                     (not %%switch_label%%10)
                                                                     (=>
                                                                      (has_type idx$2@ INT)
                                                                      (and
                                                                       (=>
                                                                        %%location_label%%9
                                                                        (exists ((idx$3 Poly)) (!
                                                                          (and
                                                                           (has_type idx$3 INT)
                                                                           (and
                                                                            (let
                                                                             ((tmp%%$7 0))
                                                                             (let
                                                                              ((tmp%%$8 (%I idx$3)))
                                                                              (let
                                                                               ((tmp%%$9 (vstd!seq.Seq.len.? T&. T& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. T&.
                                                                                    T& $ TYPE%alloc!alloc.Global.
                                                                                   ) left@
                                                                               ))))
                                                                               (and
                                                                                (<= tmp%%$7 tmp%%$8)
                                                                                (< tmp%%$8 tmp%%$9)
                                                                            ))))
                                                                            (= (vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. T&. T&
                                                                                $ TYPE%alloc!alloc.Global.
                                                                               ) left@
                                                                              ) idx$3
                                                                             ) (vstd!seq.Seq.index.? T&. T& sorted_left@1 j@)
                                                                          )))
                                                                          :pattern ((vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec.
                                                                              T&. T& $ TYPE%alloc!alloc.Global.
                                                                             ) left@
                                                                            ) idx$3
                                                                          ))
                                                                          :qid user_lib__Chap35__OrderStatSelectMtEph__OrderStatSelectMtEph__select_inner_6
                                                                          :skolemid skolem_user_lib__Chap35__OrderStatSelectMtEph__OrderStatSelectMtEph__select_inner_6
                                                                       )))
                                                                       (=>
                                                                        (= idx@ (%I (as_type (%%choose%%0 INT (vstd!seq.Seq.len.? T&. T& (vstd!view.View.view.?
                                                                              $ (TYPE%alloc!vec.Vec. T&. T& $ TYPE%alloc!alloc.Global.) left@
                                                                             )
                                                                            ) 0 T&. T& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. T&. T& $ TYPE%alloc!alloc.Global.)
                                                                             left@
                                                                            ) (vstd!seq.Seq.index.? T&. T& sorted_left@1 j@) T&. T& (vstd!view.View.view.? $ (
                                                                              TYPE%alloc!vec.Vec. T&. T& $ TYPE%alloc!alloc.Global.
                                                                             ) left@
                                                                            )
                                                                           ) INT
                                                                        )))
                                                                        (and
                                                                         (=>
                                                                          %%location_label%%10
                                                                          (req%vstd!seq.impl&%2.spec_index. T&. T& sorted_left@1 j@)
                                                                         )
                                                                         (=>
                                                                          (= tmp%26 (vstd!seq.Seq.index.? T&. T& sorted_left@1 j@))
                                                                          (or
                                                                           (and
                                                                            (=>
                                                                             (%B (lib!vstdplus.total_order.total_order.TotalOrder.le.? T&. T& tmp%26 pivot@))
                                                                             (and
                                                                              (=>
                                                                               %%location_label%%11
                                                                               (req%vstd!seq.impl&%2.spec_index. T&. T& sorted_left@1 j@)
                                                                              )
                                                                              (=>
                                                                               (= tmp%27 (vstd!seq.Seq.index.? T&. T& sorted_left@1 j@))
                                                                               (=>
                                                                                (= tmp%28 (not (= tmp%27 pivot@)))
                                                                                %%switch_label%%9
                                                                            ))))
                                                                            (=>
                                                                             (not (%B (lib!vstdplus.total_order.total_order.TotalOrder.le.? T&. T& tmp%26 pivot@)))
                                                                             (=>
                                                                              (= tmp%28 false)
                                                                              %%switch_label%%9
                                                                           )))
                                                                           (not %%switch_label%%9)
                                                            )))))))))))))))
                                                            (=>
                                                             (forall ((j$ Poly)) (!
                                                               (=>
                                                                (has_type j$ INT)
                                                                (=>
                                                                 (let
                                                                  ((tmp%%$13 0))
                                                                  (let
                                                                   ((tmp%%$14 (%I j$)))
                                                                   (let
                                                                    ((tmp%%$15 (vstd!seq.Seq.len.? T&. T& sorted_left@1)))
                                                                    (and
                                                                     (<= tmp%%$13 tmp%%$14)
                                                                     (< tmp%%$14 tmp%%$15)
                                                                 ))))
                                                                 (and
                                                                  (%B (lib!vstdplus.total_order.total_order.TotalOrder.le.? T&. T& (vstd!seq.Seq.index.?
                                                                     T&. T& sorted_left@1 j$
                                                                    ) pivot@
                                                                  ))
                                                                  (not (= (vstd!seq.Seq.index.? T&. T& sorted_left@1 j$) pivot@))
                                                               )))
                                                               :pattern ((vstd!seq.Seq.index.? T&. T& sorted_left@1 j$))
                                                               :qid user_lib__Chap35__OrderStatSelectMtEph__OrderStatSelectMtEph__select_inner_8
                                                               :skolemid skolem_user_lib__Chap35__OrderStatSelectMtEph__OrderStatSelectMtEph__select_inner_8
                                                             ))
                                                             (and
                                                              (=>
                                                               (has_type j$1@ INT)
                                                               (=>
                                                                (let
                                                                 ((tmp%%$22 0))
                                                                 (let
                                                                  ((tmp%%$23 (%I j$1@)))
                                                                  (let
                                                                   ((tmp%%$24 (vstd!seq.Seq.len.? T&. T& sorted_right@1)))
                                                                   (and
                                                                    (<= tmp%%$22 tmp%%$23)
                                                                    (< tmp%%$23 tmp%%$24)
                                                                ))))
                                                                (=>
                                                                 (= tmp%30 (vstd!seq_lib.impl&%0.to_multiset.? T&. T& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec.
                                                                     T&. T& $ TYPE%alloc!alloc.Global.
                                                                    ) right@
                                                                 )))
                                                                 (and
                                                                  (=>
                                                                   %%location_label%%12
                                                                   (req%vstd!seq.impl&%2.spec_index. T&. T& sorted_right@1 j$1@)
                                                                  )
                                                                  (=>
                                                                   (= tmp%29 (vstd!seq.Seq.index.? T&. T& sorted_right@1 j$1@))
                                                                   (=>
                                                                    (> (vstd!multiset.impl&%0.count.? T&. T& tmp%30 tmp%29) 0)
                                                                    (=>
                                                                     (has_type idx$5@ INT)
                                                                     (or
                                                                      (and
                                                                       (=>
                                                                        (let
                                                                         ((tmp%%$16 0))
                                                                         (let
                                                                          ((tmp%%$17 (%I idx$5@)))
                                                                          (let
                                                                           ((tmp%%$18 (vstd!seq.Seq.len.? T&. T& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. T&.
                                                                                T& $ TYPE%alloc!alloc.Global.
                                                                               ) right@
                                                                           ))))
                                                                           (and
                                                                            (<= tmp%%$16 tmp%%$17)
                                                                            (< tmp%%$17 tmp%%$18)
                                                                        ))))
                                                                        (=>
                                                                         (= tmp%32 (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. T&. T& $ TYPE%alloc!alloc.Global.)
                                                                           right@
                                                                         ))
                                                                         (and
                                                                          (=>
                                                                           %%location_label%%13
                                                                           (req%vstd!seq.impl&%2.spec_index. T&. T& tmp%32 idx$5@)
                                                                          )
                                                                          (=>
                                                                           (= tmp%31 (vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec.
                                                                               T&. T& $ TYPE%alloc!alloc.Global.
                                                                              ) right@
                                                                             ) idx$5@
                                                                           ))
                                                                           (=>
                                                                            (= tmp%34 tmp%31)
                                                                            (and
                                                                             (=>
                                                                              %%location_label%%14
                                                                              (req%vstd!seq.impl&%2.spec_index. T&. T& sorted_right@1 j$1@)
                                                                             )
                                                                             (=>
                                                                              (= tmp%33 (vstd!seq.Seq.index.? T&. T& sorted_right@1 j$1@))
                                                                              (=>
                                                                               (= tmp%35 (= tmp%34 tmp%33))
                                                                               %%switch_label%%8
                                                                       ))))))))
                                                                       (=>
                                                                        (not (let
                                                                          ((tmp%%$16 0))
                                                                          (let
                                                                           ((tmp%%$17 (%I idx$5@)))
                                                                           (let
                                                                            ((tmp%%$18 (vstd!seq.Seq.len.? T&. T& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. T&.
                                                                                 T& $ TYPE%alloc!alloc.Global.
                                                                                ) right@
                                                                            ))))
                                                                            (and
                                                                             (<= tmp%%$16 tmp%%$17)
                                                                             (< tmp%%$17 tmp%%$18)
                                                                        )))))
                                                                        (=>
                                                                         (= tmp%35 false)
                                                                         %%switch_label%%8
                                                                      )))
                                                                      (and
                                                                       (not %%switch_label%%8)
                                                                       (=>
                                                                        (has_type idx$6@ INT)
                                                                        (and
                                                                         (=>
                                                                          %%location_label%%15
                                                                          (exists ((idx$7 Poly)) (!
                                                                            (and
                                                                             (has_type idx$7 INT)
                                                                             (and
                                                                              (let
                                                                               ((tmp%%$19 0))
                                                                               (let
                                                                                ((tmp%%$20 (%I idx$7)))
                                                                                (let
                                                                                 ((tmp%%$21 (vstd!seq.Seq.len.? T&. T& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. T&.
                                                                                      T& $ TYPE%alloc!alloc.Global.
                                                                                     ) right@
                                                                                 ))))
                                                                                 (and
                                                                                  (<= tmp%%$19 tmp%%$20)
                                                                                  (< tmp%%$20 tmp%%$21)
                                                                              ))))
                                                                              (= (vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. T&. T&
                                                                                  $ TYPE%alloc!alloc.Global.
                                                                                 ) right@
                                                                                ) idx$7
                                                                               ) (vstd!seq.Seq.index.? T&. T& sorted_right@1 j$1@)
                                                                            )))
                                                                            :pattern ((vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec.
                                                                                T&. T& $ TYPE%alloc!alloc.Global.
                                                                               ) right@
                                                                              ) idx$7
                                                                            ))
                                                                            :qid user_lib__Chap35__OrderStatSelectMtEph__OrderStatSelectMtEph__select_inner_9
                                                                            :skolemid skolem_user_lib__Chap35__OrderStatSelectMtEph__OrderStatSelectMtEph__select_inner_9
                                                                         )))
                                                                         (=>
                                                                          (= idx$4@ (%I (as_type (%%choose%%0 INT (vstd!seq.Seq.len.? T&. T& (vstd!view.View.view.?
                                                                                $ (TYPE%alloc!vec.Vec. T&. T& $ TYPE%alloc!alloc.Global.) right@
                                                                               )
                                                                              ) 0 T&. T& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. T&. T& $ TYPE%alloc!alloc.Global.)
                                                                               right@
                                                                              ) (vstd!seq.Seq.index.? T&. T& sorted_right@1 j$1@) T&. T& (vstd!view.View.view.?
                                                                               $ (TYPE%alloc!vec.Vec. T&. T& $ TYPE%alloc!alloc.Global.) right@
                                                                              )
                                                                             ) INT
                                                                          )))
                                                                          (=>
                                                                           (= tmp%37 pivot@)
                                                                           (and
                                                                            (=>
                                                                             %%location_label%%16
                                                                             (req%vstd!seq.impl&%2.spec_index. T&. T& sorted_right@1 j$1@)
                                                                            )
                                                                            (=>
                                                                             (= tmp%36 (vstd!seq.Seq.index.? T&. T& sorted_right@1 j$1@))
                                                                             (or
                                                                              (and
                                                                               (=>
                                                                                (%B (lib!vstdplus.total_order.total_order.TotalOrder.le.? T&. T& tmp%37 tmp%36))
                                                                                (and
                                                                                 (=>
                                                                                  %%location_label%%17
                                                                                  (req%vstd!seq.impl&%2.spec_index. T&. T& sorted_right@1 j$1@)
                                                                                 )
                                                                                 (=>
                                                                                  (= tmp%38 (vstd!seq.Seq.index.? T&. T& sorted_right@1 j$1@))
                                                                                  (=>
                                                                                   (= tmp%39 (not (= tmp%38 pivot@)))
                                                                                   %%switch_label%%7
                                                                               ))))
                                                                               (=>
                                                                                (not (%B (lib!vstdplus.total_order.total_order.TotalOrder.le.? T&. T& tmp%37 tmp%36)))
                                                                                (=>
                                                                                 (= tmp%39 false)
                                                                                 %%switch_label%%7
                                                                              )))
                                                                              (not %%switch_label%%7)
                                                              ))))))))))))))))
                                                              (=>
                                                               (forall ((j$ Poly)) (!
                                                                 (=>
                                                                  (has_type j$ INT)
                                                                  (=>
                                                                   (let
                                                                    ((tmp%%$25 0))
                                                                    (let
                                                                     ((tmp%%$26 (%I j$)))
                                                                     (let
                                                                      ((tmp%%$27 (vstd!seq.Seq.len.? T&. T& sorted_right@1)))
                                                                      (and
                                                                       (<= tmp%%$25 tmp%%$26)
                                                                       (< tmp%%$26 tmp%%$27)
                                                                   ))))
                                                                   (and
                                                                    (%B (lib!vstdplus.total_order.total_order.TotalOrder.le.? T&. T& pivot@ (vstd!seq.Seq.index.?
                                                                       T&. T& sorted_right@1 j$
                                                                    )))
                                                                    (not (= (vstd!seq.Seq.index.? T&. T& sorted_right@1 j$) pivot@))
                                                                 )))
                                                                 :pattern ((vstd!seq.Seq.index.? T&. T& sorted_right@1 j$))
                                                                 :qid user_lib__Chap35__OrderStatSelectMtEph__OrderStatSelectMtEph__select_inner_11
                                                                 :skolemid skolem_user_lib__Chap35__OrderStatSelectMtEph__OrderStatSelectMtEph__select_inner_11
                                                               ))
                                                               (and
                                                                (=>
                                                                 (has_type ai@ INT)
                                                                 (=>
                                                                  (has_type bi@ INT)
                                                                  (=>
                                                                   (let
                                                                    ((tmp%%$28 0))
                                                                    (let
                                                                     ((tmp%%$29 (%I ai@)))
                                                                     (let
                                                                      ((tmp%%$30 (%I bi@)))
                                                                      (let
                                                                       ((tmp%%$31 (vstd!seq.Seq.len.? T&. T& candidate@1)))
                                                                       (and
                                                                        (and
                                                                         (<= tmp%%$28 tmp%%$29)
                                                                         (< tmp%%$29 tmp%%$30)
                                                                        )
                                                                        (< tmp%%$30 tmp%%$31)
                                                                   )))))
                                                                   (=>
                                                                    (= ll@ (vstd!seq.Seq.len.? T&. T& sorted_left@1))
                                                                    (=>
                                                                     (= el@ (vstd!seq.Seq.len.? T&. T& equals_seq@1))
                                                                     (or
                                                                      (and
                                                                       (=>
                                                                        (and
                                                                         (< (%I ai@) ll@)
                                                                         (< (%I bi@) ll@)
                                                                        )
                                                                        %%switch_label%%2
                                                                       )
                                                                       (=>
                                                                        (not (and
                                                                          (< (%I ai@) ll@)
                                                                          (< (%I bi@) ll@)
                                                                        ))
                                                                        (or
                                                                         (and
                                                                          (=>
                                                                           (and
                                                                            (< (%I ai@) ll@)
                                                                            (< (%I bi@) (nClip (Add ll@ el@)))
                                                                           )
                                                                           %%switch_label%%3
                                                                          )
                                                                          (=>
                                                                           (not (and
                                                                             (< (%I ai@) ll@)
                                                                             (< (%I bi@) (nClip (Add ll@ el@)))
                                                                           ))
                                                                           (or
                                                                            (and
                                                                             (=>
                                                                              (and
                                                                               (< (%I ai@) ll@)
                                                                               (>= (%I bi@) (nClip (Add ll@ el@)))
                                                                              )
                                                                              (and
                                                                               (=>
                                                                                %%location_label%%18
                                                                                (req%vstd!seq.impl&%2.spec_index. T&. T& candidate@1 ai@)
                                                                               )
                                                                               (=>
                                                                                (= tmp%40 (vstd!seq.Seq.index.? T&. T& candidate@1 ai@))
                                                                                (=>
                                                                                 (= tmp%42 tmp%40)
                                                                                 (=>
                                                                                  (= tmp%43 pivot@)
                                                                                  (and
                                                                                   (=>
                                                                                    %%location_label%%19
                                                                                    (req%vstd!seq.impl&%2.spec_index. T&. T& candidate@1 bi@)
                                                                                   )
                                                                                   (=>
                                                                                    (= tmp%41 (vstd!seq.Seq.index.? T&. T& candidate@1 bi@))
                                                                                    (=>
                                                                                     (ens%lib!vstdplus.total_order.total_order.TotalOrder.transitive. T&. T& tmp%42 tmp%43
                                                                                      tmp%41
                                                                                     )
                                                                                     %%switch_label%%4
                                                                             ))))))))
                                                                             (=>
                                                                              (not (and
                                                                                (< (%I ai@) ll@)
                                                                                (>= (%I bi@) (nClip (Add ll@ el@)))
                                                                              ))
                                                                              (or
                                                                               (and
                                                                                (=>
                                                                                 (and
                                                                                  (and
                                                                                   (and
                                                                                    (>= (%I ai@) ll@)
                                                                                    (< (%I ai@) (nClip (Add ll@ el@)))
                                                                                   )
                                                                                   (>= (%I bi@) ll@)
                                                                                  )
                                                                                  (< (%I bi@) (nClip (Add ll@ el@)))
                                                                                 )
                                                                                 (=>
                                                                                  (ens%lib!vstdplus.total_order.total_order.TotalOrder.reflexive. T&. T& pivot@)
                                                                                  %%switch_label%%5
                                                                                ))
                                                                                (=>
                                                                                 (not (and
                                                                                   (and
                                                                                    (and
                                                                                     (>= (%I ai@) ll@)
                                                                                     (< (%I ai@) (nClip (Add ll@ el@)))
                                                                                    )
                                                                                    (>= (%I bi@) ll@)
                                                                                   )
                                                                                   (< (%I bi@) (nClip (Add ll@ el@)))
                                                                                 ))
                                                                                 (or
                                                                                  (and
                                                                                   (=>
                                                                                    (and
                                                                                     (and
                                                                                      (>= (%I ai@) ll@)
                                                                                      (< (%I ai@) (nClip (Add ll@ el@)))
                                                                                     )
                                                                                     (>= (%I bi@) (nClip (Add ll@ el@)))
                                                                                    )
                                                                                    %%switch_label%%6
                                                                                   )
                                                                                   (=>
                                                                                    (not (and
                                                                                      (and
                                                                                       (>= (%I ai@) ll@)
                                                                                       (< (%I ai@) (nClip (Add ll@ el@)))
                                                                                      )
                                                                                      (>= (%I bi@) (nClip (Add ll@ el@)))
                                                                                    ))
                                                                                    %%switch_label%%6
                                                                                  ))
                                                                                  (and
                                                                                   (not %%switch_label%%6)
                                                                                   %%switch_label%%5
                                                                               ))))
                                                                               (and
                                                                                (not %%switch_label%%5)
                                                                                %%switch_label%%4
                                                                            ))))
                                                                            (and
                                                                             (not %%switch_label%%4)
                                                                             %%switch_label%%3
                                                                         ))))
                                                                         (and
                                                                          (not %%switch_label%%3)
                                                                          %%switch_label%%2
                                                                      ))))
                                                                      (and
                                                                       (not %%switch_label%%2)
                                                                       (and
                                                                        (=>
                                                                         %%location_label%%20
                                                                         (req%vstd!seq.impl&%2.spec_index. T&. T& candidate@1 ai@)
                                                                        )
                                                                        (=>
                                                                         (= tmp%44 (vstd!seq.Seq.index.? T&. T& candidate@1 ai@))
                                                                         (=>
                                                                          %%location_label%%21
                                                                          (req%vstd!seq.impl&%2.spec_index. T&. T& candidate@1 bi@)
                                                                ))))))))))
                                                                (=>
                                                                 (vstd!relations.sorted_by.? T&. T& candidate@1 (Poly%fun%2. leq@1))
                                                                 (=>
                                                                  (ens%vstd!seq_lib.lemma_multiset_commutative. T&. T& sorted_left@1 equals_seq@1)
                                                                  (=>
                                                                   (= tmp%46 (vstd!seq.Seq.add.? T&. T& sorted_left@1 equals_seq@1))
                                                                   (=>
                                                                    (ens%vstd!seq_lib.lemma_multiset_commutative. T&. T& tmp%46 sorted_right@1)
                                                                    (=>
                                                                     (ext_eq false (TYPE%vstd!multiset.Multiset. T&. T&) (vstd!seq_lib.impl&%0.to_multiset.?
                                                                       T&. T& candidate@1
                                                                      ) (vstd!seq_lib.impl&%0.to_multiset.? T&. T& s@1)
                                                                     )
                                                                     (and
                                                                      (=>
                                                                       %%location_label%%22
                                                                       (req%vstd!seq_lib.impl&%0.sort_by. T&. T& s@1 (Poly%fun%2. leq@1))
                                                                      )
                                                                      (=>
                                                                       (= tmp%47 (vstd!seq_lib.impl&%0.sort_by.? T&. T& s@1 (Poly%fun%2. leq@1)))
                                                                       (=>
                                                                        (ens%vstd!seq_lib.lemma_sorted_unique. T&. T& tmp%47 candidate@1 leq@1)
                                                                        (or
                                                                         (and
                                                                          (=>
                                                                           (< k! left_count@)
                                                                           (=>
                                                                            (has_resolved $ (TYPE%alloc!vec.Vec. T&. T& $ TYPE%alloc!alloc.Global.) right@)
                                                                            (=>
                                                                             (= left_a@ (lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS./ArraySeqMtEphS left@))
                                                                             (=>
                                                                              (has_resolved $ (TYPE%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS. T&. T&)
                                                                               (Poly%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS. left_a@)
                                                                              )
                                                                              (=>
                                                                               (= tmp%48 (lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphTrait.spec_len.? $ (
                                                                                  TYPE%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS. T&. T&
                                                                                 ) T&. T& (Poly%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS. left_a@)
                                                                               ))
                                                                               (=>
                                                                                (has_type j$2@ INT)
                                                                                (=>
                                                                                 (= left_a_view@ (vstd!seq.Seq.new.? T&. T& tmp%48 (Poly%fun%1. (mk_fun (%%lambda%%3 $
                                                                                      (TYPE%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS. T&. T&) T&. T& (Poly%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS.
                                                                                       left_a@
                                                                                 ))))))
                                                                                 (=>
                                                                                  (ext_eq false (TYPE%vstd!seq.Seq. T&. T&) left_a_view@ (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec.
                                                                                     T&. T& $ TYPE%alloc!alloc.Global.
                                                                                    ) left@
                                                                                  ))
                                                                                  (=>
                                                                                   (ens%lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.select_inner. T&. T& left_a@
                                                                                    k! tmp%49
                                                                                   )
                                                                                   (=>
                                                                                    (= tmp%55 tmp%49)
                                                                                    %%switch_label%%0
                                                                          ))))))))))
                                                                          (=>
                                                                           (not (< k! left_count@))
                                                                           (=>
                                                                            (has_resolved $ (TYPE%alloc!vec.Vec. T&. T& $ TYPE%alloc!alloc.Global.) left@)
                                                                            (=>
                                                                             (= tmp%50 k!)
                                                                             (=>
                                                                              (uInv SZ (Sub n@ right_count@))
                                                                              (or
                                                                               (and
                                                                                (=>
                                                                                 (< tmp%50 (uClip SZ (Sub n@ right_count@)))
                                                                                 (=>
                                                                                  (has_resolved $ (TYPE%alloc!vec.Vec. T&. T& $ TYPE%alloc!alloc.Global.) right@)
                                                                                  (=>
                                                                                   (= tmp%54 (core!option.Option./Some pivot@))
                                                                                   %%switch_label%%1
                                                                                )))
                                                                                (=>
                                                                                 (not (< tmp%50 (uClip SZ (Sub n@ right_count@))))
                                                                                 (=>
                                                                                  (= right_a@ (lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS./ArraySeqMtEphS
                                                                                    right@
                                                                                  ))
                                                                                  (=>
                                                                                   (has_resolved $ (TYPE%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS. T&. T&)
                                                                                    (Poly%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS. right_a@)
                                                                                   )
                                                                                   (=>
                                                                                    (= tmp%51 k!)
                                                                                    (=>
                                                                                     (uInv SZ (Sub n@ right_count@))
                                                                                     (=>
                                                                                      (uInv SZ (Sub tmp%51 (uClip SZ (Sub n@ right_count@))))
                                                                                      (=>
                                                                                       (= new_k@ (uClip SZ (Sub tmp%51 (uClip SZ (Sub n@ right_count@)))))
                                                                                       (=>
                                                                                        (= ll$1@ (vstd!seq.Seq.len.? T&. T& sorted_left@1))
                                                                                        (=>
                                                                                         (= el$1@ (vstd!seq.Seq.len.? T&. T& equals_seq@1))
                                                                                         (=>
                                                                                          (= tmp%52 (lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphTrait.spec_len.? $ (
                                                                                             TYPE%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS. T&. T&
                                                                                            ) T&. T& (Poly%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS. right_a@)
                                                                                          ))
                                                                                          (=>
                                                                                           (has_type j$3@ INT)
                                                                                           (=>
                                                                                            (= right_a_view@ (vstd!seq.Seq.new.? T&. T& tmp%52 (Poly%fun%1. (mk_fun (%%lambda%%3 $
                                                                                                 (TYPE%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS. T&. T&) T&. T& (Poly%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS.
                                                                                                  right_a@
                                                                                            ))))))
                                                                                            (=>
                                                                                             (ext_eq false (TYPE%vstd!seq.Seq. T&. T&) right_a_view@ (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec.
                                                                                                T&. T& $ TYPE%alloc!alloc.Global.
                                                                                               ) right@
                                                                                             ))
                                                                                             (=>
                                                                                              (ens%lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.select_inner. T&. T& right_a@
                                                                                               new_k@ tmp%53
                                                                                              )
                                                                                              (=>
                                                                                               (= tmp%54 tmp%53)
                                                                                               %%switch_label%%1
                                                                               ))))))))))))))))
                                                                               (and
                                                                                (not %%switch_label%%1)
                                                                                (=>
                                                                                 (= tmp%55 tmp%54)
                                                                                 %%switch_label%%0
                                                                         ))))))))
                                                                         (and
                                                                          (not %%switch_label%%0)
                                                                          (=>
                                                                           (= found! tmp%55)
                                                                           (=>
                                                                            (= tmp%4 found!)
                                                                            (=>
                                                                             (= tmp%1 (lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphTrait.spec_len.? $ (TYPE%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS.
                                                                                T&. T&
                                                                               ) T&. T& (Poly%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS. a!)
                                                                             ))
                                                                             (=>
                                                                              (has_type i@ INT)
                                                                              (=>
                                                                               (= tmp%3 (vstd!seq.Seq.new.? T&. T& tmp%1 (Poly%fun%1. (mk_fun (%%lambda%%3 $ (TYPE%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS.
                                                                                     T&. T&
                                                                                    ) T&. T& (Poly%lib!Chap19.ArraySeqMtEph.ArraySeqMtEph.ArraySeqMtEphS. a!)
                                                                               )))))
                                                                               (=>
                                                                                %%location_label%%23
                                                                                (req%lib!Chap35.OrderStatSelectMtEph.OrderStatSelectMtEph.spec_kth. T&. T& tmp%3 (
                                                                                  I k!
 )))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
 (get-info :all-statistics)
 (get-info :version)
 (set-option :rlimit 30000000)
 (check-sat)
 (set-option :rlimit 0)
 (get-info :all-statistics)
(pop)
